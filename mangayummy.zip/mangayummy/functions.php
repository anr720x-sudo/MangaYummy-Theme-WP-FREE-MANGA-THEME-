<?php
/**
 * MangaYummy WordPress Theme
 * Copyright (C) 2026 MangaYummy (buymeacoffee.com/mangayummy9)
 * Licensed under GPL-2.0-or-later
 */

/**
 * MangaYummy Theme Functions
 */

// ===== INCLUDE CHAPTER IMAGE AUTOGENERATE (admin-only assets) =====
if (file_exists(get_template_directory() . '/inc/chapter-autogenerate.php')) {
    require_once get_template_directory() . '/inc/chapter-autogenerate.php';
}

// ===== INCLUDE LEGACY AJAX ALIASES (temporary, for migration) =====
if (file_exists(get_template_directory() . '/inc/mangayummy-ajax-aliases.php')) {
    require_once get_template_directory() . '/inc/mangayummy-ajax-aliases.php';
}

// ===== INCLUDE ONE CLICK DEMO IMPORT INTEGRATION =====

// ===== INCLUDE DONATION NOTICE (admin) =====
if (is_admin() && file_exists(get_template_directory() . '/inc/mangayummy-donate.php')) {
    require_once get_template_directory() . '/inc/mangayummy-donate.php';
}

// ===== INCLUDE RECALCULATE BOOKMARKS (admin tool) =====
if (is_admin() && file_exists(get_template_directory() . '/recalculate-bookmarks.php')) {
    require_once get_template_directory() . '/recalculate-bookmarks.php';
}

// ===== INCLUDE WEBP CONVERTER TOOL (admin) =====
if (is_admin() && file_exists(get_template_directory() . '/tools-webp-convert.php')) {
    require_once get_template_directory() . '/tools-webp-convert.php';
}

// ===== CLEAN ADMIN FOOTER TEXT =====
// Prevent default WP admin footer text/version from showing on custom admin pages.
if (is_admin()) {
    add_filter('admin_footer_text', '__return_empty_string', 999);
    add_filter('update_footer', '__return_empty_string', 999);
}

// ===== Content-Security-Policy header (theme) =====
// Adds a single CSP header via the send_headers hook. Does not use Cloudflare or plugins.
if (!function_exists('mangayummy_send_csp_header')) {
    function mangayummy_send_csp_header() {
        // If headers already sent, abort
        if (headers_sent()) {
            return;
        }

        // Avoid adding if another CSP header already exists
        foreach (headers_list() as $h) {
            if (stripos($h, 'Content-Security-Policy:') === 0) {
                return;
            }
        }

        $policy = "default-src 'self'; script-src 'self' https://challenges.cloudflare.com https://www.googletagmanager.com https://www.google-analytics.com https://googleads.g.doubleclick.net https://pagead2.googlesyndication.com 'unsafe-inline'; connect-src 'self' https://challenges.cloudflare.com https://www.google-analytics.com https://stats.g.doubleclick.net https://googleads.g.doubleclick.net https://pagead2.googlesyndication.com https://cdn.jsdelivr.net; img-src 'self' data: https://www.google-analytics.com https://stats.g.doubleclick.net; frame-src 'self' https://www.youtube.com https://www.youtube-nocookie.com https://challenges.cloudflare.com;";

        // Send header (will be present once). Use header() only when safe.
        header('Content-Security-Policy: ' . $policy);
    }
    add_action('send_headers', 'mangayummy_send_csp_header', 10);
}

// ===== NO-CACHE HEADERS FOR HOME + AUTH MODAL PAGES =====
if (!function_exists('mangayummy_send_no_cache_headers')) {
    function mangayummy_send_no_cache_headers() {
        // If headers already sent, abort
        if (headers_sent()) {
            return;
        }

        // Keep anonymous homepage cacheable; force no-cache elsewhere or for logged-in users.
        if ((is_front_page() && !is_user_logged_in()) === false) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
        }
    }
    add_action('send_headers', 'mangayummy_send_no_cache_headers', 9);
}

// ===== CREATE NOTIFICATIONS TABLE ON THEME LOAD =====
function mangayummy_create_notifications_table() {
    // Skip if already created (performance optimization)
    if (get_option('mangayummy_notifications_table_created')) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'comment_notifications';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT NOT NULL,
        comment_id BIGINT NOT NULL,
        reply_id BIGINT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX (user_id),
        INDEX (is_read)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $result = dbDelta($sql);

    // Add type column if it doesn't exist (for mentions support)
    $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE 'type'");
    if (empty($column_exists)) {
        $wpdb->query("ALTER TABLE $table_name ADD COLUMN type VARCHAR(20) DEFAULT 'reply' AFTER reply_id");
    }

    // Mark as created to skip on future page loads
    update_option('mangayummy_notifications_table_created', true);
}
add_action('after_switch_theme', 'mangayummy_create_notifications_table');
// Run once on init if not already created
add_action('init', 'mangayummy_create_notifications_table');

// ===== CREATE MANGA FOLLOW / NOTIFICATIONS TABLES =====
function mangayummy_create_manga_follow_tables() {
    // Skip if already created (performance optimization)
    if (get_option('mangayummy_manga_follow_tables_created')) {
        return;
    }

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $table_follows = $wpdb->prefix . 'manga_follows';
    $table_notifications = $wpdb->prefix . 'manga_notifications';

    $sql_follows = "CREATE TABLE $table_follows (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        manga_id BIGINT(20) UNSIGNED NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_manga_unique (user_id, manga_id),
        KEY user_id (user_id),
        KEY manga_id (manga_id)
    ) $charset_collate;";

    $sql_notifications = "CREATE TABLE $table_notifications (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        manga_id BIGINT(20) UNSIGNED NOT NULL,
        chapter_id BIGINT(20) UNSIGNED NOT NULL,
        chapter_title VARCHAR(255),
        chapter_number VARCHAR(50),
        is_read TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY manga_id (manga_id),
        KEY chapter_id (chapter_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_follows);
    dbDelta($sql_notifications);

    // Ensure unique index exists on notifications for user+chapter (avoid duplicates)
    $index_exists = $wpdb->get_results("SHOW INDEX FROM $table_notifications WHERE Key_name = 'user_chapter_unique'");
    if (empty($index_exists)) {
        $wpdb->query("ALTER TABLE $table_notifications ADD UNIQUE KEY user_chapter_unique (user_id, chapter_id)");
    }

    // Mark as created to skip on future page loads
    update_option('mangayummy_manga_follow_tables_created', true);
}
add_action('after_switch_theme', 'mangayummy_create_manga_follow_tables');
add_action('init', 'mangayummy_create_manga_follow_tables');

// Clean up duplicate notifications created before unique key existed
function mangayummy_cleanup_duplicate_chapter_notifications() {
    // Run only once (so it doesn't run on every page load)
    if (get_option('mangayummy_cleaned_duplicate_chapter_notifications')) {
        return;
    }

    global $wpdb;
    $table_notifications = $wpdb->prefix . 'manga_notifications';

    // Delete duplicates keeping the lowest ID
    $wpdb->query(
        "DELETE n1 FROM $table_notifications n1
         INNER JOIN $table_notifications n2
         WHERE n1.user_id = n2.user_id
           AND n1.chapter_id = n2.chapter_id
           AND n1.id > n2.id"
    );

    update_option('mangayummy_cleaned_duplicate_chapter_notifications', true);
}
add_action('init', 'mangayummy_cleanup_duplicate_chapter_notifications');

// ===== ENSURE PROFILE PAGE EXISTS =====
function mangayummy_ensure_profile_page() {
    // Skip if already checked (performance optimization)
    if (get_option('mangayummy_profile_page_checked')) {
        return;
    }
    
    $query = new WP_Query([
        'post_type' => 'page',
        'name' => 'profile',
        'posts_per_page' => 1,
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    ]);
    $profile_page = $query->posts ? $query->posts[0] : null;
    
    // Mark as checked regardless of result
    update_option('mangayummy_profile_page_checked', true);
    
    if (!$profile_page) {
        $page_id = wp_insert_post(array(
            'post_title'    => 'Profile',
            'post_name'     => 'profile',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_template' => 'page-profile.php'
        ));
    }
}
add_action('init', 'mangayummy_ensure_profile_page');

/**
 * Prefetch latest chapters for multiple manga IDs in one query.
 *
 * This avoids running a WP_Query per manga when the cache is missing.
 * It returns an array indexed by manga_id containing an array of up to 2 chapter WP_Posts.
 *
 * @param int[] $manga_ids
 * @return array<int, WP_Post[]>
 */
function mangayummy_prefetch_latest_chapters(array $manga_ids) {
    $manga_ids = array_filter(array_map('intval', $manga_ids));
    $manga_ids = array_values(array_unique($manga_ids));
    if (empty($manga_ids)) {
        return [];
    }

    $result = [];
    $missing = [];

    foreach ($manga_ids as $mid) {
        $cache_key = 'manga_latest_chapters_' . $mid;
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            $result[$mid] = $cached;
        } else {
            $missing[] = $mid;
        }
    }

    if (empty($missing)) {
        return $result;
    }

    global $wpdb;

    // Query the latest 2 chapters per manga in one shot
    $placeholders = implode(',', array_fill(0, count($missing), '%d'));
    $sql = "
        SELECT p.ID AS chapter_id,
               CAST(pm.meta_value AS UNSIGNED) AS manga_id,
               CAST(pm2.meta_value AS DECIMAL(10,4)) AS chapter_num,
               p.post_date
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_manga_id'
        LEFT JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = p.ID AND pm2.meta_key = '_chapter_number'
        WHERE p.post_type = 'chapter'
          AND p.post_status = 'publish'
          AND pm.meta_value IN ($placeholders)
        ORDER BY manga_id ASC, chapter_num DESC, p.post_date DESC
    ";

    $prepare_args = array_merge([$sql], $missing);
    $rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], $prepare_args));

    // Keep only the first two chapters per manga_id
    $selected = [];
    $current_mid = null;
    $count = 0;
    foreach ($rows as $row) {
        $mid = intval($row->manga_id);
        if ($current_mid !== $mid) {
            $current_mid = $mid;
            $count = 0;
        }
        if ($count >= 2) {
            continue;
        }
        $selected[$mid][] = intval($row->chapter_id);
        $count++;
    }

    // Load all chapter posts in a single query to avoid N queries
    $all_chapter_ids = [];
    foreach ($selected as $ids) {
        $all_chapter_ids = array_merge($all_chapter_ids, $ids);
    }
    $all_chapter_ids = array_values(array_unique($all_chapter_ids));

    $posts_by_id = [];
    if (!empty($all_chapter_ids)) {
        $posts = get_posts([
            'post_type' => 'chapter',
            'post__in' => $all_chapter_ids,
            'numberposts' => -1,
            'orderby' => 'post__in',
            'order' => 'ASC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);
        foreach ($posts as $p) {
            $posts_by_id[$p->ID] = $p;
        }
    }

    foreach ($missing as $mid) {
        $chapters = [];
        if (isset($selected[$mid])) {
            foreach ($selected[$mid] as $cid) {
                if (isset($posts_by_id[$cid])) {
                    $chapters[] = $posts_by_id[$cid];
                }
            }
        }
        $result[$mid] = $chapters;
        set_transient('manga_latest_chapters_' . $mid, $chapters, 5 * MINUTE_IN_SECONDS);
    }

    return $result;
}

/**
 * Prefetch ratings for multiple manga IDs.
 *
 * Returns an array indexed by manga_id with keys:
 *  - average (float)
 *  - count (int)
 *
 * Uses a transient per manga for 10 minutes.
 *
 * @param int[] $manga_ids
 * @return array<int, array{average: float, count: int}>
 */
function mangayummy_prefetch_ratings(array $manga_ids) {
    $manga_ids = array_filter(array_map('intval', $manga_ids));
    $manga_ids = array_values(array_unique($manga_ids));
    if (empty($manga_ids)) {
        return [];
    }

    $result = [];
    $missing = [];
    foreach ($manga_ids as $mid) {
        $cache_key = 'mangayummy_rating_' . $mid;
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            $result[$mid] = $cached;
        } else {
            $missing[] = $mid;
        }
    }

    if (!empty($missing)) {
        global $wpdb;
        $placeholders = implode(',', array_fill(0, count($missing), '%d'));
        $sql = "
            SELECT post_id,
                   MAX(CASE WHEN meta_key = '_rating_total' THEN meta_value END) AS rating_total,
                   MAX(CASE WHEN meta_key = '_rating_count' THEN meta_value END) AS rating_count,
                   MAX(CASE WHEN meta_key = '_rating_avg' THEN meta_value END) AS rating_avg
            FROM {$wpdb->postmeta}
            WHERE post_id IN ($placeholders)
              AND meta_key IN ('_rating_total', '_rating_count', '_rating_avg')
            GROUP BY post_id
        ";
        $prepare_args = array_merge([$sql], $missing);
        $rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], $prepare_args));

        $ratings = [];
        foreach ($rows as $row) {
            $mid = intval($row->post_id);
            $avg_meta = floatval($row->rating_avg);
            $total = floatval($row->rating_total);
            $count = intval($row->rating_count);
            if ($avg_meta > 0) {
                $average = round($avg_meta, 1);
            } elseif ($count > 0) {
                $average = round($total / $count, 1);
            } else {
                $average = 0;
            }
            $ratings[$mid] = [
                'average' => $average,
                'count' => $count,
            ];
        }

        foreach ($missing as $mid) {
            $rating = $ratings[$mid] ?? ['average' => 0, 'count' => 0];
            $result[$mid] = $rating;
            set_transient('mangayummy_rating_' . $mid, $rating, 10 * MINUTE_IN_SECONDS);
        }
    }

    return $result;
}

/**
 * Prefetch genres (terms) for multiple manga IDs in one query.
 * Returns an array [manga_id => array of term objects].
 *
 * @param int[] $manga_ids
 * @return array<int, WP_Term[]>
 */
function mangayummy_prefetch_manga_genres(array $manga_ids) {
    $manga_ids = array_filter(array_map('intval', $manga_ids));
    $manga_ids = array_values(array_unique($manga_ids));
    if (empty($manga_ids)) {
        return [];
    }

    global $wpdb;
    $placeholders = implode(',', array_fill(0, count($manga_ids), '%d'));
    $sql = "
        SELECT tr.object_id AS manga_id, t.term_id
        FROM {$wpdb->term_relationships} tr
        INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
        INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
        WHERE tt.taxonomy = 'genre'
          AND tr.object_id IN ($placeholders)
    ";

    $prepare_args = array_merge([$sql], $manga_ids);
    $rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], $prepare_args));

    $term_ids = [];
    $mapping = [];
    foreach ($rows as $row) {
        $mid = intval($row->manga_id);
        $tid = intval($row->term_id);
        $mapping[$mid][] = $tid;
        $term_ids[] = $tid;
    }

    if (empty($term_ids)) {
        return [];
    }

    $term_ids = array_values(array_unique($term_ids));
    $terms = get_terms([
        'taxonomy' => 'genre',
        'include' => $term_ids,
        'hide_empty' => false,
    ]);

    $terms_by_id = [];
    foreach ($terms as $term) {
        $terms_by_id[$term->term_id] = $term;
    }

    $result = [];
    foreach ($mapping as $mid => $tids) {
        $result[$mid] = [];
        foreach ($tids as $tid) {
            if (isset($terms_by_id[$tid])) {
                $result[$mid][] = $terms_by_id[$tid];
            }
        }
    }

    return $result;
}

/**
 * Prefetch post meta for many posts in one query.
 * Returns an array [post_id => [meta_key => meta_value]].
 * Uses a per-post transient cache (10 minutes).
 *
 * @param int[] $post_ids
 * @param string[] $meta_keys
 * @return array<int, array<string, string>>
 */
function mangayummy_prefetch_post_meta_bulk(array $post_ids, array $meta_keys) {
    $post_ids = array_filter(array_map('intval', $post_ids));
    $post_ids = array_values(array_unique($post_ids));
    $meta_keys = array_filter(array_map('strval', $meta_keys));
    $meta_keys = array_values(array_unique($meta_keys));

    if (empty($post_ids) || empty($meta_keys)) {
        return [];
    }

    $result = [];
    $missing = [];
    $needs_translator_user = in_array('_translator_user', $meta_keys, true);

    foreach ($post_ids as $pid) {
        $cache_key = 'mangayummy_postmeta_bulk_' . $pid;
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            if ($needs_translator_user) {
                unset($cached['_translator_user']);
                $result[$pid] = $cached;
                $missing[] = $pid;
            } else {
                $result[$pid] = $cached;
            }
        } else {
            $missing[] = $pid;
        }
    }

    if (!empty($missing)) {
        global $wpdb;
        $pid_placeholders = implode(',', array_fill(0, count($missing), '%d'));
        $key_placeholders = implode(',', array_fill(0, count($meta_keys), '%s'));

        $sql = "
            SELECT post_id, meta_key, meta_value
            FROM {$wpdb->postmeta}
            WHERE post_id IN ($pid_placeholders)
              AND meta_key IN ($key_placeholders)
        ";

        $prepare_args = array_merge([$sql], $missing, $meta_keys);
        $rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], $prepare_args));

        $mapping = [];
        foreach ($rows as $row) {
            $pid = intval($row->post_id);
            if (!isset($mapping[$pid])) {
                $mapping[$pid] = [];
            }
            $mapping[$pid][$row->meta_key] = $row->meta_value;
        }

        $cache_expiration = $needs_translator_user ? MINUTE_IN_SECONDS : 10 * MINUTE_IN_SECONDS;

        foreach ($missing as $pid) {
            $data = $mapping[$pid] ?? [];
            foreach ($meta_keys as $key) {
                if (!isset($data[$key]) && $key !== '_translator_user') {
                    $data[$key] = '';
                }
            }

            if ($needs_translator_user) {
                $cache_data = $data;
                unset($cache_data['_translator_user']);
                set_transient('mangayummy_postmeta_bulk_' . $pid, $cache_data, 6 * MONTH_IN_SECONDS);
            } else {
                set_transient('mangayummy_postmeta_bulk_' . $pid, $data, $cache_expiration);
            }

            if (isset($result[$pid]) && is_array($result[$pid])) {
                $result[$pid] = array_merge($result[$pid], $data);
            } else {
                $result[$pid] = $data;
            }
        }
    }

    return $result;
}

// Ensure manga page exists
function mangayummy_ensure_manga_page() {
    $query = new WP_Query([
        'post_type' => 'page',
        'post_status' => 'publish',
        'name' => 'manga',
        'posts_per_page' => 1,
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    ]);
    $manga_page = $query->posts ? $query->posts[0] : null;
    
    if (!$manga_page) {
        $page_id = wp_insert_post(array(
            'post_title'    => 'Manga',
            'post_name'     => 'manga',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page'
        ));
        if ($page_id) {
            update_post_meta($page_id, '_wp_page_template', 'page-manga.php');
        }
    }
}
add_action('init', 'mangayummy_ensure_manga_page');

// Ensure recomandate page exists
function mangayummy_ensure_recomandate_page() {
    $query = new WP_Query([
        'post_type' => 'page',
        'post_status' => 'publish',
        'name' => 'recommended',
        'posts_per_page' => 1,
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    ]);
    $recomandate_page = $query->posts ? $query->posts[0] : null;
    
    if (!$recomandate_page) {
        $page_id = wp_insert_post(array(
            'post_title'    => 'Recommended',
            'post_name'     => 'recommended',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page'
        ));
        if ($page_id) {
            update_post_meta($page_id, '_wp_page_template', 'page-recomandate.php');
        }
    }
}
add_action('init', 'mangayummy_ensure_recomandate_page');

// ===== CREATE PRIVATE MESSAGES TABLE =====
function mangayummy_create_messages_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'private_messages';
    $charset_collate = $wpdb->get_charset_collate();

    // Check if table already exists (avoid unnecessary operations)
    $query_check = $wpdb->prepare(
        "SELECT 1 FROM information_schema.tables WHERE table_schema = %s AND table_name = %s LIMIT 1",
        DB_NAME,
        $table_name
    );
    $table_exists = $wpdb->get_var($query_check);
    
    if ($table_exists) {
        return; // Table exists, skip
    }

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        sender_id BIGINT NOT NULL,
        receiver_id BIGINT NOT NULL,
        message LONGTEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX (receiver_id),
        INDEX (is_read),
        INDEX (created_at)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
// Only run on theme activation, not on every init (production optimized)
add_action('after_switch_theme', 'mangayummy_create_messages_table');

// ===== CHAPTER NUMBER HELPER =====
/**
 * Retrieve the chapter number for a chapter post.
 * Priority:
 *  - meta '_chapter_number' (canonical)
 *  - extract from post_name in format 'capitolul-{num}'
 * Returns normalized number as string (e.g. '12' or '12.5') or null if not found.
 */

/**
 * Normalize a user-supplied or API-derived chapter number string.
 *
 * Trims whitespace, converts commas to dots, and removes trailing zeroes/dots
 * so that "14.50" and "14.5" are treated identically.  Returns an empty
 * string if the input is blank after trimming.
 *
 * @param mixed $num
 * @return string
 */
if (!function_exists('mangayummy_normalize_chapter_number')) {
    function mangayummy_normalize_chapter_number($num) {
        $num = trim((string)$num);
        if ($num === '') {
            return '';
        }
        $num = str_replace(',', '.', $num);
        if (strpos($num, '.') !== false) {
            $num = rtrim($num, '0');
            $num = rtrim($num, '.');
        }
        return $num;
    }
}

function mangayummy_get_chapter_number($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }

    $cache_key = 'chapter_number_' . intval($post_id);
    $cached = wp_cache_get($cache_key, 'mangayummy');
    if ($cached !== false) {
        return $cached;
    }

    // Prefer explicit meta key '_chapter_number' only. Treat '0' as valid.
    $keys = array('_chapter_number');
    $result = null;
    foreach ($keys as $k) {
        $v = get_post_meta($post_id, $k, true);
        // use isset check to accept '0' and non-empty strings
        if (isset($v) && $v !== '') {
            $v = trim((string)$v);
            if ($v === '') continue;
            // Normalize comma decimal separator
            $v = str_replace(',', '.', $v);
            if (preg_match('/^\d+(?:\.\d+)?$/', $v)) {
                $result = $v;
            } else {
                // If meta exists but not numeric, skip (do not return ID)
                $result = null;
            }
            break;
        }
    }

    if ($result === null) {
        // Fallback: extract from post_name like 'capitolul-12' or 'capitolul-12-5'
        $post_name = get_post_field('post_name', $post_id);
        if ($post_name) {
            if (preg_match('/^capitolul-(\d+(?:[-\.]\d+)?)$/', $post_name, $m)) {
                $num = $m[1];
                // normalize dash decimal to dot
                $num = str_replace('-', '.', $num);
                if (preg_match('/^\d+(?:\.\d+)?$/', $num)) {
                    $result = $num;
                }
            }
        }
    }

    wp_cache_set($cache_key, $result, 'mangayummy');
    return $result;
}

// Invalidate chapter number cache when a chapter is saved/updated
add_action('save_post_chapter', function($post_id) {
    wp_cache_delete('chapter_number_' . intval($post_id), 'mangayummy');
});

// One-off admin endpoint to fix a chapter's slug to match its chapter number.
add_action('admin_init', function() {
    if (!isset($_GET['mangayummy_fix_chapter_slug']) || !isset($_GET['post'])) {
        return;
    }

    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized', 'Unauthorized', array('response' => 403));
    }

    $post_id = intval($_GET['post']);
    if ($post_id <= 0) {
        wp_die(esc_html__('Invalid post id', 'mangayummy'), 'Error', array('response' => 400));
    }

    $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
    if (!$nonce || !wp_verify_nonce($nonce, 'mangayummy_fix_chapter_slug_' . $post_id)) {
        wp_die(esc_html__('Invalid security token', 'mangayummy'), 'Unauthorized', array('response' => 403));
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'chapter') {
        wp_die(esc_html__('Post is not a chapter', 'mangayummy'), 'Error', array('response' => 400));
    }

    // Use canonical getter which treats '0' as valid
    $num = mangayummy_get_chapter_number($post_id);
    if ($num === null || $num === '') {
        wp_redirect(add_query_arg('mangayummy_fix_done', 'no_number', wp_get_referer() ?: admin_url('edit.php')));
        exit;
    }

    $slug_num = mangayummy_normalize_chapter_number($num);
    $new_slug = sanitize_title('capitolul-' . $slug_num);

    // DO NOT update post_name directly - let save_post hook handle it
    // Instead, trigger save_post by updating a meta field that will cause re-save
    $updated = false;
    // The save_post hook will handle slug setting now

    // Ensure Yoast meta is set
    update_post_meta($post_id, '_yoast_wpseo_slug', $new_slug);

    wp_redirect(add_query_arg('mangayummy_fix_done', $updated ? 'updated' : 'no_change', wp_get_referer() ?: admin_url('post.php?post=' . $post_id . '&action=edit')));
    exit;
});

// Show simple admin notice after running the one-off fix
add_action('admin_notices', function() {
    if (!isset($_GET['mangayummy_fix_done'])) return;
    $val = sanitize_text_field($_GET['mangayummy_fix_done']);
    if ($val === 'updated') {
        echo '<div class="notice notice-success inline"><p>Chapter slug updated to match chapter number.</p></div>';
    } elseif ($val === 'no_change') {
        echo '<div class="notice notice-info inline"><p>No change needed; slug already matched chapter number.</p></div>';
    } elseif ($val === 'no_number') {
        echo '<div class="notice notice-warning inline"><p>Chapter number missing; cannot update slug.</p></div>';
    }
});

// TIMEZONE: Moved to wp-config.php to be set BEFORE WordPress loads
// Setting timezone here causes WordPress Site Health warning

function mangayummy_debug_log($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
    }
}

// ===== CONTENT SECURITY POLICY (to silence Cloudflare fallback warnings) =====
function mangayummy_send_csp_headers() {
    // Ensure we replace any existing CSP header to avoid duplicates
    header_remove('Content-Security-Policy');
    header(
        "Content-Security-Policy: " .
        "default-src 'self'; " .
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://challenges.cloudflare.com https://static.cloudflareinsights.com https://www.googletagmanager.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com; " .
        "script-src-elem 'self' 'unsafe-inline' https://challenges.cloudflare.com https://static.cloudflareinsights.com https://www.googletagmanager.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com; " .
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com https://fonts.googleapis.com; " .
        "font-src 'self' data: https://fonts.gstatic.com https://cdnjs.cloudflare.com https://unpkg.com; " .
        "img-src 'self' data: https:; " .
        "connect-src 'self' https://challenges.cloudflare.com https://www.google-analytics.com https://cdn.jsdelivr.net https://discord.com; " .
        "frame-src 'self' https://challenges.cloudflare.com https://discord.com https://www.youtube.com https://www.youtube-nocookie.com; " .
        "form-action 'self' https://discord.com; " .
        "worker-src 'self' blob:;",
        true
    );
}
add_action('send_headers', 'mangayummy_send_csp_headers', 0);

// Relax CSP connect-src to allow fetch from common CDNs
function mangayummy_relax_csp_for_externals() {
    // Remove the strict CSP temporarily to check headers (this is a workaround for debugging)
    // In production, we rely on img-src 'self' data: https:; which already allows img tag loads
    // Fetch API can still be blocked by stricter connect-src if needed for future use
}
add_action('send_headers', 'mangayummy_relax_csp_for_externals', 1);

// ===== AUTO FOCUS KEYPHRASE FOR MANGA (Yoast/Rank Math) =====
/**
 * Automatically populate SEO "Focus keyphrase" when saving manga posts.
 * Targets multiple plugin meta keys (Yoast, Rank Math) but only fills when empty.
 */
function mangayummy_auto_focus_keyphrase($post_id, $post, $update) {
    // Only for 'manga' post type
    if ($post->post_type !== 'manga') return;

    // Skip autosave, revisions, or insufficient caps
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!current_user_can('edit_post', $post_id)) return;

    // Build a concise Romanian keyphrase
    $title = get_the_title($post_id);
    $title = is_string($title) ? trim($title) : '';
    if ($title === '') return;

    // Avoid duplicate 'manga' word if present in title
    $contains_manga = (stripos($title, 'manga') !== false);
    $keyphrase = $contains_manga ? $title : ($title . ' manga');
    $keyphrase = sanitize_text_field($keyphrase);

    // Known meta keys across popular SEO plugins
    $keys = array(
        '_yoast_wpseo_focuskw',          // Yoast (legacy/common)
        'yoast_wpseo_focuskw',           // Yoast (alt)
        'yoast_wpseo_focus_keyword',     // Yoast (some versions)
        'rank_math_focus_keyword'        // Rank Math
    );

    foreach ($keys as $meta_key) {
        $existing = get_post_meta($post_id, $meta_key, true);
        if (empty($existing)) {
            update_post_meta($post_id, $meta_key, $keyphrase);
        }
    }
}
add_action('save_post_manga', 'mangayummy_auto_focus_keyphrase', 10, 3);

/**
 * Auto-fill Yoast/RankMath focus keyphrase for chapter posts.
 * Format: "{Manga Title} – Capitolul {number}" (no site name)
 * Only fills when focus meta is empty so user overrides are preserved.
 */
function mangayummy_auto_focus_keyphrase_chapter($post_id, $post, $update) {
    // Basic checks
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (!$post || $post->post_type !== 'chapter') return;

    // Get manga title from meta or parent
    $manga_id = get_post_meta($post_id, '_manga_id', true);
    if (empty($manga_id)) {
        $manga_id = $post->post_parent;
    }
    $manga_title = '';
    if ($manga_id) {
        $manga = get_post($manga_id);
        if ($manga) $manga_title = $manga->post_title;
    }

    if (!$manga_title) {
        // fallback to current post title if manga not found
        $manga_title = get_the_title($post_id);
    }

    // Get chapter number (treat 0 as valid)
    if (function_exists('mangayummy_get_chapter_number')) {
        $ch_num = mangayummy_get_chapter_number($post_id);
    } else {
        $ch_num = get_post_meta($post_id, '_chapter_number', true);
    }

    if ($ch_num === null || $ch_num === '') return;

    $ch_display = $ch_num;
    // normalize decimal dash/dot to dot for display
    $ch_display = str_replace('-', '.', (string)$ch_display);

    // Format requested: no dash and lowercase 'capitolul'
    $keyphrase = trim($manga_title) . ' capitolul ' . $ch_display;
    $keyphrase = sanitize_text_field($keyphrase);

    // Broad set of meta keys used by Yoast / Rank Math across versions
    $keys = array(
        '_yoast_wpseo_focuskw',          // Yoast (common)
        'yoast_wpseo_focuskw',           // Yoast alt
        'yoast_wpseo_focus_keyword',     // Yoast variant
        '_yoast_wpseo_primary_keyword',  // Yoast primary keyword meta
        'yoast_focuskw',                 // older Yoast key
        'wpseo_focuskw',                 // alternative key
        'focus_keyword',                 // generic/key plugin
        'rank_math_focus_keyword'        // Rank Math
    );

    foreach ($keys as $meta_key) {
        $existing = get_post_meta($post_id, $meta_key, true);
        // Treat empty, null or whitespace-only values as empty
        if (!is_string($existing) || trim($existing) === '') {
            update_post_meta($post_id, $meta_key, $keyphrase);
        }
    }
}
// Run after other save handlers to ensure meta inputs are available
add_action('save_post_chapter', 'mangayummy_auto_focus_keyphrase_chapter', 100, 3);

// Invalidate front-page "recent chapters" transient when chapters change
function mangayummy_invalidate_frontpage_recent_chapters($post_id, $post = null, $update = null) {
    if (get_post_type($post_id) !== 'chapter') return;
    // Remove cached IDs and HTML so front page regenerates quickly on next load
    delete_transient('mangayummy_frontpage_recent_chapter_ids_v2');
    delete_transient('mangayummy_latest_chapters_html');
}
add_action('save_post_chapter', 'mangayummy_invalidate_frontpage_recent_chapters', 10, 3);
add_action('deleted_post', 'mangayummy_invalidate_frontpage_recent_chapters');
add_action('trashed_post', 'mangayummy_invalidate_frontpage_recent_chapters');

// ===== GUEST ID GENERATION =====
/**
 * Generate a unique numeric ID for guest users based on their IP address
 * Returns a number 1-9999 derived from IP hash
 * @return int Unique guest ID
 */
function mangayummy_get_guest_id() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : 'guest';
    $ip_hash = md5($ip);
    // Convert first 4 chars of hex hash to decimal, then mod 9999 to get 1-9999
    $guest_id = (hexdec(substr($ip_hash, 0, 4)) % 9999) + 1;
    return $guest_id;
}

// ===== AVATAR SYSTEM: DISABLE GRAVATAR COMPLETELY =====
add_filter('option_show_avatars', '__return_false');
add_filter('option_avatar_default', '__return_false');

// ===== CLASSIC AUTHENTICATION HANDLERS =====
// Username/password login and registration via AJAX
require_once get_template_directory() . '/inc/auth-login.php';
require_once get_template_directory() . '/inc/auth-register.php';
require_once get_template_directory() . '/inc/auth-password.php';
require_once get_template_directory() . '/inc/auth-discord.php';
// MangaDex client (centralized caching + background refresh)
// MangaDex client removed per user request
// legacy MangaDex/MangaTerra sync helpers removed; no longer used

// ===== AJAX: Get Community Users =====
add_action('wp_ajax_mangayummy_get_community_users', function() {
    $page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
    $per_page = isset($_POST['per_page']) ? min(100, max(10, intval($_POST['per_page']))) : 50;
    
    $args = array(
        'number'  => $per_page,
        'offset'  => ($page - 1) * $per_page,
        'orderby' => 'registered',
        'order'   => 'DESC',
        'meta_query' => [
            'relation' => 'OR',
            [
                'key' => 'email_verified',
                'compare' => 'NOT EXISTS'
            ],
            [
                'key' => 'email_verified',
                'value' => '1',
                'compare' => '='
            ]
        ]
    );
    
    $users = get_users($args);
    $user_data = array();
    
    foreach ($users as $user) {
        // Get user metadata
        $level = intval(get_user_meta($user->ID, 'user_level', true)) ?: 1;
        $group = get_user_meta($user->ID, 'user_group', true) ?: 'Cititor';
        
        // Get avatar
        $avatar_url = get_user_meta($user->ID, 'user_avatar', true);
        if (!$avatar_url) {
            $avatar_url = get_avatar_url($user->ID, array('size' => 80));
        }
        
        $user_data[] = array(
            'id'         => $user->ID,
            'name'       => sanitize_text_field($user->display_name ?: $user->user_login),
            'level'      => $level,
            'group'      => sanitize_text_field($group),
            'avatar'     => esc_url($avatar_url),
            'registered' => $user->user_registered
        );
    }
    
    wp_send_json_success(array(
        'users' => $user_data,
        'count' => count($user_data)
    ));
});
add_action('wp_ajax_nopriv_mangayummy_get_community_users', function() {
    // Allow non-logged-in users to view community
    do_action('wp_ajax_mangayummy_get_community_users');
});

// ===== AJAX: Logout Handler =====
add_action('wp_ajax_mangayummy_logout', function() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    // Logout the user
    wp_logout();
    
    // Send success response
    wp_send_json_success(array(
        'message' => 'Logged out successfully',
        'redirect' => home_url('/')
    ));
});

// Allow non-logged-in users to call logout (no harm if already logged out)
add_action('wp_ajax_nopriv_mangayummy_logout', function() {
    wp_send_json_success(array(
        'message' => 'Logged out successfully',
        'redirect' => home_url('/')
    ));
});

// ===== MANGA REPORT / SUGGEST EDITS =====
add_action('wp_ajax_mangayummy_submit_report', function() {
    check_ajax_referer('mangayummy_report_nonce', 'nonce');

    $manga_id = intval($_POST['manga_id'] ?? 0);
    $title = sanitize_text_field($_POST['title'] ?? '');
    $alternative_titles = sanitize_textarea_field($_POST['alternative_titles'] ?? '');
    $genres = sanitize_text_field($_POST['genres'] ?? '');
    $status = sanitize_text_field($_POST['status'] ?? '');
    $type = sanitize_text_field($_POST['type'] ?? '');
    $author = sanitize_text_field($_POST['author'] ?? '');
    $artist = sanitize_text_field($_POST['artist'] ?? '');
    $year = preg_replace('/[^0-9]/', '', sanitize_text_field($_POST['year'] ?? ''));
    $final_chapter = sanitize_text_field($_POST['final_chapter'] ?? '');
    $translator_ro = sanitize_text_field($_POST['translator_ro'] ?? '');
    $description = sanitize_textarea_field($_POST['description'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');
    $changed_fields_raw = wp_unslash($_POST['changed_fields'] ?? '');
    $changed_fields = json_decode($changed_fields_raw, true);
    if (!is_array($changed_fields)) {
        $changed_fields = array();
    }

    if (!$manga_id || !get_post($manga_id)) {
        wp_send_json_error(__('Manga nu gasita', 'mangayummy'));
    }

    // Get current user info
    $user_id = get_current_user_id();
    $user_name = $user_id ? get_user_by('ID', $user_id)->display_name : 'Anonim';
    $user_email = $user_id ? get_user_by('ID', $user_id)->user_email : '';

    $normalize_report_value = static function($value) {
        $value = (string) $value;
        $value = wp_strip_all_tags($value);
        $value = preg_replace('/\s+/', ' ', $value);
        return trim($value);
    };

    $meta_alternative_titles = get_post_meta($manga_id, '_alternative_titles', true);
    if (is_array($meta_alternative_titles)) {
        $meta_alternative_titles = implode(', ', array_filter(array_map('trim', $meta_alternative_titles)));
    }

    $genre_names = wp_get_post_terms($manga_id, 'genre', array('fields' => 'names'));
    $current_genres = is_array($genre_names) ? implode(', ', $genre_names) : '';

    $translator_meta = get_post_meta($manga_id, '_translator_user', true);
    $current_translator = '';
    if (is_numeric($translator_meta)) {
        $translator_user = get_user_by('ID', intval($translator_meta));
        if ($translator_user) {
            $current_translator = $translator_user->display_name ?: $translator_user->user_login;
        }
    } elseif (is_string($translator_meta)) {
        $current_translator = $translator_meta;
    }

    $current_values = array(
        'title' => get_the_title($manga_id),
        'alternative_titles' => (string) $meta_alternative_titles,
        'genres' => (string) $current_genres,
        'status' => (string) get_post_meta($manga_id, '_status', true),
        'type' => (string) get_post_meta($manga_id, '_manga_type', true),
        'author' => (string) get_post_meta($manga_id, '_author', true),
        'artist' => (string) get_post_meta($manga_id, '_artist', true),
        'year' => (string) get_post_meta($manga_id, '_release_year', true),
        'final_chapter' => (string) get_post_meta($manga_id, '_final_chapter', true),
        'translator_ro' => (string) $current_translator,
        'description' => (string) get_post_field('post_content', $manga_id),
    );

    $submitted_values = array(
        'title' => $title,
        'alternative_titles' => $alternative_titles,
        'genres' => $genres,
        'status' => $status,
        'type' => $type,
        'author' => $author,
        'artist' => $artist,
        'year' => (string) $year,
        'final_chapter' => $final_chapter,
        'translator_ro' => $translator_ro,
        'description' => $description,
    );

    $field_labels = array(
        'title' => 'Titlu',
        'alternative_titles' => 'Titluri alternative',
        'genres' => 'Genuri',
        'status' => 'Status',
        'type' => 'Tip',
        'author' => 'Autor',
        'artist' => 'Artist',
        'year' => 'An',
        'final_chapter' => 'Capitol final',
        'translator_ro' => 'Traducerea in romana',
        'description' => 'Description',
    );

    $allowed_field_keys = array_keys($field_labels);
    if (!empty($changed_fields)) {
        $normalized_changed = array_map('sanitize_key', $changed_fields);
        $fields_to_compare = array_values(array_intersect($allowed_field_keys, $normalized_changed));
    } else {
        // Fallback for older frontend payloads.
        $fields_to_compare = $allowed_field_keys;
    }

    $changes = array();
    foreach ($fields_to_compare as $field_key) {
        $field_label = $field_labels[$field_key] ?? $field_key;
        $old_value = $normalize_report_value($current_values[$field_key] ?? '');
        $new_value = $normalize_report_value($submitted_values[$field_key] ?? '');
        if ($old_value !== $new_value) {
            $changes[$field_key] = array(
                'label' => $field_label,
                'old' => $old_value,
                'new' => $new_value,
            );
        }
    }

    if (empty($changes)) {
        wp_send_json_error(__('Nu exista modificari reale de trimis.', 'mangayummy'));
    }

    // Build report data
    $report_data = [
        'manga_id' => $manga_id,
        'manga_title' => get_the_title($manga_id),
        'user_id' => $user_id,
        'user_name' => $user_name,
        'user_email' => $user_email,
        'submitted_at' => current_time('mysql'),
        'ip_address' => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
        'changes' => $changes,
        'suggested' => [
            'title' => $title,
            'alternative_titles' => $alternative_titles,
            'genres' => $genres,
            'status' => $status,
            'type' => $type,
            'author' => $author,
            'artist' => $artist,
            'year' => $year,
            'final_chapter' => $final_chapter,
            'translator_ro' => $translator_ro,
            'description' => $description,
            'message' => $message
        ]
    ];

    // Save report as post meta on the manga
    $reports = get_post_meta($manga_id, '_manga_reports', true);
    if (!is_array($reports)) {
        $reports = [];
    }

    // Limit reports to last 100 for performance
    if (count($reports) >= 100) {
        array_shift($reports);
    }

    $reports[] = $report_data;
    update_post_meta($manga_id, '_manga_reports', $reports);

    // Email notifications are intentionally disabled.

    wp_send_json_success([
        'message' => 'Report submitted successfully!',
        'report_id' => count($reports)
    ]);
});

add_action('wp_ajax_nopriv_mangayummy_submit_report', function() {
    check_ajax_referer('mangayummy_report_nonce', 'nonce');

    // Allow anonymous reports too
    do_action('wp_ajax_mangayummy_submit_report');
});

// ===== ADMIN: MANGA REPORTS =====

add_action('admin_menu', function() {
    add_submenu_page(
        'edit.php?post_type=manga',
        'All Manga Modification Reports',
        'Manga Modification Reports',
        'manage_options',
        'mangayummy-all-manga-reports',
        'mangayummy_render_all_reports_admin_page'
    );
});

function mangayummy_render_reports_metabox($post) {
    $manga_id = $post->ID;
    $reports = get_post_meta($manga_id, '_manga_reports', true);

    if (!is_array($reports) || empty($reports)) {
        echo '<p style="color: #666;">No reports or suggestions at this time.</p>';
        return;
    }

    // Reverse to show newest first
    $reports = array_reverse($reports);

    echo '<div style="max-height: 600px; overflow-y: auto;">';
    foreach ($reports as $index => $report) {
        $suggested = $report['suggested'] ?? [];
        $changes = $report['changes'] ?? [];
        $user_info = $report['user_name'];
        if (!empty($report['user_email'])) {
            $user_info .= ' (' . $report['user_email'] . ')';
        }

        echo '<div style="border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: #f9f9f9;">';
        echo '<strong style="color: #0073aa;">Report #' . (count($reports) - $index) . ' - ' . esc_html($user_info) . '</strong>';
        echo '<br><small style="color: #666;">Date: ' . esc_html($report['submitted_at']) . ' | IP: ' . esc_html($report['ip_address']) . '</small>';
        echo '<br><br>';

        if (!empty($changes) && is_array($changes)) {
            echo '<strong style="display:block; margin-bottom: 6px;">Modificari detectate:</strong>';
            foreach ($changes as $change) {
                $label = esc_html($change['label'] ?? 'Camp');
                $old_value = esc_html($change['old'] ?? '');
                $new_value = esc_html($change['new'] ?? '');

                echo '<div style="background:#fff; border-left:3px solid #13667a; padding:10px; margin:8px 0; border-radius:4px;">';
                echo '<strong>' . $label . ':</strong><br>';
                echo '<div style="margin-top:6px; padding:6px 8px; background:#f3f4f6; border-left:3px solid #8b949e; color:#4b5563;">';
                echo '<strong style="color:#374151;">Vechi:</strong> ' . ($old_value !== '' ? $old_value : '(gol)');
                echo '</div>';
                echo '<div style="margin-top:6px; padding:6px 8px; background:#fdecec; border-left:3px solid #d32f2f; color:#7f1d1d;">';
                echo '<strong style="color:#b91c1c;">Nou:</strong> ' . ($new_value !== '' ? $new_value : '(gol)');
                echo '</div>';
                echo '</div>';
            }
        } else {

            if (!empty($suggested['title']) && $suggested['title'] !== get_the_title($manga_id)) {
                echo '<strong>Title:</strong> ' . esc_html($suggested['title']) . '<br>';
            }
            if (!empty($suggested['alternative_titles'])) {
                echo '<strong>Alternative Titles:</strong> ' . esc_html($suggested['alternative_titles']) . '<br>';
            }
            if (!empty($suggested['genres'])) {
                echo '<strong>Suggested Genres:</strong> ' . esc_html($suggested['genres']) . '<br>';
            }
            if (!empty($suggested['status'])) {
                echo '<strong>Suggested Status:</strong> ' . esc_html($suggested['status']) . '<br>';
            }
            if (!empty($suggested['type'])) {
                echo '<strong>Suggested Type:</strong> ' . esc_html($suggested['type']) . '<br>';
            }
            if (!empty($suggested['author'])) {
                echo '<strong>Suggested Author:</strong> ' . esc_html($suggested['author']) . '<br>';
            }
            if (!empty($suggested['artist'])) {
                echo '<strong>Suggested Artist:</strong> ' . esc_html($suggested['artist']) . '<br>';
            }
            if (!empty($suggested['year'])) {
                echo '<strong>Suggested Year:</strong> ' . esc_html($suggested['year']) . '<br>';
            }
            if (!empty($suggested['final_chapter'])) {
                echo '<strong>Suggested Final Chapter:</strong> ' . esc_html($suggested['final_chapter']) . '<br>';
            }
            if (!empty($suggested['translator_ro'])) {
                echo '<strong>Suggested Romanian Translation:</strong> ' . esc_html($suggested['translator_ro']) . '<br>';
            }
        }

        if (!empty($suggested['description'])) {
            echo '<strong>Suggested Description:</strong><br><div style="background: #fff; padding: 8px; border-left: 3px solid #7a7a7a; margin-top: 5px; margin-bottom: 8px; white-space: pre-wrap;">' . esc_html($suggested['description']) . '</div>';
        }
        if (!empty($suggested['message'])) {
            echo '<strong>Message:</strong><br><div style="background: #fff; padding: 8px; border-left: 3px solid #13667a; margin-top: 5px;">' . wp_kses_post($suggested['message']) . '</div>';
        }

        echo '</div>';
    }
    echo '</div>';
    echo '<p style="margin-top: 15px; font-size: 12px; color: #999;">Last 100 reports are saved automatically.</p>';
}

function mangayummy_render_all_reports_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Access Denied', 'mangayummy'));
    }

    $current_page = max(1, intval($_REQUEST['rpaged'] ?? 1));

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['mangayummy_reports_action'])) {
        check_admin_referer('mangayummy_reports_admin_action', 'mangayummy_reports_nonce');

        $action_type = sanitize_text_field($_POST['mangayummy_reports_action']);
        $manga_id = intval($_POST['manga_id'] ?? 0);
        $report_index = intval($_POST['report_index'] ?? -1);
        $notice = 'none';

        if ($manga_id > 0) {
            $reports = get_post_meta($manga_id, '_manga_reports', true);
            $reports = is_array($reports) ? array_values($reports) : array();

            if ($action_type === 'delete_single' && isset($reports[$report_index])) {
                unset($reports[$report_index]);
                $reports = array_values($reports);
                if (empty($reports)) {
                    delete_post_meta($manga_id, '_manga_reports');
                } else {
                    update_post_meta($manga_id, '_manga_reports', $reports);
                }
                $notice = 'deleted_single';
            }

        }

        $redirect_url = add_query_arg(
            array(
                'post_type' => 'manga',
                'page' => 'mangayummy-all-manga-reports',
                'rpaged' => max(1, intval($_POST['rpaged'] ?? $current_page)),
                'reports_notice' => $notice,
            ),
            admin_url('edit.php')
        );
        wp_safe_redirect($redirect_url);
        exit;
    }

    $manga_ids = get_posts(array(
        'post_type' => 'manga',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'no_found_rows' => true,
        'meta_query' => array(
            array(
                'key' => '_manga_reports',
                'compare' => 'EXISTS'
            )
        )
    ));

    $all_reports = array();
    foreach ($manga_ids as $manga_id) {
        $reports = get_post_meta($manga_id, '_manga_reports', true);
        if (!is_array($reports) || empty($reports)) {
            continue;
        }

        foreach ($reports as $report_index => $report) {
            if (!is_array($report)) {
                continue;
            }

            $report['manga_id'] = intval($manga_id);
            $report['manga_title'] = get_the_title($manga_id);
            $report['report_index'] = intval($report_index);
            $all_reports[] = $report;
        }
    }

    usort($all_reports, function($a, $b) {
        $a_ts = strtotime($a['submitted_at'] ?? '') ?: 0;
        $b_ts = strtotime($b['submitted_at'] ?? '') ?: 0;
        return $b_ts <=> $a_ts;
    });

    $per_page = 50;
    $total_reports = count($all_reports);
    $total_pages = max(1, (int) ceil($total_reports / $per_page));
    $offset = ($current_page - 1) * $per_page;
    $paged_reports = array_slice($all_reports, $offset, $per_page);

    echo '<div class="wrap">';
    echo '<h1>Report: Manga Changes</h1>';
    echo '<p>Total reports: <strong>' . intval($total_reports) . '</strong></p>';

    $reports_notice = sanitize_text_field($_GET['reports_notice'] ?? '');
    if ($reports_notice === 'deleted_single') {
        echo '<div class="notice notice-success is-dismissible"><p>Report has been deleted.</p></div>';
    } elseif ($reports_notice === 'none') {
        echo '<div class="notice notice-warning is-dismissible"><p>Action could not be applied.</p></div>';
    }

    if (empty($paged_reports)) {
        echo '<p style="color:#666;">No reports available.</p>';
        echo '</div>';
        return;
    }

    foreach ($paged_reports as $index => $report) {
        $report_number = $offset + $index + 1;
        $suggested = $report['suggested'] ?? array();
        $changes = $report['changes'] ?? array();
        $user_name = esc_html($report['user_name'] ?? 'Anonymous');
        $user_email = !empty($report['user_email']) ? ' (' . esc_html($report['user_email']) . ')' : '';
        $submitted_at = esc_html($report['submitted_at'] ?? '');
        $ip_address = esc_html($report['ip_address'] ?? '');
        $manga_id = intval($report['manga_id'] ?? 0);
        $report_index = intval($report['report_index'] ?? -1);
        $manga_title = esc_html($report['manga_title'] ?? 'Manga');
        $manga_link = $manga_id ? get_edit_post_link($manga_id, '') : '';

        echo '<div style="border:1px solid #ddd; border-radius:6px; background:#fff; padding:12px; margin:12px 0;">';
        echo '<strong style="color:#0073aa;">Raport #' . intval($report_number) . ' - ' . $user_name . $user_email . '</strong>';
        echo '<br><small style="color:#666;">Data: ' . $submitted_at . ' | IP: ' . $ip_address . '</small>';
        echo '<br><small style="color:#666;">Manga: ';
        if (!empty($manga_link)) {
            echo '<a href="' . esc_url($manga_link) . '">' . $manga_title . '</a>';
        } else {
            echo $manga_title;
        }
        echo '</small>';
        echo '<br><br>';

        if (!empty($changes) && is_array($changes)) {
            echo '<strong style="display:block; margin-bottom: 6px;">Modificari detectate:</strong>';
            foreach ($changes as $change) {
                $label = esc_html($change['label'] ?? 'Camp');
                $old_value = esc_html($change['old'] ?? '');
                $new_value = esc_html($change['new'] ?? '');

                echo '<div style="background:#fff; border-left:3px solid #13667a; padding:10px; margin:8px 0; border-radius:4px;">';
                echo '<strong>' . $label . ':</strong><br>';
                echo '<div style="margin-top:6px; padding:6px 8px; background:#f3f4f6; border-left:3px solid #8b949e; color:#4b5563;">';
                echo '<strong style="color:#374151;">Vechi:</strong> ' . ($old_value !== '' ? $old_value : '(gol)');
                echo '</div>';
                echo '<div style="margin-top:6px; padding:6px 8px; background:#fdecec; border-left:3px solid #d32f2f; color:#7f1d1d;">';
                echo '<strong style="color:#b91c1c;">Nou:</strong> ' . ($new_value !== '' ? $new_value : '(gol)');
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<em style="color:#666;">Old report without detailed diff.</em><br>';
            if (!empty($suggested['message'])) {
                echo '<div style="margin-top:8px; padding:8px; background:#f8f8f8; border-left:3px solid #13667a;">' . wp_kses_post($suggested['message']) . '</div>';
            }
        }

        echo '<div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">';
        echo '<form method="post" style="display:inline;">';
        wp_nonce_field('mangayummy_reports_admin_action', 'mangayummy_reports_nonce');
        echo '<input type="hidden" name="mangayummy_reports_action" value="delete_single">';
        echo '<input type="hidden" name="manga_id" value="' . intval($manga_id) . '">';
        echo '<input type="hidden" name="report_index" value="' . intval($report_index) . '">';
        echo '<input type="hidden" name="rpaged" value="' . intval($current_page) . '">';
        echo '<button type="submit" class="button button-secondary" onclick="return confirm(\'Are you sure you want to delete this report?\');">Delete report</button>';
        echo '</form>';

        echo '</div>';

        echo '</div>';
    }

    if ($total_pages > 1) {
        $base_url = admin_url('edit.php?post_type=manga&page=mangayummy-all-manga-reports');
        echo '<div class="tablenav"><div class="tablenav-pages">';
        for ($p = 1; $p <= $total_pages; $p++) {
            $url = add_query_arg('rpaged', $p, $base_url);
            $is_current = $p === $current_page;
            $style = $is_current ? 'font-weight:700; text-decoration:underline;' : '';
            echo '<a href="' . esc_url($url) . '" style="margin-right:10px; ' . esc_attr($style) . '">' . intval($p) . '</a>';
        }
        echo '</div></div>';
    }

    echo '</div>';
}

// ===== CACHE POLICY =====
// Logged-in users should always see fresh content (profiles, settings, notifications, etc.)
// Front page should be cacheable for anonymous users (Cloudflare, etc.).
add_action('template_redirect', function () {
    if (!is_user_logged_in() && is_front_page()) {
        header('Cache-Control: public, max-age=300, s-maxage=300');
        return;
    }

    if (is_user_logged_in()) {
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
    }
}, 1);

function mangayummy_purge_page_cache_on_customizer_save() {
    // Clear theme transients that affect homepage/profile widgets.
    delete_transient('mangayummy_latest_chapters_html');
    delete_transient('mangayummy_frontpage_recent_chapter_ids_v2');
    delete_transient('mangayummy_recent_comments_frontpage_desktop');
    delete_transient('mangayummy_recent_comments_frontpage_tablet');
    delete_transient('mangayummy_recent_comments_frontpage_phone');
    delete_transient('mangayummy_popular_manga_carousel');

    // Trigger known page-cache plugin purges only when available.
    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }
    if (function_exists('wpfc_clear_all_cache')) {
        wpfc_clear_all_cache(true);
    }
    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
    }
    if (function_exists('wp_cache_clear_cache')) {
        wp_cache_clear_cache();
    }
    do_action('litespeed_purge_all');
}
add_action('customize_save_after', 'mangayummy_purge_page_cache_on_customizer_save');

// Redirect legacy /stirii route to homepage
add_action('template_redirect', function () {
    if (is_front_page() || is_admin()) {
        return;
    }

    $request_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    if ($request_path === 'stirii') {
        wp_safe_redirect(home_url('/'), 301);
        exit;
    }
}, 1);

/**
 * PERFORMANCE: Preconnect to external CDNs for faster resource loading
 * Establishes early connections to 3rd party origins
 */
add_action('wp_head', function() {
    // CDNs used by this theme - preconnect to establish early connections
    $preconnect_origins = [
        'https://cdn.jsdelivr.net',    // Swiper.js
        'https://cdnjs.cloudflare.com', // Font Awesome
        'https://unpkg.com',           // Ionicons
    ];
    
    foreach ($preconnect_origins as $origin) {
        echo '<link rel="preconnect" href="' . esc_url($origin) . '" crossorigin>' . "\n";
    }
    
    // DNS prefetch lines for removed external services omitted
}, 1);

/**
 * AJAX: Move all chapters for a manga to trash (admin only)
 */
add_action('wp_ajax_mangayummy_trash_all_chapters', 'mangayummy_trash_all_chapters');
function mangayummy_trash_all_chapters() {
    if (empty($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(array('message' => 'Security error'));
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Permisiuni insuficiente'));
    }

    $manga_id = isset($_POST['manga_id']) ? intval($_POST['manga_id']) : 0;
    if ($manga_id <= 0) {
        wp_send_json_error(array('message' => 'Manga invalid'));
    }

    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'posts_per_page' => -1,
        'meta_query' => array(array('key' => '_manga_id', 'value' => $manga_id, 'compare' => '=')),
        'fields' => 'ids',
    ));

    $trashed = 0;
    if (!empty($chapters)) {
        foreach ($chapters as $cid) {
            if (wp_trash_post($cid)) $trashed++;
        }
    }

    wp_send_json_success(array('trashed' => $trashed));
}

/**
 * PERFORMANCE: Completely disable WordPress emoji scripts and styles
 * Saves ~20KB and multiple HTTP requests for emoji SVGs
 */
add_action('init', function() {
    // Remove emoji scripts
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    
    // Remove emoji DNS prefetch
    remove_filter('wp_resource_hints', 'wp_resource_hints', 10);
    
    // Remove emoji from feeds
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    
    // Remove emoji from emails
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    
    // Remove TinyMCE emoji plugin
    add_filter('tiny_mce_plugins', function($plugins) {
        return is_array($plugins) ? array_diff($plugins, ['wpemoji']) : [];
    });
    
    // Remove emoji inline styles
    add_filter('emoji_svg_url', '__return_false');
}, 1);

/**
 * PERFORMANCE: Disable oEmbed (YouTube, Twitter embeds auto-discovery)
 * If you don't use embeds, saves HTTP requests
 */
add_action('init', function() {
    // Remove oEmbed discovery links
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'wp_oembed_add_host_js');
    
    // Remove REST API oEmbed endpoint
    remove_action('rest_api_init', 'wp_oembed_register_route');
    
    // Remove oEmbed filter
    remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
}, 1);

/**
 * SECURITY: Hide plugin REST namespaces and routes from anonymous users
 */
add_filter('rest_index_response', 'mangayummy_filter_rest_index_response_for_guests', 10, 2);
add_filter('rest_pre_dispatch', 'mangayummy_restrict_rest_routes_for_guests', 10, 3);

function mangayummy_filter_rest_index_response_for_guests($response, $server) {
    if (is_user_logged_in()) {
        return $response;
    }

    if (!($response instanceof WP_REST_Response)) {
        return $response;
    }

    $data = $response->get_data();
    if (empty($data['routes']) || empty($data['namespaces'])) {
        return $response;
    }

    $blocked_namespaces = array(
        'hostinger',
        'hostinger-easy-onboarding',
        'yoast',
        'site-kit',
        'googlesitekit',
        'akismet',
        'jetpack',
        'wp-statistics',
        'woocommerce',
        'wc',
        'wp-abilities',
        'mcp',
        'wp-site-health',
        'wp-block-editor',
        'hostinger-tools-plugin',
        'hostinger-ai-assistant',
        'hostinger-amplitude',
        'hostinger-reach',
    );

    $namespace_pattern = implode('|', array_map('preg_quote', $blocked_namespaces));
    $blocked_route_regex = '#^/(?:wp/v2/(?:plugins|themes|site|users)|(?:' . $namespace_pattern . '))(?:/|$)#i';
    foreach ($data['routes'] as $route => $route_info) {
        if (preg_match($blocked_route_regex, $route)) {
            unset($data['routes'][$route]);
        }
    }

    $data['namespaces'] = array_values(array_filter($data['namespaces'], function($namespace) use ($namespace_pattern) {
        return !preg_match('#^(?:' . $namespace_pattern . ')#i', $namespace);
    }));

    $response->set_data($data);
    return $response;
}

function mangayummy_restrict_rest_routes_for_guests($result, $server, $request) {
    if (is_user_logged_in()) {
        return $result;
    }

    $route = $request instanceof WP_REST_Request ? $request->get_route() : '';
    if (!$route) {
        return $result;
    }

    $blocked_namespaces = array(
        'hostinger',
        'hostinger-easy-onboarding',
        'yoast',
        'site-kit',
        'googlesitekit',
        'akismet',
        'jetpack',
        'wp-statistics',
        'woocommerce',
        'wc',
        'wp-abilities',
        'mcp',
        'wp-site-health',
        'wp-block-editor',
        'hostinger-tools-plugin',
        'hostinger-ai-assistant',
        'hostinger-amplitude',
        'hostinger-reach',
    );
    $namespace_pattern = implode('|', array_map('preg_quote', $blocked_namespaces));
    $blocked_route_regex = '#^/(?:wp/v2/(?:plugins|themes|site|users)|(?:' . $namespace_pattern . '))(?:/|$)#i';

    if (preg_match($blocked_route_regex, $route)) {
        return new WP_Error('rest_forbidden', __('REST route unavailable.'), array('status' => 404));
    }

    return $result;
}

/**
 * PERFORMANCE: Remove unnecessary WordPress head clutter
 */
add_action('init', function() {
    // Remove WordPress version (security + small performance)
    remove_action('wp_head', 'wp_generator');
    
    // Remove wlwmanifest link (Windows Live Writer - obsolete)
    remove_action('wp_head', 'wlwmanifest_link');
    
    // Remove RSD link (Really Simple Discovery - rarely used)
    remove_action('wp_head', 'rsd_link');
    
    // Remove shortlink
    remove_action('wp_head', 'wp_shortlink_wp_head');
    
    // Remove REST API link from head (still works, just hidden)
    remove_action('wp_head', 'rest_output_link_wp_head');
    
    // Remove adjacent posts links (previous/next)
    remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10);
}, 1);

/**
 * PERFORMANCE: Remove query strings from static resources (better caching)
 */
add_filter('script_loader_src', 'mangayummy_remove_query_strings', 15);
add_filter('style_loader_src', 'mangayummy_remove_query_strings', 15);
function mangayummy_remove_query_strings($src) {
    if (strpos($src, '?ver=') !== false) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}

/**
 * PERFORMANCE: Disable self-pingbacks (when you link to your own posts)
 */
add_action('pre_ping', function(&$links) {
    $home = get_option('home');
    foreach ($links as $l => $link) {
        if (strpos($link, $home) === 0) {
            unset($links[$l]);
        }
    }
});

/**
 * PERFORMANCE: Disable Gutenberg block library CSS on frontend (if not using blocks)
 * Saves ~30KB CSS
 */
add_action('wp_enqueue_scripts', function() {
    // Remove Gutenberg block library CSS
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('wc-blocks-style'); // WooCommerce blocks
    wp_dequeue_style('global-styles'); // Global styles
    
    // Remove classic theme styles (not needed for custom theme)
    wp_dequeue_style('classic-theme-styles');
}, 100);

/**
 * PERFORMANCE: Disable WordPress heartbeat on frontend (reduces AJAX calls)
 * Keep it in admin for autosave
 */
add_action('init', function() {
    if (!is_admin()) {
        wp_deregister_script('heartbeat');
    }
}, 1);

/**
 * Disable emoji conversion in comments
 * Removes WordPress automatic emoji conversion from comment text
 */
add_filter('comment_text', 'mangayummy_disable_emoji_in_comments', 0);
add_filter('comment_text_rss', 'mangayummy_disable_emoji_in_comments', 0);

function mangayummy_disable_emoji_in_comments($text) {
    remove_filter('comment_text', 'wp_staticize_emoji');
    remove_filter('the_content', 'wp_filter_content_tags');
    remove_filter('comment_text', 'wp_filter_content_tags');
    remove_filter('comment_text', 'wp_make_content_images_responsive');
    return $text;
}

/**
 * Format date in Romanian
 * @param string|int $date Date string or timestamp
 * @param string $format Date format
 * @return string Formatted date in Romanian
 */
function mangayummy_get_date_ro($date = null, $format = 'j F Y') {
    $months_ro = [
        'January' => 'Ianuarie',
        'February' => 'Februarie',
        'March' => 'Martie',
        'April' => 'Aprilie',
        'May' => 'Mai',
        'June' => 'Iunie',
        'July' => 'Iulie',
        'August' => 'August',
        'September' => 'Septembrie',
        'October' => 'Octombrie',
        'November' => 'Noiembrie',
        'December' => 'Decembrie',
    ];

    if (!$date) {
        $date = get_the_date('Y-m-d H:i:s');
    }

    // Converteste string la timestamp
    if (!is_numeric($date)) {
        $timestamp = strtotime($date);
    } else {
        $timestamp = intval($date);
    }

    // Foloseste timezone-ul din WordPress (evită offset manual)
    $formatted = wp_date($format, $timestamp);

    foreach ($months_ro as $en => $ro) {
        $formatted = str_replace($en, $ro, $formatted);
    }

    return $formatted;
}

/**
 * Format time ago in Romanian (MangaYummy style)
 * @param int $timestamp Unix timestamp
 * @return string Time ago text (e.g., "2 ore în urmă", "1 zi în urmă")
 */
function mangayummy_time_ago($timestamp) {
    if (!$timestamp || $timestamp <= 0) {
        return 'Just now';
    }
    
    $now = current_time('timestamp');
    $diff = $now - intval($timestamp);
    
    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $minutes = (int) floor($diff / 60);
        return $minutes . ' ' . ($minutes == 1 ? 'minute' : 'minutes') . ' ago';
    } elseif ($diff < 86400) {
        $hours = (int) floor($diff / 3600);
        return $hours . ' ' . ($hours == 1 ? 'hour' : 'hours') . ' ago';
    } elseif ($diff < 604800) {
        $days = (int) floor($diff / 86400);
        return $days . ' ' . ($days == 1 ? 'day' : 'days') . ' ago';
    } elseif ($diff < 2592000) {
        $weeks = (int) floor($diff / 604800);
        return $weeks . ' ' . ($weeks == 1 ? 'week' : 'weeks') . ' ago';
    } elseif ($diff < 31536000) {
        $months = (int) floor($diff / 2592000);
        return $months . ' ' . ($months == 1 ? 'month' : 'months') . ' ago';
    } else {
        $years = (int) floor($diff / 31536000);
        return $years . ' ' . ($years == 1 ? 'year' : 'years') . ' ago';
    }
}

/**
 * Get ALL descendants of a comment (recursively)
 * Used to flatten reply hierarchy into single container
 * 
 * @param int $comment_id Parent comment ID
 * @return array Flat array of all descendant comments
 */
function mangayummy_get_all_comment_descendants($comment_id) {
    $comment_id = intval($comment_id);
    if ($comment_id <= 0) {
        return [];
    }

    $comment = get_comment($comment_id);
    if (!$comment) {
        return [];
    }

    $post_id = intval($comment->comment_post_ID);
    if ($post_id <= 0) {
        return [];
    }

    static $post_children_map = [];
    static $descendants_memo = [];

    // Build a single children map per post to avoid N+1 recursive queries.
    if (!isset($post_children_map[$post_id])) {
        $all_comments = get_comments([
            'post_id' => $post_id,
            'status' => 'approve',
            'orderby' => 'date',
            'order' => 'ASC',
            'number' => 0,
        ]);

        $children_map = [];
        foreach ($all_comments as $item) {
            $parent = intval($item->comment_parent);
            if (!isset($children_map[$parent])) {
                $children_map[$parent] = [];
            }
            $children_map[$parent][] = $item;
        }

        $post_children_map[$post_id] = $children_map;
        $descendants_memo[$post_id] = [];
    }

    if (isset($descendants_memo[$post_id][$comment_id])) {
        return $descendants_memo[$post_id][$comment_id];
    }

    $children_map = $post_children_map[$post_id];
    $all_descendants = [];

    if (!empty($children_map[$comment_id])) {
        foreach ($children_map[$comment_id] as $reply) {
            $all_descendants[] = $reply;
            $nested = mangayummy_get_all_comment_descendants($reply->comment_ID);
            if (!empty($nested)) {
                $all_descendants = array_merge($all_descendants, $nested);
            }
        }
    }

    $descendants_memo[$post_id][$comment_id] = $all_descendants;
    return $all_descendants;
}

function mangayummy_get_comment_user_context($user_id) {
    $user_id = intval($user_id);
    if ($user_id <= 0) {
        return null;
    }

    static $user_context_cache = [];

    if (isset($user_context_cache[$user_id])) {
        return $user_context_cache[$user_id];
    }

    $user = get_user_by('id', $user_id);
    if (!$user) {
        $user_context_cache[$user_id] = null;
        return null;
    }

    $avatar_url = get_user_meta($user_id, 'profile_avatar', true);
    if (!$avatar_url) {
        $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
    }

    $user_context_cache[$user_id] = [
        'user' => $user,
        'display_name' => $user->display_name,
        'avatar_url' => $avatar_url,
        'level_label' => mangayummy_get_user_level_label($user_id),
        'level_tier_class' => mangayummy_get_user_level_tier_class($user_id),
        'group_info' => mangayummy_get_user_group($user_id),
    ];

    return $user_context_cache[$user_id];
}

/**
 * Override get_avatar to use profile_avatar from user_meta
 * Properly handles: numeric ID, WP_Comment objects, email strings
 * Falls back to local default-avatar.png - ALWAYS returns <img> tag
 * 
 * CRITICAL: This runs on EVERY get_avatar() call, including comments
 */
add_filter('get_avatar', function($avatar, $id_or_email, $size, $default, $alt) {
    // Default size to 96 if not specified
    if (!$size) $size = 96;
    
    $user = false;

    // Case 1: Numeric user ID
    if (is_numeric($id_or_email)) {
        $user = get_user_by('id', intval($id_or_email));
    }
    // Case 2: WP_Comment object (most common in comments)
    elseif ($id_or_email instanceof WP_Comment) {
        $user = get_user_by('email', $id_or_email->comment_author_email);
    }
    // Case 3: Email string
    elseif (is_string($id_or_email) && !empty($id_or_email)) {
        $user = get_user_by('email', $id_or_email);
    }

    // If user found AND has custom avatar in profile_avatar meta
    if ($user && is_object($user)) {
        $custom_avatar = get_user_meta($user->ID, 'profile_avatar', true);
        if ($custom_avatar && !empty($custom_avatar)) {
            return '<img src="' . esc_url($custom_avatar) . '" class="avatar avatar-' . intval($size) . '" width="' . intval($size) . '" height="' . intval($size) . '" alt="' . esc_attr($alt) . '" />';
        }
    }

    // Fallback to local default-avatar.png (NEVER return empty, NEVER use Gravatar)
    $default_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
    return '<img src="' . esc_url($default_avatar_url) . '" class="avatar avatar-' . intval($size) . '" width="' . intval($size) . '" height="' . intval($size) . '" alt="' . esc_attr($alt) . '" />';
}, 10, 5);

// ===== PERFORMANCE: Add defer attribute to all theme scripts =====
add_filter('script_loader_tag', function($tag, $handle, $src) {
    // Skip admin scripts and wp-includes scripts
    if (is_admin() || strpos($src, 'wp-includes') !== false) {
        return $tag;
    }
    // Skip if already has defer or async
    if (strpos($tag, 'defer') !== false || strpos($tag, 'async') !== false) {
        return $tag;
    }
    // Add defer to theme scripts
    if (strpos($src, get_template_directory_uri()) !== false || strpos($src, 'cdn.jsdelivr.net') !== false) {
        return str_replace(' src', ' defer src', $tag);
    }
    return $tag;
}, 10, 3);

// ===== PERFORMANCE: Register optimized image sizes for manga covers =====
add_action('after_setup_theme', function() {
    // Manga card thumbnail (for grids and carousels) - 300x420 (manga ratio ~0.71)
    add_image_size('manga-card', 300, 420, true);
    // Manga card small (for smaller displays)
    add_image_size('manga-card-small', 200, 280, true);
    // Manga poster (for single manga page)
    add_image_size('manga-poster', 400, 560, true);
    
    // Enable support for responsive images
    add_theme_support('post-thumbnails');
});

// Show admin bar only for administrators.
add_filter('show_admin_bar', function($show) {
    return current_user_can('manage_options');
});

// ===== PERFORMANCE: Fallback for manga-card if not generated yet =====
// ===== PERFORMANCE: Force manga-card size, fallback to medium if not available =====
add_filter('post_thumbnail_html', function($html, $post_id, $post_thumbnail_id, $size, $attr) {
    // If manga-card size requested, ensure we get the smallest available size
    if ($size === 'manga-card' && $html) {
        // Check if image is using a larger size (400x560 or full) and try to get smaller
        if (strpos($html, '400x560') !== false || strpos($html, '-scaled') !== false) {
            // Try to get the 300x420 version instead
            $small_url = wp_get_attachment_image_url($post_thumbnail_id, 'manga-card');
            if (!$small_url) {
                $small_url = wp_get_attachment_image_url($post_thumbnail_id, 'medium');
            }
            if ($small_url) {
                $html = preg_replace('/src="[^"]*"/', 'src="' . esc_url($small_url) . '"', $html);
            }
        }
        // Add explicit dimensions
        if (strpos($html, 'width=') === false) {
            $html = str_replace('<img', '<img width="300" height="420"', $html);
        }
    }
    return $html;
}, 10, 5);

// NOTE: Image preloading removed - causes console warnings when images are cached
// or when exact URLs don't match. Modern browsers handle this well with fetchpriority="high"

// Enqueue scripts and styles
function mangayummy_assets() {
    $style_version = '3.7.25'; // Increment this on style changes
    wp_enqueue_style(
        'mangayummy-style',
        get_template_directory_uri() . '/style_new.css?v=' . $style_version,
        [],
        $style_version
    );
    
    // Ionicons & Font Awesome 5 - only on manga/chapter pages and top-100 page (for ratings & reactions)
    if (is_singular('manga') || is_singular('chapter') || get_query_var('automatic_page') === 'top_100_manga') {
        // Ionicons for rating stars
        wp_enqueue_style(
            'ionicons',
            'https://unpkg.com/ionicons@2.0.1/css/ionicons.min.css',
            [],
            '2.0.1'
        );
        // Font Awesome 5 for comment reactions (like/dislike) and top-100 icons
        wp_enqueue_style(
            'font-awesome-5',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css',
            [],
            '5.15.4'
        );
    }
    
    // Swiper Library - only on front page
    if (is_front_page()) {
        wp_enqueue_style(
            'swiper-css',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
            [],
            '11'
        );
        wp_enqueue_script(
            'swiper-js',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
            [],
            '11',
            true // Load in footer
        );
    }
    
    wp_enqueue_script(
        'mangayummy-main',
        get_template_directory_uri() . '/js/main.js?v=' . filemtime(get_template_directory() . '/js/main.js'),
        is_front_page() ? ['swiper-js'] : [],
        filemtime(get_template_directory() . '/js/main.js'),
        true
    );
    
    // Enqueue social.js only on pages with genre filtering (manhua, manga, browse)
    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';
    if (is_page('manhua') || is_page('manga') || is_page('browse') || is_page('advanced-search') || is_page('cautare-avansata') || strpos($request_uri, '/browse') === 0 || strpos($request_uri, '/advanced-search') === 0 || strpos($request_uri, '/cautare-avansata') === 0 || is_page('users') || is_page('utilizatori')) {
        wp_enqueue_script(
            'mangayummy-social',
            get_template_directory_uri() . '/assets/js/social.js',
            [],
            filemtime(get_template_directory() . '/assets/js/social.js'),
            true
        );
        // Localize social.js with AJAX and site URL
        wp_localize_script('mangayummy-social', 'mangayummy', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'siteurl' => site_url(),
        ));
    }
    
    wp_localize_script('mangayummy-main', 'ya_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ya_ajax_nonce'),
        'logout_nonce' => wp_create_nonce('mangayummy_logout'),
        'currentUserId' => get_current_user_id(),
    ));
    
    // Load auth modal on all pages (not for logged in users, or on auth page)
    if (!is_user_logged_in()) {
        wp_enqueue_style(
            'auth-modal-style',
            get_template_directory_uri() . '/css/auth-modal.css?v=' . filemtime(get_template_directory() . '/css/auth-modal.css'),
            [],
            filemtime(get_template_directory() . '/css/auth-modal.css')
        );
        wp_enqueue_script(
            'auth-modal-script',
            get_template_directory_uri() . '/js/auth-modal.js?v=' . filemtime(get_template_directory() . '/js/auth-modal.js'),
            [],
            filemtime(get_template_directory() . '/js/auth-modal.js'),
            true
        );
        wp_localize_script('auth-modal-script', 'ya_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ya_ajax_nonce'),
        ));
    }
    
    // Chat system is loaded via footer.php for reliability
    
    // Chapter status script on profile pages
    $is_profile_page = is_page('profile') || is_page_template('page-profile.php') || get_query_var('view_user');
    if ($is_profile_page || is_page('messages') || is_page('mesaje')) {
        wp_enqueue_script(
            'chapter-status-script',
            get_template_directory_uri() . '/js/chapter-status.js',
            array('mangayummy-main'),
            filemtime(get_template_directory() . '/js/chapter-status.js'),
            true
        );
    }
    
    // Front page CSS
    if (is_front_page()) {
        $css_version = '3.1.26'; // Incrementează când modifici CSS-ul
        wp_enqueue_style(
            'mangayummy-front-page',
            get_template_directory_uri() . '/css/front-page.css?v=' . $css_version . '.' . filemtime(get_template_directory() . '/css/front-page.css'),
            [],
            null // No version parameter since we have query string
        );
    }
    
    // Latest chapters page CSS
    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';
    if (is_page_template('page-cele-mai-noi-capitole.php') || is_page('latest-chapters') || is_page('cele-mai-noi-capitole') || strpos($request_uri, '/latest-chapters') !== false || strpos($request_uri, '/cele-mai-noi-capitole') !== false) {
        wp_enqueue_style(
            'cele-mai-noi-capitole-style',
            get_template_directory_uri() . '/css/cele-mai-noi-capitole.css?v=' . filemtime(get_template_directory() . '/css/cele-mai-noi-capitole.css'),
            ['mangayummy-style'],
            null
        );
    }
    
    // Top 100 page CSS
    if (get_query_var('automatic_page') === 'top_100_manga') {
        $top100_css_path = get_template_directory() . '/css/top-100.css';
        $top100_version = file_exists($top100_css_path) ? filemtime($top100_css_path) : time();

        // Expose helper via function so template can show the same version
        if (!function_exists('mangayummy_get_top100_version')) {
            function mangayummy_get_top100_version() {
                $path = get_template_directory() . '/css/top-100.css';
                return file_exists($path) ? date('Y.m.d.Hi', filemtime($path)) : date('Y.m.d.Hi');
            }
        }

        wp_enqueue_style(
            'mangayummy-top-100',
            get_template_directory_uri() . '/css/top-100.css?v=' . $top100_version,
            ['mangayummy-style'],
            null
        );
    }
    
    // Translator groups page CSS
    if (is_page('translator-groups') || get_query_var('translator_group')) {
        wp_enqueue_style(
            'translator-group-style',
            get_template_directory_uri() . '/css/translator-group.css',
            ['mangayummy-style'],
            filemtime(get_template_directory() . '/css/translator-group.css')
        );
    }
    
    // Advanced search page CSS
    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';
    if (is_page('browse') || is_page('advanced-search') || is_page('cautare-avansata') || strpos($request_uri, '/browse') === 0 || strpos($request_uri, '/advanced-search') === 0 || strpos($request_uri, '/cautare-avansata') === 0) {
        // version can be bumped manually when making visual tweaks
        $cautare_version = '1.0.0';
        wp_enqueue_style(
            'cautare-avansata-style',
            get_template_directory_uri() . '/css/cautare-avansata.css?v=' . $cautare_version . '.' . filemtime(get_template_directory() . '/css/cautare-avansata.css'),
            ['mangayummy-style'],
            null
        );
    }
}

/**
 * Wrap images in the_content with a placeholder + data-src base64 for protected lazy loading.
 */
function mangayummy_protected_lazy_images_content( $content ) {
    if ( is_admin() || empty( $content ) ) {
        return $content;
    }

    return preg_replace_callback(
        '/<img\b([^>]*?)\bsrc\s*=\s*(["\'])(https?:\/\/[^"\']*\/wp-content\/uploads\/chapters\/[^"\']+\.(?:jpg|jpeg|png|webp))\2([^>]*?)>/i',
        function ( $matches ) {
            $before = trim( $matches[1] );
            $src = $matches[3];
            $after = trim( $matches[4] );

            if ( stripos( $before . ' ' . $after, 'data-src=' ) !== false ) {
                return $matches[0];
            }

            $encoded = base64_encode( $src );
            $placeholder = 'data:image/gif;base64,R0lGODlhAQABAPAAAP///wAAACwAAAAAAQABAEACAkQBADs='; // 1x1 transparent GIF

            $new = '<img ' . $before . ' src="' . esc_url( $placeholder ) . '" data-src="' . esc_attr( $encoded ) . '" data-lazy="mangayummy" ' . $after . '>';
            return $new;
        },
        $content
    );
}
// Lazy protection for content disabled (no action needed)

add_action('wp_enqueue_scripts', 'mangayummy_assets');

// Redirect /manga/ to /recent-updates/
// add_action('template_redirect', function() {
//     if (is_archive('manga')) {
//         wp_redirect(home_url('/recente-actualizari/'), 301);
//         exit;
//     }
// });

// Enqueue single page styles
function mangayummy_single_assets() {
    if (is_singular(array('manga','chapter','stire'))) {
        $css_version = '2.1.3'; // Incrementează când modifici CSS-ul
        wp_enqueue_style(
            'single-manga-style',
            get_template_directory_uri() . '/css/single-manga.css?v=' . $css_version . '.' . filemtime(get_template_directory() . '/css/single-manga.css'),
            [],
            null // No version parameter since we have query string
        );
        // Load genre colors CSS
        wp_enqueue_style(
            'genre-colors-style',
            get_template_directory_uri() . '/assets/css/genre-colors.css',
            ['single-manga-style'],
            filemtime(get_template_directory() . '/assets/css/genre-colors.css')
        );

        // Lazy load protection script for manga-related images is disabled.
        // Load comments.js on manga and stire pages (chapter pages use lighter chapter-comments.js)
        if (is_singular('manga') || is_singular('stire')) {
            wp_enqueue_script(
                'mangayummy-comments',
                get_template_directory_uri() . '/js/comments.js',
                ['jquery'],
                filemtime(get_template_directory() . '/js/comments.js'),
                true
            );
            
            wp_localize_script('mangayummy-comments', 'mangayummy_comments', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('mangayummy_comment_nonce'),
                'post_id' => get_the_ID(),
            ]);
        }

        if (is_singular('manga')) {
            // single-manga.js only needed on manga page (for Recent Activity modal)
            // include dynamic version parameter to force clients to fetch new file
            wp_enqueue_script(
                'single-manga-script',
                get_template_directory_uri() . '/js/single-manga.js?v=' . time(),
                ['mangayummy-main'],
                filemtime(get_template_directory() . '/js/single-manga.js'),
                true
            );
            wp_localize_script('single-manga-script', 'mangayummy_ajax', [
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ya_ajax_nonce'),
            ]);
            // Also localize for inline scripts in single-manga.php
            wp_localize_script('mangayummy-main', 'mangayummy_comments', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('mangayummy_comment_nonce'),
                'post_id' => get_the_ID(),
            ]);
        }

        // For chapter pages, also localize for inline scripts
        if (is_singular('chapter')) {
            wp_localize_script('mangayummy-main', 'mangayummy_comments', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('mangayummy_comment_nonce'),
                'post_id' => get_the_ID(),
            ]);
        }
        wp_enqueue_script(
            'toggle-replies-script',
            get_template_directory_uri() . '/js/toggle-replies.js',
            [],
            filemtime(get_template_directory() . '/js/toggle-replies.js'),
            true
        );
        wp_enqueue_script(
            'chapter-status-script',
            get_template_directory_uri() . '/js/chapter-status.js',
            array('mangayummy-main'),
            filemtime(get_template_directory() . '/js/chapter-status.js'),
            true
        );
    }
    // Modern Auth Page
    if (is_page_template('page-auth.php')) {
        wp_enqueue_style(
            'auth-modern-style',
            get_template_directory_uri() . '/css/auth-modern.css?v=' . filemtime(get_template_directory() . '/css/auth-modern.css'),
            [],
            filemtime(get_template_directory() . '/css/auth-modern.css')
        );
        wp_enqueue_script(
            'auth-modern-script',
            get_template_directory_uri() . '/js/auth-modern.js?v=' . filemtime(get_template_directory() . '/js/auth-modern.js'),
            [],
            filemtime(get_template_directory() . '/js/auth-modern.js'),
            true
        );
        wp_localize_script('auth-modern-script', 'ya_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ya_ajax_nonce'),
        ]);
    }
    if (is_singular('chapter')) {
        wp_enqueue_style(
            'single-chapter-style',
            get_template_directory_uri() . '/css/single-chapter.css?v=' . filemtime(get_template_directory() . '/css/single-chapter.css'),
            [],
            filemtime(get_template_directory() . '/css/single-chapter.css')
        );
        wp_enqueue_script(
            'chapter-lazy-loading',
            get_template_directory_uri() . '/js/chapter-lazy-loading.js?v=' . filemtime(get_template_directory() . '/js/chapter-lazy-loading.js'),
            [],
            filemtime(get_template_directory() . '/js/chapter-lazy-loading.js'),
            true
        );
        // Light chapter comments script (vanilla JS, no jQuery)
        wp_enqueue_script(
            'chapter-comments',
            get_template_directory_uri() . '/js/chapter-comments.js',
            [],
            filemtime(get_template_directory() . '/js/chapter-comments.js'),
            true
        );
        wp_localize_script('chapter-comments', 'mangayummy_comments', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mangayummy_comment_nonce'),
            'post_id' => get_the_ID(),
        ]);
    }
}
add_action('wp_enqueue_scripts', 'mangayummy_single_assets');

// ===== SEO OPTIMIZATION FOR MANGA SITE =====

/**
 * Dynamic Title Tag for SEO
 * Generates unique titles for Manga & Chapter pages
 */
add_filter('pre_get_document_title', function($title) {
    if (is_singular('manga')) {
        $manga_title = get_the_title();
        $alt_names = get_post_meta(get_the_ID(), 'alternative_names', true);
        $alt_text = $alt_names ? ' (' . $alt_names . ')' : '';
        return trim($manga_title . $alt_text) . ' | ' . get_bloginfo('name');
    }
    
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        $chapter_num = mangayummy_get_chapter_number($chapter_id);
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        if (!$manga_id) {
            $manga_id = wp_get_post_parent_id($chapter_id);
        }
        $manga_title = $manga_id ? get_the_title($manga_id) : get_the_title($chapter_id);
        // title format: {manga} Chapter {num}
        $num_text = $chapter_num ? ' Chapter ' . $chapter_num : '';
        return trim($manga_title . $num_text) . ' | ' . get_bloginfo('name');
    }
    
    if (get_query_var('automatic_page') === 'top_100_manga') {
        return 'Top 100 Manga | ' . get_bloginfo('name');
    }
    
    if (is_page('about') || is_page('despre')) {
        $about_title = trim(get_theme_mod('mangayummy_about_title', 'About ' . get_bloginfo('name')));
        if ($about_title === '') {
            $about_title = 'About';
        }
        return $about_title . ' | ' . get_bloginfo('name');
    }
    
    if (is_page('users') || is_page('utilizatori')) {
        return 'Users | ' . get_bloginfo('name');
    }
    
    return $title;
});

/**
 * Meta Description for SEO
 * Auto-generated for Manga & Chapter pages
 */
add_action('wp_head', function() {
    $site_name = get_bloginfo('name');

    if (is_singular('manga')) {
        $manga_title = get_the_title();
        $alt_names = get_post_meta(get_the_ID(), 'alternative_names', true);
        $author = get_post_meta(get_the_ID(), '_author', true);
        
        $desc = 'Read ' . $manga_title;
        if ($alt_names) {
            $desc .= ' (' . $alt_names . ')';
        }
        $desc .= ' online. ';
        if ($author) {
            $desc .= 'Author: ' . $author . '. ';
        }
        $desc .= 'Updated chapters and complete reading experience on ' . $site_name . '.';
        
        echo '<meta name="description" content="' . esc_attr(substr($desc, 0, 160)) . '">' . "\n";
    }
    
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        $chapter_num = mangayummy_get_chapter_number($chapter_id);
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        if (!$manga_id) {
            $manga_id = wp_get_post_parent_id($chapter_id);
        }
        $manga_title = $manga_id ? get_the_title($manga_id) : '';
        
        $desc = 'Read ' . $manga_title;
        if ($chapter_num) {
            $desc .= ' Chapter ' . $chapter_num;
        }
        $desc .= ' online on ' . $site_name . '.';
        
        echo '<meta name="description" content="' . esc_attr(substr($desc, 0, 160)) . '">' . "\n";
    }
    
    if (get_query_var('automatic_page') === 'top_100_manga') {
        echo '<meta name="description" content="Discover the Top 100 manga ranked by readers on ' . esc_attr($site_name) . '.">' . "\n";
    }
    
    if (is_page('about') || is_page('despre')) {
        $about_desc = trim(get_theme_mod('mangayummy_about_desc_1', ''));
        if ($about_desc === '') {
            $about_desc = 'Learn more about our platform, mission, and team.';
        }
        echo '<meta name="description" content="' . esc_attr(wp_trim_words($about_desc, 26, '')) . '">' . "\n";
    }
    
    if (is_page('users') || is_page('utilizatori')) {
        echo '<meta name="description" content="Explore the community on ' . esc_attr($site_name) . '. Discover active readers, translators, and members.">' . "\n";
    }

    if (is_singular('stire')) {
        $stire_excerpt = get_post_field('post_excerpt', get_the_ID());
        if (!$stire_excerpt) {
            $stire_excerpt = wp_trim_words(get_the_content(), 25, '...');
        }
        $stire_desc = wp_strip_all_tags($stire_excerpt);
        echo '<meta name="description" content="' . esc_attr(substr($stire_desc, 0, 160)) . '">' . "\n";
    }
}, 5); // Priority 5 (before default WordPress meta)

// ===== GENRE TAXONOMY SEO (Yoast) =====
// Auto-fill Yoast meta for genres (without overwriting existing values)
function mangayummy_update_genre_seo_meta($term_id) {
    // Bail if term_id invalid
    if (!$term_id) {
        return;
    }

    $term = get_term($term_id, 'genre');
    if (!$term || is_wp_error($term)) {
        return;
    }

    $name = $term->name;

    // Only set if missing
    $current_title = get_term_meta($term_id, 'wpseo_title', true);
    if (empty($current_title)) {
        $seo_title = $name . ' Manga - Read Online';
        update_term_meta($term_id, 'wpseo_title', $seo_title);
    }

    $current_desc = get_term_meta($term_id, 'wpseo_metadesc', true);
    if (empty($current_desc)) {
        $seo_desc = 'Read manga in the ' . $name . ' genre online. Complete series and updated chapters.';
        update_term_meta($term_id, 'wpseo_metadesc', $seo_desc);
    }
}
add_action('created_genre', 'mangayummy_update_genre_seo_meta', 10, 1);
add_action('edited_genre', 'mangayummy_update_genre_seo_meta', 10, 1);

// Ensure title/meta are populated at runtime if still missing (without overwriting existing)
add_filter('wpseo_title', function($title) {
    if (is_tax('genre')) {
        $term = get_queried_object();
        if ($term && isset($term->term_id)) {
            $existing = get_term_meta($term->term_id, 'wpseo_title', true);
            if (empty($existing)) {
                $new_title = $term->name . ' Manga - Read Online';
                update_term_meta($term->term_id, 'wpseo_title', $new_title);
                return $new_title;
            }
        }
    }
    return $title;
}, 10, 1);

add_filter('wpseo_metadesc', function($desc) {
    if (is_tax('genre')) {
        $term = get_queried_object();
        if ($term && isset($term->term_id)) {
            $existing = get_term_meta($term->term_id, 'wpseo_metadesc', true);
            if (empty($existing)) {
                $new_desc = 'Read manga in the ' . $term->name . ' genre online. Complete series and updated chapters.';
                update_term_meta($term->term_id, 'wpseo_metadesc', $new_desc);
                return $new_desc;
            }
        }
    }
    return $desc;
}, 10, 1);

// Yoast SEO optimization for Translator Groups page
add_filter('wpseo_title', function($title) {
    if (is_page('translator-groups')) {
        return 'Translator Groups | ' . get_bloginfo('name');
    }
    return $title;
}, 10, 1);

add_filter('wpseo_metadesc', function($desc) {
    if (is_page('translator-groups')) {
        return 'Browse translator groups and discover teams working on manga, manhwa, and manhua.';
    }
    return $desc;
}, 10, 1);

add_filter('wpseo_focuskw', function($focuskw) {
    if (is_page('translator-groups')) {
        return 'manga translator groups';
    }
    return $focuskw;
}, 10, 1);

// Force index/follow for genre taxonomy
add_filter('wpseo_robots', function($robots) {
    if (is_tax('genre')) {
        return 'index, follow';
    }
    return $robots;
}, 10, 1);

// Register custom Yoast variable for english title
// ensure registration runs early on init when Yoast is available
add_action('init', function() {
    if (function_exists('wpseo_register_var_replacement')) {
        wpseo_register_var_replacement(
            '%%english_title%%',
            'mangayummy_yoast_english_title',
            'advanced',
            'English title stored in post meta (fallbacks to main title)'
        );
    }
});
// The extra-replacements hook ran previously but the variable is already registered
// so we no longer need the second call, which triggered a warning in Yoast.
// Keeping this commented out in case older Yoast versions require it:
/*
add_action('wpseo_register_extra_replacements', function() {
    if (function_exists('wpseo_register_var_replacement')) {
        wpseo_register_var_replacement(
            '%%english_title%%',
            'mangayummy_yoast_english_title',
            'advanced'
        );
    }
});
*/

function mangayummy_yoast_english_title($replacement) {
    if (is_singular('manga')) {
        $english = get_post_meta(get_the_ID(), 'english_title', true);
        if (!empty($english)) {
            return $english;
        }
        // fallback to default post title
        return get_the_title();
    }
    // outside manga posts we don't want the placeholder string to leak
    return '';
}

// Keep genre taxonomy in Yoast sitemap
add_filter('wpseo_sitemap_exclude_taxonomy', function($exclude, $taxonomy) {
    if ($taxonomy === 'genre') {
        return false; // ensure it's included
    }
    return $exclude;
}, 10, 2);

// Make sure schema archive is enabled for genre taxonomy
add_filter('wpseo_schema_needs_taxonomy', function($needs_taxonomy, $context) {
    if (is_tax('genre')) {
        return true;
    }
    return $needs_taxonomy;
}, 10, 2);

// ===== ONE-TIME MIGRATION: Populate missing Yoast title/meta for existing genres =====
add_action('admin_init', function() {
    $flag = get_option('mangayummy_genre_seo_migrated', false);
    if ($flag) {
        return; // already ran
    }

    $terms = get_terms(array(
        'taxonomy' => 'genre',
        'hide_empty' => false,
    ));

    if (is_wp_error($terms)) {
        return;
    }

    foreach ($terms as $term) {
        $term_id = $term->term_id;

        $current_title = get_term_meta($term_id, 'wpseo_title', true);
        if (empty($current_title)) {
            $seo_title = $term->name . ' Manga - Read Online';
            update_term_meta($term_id, 'wpseo_title', $seo_title);
        }

        $current_desc = get_term_meta($term_id, 'wpseo_metadesc', true);
        if (empty($current_desc)) {
            $seo_desc = 'Read manga in the ' . $term->name . ' genre online. Complete series and updated chapters.';
            update_term_meta($term_id, 'wpseo_metadesc', $seo_desc);
        }
    }

    // Mark as completed so it won't run again
    update_option('mangayummy_genre_seo_migrated', true, false);
});

// NOTE: One-time migration and slug-protection filter removed per cleanup request.
// All automated admin-init migrations were deleted to avoid runtime DB changes here.

// Removed admin_init one-time reindex and hard-reset migrations per cleanup instructions.
// These were performing DB-wide changes and are intentionally deleted to avoid runtime migrations.

/**
 * Schema.org Structured Data for SEO
 * ComicSeries for Manga, Chapter for Chapter pages
 */
add_action('wp_head', function() {
    $site_name = get_bloginfo('name');

    if (is_singular('manga')) {
        $manga_id = get_the_ID();
        $manga_title = get_the_title();
        $alt_names = get_post_meta($manga_id, 'alternative_names', true);
        $author = get_post_meta($manga_id, '_author', true);
        $artist = get_post_meta($manga_id, '_artist', true);
        $manga_cover = get_the_post_thumbnail_url($manga_id, 'full');
        $status = get_post_meta($manga_id, '_status', true);
        $rating = get_post_meta($manga_id, '_rating_avg', true);
        $description = get_the_excerpt($manga_id);
        
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'ComicSeries',
            'name' => $manga_title,
            'url' => get_permalink($manga_id),
            'inLanguage' => get_bloginfo('language'),
            'publisher' => [
                '@type' => 'Organization',
                'name' => $site_name,
                'url' => home_url('/')
            ]
        ];
        
        if ($description) {
            $schema['description'] = wp_strip_all_tags(substr($description, 0, 300));
        }
        
        if ($alt_names) {
            $schema['alternateName'] = array_map('trim', explode(',', $alt_names));
        }
        
        if ($manga_cover) {
            $schema['image'] = $manga_cover;
            $schema['thumbnailUrl'] = $manga_cover;
        }
        
        // Add genres
        $genres = get_the_terms($manga_id, 'genre');
        if ($genres && !is_wp_error($genres)) {
            $schema['genre'] = array_map(function($term) { return $term->name; }, $genres);
        }
        
        if ($author || $artist) {
            $schema['author'] = [];
            if ($author) {
                $schema['author'][] = [
                    '@type' => 'Person',
                    'name' => $author,
                    'role' => 'Author'
                ];
            }
            if ($artist) {
                $schema['author'][] = [
                    '@type' => 'Person',
                    'name' => $artist,
                    'role' => 'Illustrator'
                ];
            }
        }
        
        // Add dates
        $schema['datePublished'] = get_the_date('c', $manga_id);
        $schema['dateModified'] = get_the_modified_date('c', $manga_id);
        
        if ($status === 'completed') {
            $schema['status'] = 'CompletedPublications';
        } else {
            $schema['status'] = 'OngoingPublications';
        }
        
        if ($rating) {
            $rating_count = get_post_meta($manga_id, '_rating_count', true);
            // Convertește rating din 0-10 în 0-5 pentru Google (schema.org)
            $rating_for_google = min((float)$rating / 2, 5.0); // max 5.0
            $schema['aggregateRating'] = [
                '@type' => 'AggregateRating',
                'ratingValue' => number_format($rating_for_google, 1),
                'bestRating' => 5,
                'worstRating' => 1,
                'ratingCount' => intval($rating_count) ?: 1
            ];
        }
        
        echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>' . "\n";
    }
    
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        $chapter_title = get_the_title();
        $chapter_num = mangayummy_get_chapter_number($chapter_id);
        
        // Get parent manga from meta or parent
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        if (!$manga_id) {
            $manga_id = wp_get_post_parent_id($chapter_id);
        }
        $manga_title = $manga_id ? get_the_title($manga_id) : '';
        $manga_cover = $manga_id ? get_the_post_thumbnail_url($manga_id, 'full') : '';
        
        // Get chapter images count for numberOfPages
        $chapter_images = get_post_meta($chapter_id, '_chapter_images', true);
        $page_count = is_array($chapter_images) ? count($chapter_images) : 0;
        
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'Chapter',
            'name' => $manga_title . ' - Chapter ' . ($chapter_num ?: ''),
            'headline' => $chapter_title ?: ('Chapter ' . $chapter_num),
            'position' => $chapter_num ?: 0,
            'url' => get_permalink($chapter_id),
            'datePublished' => get_the_date('c', $chapter_id),
            'dateModified' => get_the_modified_date('c', $chapter_id),
            'inLanguage' => get_bloginfo('language'),
            'isPartOf' => [
                '@type' => 'ComicSeries',
                'name' => $manga_title,
                'url' => $manga_id ? get_permalink($manga_id) : ''
            ]
        ];
        
        if ($page_count > 0) {
            $schema['numberOfPages'] = $page_count;
        }
        
        if ($manga_cover) {
            $schema['image'] = $manga_cover;
            $schema['thumbnailUrl'] = $manga_cover;
        }
        
        // Add author/translator info if available
        $translator_group = get_post_meta($chapter_id, '_translation_group', true);
        if ($translator_group) {
            $schema['translator'] = [
                '@type' => 'Organization',
                'name' => $translator_group
            ];
        }
        
        echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>' . "\n";
    }

    if (is_singular('stire')) {
        $stire_id    = get_the_ID();
        $stire_title = get_the_title();
        $stire_excerpt = get_post_field('post_excerpt', $stire_id);
        if (!$stire_excerpt) {
            $stire_excerpt = wp_trim_words(get_the_content(), 25, '...');
        }
        $stire_desc  = wp_strip_all_tags($stire_excerpt);
        $stire_image = get_the_post_thumbnail_url($stire_id, 'large');
        if (!$stire_image) {
            $stire_image = get_post_meta($stire_id, '_stire_cover_url', true);
        }
        $stire_author_id   = intval(get_post_field('post_author', $stire_id));
        $stire_author_name = $stire_author_id ? get_the_author_meta('display_name', $stire_author_id) : $site_name;

        $stire_schema = [
            '@context'      => 'https://schema.org',
            '@type'         => 'NewsArticle',
            'headline'      => $stire_title,
            'description'   => substr($stire_desc, 0, 200),
            'url'           => get_permalink($stire_id),
            'datePublished' => get_the_date('c', $stire_id),
            'dateModified'  => get_the_modified_date('c', $stire_id),
            'inLanguage'    => get_bloginfo('language'),
            'author' => [
                '@type' => 'Person',
                'name'  => $stire_author_name,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name'  => $site_name,
                'url'   => home_url('/'),
                'logo'  => [
                    '@type' => 'ImageObject',
                    'url'   => get_template_directory_uri() . '/assets/img/logo.png',
                ],
            ],
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id'   => get_permalink($stire_id),
            ],
        ];

        if ($stire_image) {
            $stire_schema['image'] = [
                '@type' => 'ImageObject',
                'url'   => $stire_image,
            ];
        }

        echo '<script type="application/ld+json">' . wp_json_encode($stire_schema) . '</script>' . "\n";
    }
}, 10);

/**
 * Disable Yoast SEO Open Graph and Twitter presenters.
 * Use wpseo_frontend_presenters for Yoast 14+ and fallback for older filters.
 */
function mangayummy_disable_yoast_og_twitter_presenters($presenters) {
    if (!is_array($presenters)) {
        return $presenters;
    }

    // Only strip Yoast social presenters on manga/chapter/stire pages.
    if (!is_singular('manga') && !is_singular('chapter') && !is_singular('stire')) {
        return $presenters;
    }

    $filtered = [];

    foreach ($presenters as $key => $presenter) {
        $class = is_object($presenter) ? get_class($presenter) : '';

        // Yoast presenter arrays are often numeric; filtering by class is safer
        // than unsetting named keys like 'open_graph'/'twitter'.
        if ($class !== '' && (
            stripos($class, 'Open_Graph') !== false ||
            stripos($class, 'Twitter') !== false
        )) {
            continue;
        }

        $filtered[$key] = $presenter;
    }

    return $filtered;
}

add_filter('wpseo_frontend_presenters', 'mangayummy_disable_yoast_og_twitter_presenters', 99);

/**
 * Determine MIME type for an image URL (local attachment or extension-based)
 */
function mangayummy_get_image_mime_type($image_url) {
    if (empty($image_url)) {
        return '';
    }

    // If it is a local attachment URL, prefer the attachment mime type.
    $attachment_id = attachment_url_to_postid($image_url);
    if ($attachment_id) {
        $mime = get_post_mime_type($attachment_id);
        if (!empty($mime)) {
            return $mime;
        }
    }

    $path = parse_url($image_url, PHP_URL_PATH);
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

    $map = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'ico' => 'image/x-icon',
        'cur' => 'image/x-icon',
    ];

    return $map[$ext] ?? '';
}

add_action('wp_head', function() {
    $site_name = get_bloginfo('name');

    // Disable Yoast SEO Open Graph/Twitter tags to avoid duplicate OG metadata
    // (wpseo_opengraph is deprecated in Yoast >=14; use wpseo_frontend_presenters handler above)
    //wpseo_opengraph removed to prevent deprecation warning
    remove_action('wpseo_head', 'wpseo_frontend_head', 1);

    if (is_singular('manga')) {
        $manga_id = get_the_ID();
        $manga_title = get_the_title();
        $alt_names = get_post_meta($manga_id, 'alternative_names', true);
        $author = get_post_meta($manga_id, '_author', true);
        $desc = get_the_excerpt();
        if (!$desc) {
            $desc = 'Read ' . $manga_title . ' online on ' . $site_name . '.';
            if (!empty($author)) {
                $desc .= ' Author: ' . $author . '.';
            }
        }
        $desc = wp_strip_all_tags($desc);
        $image = get_the_post_thumbnail_url($manga_id, 'large');
        
        // Keywords
        $keywords = trim($manga_title . ', ' . $alt_names . ', manga, read online', ', ');
        echo '<meta name="keywords" content="' . esc_attr($keywords) . '">' . "\n";
        
        // Open Graph for social sharing (single manga)
        echo '<meta property="og:type" content="website">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($manga_title) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(substr($desc, 0, 160)) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink($manga_id)) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '">' . "\n";
        if ($image) {
            echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
            $og_type = mangayummy_get_image_mime_type($image);
            if (!empty($og_type)) {
                echo '<meta property="og:image:type" content="' . esc_attr($og_type) . '">' . "\n";
            }
        } else {
            // fallback to a generic site logo or no-image placeholder if no featured image
            $fallback_image = get_template_directory_uri() . '/assets/img/default-og-image.png';
            echo '<meta property="og:image" content="' . esc_url($fallback_image) . '">' . "\n";
            $og_type = mangayummy_get_image_mime_type($fallback_image);
            if (!empty($og_type)) {
                echo '<meta property="og:image:type" content="' . esc_attr($og_type) . '">' . "\n";
            }
        }
        echo '<meta name="twitter:card" content="summary">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($manga_title) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr(substr($desc, 0, 160)) . '">' . "\n";
    }
    
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        $chapter_num = mangayummy_get_chapter_number($chapter_id);
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        if (!$manga_id) {
            $manga_id = wp_get_post_parent_id($chapter_id);
        }
        $manga_title = $manga_id ? get_the_title($manga_id) : '';
        $image = $manga_id ? get_the_post_thumbnail_url($manga_id, 'full') : '';
        
        // Open Graph
        echo '<meta property="og:type" content="article">' . "\n";
        $og_title = $manga_title . ($chapter_num ? ' - Chapter ' . $chapter_num : '');
        echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . "\n";
        $og_desc = 'Read ' . $manga_title . ($chapter_num ? ' Chapter ' . $chapter_num : '') . ' online on ' . $site_name . '.';
        echo '<meta property="og:description" content="' . esc_attr($og_desc) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink($chapter_id)) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '">' . "\n";
        if ($image) {
            echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
        }
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($og_title) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($og_desc) . '">' . "\n";
    }

    if (is_singular('stire')) {
        $stire_id    = get_the_ID();
        $stire_title = get_the_title();
        $stire_excerpt = get_post_field('post_excerpt', $stire_id);
        if (!$stire_excerpt) {
            $stire_excerpt = wp_trim_words(get_the_content(), 25, '...');
        }
        $stire_desc  = wp_strip_all_tags($stire_excerpt);
        $stire_image = get_the_post_thumbnail_url($stire_id, 'large');
        if (!$stire_image) {
            $stire_image = get_post_meta($stire_id, '_stire_cover_url', true);
        }

        echo '<meta property="og:type" content="article">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($stire_title) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(substr($stire_desc, 0, 160)) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink($stire_id)) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '">' . "\n";
        echo '<meta property="article:published_time" content="' . esc_attr(get_the_date('c', $stire_id)) . '">' . "\n";
        echo '<meta property="article:modified_time" content="' . esc_attr(get_the_modified_date('c', $stire_id)) . '">' . "\n";
        if ($stire_image) {
            echo '<meta property="og:image" content="' . esc_url($stire_image) . '">' . "\n";
            $og_type = mangayummy_get_image_mime_type($stire_image);
            if (!empty($og_type)) {
                echo '<meta property="og:image:type" content="' . esc_attr($og_type) . '">' . "\n";
            }
        }
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($stire_title) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr(substr($stire_desc, 0, 160)) . '">' . "\n";
        if ($stire_image) {
            echo '<meta name="twitter:image" content="' . esc_url($stire_image) . '">' . "\n";
        }
    }
}, 11);

// Disable unnecessary feeds for non-manga pages (RSS/feed hardening)
add_action('do_feed', 'mangayummy_disable_feeds', 1);
add_action('do_feed_rdf', 'mangayummy_disable_feeds', 1);
add_action('do_feed_rss', 'mangayummy_disable_feeds', 1);
add_action('do_feed_rss2', 'mangayummy_disable_feeds', 1);
add_action('do_feed_atom', 'mangayummy_disable_feeds', 1);

function mangayummy_disable_feeds() {
    if (!is_singular('manga') && !is_singular('chapter') && !is_home()) {
        wp_redirect(home_url(), 301);
        exit;
    }
}

/**
 * SEO: Combined meta tags output (consolidated for performance)
 * Handles: noindex, canonical, robots
 */
add_action('wp_head', function() {
    // Don't index: login, register, settings pages, search results
    if (is_page('login') || is_page('register') || is_page('settings') || 
        is_page('messages') || is_page('mesaje') || is_search()) {
        echo '<meta name="robots" content="noindex, nofollow">' . "\n";
    }
    
    // Don't index user profiles with pagination
    if (is_page('profile') && get_query_var('paged') > 1) {
        echo '<meta name="robots" content="noindex, follow">' . "\n";
    }
    
    // Add canonical URLs for manga/chapter/stire pages
    if (is_singular('manga') || is_singular('chapter') || is_singular('stire')) {
        echo '<link rel="canonical" href="' . esc_url(get_permalink()) . '">' . "\n";
    }
}, 10);

/**
 * SEO: BreadcrumbList Schema.org for better Google navigation
 * Helps Google understand site structure and show breadcrumbs in search results
 */
add_action('wp_head', function() {
    if (is_singular('manga')) {
        $manga_id = get_the_ID();
        $manga_title = get_the_title();
        
        $breadcrumb = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => mangayummy_obfuscate_unicode_text('Home'),
                    'item' => home_url('/')
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => mangayummy_obfuscate_unicode_text('Manga'),
                    'item' => home_url('/manga/')
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => mangayummy_obfuscate_unicode_text($manga_title),
                    'item' => get_permalink($manga_id)
                ]
            ]
        ];
        
        echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb) . '</script>' . "\n";
    }
    
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        $chapter_num = mangayummy_get_chapter_number($chapter_id);
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        if (!$manga_id) {
            $manga_id = wp_get_post_parent_id($chapter_id);
        }
        $manga_title = $manga_id ? get_the_title($manga_id) : '';
        
        $breadcrumb = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => home_url('/')
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Manga',
                    'item' => home_url('/manga/')
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => mangayummy_obfuscate_unicode_text($manga_title),
                    'item' => $manga_id ? get_permalink($manga_id) : ''
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 4,
                    'name' => mangayummy_obfuscate_unicode_text('Chapter ' . ($chapter_num ?: '')),
                    'item' => get_permalink($chapter_id)
                ]
            ]
        ];
        
        echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb) . '</script>' . "\n";
    }
}, 11);

/**
 * SEO: Add rel="prev" and rel="next" for chapter pagination
 * Helps Google understand chapter sequence and crawl efficiently
 */
add_action('wp_head', function() {
    if (!is_singular('chapter')) {
        return;
    }
    
    $chapter_id = get_the_ID();
    $manga_id = get_post_meta($chapter_id, '_manga_id', true);
    if (!$manga_id) {
        return;
    }
    
    $current_chapter_num = mangayummy_get_chapter_number($chapter_id);
    if ($current_chapter_num === null) {
        return;
    }
    $current_num = floatval($current_chapter_num);
    
    // Get all chapters for this manga, sorted by chapter number
    $cache_key = 'manga_chapters_nav_' . $manga_id;
    $chapters_nav = wp_cache_get($cache_key, 'mangayummy_seo');
    
    if ($chapters_nav === false) {
        $all_chapters = get_posts([
            'post_type' => 'chapter',
            'meta_query' => [['key' => '_manga_id', 'value' => $manga_id]],
            'posts_per_page' => -1,
            'fields' => 'ids',
            'no_found_rows' => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false
        ]);
        
        $chapters_nav = [];
        foreach ($all_chapters as $cid) {
            $num_raw = mangayummy_get_chapter_number($cid);
            $num = $num_raw !== null ? floatval($num_raw) : 0;
            $chapters_nav[$cid] = $num;
        }
        asort($chapters_nav); // Sort by chapter number
        wp_cache_set($cache_key, $chapters_nav, 'mangayummy_seo', 300);
    }
    
    $chapter_ids = array_keys($chapters_nav);
    $current_pos = array_search($chapter_id, $chapter_ids);
    
    if ($current_pos === false) {
        return;
    }
    
    // Previous chapter (lower number)
    if ($current_pos > 0) {
        $prev_id = $chapter_ids[$current_pos - 1];
        echo '<link rel="prev" href="' . esc_url(get_permalink($prev_id)) . '">' . "\n";
    }
    
    // Next chapter (higher number)
    if ($current_pos < count($chapter_ids) - 1) {
        $next_id = $chapter_ids[$current_pos + 1];
        echo '<link rel="next" href="' . esc_url(get_permalink($next_id)) . '">' . "\n";
    }
}, 12);

// ===== IMAGE PROXY SYSTEM REMOVED =====

/**
 * Return original image URL directly (no proxying)
 * Usage: mangayummy_proxy_image_url('https://cdn.example.com/image.jpg')
 */
function mangayummy_proxy_image_url($external_url) {
    if (empty($external_url)) {
        return '';
    }

    // Validate URL (only absolute HTTP/HTTPS URLs allowed)
    if (!filter_var($external_url, FILTER_VALIDATE_URL)) {
        return '';
    }

    $parsed = parse_url($external_url);
    if (!isset($parsed['scheme']) || !in_array(strtolower($parsed['scheme']), ['http', 'https'], true)) {
        return '';
    }

    // No proxy: return original user-provided image URL as is
    return esc_url_raw($external_url);
}

// Disable image proxy endpoint, browser should load images directly from source
// no init hook for ?image-proxy requests anymore.

/**
 * Fallback image URL (SVG placeholder if image fails)
 * Used as fallback in frontend
 */
function mangayummy_fallback_image() {
    return 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 400 600%22%3E%3Crect fill=%22%23ddd%22 width=%22400%22 height=%22600%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 fill=%22%23999%22 font-size=%2220%22%3E📖 Imagine indisponibilă%3C/text%3E%3C/svg%3E';
}
// Enqueue Auth styles
function mangayummy_auth_assets() {
    if (is_page_template('page-login.php') || is_page_template('page-register.php')) {
        wp_enqueue_style(
            'auth-style',
            get_template_directory_uri() . '/assets/css/auth.css',
            [],
            filemtime(get_template_directory() . '/assets/css/auth.css')
        );
        wp_enqueue_script(
            'mangayummy-auth',
            get_template_directory_uri() . '/assets/js/auth.js',
            [],
            filemtime(get_template_directory() . '/assets/js/auth.js'),
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'mangayummy_auth_assets');

// Enqueue Profile Page Assets
function mangayummy_profile_assets() {
    // Profile page can be accessed via /profile, /users/ID/ or by reader_name query var
    if (is_page('profile') || is_page_template('page-profile.php') || get_query_var('reader_name') || get_query_var('view_user')) {
        $css_version = '2.3.2'; // Incrementează când modifici CSS-ul
        // Enqueue profile styles
        wp_enqueue_style(
            'profile-style',
            get_template_directory_uri() . '/css/profile.css?v=' . $css_version . '.' . filemtime(get_template_directory() . '/css/profile.css'),
            [],
            null
        );
        
        // Enqueue Cropper.js for image cropping
        wp_enqueue_style(
            'cropperjs-css',
            'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css',
            [],
            '1.6.1'
        );
        wp_enqueue_script(
            'cropperjs',
            'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js',
            [],
            '1.6.1',
            true
        );
        
        // Enqueue profile scripts (versioned like front-page.css to avoid aggressive caching)
        $profile_js_version = '1.0.0'; // increment when modifying major behavior
        wp_enqueue_script(
            'mangayummy-profile',
            get_template_directory_uri() . '/js/profile.js?v=' . $profile_js_version . '.' . filemtime(get_template_directory() . '/js/profile.js'),
            ['jquery', 'cropperjs'],
            null,
            true
        );

        $current_user_id = get_current_user_id();
        $current_user_group = $current_user_id ? get_user_meta($current_user_id, 'user_group', true) : false;
        $allow_gif = $current_user_id ? (!empty($current_user_group) || get_user_meta($current_user_id, '_allow_gif_uploads', true)) : false;
        $max_size = $current_user_id && (!empty($current_user_group) || get_user_meta($current_user_id, '_allow_gif_uploads', true)) ? 10 * 1024 * 1024 : 2 * 1024 * 1024;
        
        wp_localize_script('mangayummy-profile', 'mangayummy_ajax', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('ya_ajax_nonce'),
            'comment_nonce' => wp_create_nonce('mangayummy_comment_nonce'),
            'userGroup' => $current_user_group ?: 'user',
            'allowGif' => $allow_gif ? true : false,
            'maxSize' => $max_size,
        ]);
        
        // Add actions/status script for profile cards
        wp_enqueue_script(
            'chapter-status-script',
            get_template_directory_uri() . '/js/chapter-status.js',
            array('mangayummy-main'),
            filemtime(get_template_directory() . '/js/chapter-status.js'),
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'mangayummy_profile_assets');

// NOTE: settings enqueues removed (kill switch). No frontend settings assets are enqueued here.

// Enqueue Community Page Assets
function mangayummy_community_assets() {
    if (is_page('community') || is_page_template('page-community.php')) {
        wp_enqueue_style(
            'community-style',
            get_template_directory_uri() . '/css/community.css',
            [],
            filemtime(get_template_directory() . '/css/community.css')
        );
    }
}
add_action('wp_enqueue_scripts', 'mangayummy_community_assets');

// Register Custom Post Types
function mangayummy_register_post_types() {
    // Manga Series
    register_post_type('manga', array(
        'labels' => array(
            'name' => 'Manga Series',
            'singular_name' => 'Manga Series',
            'menu_name' => 'Manga Series',
            'all_items' => 'All Manga Series',
            'add_new_item' => 'Add New Manga Series',
            'edit_item' => 'Edit Manga Series',
            'new_item' => 'New Manga Series',
            'view_item' => 'View Manga Series',
            'search_items' => 'Search Manga Series',
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        'menu_icon' => 'dashicons-book',
        'rewrite' => array('slug' => 'manga'),
    ));

    // Chapters
    // NOTE: rewrite is set to false because chapters will use a custom
    // permalink structure: /manga/{manga-slug}/{chapter-slug}
    register_post_type('chapter', array(
        'labels' => array(
            'name' => 'Capitole',
            'singular_name' => 'Capitol',
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'comments'),
        'hierarchical' => true,
        'menu_icon' => 'dashicons-media-document',
        'rewrite' => false,
    ));
}
add_action('init', 'mangayummy_register_post_types');

// Flush rewrite rules on theme activation
function mangayummy_flush_rewrite_rules() {
    mangayummy_register_post_types();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'mangayummy_flush_rewrite_rules');

// Flush chapter rewrite rules only once (safe, run on admin init)
add_action('admin_init', function() {
    if (get_option('mangayummy_chapter_rewrites_flushed')) {
        return;
    }

    // Ensure our rewrite rule exists and then flush
    mangayummy_add_rewrite_rules();
    add_rewrite_rule('^manga/([^/]+)/([^/]+)/?$', 'index.php?post_type=chapter&name=$matches[2]', 'top');
    flush_rewrite_rules(false);
    update_option('mangayummy_chapter_rewrites_flushed', 1);
}, 20);

// Random slug prefix for anti-bot DMCA obfuscation
function mangayummy_generate_slug_prefix() {
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $prefix = '';
    for ($i = 0; $i < 5; $i++) {
        $prefix .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $prefix;
}

/**
 * Rate limit aggressive chapter / image-proxy requests by IP.
 * Example: block if more than 50 chapter requests in a minute.
 */
function mangayummy_get_rate_limit_request_context() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = trim((string) parse_url($request_uri, PHP_URL_PATH), '/');
    if ($path === '') {
        $path = '/';
    }

    $label = $path;

    // For chapter pages include chapter identifier and number for clearer admin diagnostics.
    if (is_singular('chapter')) {
        $chapter_id = get_queried_object_id();
        if ($chapter_id) {
            $chapter_num = function_exists('mangayummy_get_chapter_number') ? mangayummy_get_chapter_number($chapter_id) : '';
            $label .= ' [chapter_id=' . intval($chapter_id);
            if ($chapter_num !== null && $chapter_num !== '') {
                $label .= ', cap=' . $chapter_num;
            }
            $label .= ']';
        }
    }

    return [
        'time'  => time(),
        'path'  => $path,
        'label' => $label,
    ];
}

function mangayummy_rate_limit_check($limit = 50, $window_seconds = 2) {
    if (is_user_logged_in()) {
        return; // Trusted users are exempt
    }

    $remote_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ip_hash = md5($remote_ip);
    $block_key = 'mangayummy_block_' . $ip_hash;
    $rate_key = 'mangayummy_rate_' . $ip_hash;

    $block = get_transient($block_key);
    $now = time();

    if (is_array($block) && isset($block['until']) && $now < $block['until']) {
        $remaining = $block['until'] - $now;
        mangayummy_rate_limit_response(429, $remaining, $block['title'], $block['message']);
        exit;
    } elseif (is_array($block) && isset($block['until']) && $now >= $block['until']) {
        delete_transient($block_key);
    }

    $data = get_transient($rate_key);
    if (!is_array($data)) {
        $data = ['count' => 0, 'started' => $now, 'strikes' => 0, 'recent_requests' => []];
    }

    if ($now - $data['started'] > $window_seconds) {
        $data['count'] = 0;
        $data['started'] = $now;
        if (!isset($data['recent_requests']) || !is_array($data['recent_requests'])) {
            $data['recent_requests'] = [];
        }
    }

    $ctx = mangayummy_get_rate_limit_request_context();
    if (!isset($data['recent_requests']) || !is_array($data['recent_requests'])) {
        $data['recent_requests'] = [];
    }
    $data['recent_requests'][] = $ctx;
    if (count($data['recent_requests']) > 30) {
        $data['recent_requests'] = array_slice($data['recent_requests'], -30);
    }

    $data['count']++;

    if ($data['count'] > $limit) {
        $data['strikes'] = ($data['strikes'] ?? 0) + 1;

        if ($data['strikes'] === 1) {
            $block_duration = 5 * 60; // 5 min
            $title = 'Alert: suspicious traffic';
            $message = 'First strike. Blocked for 5 minutes.';
        } elseif ($data['strikes'] === 2) {
            $block_duration = 6 * 60 * 60; // 6 ore
            $title = 'Recurrence detected';
            $message = 'Second strike. Blocked for 6 hours.';
        } else {
            $block_duration = 24 * 60 * 60; // 24 ore (you can transform it to permanent)
            $title = 'Serious violation';
            $message = 'Third strike. Blocked for 24 hours.';
        }

        $reason = sprintf('Rate limit exceeded: %d requests in %d seconds.', intval($data['count']), intval($window_seconds));

        $recent = array_reverse($data['recent_requests']);
        $seen = [];
        $requests_for_log = [];
        foreach ($recent as $item) {
            $lbl = (string)($item['label'] ?? '');
            if ($lbl === '' || isset($seen[$lbl])) {
                continue;
            }
            $seen[$lbl] = true;
            $requests_for_log[] = [
                'time'  => intval($item['time'] ?? 0),
                'label' => $lbl,
            ];
            if (count($requests_for_log) >= 10) {
                break;
            }
        }

        set_transient($block_key, [
            'until'    => $now + $block_duration,
            'title'    => $title,
            'message'  => $message,
            'reason'   => $reason,
            'requests' => $requests_for_log,
        ], $block_duration);
        mangayummy_register_blocked_ip($remote_ip, $title, $message, $now + $block_duration, $reason, $requests_for_log);
        $data['count'] = 0;
        $data['started'] = $now;
        set_transient($rate_key, $data, $window_seconds);

        mangayummy_rate_limit_response(429, $block_duration, $title, $message);
        exit;
    }

    set_transient($rate_key, $data, $window_seconds);
}

function mangayummy_register_blocked_ip($ip, $title, $message, $until, $reason = '', $requests = []) {
    $blocked = get_option('mangayummy_blocked_ips', []);
    if (!is_array($blocked)) {
        $blocked = [];
    }

    $normalized_requests = [];
    if (is_array($requests)) {
        foreach ($requests as $req) {
            if (is_array($req)) {
                $normalized_requests[] = [
                    'time'  => intval($req['time'] ?? 0),
                    'label' => sanitize_text_field($req['label'] ?? ''),
                ];
            } elseif (is_string($req)) {
                $normalized_requests[] = [
                    'time'  => time(),
                    'label' => sanitize_text_field($req),
                ];
            }
        }
    }

    $blocked[$ip] = [
        'ip' => $ip,
        'title' => $title,
        'message' => $message,
        'until' => $until,
        'updated' => time(),
        'reason' => sanitize_text_field((string) $reason),
        'requests' => $normalized_requests,
    ];
    update_option('mangayummy_blocked_ips', $blocked);
}

function mangayummy_unregister_blocked_ip($ip) {
    $blocked = get_option('mangayummy_blocked_ips', []);
    if (!is_array($blocked)) {
        return;
    }
    if (isset($blocked[$ip])) {
        unset($blocked[$ip]);
        update_option('mangayummy_blocked_ips', $blocked);
    }
    $block_key = 'mangayummy_block_' . md5($ip);
    delete_transient($block_key);
}

function mangayummy_rate_limit_response($status, $retry_after, $title, $message) {
    status_header($status);
    header('Retry-After: ' . intval($retry_after));
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . esc_html($title) . '</title><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>body{margin:0;background:#111;color:#eee;font-family:Arial,sans-serif;text-align:center;padding:30px;} .blocked-wrapper{max-width:600px;margin:0 auto;} h1{font-size:1.8rem;margin-bottom:0.5rem;} p{font-size:1.1rem;line-height:1.5;margin:0.5rem 0;} a{color:#13667a;word-break:break-all;} .blocked-img{max-width:100%;height:auto;border-radius:12px;box-shadow:0 0 14px rgba(0,0,0,0.5);} @media (max-width: 480px){body{padding:16px;} h1{font-size:1.4rem;} p{font-size:1rem;} .blocked-img{max-width:90%;}}</style></head><body><div class="blocked-wrapper">';
    echo '<h1>' . esc_html($title) . '</h1>';
    echo '<p>' . esc_html($message) . '</p>';
    echo '<p><em>Dacă problema persistă, scrie-ne pe Discord: <a href="https://discord.com/invite/cbpHyQ6Mhg" target="_blank" rel="noopener noreferrer">https://discord.com/invite/cbpHyQ6Mhg</a></em></p>';
    echo '<img class="blocked-img" src="' . esc_url(get_template_directory_uri() . '/assets/img/cat-kitty.gif') . '" alt="Pisică bea cafea" />';
    echo '</div></body></html>';
}

add_action('template_redirect', function() {
    if (is_singular('chapter') || preg_match('#^/manga/.+/.+#', $_SERVER['REQUEST_URI'] ?? '')) {
        mangayummy_rate_limit_check(50, 60);
    }
});

// Ensure chapter posts have their parent set to the manga and a proper slug
// Consolidated chapter save handler - single source of truth for parent and slug
function mangayummy_handle_chapter_save($post_id, $post, $update) {
    // Run only for chapters
    if ($post->post_type !== 'chapter') {
        return;
    }

    // Abort for any AJAX request (prevents recursion/infinite loading)
    if (defined('DOING_AJAX') && DOING_AJAX) {
        mangayummy_debug_log("mangapress: ABORT chapter_save for post {$post_id} (DOING_AJAX)");
        return;
    }

    // Abort if deleting/trashing (extra hardening)
    if ($post->post_status === 'trash' || $post->post_status === 'auto-draft' ||
        (defined('DOING_AJAX') && DOING_AJAX && isset($_POST['action']) && $_POST['action'] === 'delete-post')) {
        mangayummy_debug_log("mangapress: SKIP chapter_save for post {$post_id} (status={$post->post_status})");
        return;
    }

    // Avoid autosave and revisions
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    // Capability check
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Determine manga ID: prefer _manga_id meta, fallback to post_parent
    $manga_id = (int) get_post_meta($post_id, '_manga_id', true);
    if (empty($manga_id)) {
        $manga_id = (int) $post->post_parent;
    }

    $update_args = array('ID' => $post_id);
    $need_update = false;

    // Set post_parent if needed
    if (!empty($manga_id) && (int) $post->post_parent !== (int) $manga_id) {
        $update_args['post_parent'] = (int) $manga_id;
        $need_update = true;
    }

    // Handle slug setting - single source of truth
    $current_slug = $post->post_name;
    $new_slug = null;

    // Get chapter number (prefer _chapter_number, fallback to chapter_number)
    $chapter_number = get_post_meta($post_id, '_chapter_number', true);
    if (!isset($chapter_number) || $chapter_number === '') {
        $chapter_number = get_post_meta($post_id, 'chapter_number', true);
    }

    if (isset($chapter_number) && $chapter_number !== '') {
        // Normalize chapter number and create proper slug
        $normalized_number = mangayummy_normalize_chapter_number($chapter_number);
        $base_slug = 'capitolul-' . $normalized_number;

        // Ensure chapter gets a static prefix
        $prefix = get_post_meta($post_id, 'mangayummy_slug_prefix', true);
        if (empty($prefix)) {
            $prefix = mangayummy_generate_slug_prefix();
            update_post_meta($post_id, 'mangayummy_slug_prefix', $prefix);
        }

        $new_slug = $prefix . '-' . $base_slug;

        // Update if slug is wrong or temp
        if ($current_slug !== $new_slug) {
            $update_args['post_name'] = $new_slug;
            $need_update = true;
        }
    }

    if ($need_update) {

        // Remove this hook temporarily to prevent recursion
        remove_action('save_post', 'mangayummy_handle_chapter_save', 10);

        $res = wp_update_post($update_args, true);
        if (is_wp_error($res)) {
            mangayummy_debug_log('mangapress: wp_update_post error for post ' . $post_id . ' - ' . $res->get_error_message());
        } else {
            mangayummy_debug_log('mangapress: updated chapter post ' . $post_id . ' result=' . intval($res));
        }

        // Re-add the hook
        add_action('save_post', 'mangayummy_handle_chapter_save', 10, 3);
    } else {
        mangayummy_debug_log("mangapress: no_update_needed for chapter {$post_id} (post_name={$post->post_name})");
    }
}
add_action('save_post', 'mangayummy_handle_chapter_save', 10, 3);

// Set chapter parent via wp_insert_post_data (runs on insert and update) - NO SLUG SETTING HERE
function mangayummy_wp_insert_post_data($data, $postarr) {
    $post_type = isset($postarr['post_type']) ? $postarr['post_type'] : (isset($data['post_type']) ? $data['post_type'] : '');
    if ($post_type !== 'chapter') {
        return $data;
    }

    // set post_parent from _manga_id (meta_input / POST / existing meta)
    $manga_id = 0;
    if (!empty($postarr['meta_input']['_manga_id'])) {
        $manga_id = (int) $postarr['meta_input']['_manga_id'];
    } elseif (!empty($_POST['_manga_id'])) {
        $manga_id = (int) $_POST['_manga_id'];
    } elseif (!empty($postarr['ID'])) {
        $manga_id = (int) get_post_meta($postarr['ID'], '_manga_id', true);
    }
    if (!empty($manga_id)) {
        $data['post_parent'] = $manga_id;
    }

    return $data;
}
add_filter('wp_insert_post_data', 'mangayummy_wp_insert_post_data', 10, 2);



// Ensure manga posts have a slug (post_name) on save
function mangayummy_ensure_manga_slug_on_save($post_id, $post, $update) {

    if ($post->post_type !== 'manga') {
        return;
    }
    // Abort for any AJAX request (prevents recursion/infinite loading)
    if (defined('DOING_AJAX') && DOING_AJAX) {
        mangayummy_debug_log("mangapress: ABORT ensure_manga_slug_on_save for post {$post_id} (DOING_AJAX)");
        return;
    }
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $current_slug = $post->post_name;

    $prefix = get_post_meta($post_id, 'mangayummy_slug_prefix', true);
    if (empty($prefix)) {
        $prefix = mangayummy_generate_slug_prefix();
        update_post_meta($post_id, 'mangayummy_slug_prefix', $prefix);
    }

    $base_slug = sanitize_title(get_the_title($post_id));
    if (empty($base_slug)) {
        return;
    }

    $desired_slug = $prefix . '-' . $base_slug;

    if ($current_slug !== $desired_slug) {
        remove_action('save_post', 'mangayummy_ensure_manga_slug_on_save', 10);
        wp_update_post(array('ID' => $post_id, 'post_name' => $desired_slug));
        add_action('save_post', 'mangayummy_ensure_manga_slug_on_save', 10, 3);
    }
}
add_action('save_post', 'mangayummy_ensure_manga_slug_on_save', 10, 3);

// One-time migration: ensure all existing manga/chapter posts get random 5-char prefix and permalinks are updated.
function mangayummy_migrate_slug_prefixes() {
    if ( get_option( 'mangayummy_slug_prefix_migrated' ) ) {
        return;
    }

    $post_types = array( 'manga', 'chapter' );

    $query = new WP_Query(
        array(
            'post_type' => $post_types,
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'fields' => 'ids',
        )
    );

    if ( $query->have_posts() ) {
        foreach ( $query->posts as $pid ) {
            $post = get_post( $pid );
            if ( ! $post ) {
                continue;
            }

            $prefix = get_post_meta( $pid, 'mangayummy_slug_prefix', true );
            if ( empty( $prefix ) ) {
                $prefix = mangayummy_generate_slug_prefix();
                update_post_meta( $pid, 'mangayummy_slug_prefix', $prefix );
            }

            if ( $post->post_type === 'manga' ) {
                $base_slug = sanitize_title( get_the_title( $pid ) );
            } else {
                $chapter_number = get_post_meta( $pid, '_chapter_number', true );
                if ( empty( $chapter_number ) ) {
                    $chapter_number = get_post_meta( $pid, 'chapter_number', true );
                }

                if ( ! empty( $chapter_number ) ) {
                    $base_slug = 'capitolul-' . mangayummy_normalize_chapter_number( $chapter_number );
                } else {
                    $base_slug = sanitize_title( get_the_title( $pid ) );
                }
            }

            if ( empty( $base_slug ) ) {
                continue;
            }

            $desired_slug = $prefix . '-' . $base_slug;
            if ( $post->post_name !== $desired_slug ) {
                wp_update_post( array(
                    'ID' => $pid,
                    'post_name' => $desired_slug,
                ) );
            }
        }
    }

    update_option( 'mangayummy_slug_prefix_migrated', 1 );
}
add_action( 'admin_init', 'mangayummy_migrate_slug_prefixes', 5 );

// Resolve incoming /manga/{manga-slug}/{chapter-slug} requests to correct chapter post
add_action('parse_request', function($wp) {
    if (empty($_SERVER['REQUEST_URI'])) {
        return;
    }

    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $path = trim($path, '/');

    if (!preg_match('#^manga/([^/]+)/([^/]+)/?$#i', $path, $m)) {
        return;
    }

    $manga_slug = sanitize_title($m[1]);
    $chapter_slug = sanitize_title($m[2]);

    // Find manga by slug
    $manga = get_page_by_path($manga_slug, OBJECT, 'manga');
    if (!$manga) {
        return;
    }
    $manga_id = $manga->ID;

    // Try to find chapter by _manga_id meta and post_name
    $args = array(
        'post_type' => 'chapter',
        'name' => $chapter_slug,
        'posts_per_page' => 1,
        'post_status' => 'publish',
        'meta_query' => array(array('key' => '_manga_id', 'value' => $manga_id)),
    );
    $posts = get_posts($args);

    if (empty($posts)) {
        // Fallback: try by post_parent
        $args = array(
            'post_type' => 'chapter',
            'name' => $chapter_slug,
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post_parent' => $manga_id,
        );
        $posts = get_posts($args);
    }

    if (empty($posts)) {
        // Final fallback: search by meta that contains manga id in any way
        $args = array(
            'post_type' => 'chapter',
            'name' => $chapter_slug,
            'posts_per_page' => 1,
            'post_status' => 'publish',
        );
        $posts = get_posts($args);
        if (!empty($posts)) {
            // ensure found post is associated with this manga
            $candidate = $posts[0];
            $candidate_manga = get_post_meta($candidate->ID, '_manga_id', true) ?: $candidate->post_parent;
            if ((int)$candidate_manga !== (int)$manga_id) {
                return;
            }
        }
    }

    if (!empty($posts)) {
        $chapter = $posts[0];
        // Rewrite WP query to point to this chapter
        $wp->query_vars = array('p' => $chapter->ID, 'post_type' => 'chapter');
    }
}, 1);

// Create Manga listing pages if they don't exist
function mangayummy_create_unavailable_page() {
    // Șterge pagina /manga-unavailable/ 
    $query = new WP_Query([
        'post_type' => 'page',
        'name' => 'manga-unavailable',
        'posts_per_page' => 1
    ]);
    $page = $query->posts ? $query->posts[0] : null;
    if ($page) {
        wp_delete_post($page->ID, true);
    }
}
add_action('wp_loaded', 'mangayummy_create_unavailable_page');
// Apelează și pe admin_init pentru creare automată chiar dacă tema e deja activată
// add_action('admin_init', 'mangayummy_create_manga_listing_pages');

// Register taxonomies on init with high priority
add_action('init', function() {
    // Translator Groups - register first
    register_taxonomy('translator_group', 'chapter', array(
        'labels' => array(
            'name' => 'Grupuri Traducători',
            'singular_name' => 'Grup Traducător',
        ),
        'public' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => [
            'slug' => 'translator',
            'with_front' => false,
            'hierarchical' => false
        ],
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
    ));

    // Force flush rewrite rules once (remove after testing)
    // Commented out to avoid conflicts with other taxonomies
    // if (!get_option('translator_group_rewrites_flushed_3')) {
    //     flush_rewrite_rules(false);
    //     update_option('translator_group_rewrites_flushed_3', 1);
    // }

    // Register Genre taxonomy for manga
    register_taxonomy('genre', 'manga', array(
        'labels' => array(
            'name' => 'Genres',
            'singular_name' => 'Genre',
        ),
        'public' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'gen', 'hierarchical' => false),
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
        'hierarchical' => true,
    ));

    // Register Author taxonomy for manga
    register_taxonomy('author', 'manga', array(
        'labels' => array(
            'name' => 'Authors',
            'singular_name' => 'Author',
        ),
        'public' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'autor'),
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
        'hierarchical' => false,
    ));

    // Register Artist taxonomy for manga
    register_taxonomy('artist', 'manga', array(
        'labels' => array(
            'name' => 'Artists',
            'singular_name' => 'Artist',
        ),
        'public' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'artist'),
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,
        'hierarchical' => false,
    ));
}, 10); // Changed from priority 0 to avoid conflicts

// Register Navigation Menus
function mangayummy_register_menus() {
    register_nav_menus(array(
        'primary' => 'Primary Menu',
        'footer' => 'Footer Menu'
    ));
}
add_action('init', 'mangayummy_register_menus');

// Add rewrite rules for reader profiles
function mangayummy_add_rewrite_rules() {
    add_rewrite_rule('^reader/([^/]+)/?$', 'index.php?reader_username=$matches[1]', 'top');
    add_rewrite_rule('^users/([0-9]+)/?$', 'index.php?pagename=profile&view_user=$matches[1]', 'top');
}
add_action('init', 'mangayummy_add_rewrite_rules');

// Register query vars for user profiles
add_filter('query_vars', function($vars) {
    $vars[] = 'view_user';
    return $vars;
});

// Add rewrite rule for chapter permalinks: /manga/{manga-slug}/{chapter-slug}
add_action('init', function() {
    add_rewrite_rule('^manga/([^/]+)/([^/]+)/?$', 'index.php?post_type=chapter&name=$matches[2]', 'top');
}, 11);

// Match manga/chapter URL style to the global Permalinks trailing-slash setting.
function mangayummy_permalink_has_trailing_slash() {
    $structure = (string) get_option('permalink_structure');
    if ($structure === '') {
        return true;
    }

    return substr($structure, -1) === '/';
}

function mangayummy_apply_permalink_slash_policy($url) {
    if (!is_string($url) || $url === '') {
        return $url;
    }

    $parts = wp_parse_url($url);
    if (!is_array($parts) || empty($parts['path']) || $parts['path'] === '/') {
        return $url;
    }

    $parts['path'] = mangayummy_permalink_has_trailing_slash()
        ? trailingslashit($parts['path'])
        : untrailingslashit($parts['path']);

    $rebuilt = '';
    if (!empty($parts['scheme'])) {
        $rebuilt .= $parts['scheme'] . '://';
    }
    if (!empty($parts['user'])) {
        $rebuilt .= $parts['user'];
        if (isset($parts['pass'])) {
            $rebuilt .= ':' . $parts['pass'];
        }
        $rebuilt .= '@';
    }
    if (!empty($parts['host'])) {
        $rebuilt .= $parts['host'];
    }
    if (!empty($parts['port'])) {
        $rebuilt .= ':' . $parts['port'];
    }

    $rebuilt .= $parts['path'];

    if (isset($parts['query']) && $parts['query'] !== '') {
        $rebuilt .= '?' . $parts['query'];
    }
    if (isset($parts['fragment']) && $parts['fragment'] !== '') {
        $rebuilt .= '#' . $parts['fragment'];
    }

    return $rebuilt;
}

// Generate permalinks for chapter posts using parent manga slug + sanitized title
function mangayummy_chapter_post_link($post_link, $post) {
    if ($post->post_type !== 'chapter') {
        return $post_link;
    }

    // Identify parent manga: prefer _manga_id meta, fallback to post_parent
    $manga_id = get_post_meta($post->ID, '_manga_id', true);
    if (empty($manga_id)) {
        $manga_id = $post->post_parent;
    }

    if (empty($manga_id)) {
        return $post_link; // can't build custom permalink without parent
    }

    $manga_slug = get_post_field('post_name', $manga_id);
    $manga_prefix = get_post_meta($manga_id, 'mangayummy_slug_prefix', true);
    if (empty($manga_prefix) && !empty($manga_slug)) {
        // For legacy posts where prefix may not exist yet, fall back to slug part
        $manga_prefix = explode('-', $manga_slug)[0];
    }

    // Prefer stored post_name for chapter; if empty, use helper to obtain chapter number
    $chapter_slug = get_post_field('post_name', $post->ID);
    $chapter_prefix = get_post_meta($post->ID, 'mangayummy_slug_prefix', true);
    if (empty($chapter_prefix) && !empty($chapter_slug)) {
        $chapter_prefix = explode('-', $chapter_slug)[0];
    }
    if (empty($chapter_slug)) {
        $num = mangayummy_get_chapter_number($post->ID);
        if ($num !== null) {
            // Use consistent normalization
            $slug_num = mangayummy_normalize_chapter_number($num);
            $chapter_slug = sanitize_title('capitolul-' . $slug_num);
        } else {
            // No chapter number available: do not fallback to post ID (avoid ID-based slugs)
            return $post_link;
        }
    }

    if (empty($manga_slug) || empty($chapter_slug)) {
        return $post_link;
    }

    $url = home_url('/manga/' . $manga_slug . '/' . $chapter_slug);
    return mangayummy_apply_permalink_slash_policy($url);
}
add_filter('post_type_link', 'mangayummy_chapter_post_link', 10, 2);

function mangayummy_manga_post_link($post_link, $post) {
    if ($post->post_type !== 'manga') {
        return $post_link;
    }

    $manga_slug = get_post_field('post_name', $post->ID);
    if (empty($manga_slug)) {
        return $post_link;
    }

    $url = home_url('/manga/' . $manga_slug);
    return mangayummy_apply_permalink_slash_policy($url);
}
add_filter('post_type_link', 'mangayummy_manga_post_link', 10, 2);

add_action('template_redirect', function() {
    if (!is_singular('chapter') && !is_singular('manga')) {
        return;
    }

    global $post;
    if (!$post) return;

    // Requested URL (without query string)
    $requested = home_url(add_query_arg(array(),"{$_SERVER['REQUEST_URI']}"));
    $requested = strtok($requested, '?');

    // Desired canonical permalink (uses our post_type_link filter)
    $desired = get_permalink($post->ID);
    $desired = strtok($desired, '?');

    if (untrailingslashit($requested) !== untrailingslashit($desired)) {
        wp_redirect($desired, 301);
        exit;
    }
});

// Keep canonical redirects aligned with custom manga/chapter permalink style.
add_filter('redirect_canonical', function($redirect_url, $requested_url) {
    if (!is_string($redirect_url) || $redirect_url === '') {
        return $redirect_url;
    }

    $request_path = (string) parse_url((string) $requested_url, PHP_URL_PATH);
    if (!preg_match('#^/manga/[^/]+(?:/[^/]+)?/?$#i', $request_path)) {
        return $redirect_url;
    }

    return mangayummy_apply_permalink_slash_policy($redirect_url);
}, 10, 2);

// Prevent forced trailing slash for manga/chapter URLs when permalink setting is slashless.
add_filter('user_trailingslashit', function($url, $type_of_url) {
    if (!is_string($url) || $url === '') {
        return $url;
    }

    $path = (string) parse_url($url, PHP_URL_PATH);
    if (!preg_match('#^/manga/[^/]+(?:/[^/]+)?/?$#i', $path)) {
        return $url;
    }

    return mangayummy_apply_permalink_slash_policy($url);
}, 10, 2);

// Flush rewrite rules when function is updated
add_action('init', function() {
    $wp_rewrite = $GLOBALS['wp_rewrite'];
    if (!isset($wp_rewrite->rewrite_rules['users/'])) {
        flush_rewrite_rules(false);
    }
}, 99);

// Create "Browse" page if it doesn't exist
function mangayummy_create_search_page() {
    // Skip if already checked (performance optimization)
    if (get_option('mangayummy_search_page_created')) {
        return;
    }
    
    $page_slug = 'browse';
    $page_title = 'Browse';
    
    // Check if page already exists using WP_Query
    $query = new WP_Query([
        'post_type' => 'page',
        'name' => $page_slug,
        'posts_per_page' => 1,
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    ]);
    $existing_page = $query->posts ? $query->posts[0] : null;

    // Backward compatibility: migrate legacy advanced-search page slug to /browse/.
    if (!$existing_page) {
        $legacy_query = new WP_Query([
            'post_type' => 'page',
            'name' => 'cautare-avansata',
            'posts_per_page' => 1,
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false
        ]);
        $existing_page = $legacy_query->posts ? $legacy_query->posts[0] : null;
    }
    
    if ($existing_page && $existing_page->post_status === 'publish') {
        update_option('mangayummy_search_page_created', true);
        return; // Page already exists and is published
    }
    
    // Create the page
    $page_data = array(
        'post_title'    => $page_title,
        'post_name'     => $page_slug,
        'post_content'  => '', // Empty, template will handle it
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );
    
    // If page exists but not published, update it
    if ($existing_page) {
        $page_data['ID'] = $existing_page->ID;
        wp_update_post($page_data);
    } else {
        $page_id = wp_insert_post($page_data);
    }
    
    // Mark as created
    update_option('mangayummy_search_page_created', true);
}

function mangayummy_register_stiri_cpt() {
    $labels = array(
        'name'               => 'News',
        'singular_name'      => 'News',
        'menu_name'          => 'News',
        'name_admin_bar'     => 'News',
        'add_new'            => 'Add News',
        'add_new_item'       => 'Add New News',
        'new_item'           => 'New News',
        'edit_item'          => 'Edit News',
        'view_item'          => 'View News',
        'all_items'          => 'All News',
        'search_items'       => 'Search News',
        'not_found'          => 'No News found',
        'not_found_in_trash' => 'No News found in Trash',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-megaphone',
        'supports'           => array('title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions', 'comments'),
        'has_archive'        => false,
        'rewrite'            => array('slug' => 'stire'),
        'show_in_rest'       => true,
    );

    register_post_type('stire', $args);
}
add_action('init', 'mangayummy_register_stiri_cpt', 5);

function mangayummy_user_can_edit_stire($post_id) {
    $post_id = intval($post_id);
    if ($post_id <= 0 || !is_user_logged_in()) {
        return false;
    }

    $current_user_id = get_current_user_id();
    $post_author_id = intval(get_post_field('post_author', $post_id));
    $stire_author_id = intval(get_post_meta($post_id, '_stire_author_id', true));

    if ($current_user_id === $post_author_id || $current_user_id === $stire_author_id) {
        return true;
    }

    return current_user_can('edit_post', $post_id);
}

function mangayummy_get_stire_number($post_id) {
    $post_id = intval($post_id);
    if ($post_id <= 0) {
        return 0;
    }
    $stire_number = get_post_meta($post_id, 'stire_number', true);
    if ($stire_number) {
        return intval($stire_number);
    }

    global $wpdb;
    $max_number = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT MAX(CAST(meta_value AS UNSIGNED)) FROM {$wpdb->postmeta} WHERE meta_key = %s",
        'stire_number'
    ));

    $next_number = $max_number + 1;
    update_post_meta($post_id, 'stire_number', $next_number);
    return $next_number;
}

function mangayummy_save_stire_number($post_id, $post, $update) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (wp_is_post_revision($post_id)) {
        return;
    }
    if ('stire' !== $post->post_type) {
        return;
    }
    if (get_post_meta($post_id, 'stire_number', true)) {
        return;
    }
    mangayummy_get_stire_number($post_id);
}
add_action('save_post_stire', 'mangayummy_save_stire_number', 10, 3);

function mangayummy_stire_permalink($post_link, $post, $leavename, $sample) {
    if ('stire' !== $post->post_type || empty($post->ID)) {
        return $post_link;
    }

    $number = mangayummy_get_stire_number($post->ID);
    if ($number <= 0) {
        return $post_link;
    }

    return home_url('/stire/' . $number . '/');
}
add_filter('post_type_link', 'mangayummy_stire_permalink', 10, 4);

function mangayummy_add_stire_rewrite_rule() {
    add_rewrite_rule('^stire/([0-9]+)/?$', 'index.php?post_type=stire&stire_number=$matches[1]', 'top');
}
add_action('init', 'mangayummy_add_stire_rewrite_rule', 11);

add_filter('query_vars', function($vars) {
    $vars[] = 'stire_number';
    return $vars;
});

function mangayummy_stire_number_request($vars) {
    if (!empty($vars['stire_number']) && empty($vars['p'])) {
        global $wpdb;
        $number = intval($vars['stire_number']);
        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
            'stire_number',
            $number
        ));

        if ($post_id) {
            $vars['p'] = intval($post_id);
            $vars['post_type'] = 'stire';
            unset($vars['stire_number']);
        }
    }
    return $vars;
}
add_filter('request', 'mangayummy_stire_number_request');

function mangayummy_flush_stire_rewrite_rules_once() {
    if (!get_option('mangayummy_stire_rewrite_rules_flushed')) {
        flush_rewrite_rules(false);
        update_option('mangayummy_stire_rewrite_rules_flushed', 1);
    }
}
add_action('admin_init', 'mangayummy_flush_stire_rewrite_rules_once');

function mangayummy_register_stiri_category_taxonomy() {
    $labels = array(
        'name'              => 'News Categories',
        'singular_name'     => 'News Category',
        'search_items'      => 'Search Categories',
        'all_items'         => 'All Categories',
        'edit_item'         => 'Edit Category',
        'update_item'       => 'Update Category',
        'add_new_item'      => 'Add New Category',
        'new_item_name'     => 'New Category Name',
        'menu_name'         => 'News Categories',
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'stiri-category'),
        'show_in_rest'      => true,
    );

    register_taxonomy('stiri_category', array('stire'), $args);
}
add_action('init', 'mangayummy_register_stiri_category_taxonomy', 6);

function mangayummy_create_stiri_categories() {
    $terms = array(
        'site' => 'Site',
        'anime' => 'Anime',
        'manga' => 'Manga',
        'articles' => 'Articles',
        'interview' => 'Interview',
    );
    foreach ($terms as $slug => $name) {
        if (!term_exists($slug, 'stiri_category')) {
            wp_insert_term($name, 'stiri_category', array('slug' => $slug));
        }
    }
}
add_action('init', 'mangayummy_create_stiri_categories', 7);

// Create page on init (with option check for performance)
add_action('init', 'mangayummy_create_search_page', 20);
add_action('init', 'mangayummy_create_stiri_page', 20);

function mangayummy_create_stiri_page() {
    if (get_option('mangayummy_stiri_page_created')) {
        return;
    }

    $page_slug = 'news';
    $page_title = 'News';

    $query = new WP_Query([
        'post_type' => 'page',
        'name' => $page_slug,
        'posts_per_page' => 1,
        'no_found_rows' => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    ]);
    $existing_page = $query->posts ? $query->posts[0] : null;

    if ($existing_page && $existing_page->post_status === 'publish') {
        update_option('mangayummy_stiri_page_created', true);
        return;
    }

    $page_data = array(
        'post_title'    => $page_title,
        'post_name'     => $page_slug,
        'post_content'  => '',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
    );

    if ($existing_page) {
        $page_data['ID'] = $existing_page->ID;
        wp_update_post($page_data);
    } else {
        wp_insert_post($page_data);
    }

    update_option('mangayummy_stiri_page_created', true);
}

function mangayummy_create_creaza_stire_page() {
    if (get_option('mangayummy_creaza_stire_page_created')) {
        return;
    }

    // Find parent news page
    $stiri_page = get_page_by_path('news');
    $parent_id = $stiri_page ? $stiri_page->ID : 0;

    $page_slug = 'create';
    $full_path = $parent_id ? 'news/create' : 'create';

    $query = new WP_Query([
        'post_type'              => 'page',
        'name'                   => $page_slug,
        'posts_per_page'         => 1,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'post_parent'            => $parent_id,
    ]);
    $existing_page = $query->posts ? $query->posts[0] : null;

    if ($existing_page && $existing_page->post_status === 'publish') {
        // Ensure template is set
        if (get_post_meta($existing_page->ID, '_wp_page_template', true) !== 'page-creaza.php') {
            update_post_meta($existing_page->ID, '_wp_page_template', 'page-creaza.php');
        }
        update_option('mangayummy_creaza_stire_page_created', true);
        return;
    }

    $page_data = array(
        'post_title'    => 'Create News',
        'post_name'     => $page_slug,
        'post_content'  => '',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        'post_author'   => 1,
        'post_parent'   => $parent_id,
    );

    if ($existing_page) {
        $page_data['ID'] = $existing_page->ID;
        $page_id = wp_update_post($page_data);
    } else {
        $page_id = wp_insert_post($page_data);
    }

    if ($page_id && !is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'page-creaza.php');
    }

    update_option('mangayummy_creaza_stire_page_created', true);
}
add_action('init', 'mangayummy_create_creaza_stire_page', 25);

// Catch /news/create directly and load page-creaza.php template
add_action('template_redirect', function() {
    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';
    $path = strtok($request_uri, '?');
    $path = trim($path, '/');

    if ($path === 'stiri/creaza') {
        wp_redirect(home_url('/news/create/'), 301);
        exit;
    }

    if ($path === 'news/create' || $path === 'news/create/') {
        // Redirect guests
        if (!is_user_logged_in()) {
            wp_redirect(home_url('/news/?notif=login'));
            exit;
        }

        global $wp_query, $post;
        if (isset($wp_query)) {
            $wp_query->is_404 = false;
            $wp_query->is_page = true;
            status_header(200);
        }

        $query = new WP_Query([
            'post_type'   => 'page',
            'name'        => 'create',
            'posts_per_page' => 1,
        ]);
        $post = $query->posts ? $query->posts[0] : null;
        if ($post) {
            setup_postdata($post);
        }

        $template = locate_template('page-creaza.php');
        if ($template) {
            load_template($template);
            exit;
        }
    }
}, 1);

// Show bottom-right toast when ?notif=login is present
add_action('wp_footer', function() {
    $notif = isset($_GET['notif']) ? sanitize_key($_GET['notif']) : '';
    if ($notif !== 'login') return;
    ?>
    <script>
    (function() {
        var t = document.createElement('div');
        t.className = 'ya-toast';
        t.style.cssText = 'background:rgba(231,76,60,0.96);color:#fff1f0;';
        t.innerHTML = '<i class="fa fa-lock" style="margin-right:8px;"></i>Trebuie să fii logat pentru a adăuga o știre.';
        document.body.appendChild(t);
        setTimeout(function() { t.style.opacity = '0'; t.style.transition = 'opacity 0.4s'; setTimeout(function(){ t.remove(); }, 400); }, 4000);
    })();
    </script>
    <?php
}, 20);

// Catch /browse/ directly and load template if page doesn't exist
add_action('template_redirect', function() {
    // Check if URL is /browse/ or /browse/?...
    global $wp;

    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';

    // Redirect legacy URL to the new browse URL and keep query string.
    if ((isset($wp->query_vars['pagename']) && $wp->query_vars['pagename'] === 'cautare-avansata') || strpos($request_uri, '/cautare-avansata') === 0) {
        $target = home_url('/browse/');
        if (!empty($_SERVER['QUERY_STRING'])) {
            $target .= '?' . sanitize_text_field($_SERVER['QUERY_STRING']);
        }
        wp_safe_redirect($target, 301);
        exit;
    }
    
    if (isset($wp->query_vars['pagename']) && $wp->query_vars['pagename'] === 'browse') {
        // Load the template directly and ensure the page is not treated as 404/search.
        global $wp_query;
        if (isset($wp_query)) {
            $wp_query->is_404 = false;
            $wp_query->is_search = false;
            status_header(200);
        }
        $template = locate_template('page-cautare-avansata.php');
        if ($template) {
            load_template($template);
            exit;
        }
    }
    
    // Alternative: check request URI directly
    if (strpos($request_uri, '/browse') === 0) {
        $template = locate_template('page-cautare-avansata.php');
        if ($template) {
            // Ensure page is served as a normal page even when query string includes search params.
            global $wp_query, $post;
            if (isset($wp_query)) {
                $wp_query->is_404 = false;
                $wp_query->is_search = false;
                status_header(200);
            }
            
            // Set up globals for template
            $query = new WP_Query([
                'post_type' => 'page',
                'name' => 'browse',
                'posts_per_page' => 1
            ]);
            $post = $query->posts ? $query->posts[0] : null;
            
            if ($post) {
                setup_postdata($post);
            }
            
            load_template($template);
            exit;
        }
    }

    $request_path = parse_url($request_uri, PHP_URL_PATH);
    $request_path = is_string($request_path) ? $request_path : '';
    if (strpos($request_path, '/stiri') === 0) {
        $suffix = ltrim(substr($request_path, strlen('/stiri')), '/');
        $target = home_url('/news/' . $suffix);
        $target = untrailingslashit($target) . '/';
        if (!empty($_SERVER['QUERY_STRING'])) {
            $target .= '?' . sanitize_text_field($_SERVER['QUERY_STRING']);
        }
        wp_safe_redirect($target, 301);
        exit;
    }

    if (strpos($request_uri, '/news') === 0) {
        $template = locate_template('page-stiri.php');
        if ($template) {
            global $wp_query, $post;
            if (isset($wp_query)) {
                $wp_query->is_404 = false;
                $wp_query->is_search = false;
                status_header(200);
            }
            
            $query = new WP_Query([
                'post_type' => 'page',
                'name' => 'news',
                'posts_per_page' => 1
            ]);
            $post = $query->posts ? $query->posts[0] : null;
            
            if ($post) {
                setup_postdata($post);
            }
            
            load_template($template);
            exit;
        }
    }
}, 1); // Very high priority to catch before 404

// Add query var for reader username
function mangayummy_add_query_vars($vars) {
    $vars[] = 'reader_username';
    return $vars;
}
add_filter('query_vars', 'mangayummy_add_query_vars');

// Handle reader profile template
function mangayummy_reader_profile_template($template) {
    if (get_query_var('reader_username')) {
        $user = get_user_by('login', get_query_var('reader_username'));
        if ($user) {
            $new_template = locate_template(array('reader-profile.php'));
            if ($new_template) {
                return $new_template;
            }
        }
        // If user not found, return 404
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        return get_404_template();
    }
    
    // Handle translator group page
    if (get_query_var('translator_group')) {
        $new_template = locate_template(array('translator-group.php'));
        if ($new_template) {
            return $new_template;
        }
    }
    
    return $template;
}
add_filter('template_include', 'mangayummy_reader_profile_template');

// Customizer Options
function mangayummy_customizer($wp_customize) {
    // Logo
    $wp_customize->add_setting('mangayummy_logo');
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mangayummy_logo', array(
        'label' => 'Logo',
        'section' => 'title_tagline',
    )));

    // Colors
    $wp_customize->add_section('mangayummy_colors', array(
        'title' => 'MangaYummy Colors',
        'priority' => 30,
    ));

    $wp_customize->add_setting('primary_color', array('default' => '#13667a'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label' => 'Primary Color',
        'section' => 'mangayummy_colors',
    )));

    $wp_customize->add_setting('background_pattern_color', array(
        'default' => '#1b1d22',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'background_pattern_color', array(
        'label' => 'Background Color (fallback)',
        'section' => 'mangayummy_colors',
    )));

    $wp_customize->add_setting('custom_background_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'custom_background_image', array(
        'label' => 'Custom Background Image',
        'section' => 'mangayummy_colors',
    )));

    $wp_customize->add_setting('show_main_background_pattern', array(
        'default' => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('show_main_background_pattern', array(
        'label' => 'Show background image',
        'section' => 'mangayummy_colors',
        'type' => 'checkbox',
    ));

    // Footer contact section
    $wp_customize->add_section('mangayummy_footer_contact', array(
        'title'    => 'Footer Contact',
        'priority' => 61,
    ));

    // Front page section visibility controls
    $wp_customize->add_section('mangayummy_frontpage_sections', array(
        'title'       => 'Front Page Sections',
        'description' => 'Show or hide front-page blocks.',
        'priority'    => 62,
    ));

    $wp_customize->add_setting('mangayummy_show_popular_updates', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('mangayummy_show_popular_updates', array(
        'label'   => 'Show Popular Updates',
        'section' => 'mangayummy_frontpage_sections',
        'type'    => 'checkbox',
    ));

    $wp_customize->add_setting('mangayummy_show_latest_releases', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('mangayummy_show_latest_releases', array(
        'label'   => 'Show Latest Releases',
        'section' => 'mangayummy_frontpage_sections',
        'type'    => 'checkbox',
    ));

    $wp_customize->add_setting('mangayummy_show_recently_added', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('mangayummy_show_recently_added', array(
        'label'   => 'Show Recently Added',
        'section' => 'mangayummy_frontpage_sections',
        'type'    => 'checkbox',
    ));

    $wp_customize->add_setting('mangayummy_show_frontpage_news', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('mangayummy_show_frontpage_news', array(
        'label'   => 'Show News',
        'section' => 'mangayummy_frontpage_sections',
        'type'    => 'checkbox',
    ));

    $wp_customize->add_setting('mangayummy_show_latest_comments', array(
        'default'           => 1,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('mangayummy_show_latest_comments', array(
        'label'   => 'Show Latest Comments',
        'section' => 'mangayummy_frontpage_sections',
        'type'    => 'checkbox',
    ));

    // About page section
    $wp_customize->add_section('mangayummy_about_page', array(
        'title'       => 'About Site Content',
        'description' => 'Customize content shown in the About Site page.',
        'priority'    => 63,
    ));

    $wp_customize->add_setting('mangayummy_about_title', array(
        'default'           => 'About Us',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_about_title', array(
        'label'   => 'About title',
        'section' => 'mangayummy_about_page',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('mangayummy_about_tab_label', array(
        'default'           => 'About',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_about_tab_label', array(
        'label'       => 'Main About tab label',
        'description' => 'Leave empty to hide the main About tab.',
        'section'     => 'mangayummy_about_page',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('mangayummy_about_desc_1', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('mangayummy_about_desc_1', array(
        'label'   => 'About paragraph 1',
        'section' => 'mangayummy_about_page',
        'type'    => 'textarea',
    ));

    $wp_customize->add_setting('mangayummy_about_desc_2', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('mangayummy_about_desc_2', array(
        'label'   => 'About paragraph 2',
        'section' => 'mangayummy_about_page',
        'type'    => 'textarea',
    ));

    $wp_customize->add_setting('mangayummy_about_desc_3', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('mangayummy_about_desc_3', array(
        'label'   => 'About paragraph 3',
        'section' => 'mangayummy_about_page',
        'type'    => 'textarea',
    ));

    // About tabs (user-managed)
    $wp_customize->add_setting('mangayummy_tab_contact_label', array(
        'default'           => 'Contact',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_tab_contact_label', array(
        'label'   => 'Contact tab label',
        'section' => 'mangayummy_about_page',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('mangayummy_tab_contact_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_tab_contact_title', array(
        'label'   => 'Contact tab title',
        'section' => 'mangayummy_about_page',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('mangayummy_tab_contact_content', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('mangayummy_tab_contact_content', array(
        'label'       => 'Contact tab content',
        'description' => 'Leave empty to hide this tab content.',
        'section'     => 'mangayummy_about_page',
        'type'        => 'textarea',
    ));

    $wp_customize->add_setting('mangayummy_tab_dmca_label', array(
        'default'           => 'DMCA',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_tab_dmca_label', array(
        'label'   => 'DMCA tab label',
        'section' => 'mangayummy_about_page',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('mangayummy_tab_dmca_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('mangayummy_tab_dmca_title', array(
        'label'   => 'DMCA tab title',
        'section' => 'mangayummy_about_page',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('mangayummy_tab_dmca_content', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('mangayummy_tab_dmca_content', array(
        'label'       => 'DMCA tab content',
        'description' => 'Leave empty to hide this tab content.',
        'section'     => 'mangayummy_about_page',
        'type'        => 'textarea',
    ));

    for ($tab_i = 1; $tab_i <= 6; $tab_i++) {
        $wp_customize->add_setting("mangayummy_tab_custom_{$tab_i}_label", array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("mangayummy_tab_custom_{$tab_i}_label", array(
            'label'   => "Custom tab {$tab_i} label",
            'section' => 'mangayummy_about_page',
            'type'    => 'text',
        ));

        $wp_customize->add_setting("mangayummy_tab_custom_{$tab_i}_title", array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("mangayummy_tab_custom_{$tab_i}_title", array(
            'label'   => "Custom tab {$tab_i} title",
            'section' => 'mangayummy_about_page',
            'type'    => 'text',
        ));

        $wp_customize->add_setting("mangayummy_tab_custom_{$tab_i}_content", array(
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ));
        $wp_customize->add_control("mangayummy_tab_custom_{$tab_i}_content", array(
            'label'       => "Custom tab {$tab_i} content",
            'description' => 'Leave empty to hide this tab content.',
            'section'     => 'mangayummy_about_page',
            'type'        => 'textarea',
        ));
    }

    $wp_customize->add_setting('mangayummy_footer_discord_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('mangayummy_footer_discord_url', array(
        'label'       => 'Discord URL',
        'description' => 'Ex: https://discord.gg/your-invite',
        'section'     => 'mangayummy_footer_contact',
        'type'        => 'url',
    ));

    $wp_customize->add_setting('mangayummy_footer_email', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('mangayummy_footer_email', array(
        'label'       => 'Support Email',
        'description' => 'Ex: support@example.com',
        'section'     => 'mangayummy_footer_contact',
        'type'        => 'email',
    ));

}
add_action('customize_register', 'mangayummy_customizer');

// Theme Support
function mangayummy_theme_support() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list'));
    
    // Load theme text domain for translations
    load_theme_textdomain('mangayummy', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'mangayummy_theme_support');

/**
 * Replace hardcoded accent color in frontend HTML with Customizer primary color.
 */
function mangayummy_replace_primary_color_in_output($html) {
    $primary_color = sanitize_hex_color(get_theme_mod('primary_color', '#13667a'));
    if (empty($primary_color)) {
        $primary_color = '#13667a';
    }

    if (strtolower($primary_color) === '#13667a') {
        return $html;
    }

    return str_ireplace('#13667a', $primary_color, $html);
}

function mangayummy_start_primary_color_output_buffer() {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
        return;
    }

    ob_start('mangayummy_replace_primary_color_in_output');
}
add_action('template_redirect', 'mangayummy_start_primary_color_output_buffer', 0);

function mangayummy_print_primary_color_css() {
    if (is_admin()) {
        return;
    }

    $primary_color = sanitize_hex_color(get_theme_mod('primary_color', '#13667a'));
    if (empty($primary_color)) {
        $primary_color = '#13667a';
    }

    $background_pattern_color = sanitize_hex_color(get_theme_mod('background_pattern_color', '#1b1d22'));
    if (empty($background_pattern_color)) {
        $background_pattern_color = '#1b1d22';
    }
    $show_main_pattern = (int) get_theme_mod('show_main_background_pattern', 1) === 1;
    $custom_background_image = esc_url_raw(get_theme_mod('custom_background_image', ''));
    $has_custom_background_image = !empty($custom_background_image);

    echo '<style id="mangayummy-primary-color-css">';
    echo '.ya-header{background:' . esc_attr($primary_color) . ' !important;border-top-color:' . esc_attr($primary_color) . ' !important;border-bottom-color:' . esc_attr($primary_color) . ' !important;}';
    echo '.section-dropdown-menu .dropdown-item.active{background:' . esc_attr($primary_color) . ' !important;}';
    echo 'html,body{background-color:' . esc_attr($background_pattern_color) . ' !important;}';
    echo '.bg-pattern{background-color:' . esc_attr($background_pattern_color) . ' !important;}';
    if (!$show_main_pattern || !$has_custom_background_image) {
        echo '.bg-pattern{display:none !important;background-image:none !important;}';
        echo 'html,body{background-image:none !important;}';
    }
    echo '</style>';
}
add_action('wp_head', 'mangayummy_print_primary_color_css', 120);

// Preserve WordPress responsive image behavior: do not override `srcset`/`sizes` here.

// Disable WordPress default comments for manga & chapter post types
function mangayummy_disable_default_comments() {
    remove_post_type_support('manga', 'comments');
    remove_post_type_support('chapter', 'comments');
    remove_post_type_support('manga', 'trackbacks');
    remove_post_type_support('chapter', 'trackbacks');
}
add_action('init', 'mangayummy_disable_default_comments');

/**
 * Register comment meta fields for REST API
 * Allows frontend to access _manga_id, _chapter_id, _chapter_title in API responses
 */
add_action('init', function () {
    register_meta('comment', '_manga_id', [
        'type'         => 'integer',
        'single'       => true,
        'show_in_rest' => true,
    ]);

    register_meta('comment', '_chapter_id', [
        'type'         => 'integer',
        'single'       => true,
        'show_in_rest' => true,
    ]);

    register_meta('comment', '_chapter_title', [
        'type'         => 'string',
        'single'       => true,
        'show_in_rest' => true,
    ]);

    register_meta('comment', '_chapter_number', [
        'type'         => 'integer',
        'single'       => true,
        'show_in_rest' => true,
    ]);
});

/**
 * ONE-TIME MIGRATION: Link existing chapter comments to parent manga
 * Safe script that runs only once and can be deleted after execution
 */
add_action('init', function () {
    // Only admins can trigger this
    if (!current_user_can('administrator')) {
        return;
    }

    // Check if migration already ran
    if (get_option('mangayummy_comments_migrated')) {
        return;
    }

    // Get all approved comments
    $comments = get_comments([
        'status' => 'approve',
        'number' => 0, // Get all
    ]);

    foreach ($comments as $comment) {
        // Skip if already has manga_id (already migrated)
        if (get_comment_meta($comment->comment_ID, '_manga_id', true)) {
            continue;
        }

        $post_id = $comment->comment_post_ID;

        // Only process comments on chapters
        if (get_post_type($post_id) !== 'chapter') {
            continue;
        }

        // Get manga ID from chapter post meta
        $manga_id = get_post_meta($post_id, '_manga_id', true);
        if (!$manga_id) {
            continue;
        }

        // Add chapter/manga metadata to comment
        add_comment_meta($comment->comment_ID, '_chapter_id', $post_id);
        add_comment_meta($comment->comment_ID, '_manga_id', $manga_id);
        add_comment_meta($comment->comment_ID, '_chapter_title', get_the_title($post_id));
        add_comment_meta($comment->comment_ID, '_chapter_number', get_post_meta($post_id, '_chapter_number', true));
    }

    // Mark migration as complete so it doesn't run again
    update_option('mangayummy_comments_migrated', 1);
});

// Filter: Disable comments from displaying on single-manga and single-chapter pages
function mangayummy_filter_comments_template($template) {
    if (is_singular(array('manga', 'chapter'))) {
        return '';
    }
    return $template;
}
add_filter('comments_template', 'mangayummy_filter_comments_template');

// Close comments by default for manga & chapter
function mangayummy_close_comments_by_default($open, $post_id) {
    $post = get_post($post_id);
    if ($post && in_array($post->post_type, ['manga', 'chapter'])) {
        return false;
    }
    return $open;
}
add_filter('comments_open', 'mangayummy_close_comments_by_default', 10, 2);


// Create translator groups page automatically
function mangayummy_create_translator_page() {
    // Check if page already exists
    $page_query = new WP_Query([
        'post_type' => 'page',
        'title' => 'Translator Groups',
        'posts_per_page' => 1
    ]);
    $page = $page_query->posts ? $page_query->posts[0] : null;
    
    if (!$page) {
        // Create the page
        $page_id = wp_insert_post([
            'post_title' => 'Translator Groups',
            'post_name' => 'translator-groups',
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => ''
        ]);
    }
    
    // Flush rewrite rules to ensure custom URLs work
    flush_rewrite_rules(false);
}
add_action('after_switch_theme', 'mangayummy_create_translator_page');

// ===== JSON-LD title obscuring for DMCA bots =====
function mangayummy_obfuscate_unicode_text( $text ) {
    if ( empty( $text ) || ! is_string( $text ) ) {
        return $text;
    }

    // Passing null for $limit is deprecated in PHP 8.1+.
    // Use 0 or -1 to get unlimited split behavior and preserve compatibility.
    $chars = preg_split( '//u', $text, 0, PREG_SPLIT_NO_EMPTY );
    if ( ! $chars || ! is_array( $chars ) ) {
        return $text;
    }
    return implode( "\u{200B}", $chars );
}

function mangayummy_secure_json_ld_titles( $data ) {
    if ( is_admin() ) {
        return $data;
    }

    if ( isset($data['name']) ) {
        $data['name'] = mangayummy_obfuscate_unicode_text($data['name']);
    }
    if ( isset($data['alternateName']) ) {
        if ( is_array($data['alternateName']) ) {
            $data['alternateName'] = array_map('mangayummy_obfuscate_unicode_text', $data['alternateName']);
        } else {
            $data['alternateName'] = mangayummy_obfuscate_unicode_text($data['alternateName']);
        }
    }

    return $data;
}

add_filter( 'wpseo_schema_webpage', 'mangayummy_secure_json_ld_titles' );
add_filter( 'wpseo_schema_article', 'mangayummy_secure_json_ld_titles' );
add_filter( 'woocommerce_structured_data_product', 'mangayummy_secure_json_ld_titles' );

// Obfuscate regular SEO titles as well
add_filter( 'wpseo_title', 'mangayummy_obfuscate_unicode_text', 99 );
add_filter( 'wpseo_opengraph_title', 'mangayummy_obfuscate_unicode_text', 99 );
add_filter( 'wpseo_twitter_title', 'mangayummy_obfuscate_unicode_text', 99 );

// Also run on plugin/theme activation
add_action('init', function() {
    static $initialized = false;
    if ($initialized) return;
    $initialized = true;
    
    $page_query = new WP_Query([
        'post_type' => 'page',
        'title' => 'Translator Groups',
        'posts_per_page' => 1
    ]);
    $page = $page_query->posts ? $page_query->posts[0] : null;
    if (!$page) {
        mangayummy_create_translator_page();
    }
});

// Create advanced search page
function mangayummy_create_advanced_search_page() {
    // Check if page already exists
    $page = get_page_by_path('browse', OBJECT, 'page');
    if (!$page) {
        $page = get_page_by_path('cautare-avansata', OBJECT, 'page');
    }
    
    if (!$page) {
        // Create the page
        $page_id = wp_insert_post([
            'post_title' => 'Browse',
            'post_name' => 'browse',
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_content' => ''
        ]);
    } elseif ($page->post_name !== 'browse' || $page->post_title !== 'Browse') {
        wp_update_post([
            'ID' => $page->ID,
            'post_title' => 'Browse',
            'post_name' => 'browse',
        ]);
    }
}
add_action('after_switch_theme', 'mangayummy_create_advanced_search_page');

// Also run on plugin/theme activation for advanced search page
add_action('init', function() {
    static $advanced_initialized = false;
    if ($advanced_initialized) return;
    $advanced_initialized = true;
    
    $page = get_page_by_path('browse', OBJECT, 'page');
    if (!$page) {
        $page = get_page_by_path('cautare-avansata', OBJECT, 'page');
    }
    if (!$page) {
        mangayummy_create_advanced_search_page();
    }
});

// Meta Boxes for Chapters
function mangayummy_add_meta_boxes() {
    add_meta_box('chapter_images', 'Chapter Images', 'mangayummy_chapter_images_callback', 'chapter', 'normal', 'high');
    add_meta_box('chapter_zip_upload', 'Upload ZIP with Images', 'mangayummy_chapter_zip_upload_callback', 'chapter', 'normal', 'high');
    add_meta_box('manga_details', 'Manga Details', 'mangayummy_manga_details_callback', 'manga');
    add_meta_box('manga_18', 'Age Restrictions', 'mangayummy_manga_18_callback', 'manga');
    // English title meta box for SEO support
    add_meta_box('manga_english_title', 'English Title', 'mangayummy_manga_english_title_callback', 'manga');
    add_meta_box('chapter_details', 'Chapter Details', 'mangayummy_chapter_details_callback', 'chapter');

    // External importers (MangaDex / MangaTerra) removed per request.
}
add_action('add_meta_boxes', 'mangayummy_add_meta_boxes');

function mangayummy_chapter_images_callback($post) {
    wp_nonce_field('mangayummy_chapter_images', 'mangayummy_chapter_images_nonce');
    
    // Get existing image URLs
    $images = get_post_meta($post->ID, '_chapter_images', true);
    $image_urls = is_array($images) ? $images : [];
    
    // If it's still the old format, convert it
    if (is_string($images) && !empty($images)) {
        $image_urls = array_filter(array_map('trim', explode(',', $images)));
    }
    
    // Ensure at least one empty field for new image
    if (empty($image_urls)) {
        $image_urls = [''];
    }
    ?>
    <div id="chapter-images-list">
        <style>
            .image-url-row {
                display: flex;
                gap: 10px;
                margin-bottom: 10px;
                align-items: center;
            }
            .image-url-input {
                flex: 1;
                padding: 8px 12px;
                border: 1px solid #ddd;
                border-radius: 4px;
                font-family: monospace;
                font-size: 12px;
            }
            .image-url-input:focus {
                border-color: #2196F3;
                box-shadow: 0 0 5px rgba(33, 150, 243, 0.2);
                outline: none;
            }
            .remove-image-btn {
                background: #ff6b6b;
                color: white;
                border: none;
                padding: 8px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
            }
            .remove-image-btn:hover {
                background: #ff5252;
            }
            .add-image-btn {
                background: #4CAF50;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
                margin-top: 10px;
            }
            .add-image-btn:hover {
                background: #45a049;
            }
            .chapter-images-help {
                margin-top: 15px;
                padding: 10px;
                background: #f0f7ff;
                border-left: 3px solid #2196F3;
                border-radius: 4px;
                font-size: 13px;
            }

            /* ===== Autogenerate Images (Admin helper) ===== */
            .autogenerate-section {
                margin-top: 20px;
                padding: 15px;
                background: #fff9e6;
                border-left: 3px solid #ffc107;
                border-radius: 4px;
            }
            .autogenerate-row {
                display: flex;
                gap: 10px;
                margin-bottom: 10px;
                align-items: center;
            }
            .autogenerate-input {
                flex: 1;
                padding: 8px 12px;
                border: 1px solid #ddd;
                border-radius: 4px;
                font-family: monospace;
                font-size: 12px;
            }
            .autogenerate-input:focus {
                border-color: #ffc107;
                box-shadow: 0 0 5px rgba(255, 193, 7, 0.2);
                outline: none;
            }
            .autogenerate-btn {
                background: #ffc107;
                color: #333;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
                white-space: nowrap;
            }
            .autogenerate-btn:hover {
                background: #ffb300;
            }
            .autogenerate-status {
                margin-top: 10px;
                padding: 10px;
                border-radius: 4px;
                font-size: 13px;
                display: none;
            }
            .autogenerate-status.success {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
                display: block;
            }
            .autogenerate-status.error {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
                display: block;
            }
            .autogenerate-status.info {
                background: #d1ecf1;
                color: #0c5460;
                border: 1px solid #bee5eb;
                display: block;
            }
        </style>
        
        <!-- Sequential URL Generator -->
        <div class="autogenerate-section">
            <strong>🔢 Sequential URL Generation</strong>
            <p style="margin:8px 0; font-size:12px; color:#666;">Introduceți un URL care conține un număr la final (ex: <code>.../001.png</code>), apoi câte pagini să genereze. Sistemul va crește numărul automat păstrând padding-ul.</p>
            <div class="autogenerate-row">
                <input type="text" id="seq-base-url" class="autogenerate-input" placeholder="https://site.com/chapters/0012312232/001.png">
                <input type="number" id="seq-count" class="autogenerate-input" style="width:80px;" min="1" placeholder="Număr">
                <button type="button" class="autogenerate-btn" id="seq-generate-btn">➕ Generează</button>
            <button type="button" class="autogenerate-btn" id="seq-reorder-btn">🔀 Reorder</button>
            <div id="seq-status" class="autogenerate-status"></div>
        </div>

        <?php
        foreach ($image_urls as $index => $url) {
            ?>
            <div class="image-url-row">
                <input 
                    type="url" 
                    class="image-url-input chapter-image-url" 
                    name="chapter_image_urls[]" 
                    value="<?php echo esc_attr($url); ?>" 
                    placeholder="https://example.com/image.jpg"
                >
                <div class="image-url-actions">
                    <button type="button" class="move-btn" onclick="mangayummy_moveImageRowUp(this)">↑ Sus</button>
                    <button type="button" class="move-btn" onclick="mangayummy_moveImageRowDown(this)">↓ Jos</button>
                    <?php if ($index > 0 || count($image_urls) > 1) { ?>
                        <button type="button" class="remove-image-btn" onclick="mangayummy_removeImageRow(this)">Delete</button>
                    <?php } ?>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    
    <button type="button" class="add-image-btn" id="add-image-url-btn">
        + Add another image
    </button>
    
    <div class="chapter-images-help">
        <strong>💡 Cum sa adaugi imagini:</strong><br>
        1. Copy the direct link to the image (ex: https://site.com/manga/image.jpg)<br>
        2. Lipitura linkul in campul de sus<br>
        3. Apasa "+ Adauga o alta imagine" pentru mai multe<br>
        4. Salveaza chapter-ul<br>
        ✓ Imaginile din capitole vor aparea in ordinea din lista
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#add-image-url-btn').click(function(e) {
            e.preventDefault();
            const newRow = '<div class="image-url-row">' +
                '<input type="url" class="image-url-input chapter-image-url" name="chapter_image_urls[]" placeholder="https://example.com/image.jpg">' +
                '<div class="image-url-actions">' +
                    '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowUp(this)">↑ Sus</button>' +
                    '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowDown(this)">↓ Jos</button>' +
                    '<button type="button" class="remove-image-btn" onclick="mangayummy_removeImageRow(this)">Delete</button>' +
                '</div>' +
                '</div>';
            $('#chapter-images-list').append(newRow);
        });

        // Inline sequential generator fallback (replaces removed external JS)
        $('#seq-generate-btn').click(function(e) {
            e.preventDefault();
            const base = ($('#seq-base-url').val() || '').trim();
            const cnt = parseInt($('#seq-count').val(), 10) || 0;
            const seqStatus = $('#seq-status');
            function mangayummy_showSeqStatus(type, msg) {
                if (!seqStatus.length) return;
                seqStatus.attr('class', 'autogenerate-status ' + type).text(msg);
            }
            if (!base) {
                mangayummy_showSeqStatus('error', '❌ Introduceți un URL de bază');
                return;
            }
            if (!cnt || cnt < 1) {
                mangayummy_showSeqStatus('error', '❌ Introduceți un număr valid de pagini');
                return;
            }
            const m = base.match(/^(.*?)(\d+)(\.[^\.]+)$/);
            if (!m) {
                mangayummy_showSeqStatus('error', '❌ URL-ul trebuie să se termine cu un număr urmat de extensie, ex. 001.png');
                return;
            }
            const prefix = m[1];
            const numStr = m[2];
            const suffix = m[3];
            const width = numStr.length;
            let start = parseInt(numStr, 10);
            if (isNaN(start)) start = 1;
            for (let i = 0; i < cnt; i++) {
                const nval = String(start + i).padStart(width, '0');
                let url = prefix + nval + suffix;
                // encode spaces in generated URL path
                url = url.replace(/\s/g, '%20');
                const escaped = $('<div>').text(url).html();
                const newRow = '<div class="image-url-row">' +
                    '<input type="url" class="image-url-input chapter-image-url" name="chapter_image_urls[]" value="' + escaped + '" placeholder="https://example.com/image.jpg">' +
                    '<div class="image-url-actions">' +
                        '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowUp(this)">↑ Sus</button>' +
                        '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowDown(this)">↓ Jos</button>' +
                        '<button type="button" class="remove-image-btn" onclick="mangayummy_removeImageRow(this)">Delete</button>' +
                    '</div>' +
                    '</div>';
                $('#chapter-images-list').append(newRow);
            }
            mangayummy_showSeqStatus('success', '✅ S-au generat ' + cnt + ' URL-uri! (Salvați pentru a confirma)');
        });

        // Reorder all existing image URL rows by filename (natural sort)
        $('#seq-reorder-btn').click(function(e) {
            e.preventDefault();
            const seqStatus = $('#seq-status');
            function mangayummy_showSeqStatus(type, msg) {
                if (!seqStatus.length) return;
                seqStatus.attr('class', 'autogenerate-status ' + type).text(msg);
            }

            const rows = $('#chapter-images-list .image-url-row');
            if (!rows.length) {
                mangayummy_showSeqStatus('error', '❌ Nu există link-uri de reordonat.');
                return;
            }

            const urls = [];
            rows.each(function() {
                const val = $(this).find('.image-url-input').val().trim();
                if (val) urls.push(val);
            });

            if (!urls.length) {
                mangayummy_showSeqStatus('error', '❌ Nu există link-uri valide în listă.');
                return;
            }

            urls.sort(function(a, b) {
                const aName = a.replace(/.*\/(.*?)([?#].*)?$/, '$1');
                const bName = b.replace(/.*\/(.*?)([?#].*)?$/, '$1');
                return aName.localeCompare(bName, undefined, {numeric: true, sensitivity: 'base'});
            });

            // Apply sorted order back to existing rows (leaving empty rows at end)
            let idx = 0;
            rows.each(function() {
                const $input = $(this).find('.image-url-input');
                if (idx < urls.length) {
                    $input.val(urls[idx]);
                } else {
                    $input.val('');
                }
                idx++;
            });

            mangayummy_showSeqStatus('success', '✅ Lista a fost reordonată. Salvați capitolul pentru a păstra ordinea.');
        });
    });
    
    function mangayummy_moveImageRowUp(btn) {
        const $row = jQuery(btn).closest('.image-url-row');
        const $prev = $row.prev('.image-url-row');
        if ($prev.length) {
            $row.insertBefore($prev);
        }
    }

    function mangayummy_moveImageRowDown(btn) {
        const $row = jQuery(btn).closest('.image-url-row');
        const $next = $row.next('.image-url-row');
        if ($next.length) {
            $row.insertAfter($next);
        }
    }

    function mangayummy_removeImageRow(btn) {
        jQuery(btn).closest('.image-url-row').remove();
    }
    </script>
    <?php
}


/* -----------------------------
   Metabox: Import extern în capitol (MangaDex / MangaTerra)
   ----------------------------- */
function mangayummy_chapter_importer_metabox($post) {
    // lightweight chapter importer that fetches images into the existing
    // "Chapter Images" list.  Reuses the existing mangayummy_extract_chapter_images
    // AJAX handler which works for MangaTerra clones and similar reader pages.
    ?>
    <p>
        <label for="chapter_import_url"><strong>URL capitol extern:</strong></label><br>
        <input id="chapter_import_url" type="url" style="width:100%; margin-top:6px;" placeholder="https://site.com/manga/slug/chapter/1" />
    </p>
    <p style="margin-top:8px;">
        <button id="chapter_preview_btn" class="button">Verifică imagini</button>
        <button id="chapter_import_btn" class="button button-primary">Importă imagini</button>
    </p>
    <div id="chapter_import_preview" style="margin-top:10px; font-size:13px;"></div>
    <script>
    (function(){
        const previewBtn = document.getElementById('chapter_preview_btn');
        const importBtn  = document.getElementById('chapter_import_btn');
        const urlInput   = document.getElementById('chapter_import_url');
        const previewDiv = document.getElementById('chapter_import_preview');
        const postId     = <?php echo (int) $post->ID; ?>;
        const ajaxUrl    = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
        const nonce      = '<?php echo wp_create_nonce('ya_ajax_nonce'); ?>';

        function mangayummy_escapeHtml(str) {
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
        }

        previewBtn.addEventListener('click', function(e){
            e.preventDefault();
            const url = urlInput.value.trim();
            if (!url) { previewDiv.innerHTML = '<div style="color:#d00">Introduceţi un URL valid</div>'; return; }
            previewBtn.disabled = true;
            previewBtn.textContent = 'Se verifică...';
            previewDiv.innerHTML = '<em>Se încarcă...</em>';
            const fd = new FormData();
            fd.append('action','mangayummy_extract_chapter_images');
            fd.append('chapter_url',url);
            fd.append('nonce',nonce);
            fetch(ajaxUrl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(data=>{
                previewBtn.disabled = false;
                previewBtn.textContent = 'Verifică imagini';
                if (!data.success) {
                    previewDiv.innerHTML = '<div style="color:#d00">'+(data.data?.message||'Eroare')+'</div>';
                    return;
                }
                const imgs = data.data.images||[];
                let html = '<div>Găsite ' + imgs.length + ' imagini.</div>';
                imgs.forEach(u=>{
                    html += '<div style="font-size:12px;word-break:break-all;">' + mangayummy_escapeHtml(u) + '</div>';
                });
                previewDiv.innerHTML = html;
            })
            .catch(err=>{
                previewBtn.disabled = false;
                previewBtn.textContent = 'Verifică imagini';
                previewDiv.innerHTML = '<div style="color:#d00">Eroare rețea</div>';
            });
        });

        importBtn.addEventListener('click', function(e){
            e.preventDefault();
            const url = urlInput.value.trim();
            if (!url) { previewDiv.innerHTML = '<div style="color:#d00">Introduceţi un URL valid</div>'; return; }
            importBtn.disabled = true;
            importBtn.textContent = 'Importă...';
            previewDiv.innerHTML = '<em>Import în curs...</em>';
            const fd = new FormData();
            fd.append('action','mangayummy_extract_chapter_images');
            fd.append('chapter_url',url);
            fd.append('nonce',nonce);
            fetch(ajaxUrl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(data=>{
                importBtn.disabled = false;
                importBtn.textContent = 'Importă imagini';
                if (!data.success) {
                    previewDiv.innerHTML = '<div style="color:#d00">'+(data.data?.message||'Eroare')+'</div>';
                    return;
                }
                const imgs = data.data.images||[];
                // populate existing image list
                const list = document.querySelector('#chapter-images-list');
                if (list) {
                    list.querySelectorAll('.image-url-row').forEach(n=>n.remove());
                    imgs.forEach(u=>{
                        const row = document.createElement('div');
                        row.className = 'image-url-row';
                        row.innerHTML =
                            '<input type="url" class="image-url-input chapter-image-url" name="chapter_image_urls[]" value="'+mangayummy_escapeHtml(u)+'">' +
                            '<div class="image-url-actions">' +
                                '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowUp(this)">↑ Sus</button>' +
                                '<button type="button" class="move-btn" onclick="mangayummy_moveImageRowDown(this)">↓ Jos</button>' +
                                '<button type="button" class="remove-image-btn" onclick="mangayummy_removeImageRow(this)">Delete</button>' +
                            '</div>';
                        list.appendChild(row);
                    });
                }
                previewDiv.innerHTML = '<div style="color:#2a862a">Imported ' + imgs.length + ' images – save the chapter to keep changes.</div>';
            })
            .catch(err=>{
                importBtn.disabled = false;
                importBtn.textContent = 'Importă imagini';
                previewDiv.innerHTML = '<div style="color:#d00">Eroare rețea</div>';
            });
        });
    })();
    </script>
    <?php
}

/* -----------------------------
   Metabox: Import extern în manga (MangaDex / MangaTerra)
   ----------------------------- */
function mangayummy_manga_importer_metabox($post) {
    // Note: uses ya_ajax nonce for admin-ajax calls
    ?>
    <p>
        <label for="mangayummy_import_source"><strong>Tip sursă:</strong></label><br>
        <?php $import_source = get_post_meta($post->ID, '_import_source', true) ?: 'auto'; ?>
        <select id="mangayummy_import_source" name="mangayummy_import_source" style="width:100%;">
            <option value="auto" <?php selected($import_source, 'auto'); ?>>Detectare automată (URL)</option>
            <option value="mangadex" <?php selected($import_source, 'mangadex'); ?>>MangaDex</option>
            <option value="mangaterra" <?php selected($import_source, 'mangaterra'); ?>>MangaTerra / Local</option>
        </select>
    </p>
    <p>
        <label for="mangayummy_import_url"><strong>Link extern (MangaDex / MangaTerra):</strong></label>
        <?php $import_url = esc_url(get_post_meta($post->ID, '_import_url', true)); ?>
        <input id="mangayummy_import_url" name="mangayummy_import_url" type="url" style="width:100%; margin-top:6px;" placeholder="https://mangadex.org/title/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="<?php echo $import_url; ?>" />
    </p>

    <p style="margin-top:8px;">
        <button id="mangayummy_preview_btn" class="button">Check Chapters</button>
        <button id="mangayummy_import_btn" class="button button-primary">Import Chapters</button>
    </p>

    <div id="mangayummy_import_preview" style="margin-top:10px; font-size:13px;"></div>

    <script>
    (function(){
        const previewBtn = document.getElementById('mangayummy_preview_btn');
        const importBtn = document.getElementById('mangayummy_import_btn');
        const urlInput = document.getElementById('mangayummy_import_url');
        const sourceSelect = document.getElementById('mangayummy_import_source');
        const previewDiv = document.getElementById('mangayummy_import_preview');
        const postId = <?php echo (int) $post->ID; ?>;
        const ajaxUrl = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
        const nonce = '<?php echo wp_create_nonce('ya_ajax_nonce'); ?>';

        previewBtn.addEventListener('click', function(e){
            e.preventDefault();
            const url = urlInput.value.trim();
            const source = sourceSelect.value;
            if (!url) { previewDiv.innerHTML = '<div style="color:#d00">Introdu URL valid</div>'; return; }
            previewBtn.disabled = true;
            previewBtn.textContent = 'Se verifică...';
            previewDiv.innerHTML = '<em>Se încarcă...</em>';
            const fd = new FormData();
            fd.append('action','mangayummy_admin_preview_import');
            fd.append('post_id',postId);
            fd.append('url',url);
            fd.append('source',source);
            fd.append('nonce',nonce);
            fetch(ajaxUrl,{method:'POST',body:fd})
            .then(r=>r.json())
            .then(data=>{
                previewBtn.disabled = false; previewBtn.textContent = 'Check Chapters';
                if (!data.success) { previewDiv.innerHTML = '<div style="color:#d00">'+(data.data||'Error')+'</div>'; return; }
                const counts = data.data.counts;
                const title = data.data.title || '';
                const rows = (data.data.chapters || []).slice(0,200).map(ch=>`<tr><td>${mangayummy_escapeHtml(String(ch.number||''))}</td><td>${mangayummy_escapeHtml(ch.title||'')}</td><td>${mangayummy_escapeHtml(ch.language||'')}</td><td>${mangayummy_escapeHtml(ch.status)}</td></tr>`).join('');
                previewDiv.innerHTML = `
                    <div style="font-weight:600;margin-bottom:6px;">${mangayummy_escapeHtml(title)}</div>
                    <div style="margin-bottom:6px">Found: ${counts.total} • RO: ${counts.ro_total} • To import: ${counts.would_import} • Existing: ${counts.exists} • Skipped (non-RO): ${counts.skipped_non_ro}</div>
                    <div style="max-height:220px; overflow:auto; border:1px solid #eee; padding:6px; background:#fafafa;">
                        <table style="width:100%;font-size:12px; border-collapse:collapse;"><thead><tr><th style="width:10%;text-align:left">No</th><th style="text-align:left">Title</th><th style="width:10%;text-align:left">Lang</th><th style="width:18%;text-align:left">Status</th></tr></thead><tbody>${rows}</tbody></table>
                    </div>
                `;
            })
            .catch(err=>{ previewBtn.disabled=false; previewBtn.textContent='Check Chapters'; previewDiv.innerHTML = '<div style="color:#d00">Network Error</div>'; console.error(err);});
        });

        importBtn.addEventListener('click', function(e){
            e.preventDefault();
            const url = urlInput.value.trim();
            const source = sourceSelect.value;
            if (!url) { previewDiv.innerHTML = '<div style="color:#d00">Introdu URL valid</div>'; return; }
            importBtn.disabled = true; importBtn.textContent = 'Se importă...';
            previewDiv.innerHTML = '<em>Import în curs...</em>';

            // Helper: import local in batches (automatically continues until done)
            function mangayummy_importLocalBatches(startOffset = 0, aggregated = { imported: 0, skipped: 0 }) {
                const fd = new FormData();
                fd.append('action','mangayummy_import_local');
                fd.append('url', url);
                fd.append('existing_manga_id', postId);
                fd.append('batch_offset', startOffset);
                fd.append('nonce', nonce);

                fetch(ajaxUrl, { method: 'POST', body: fd })
                .then(r => r.json())
                .then(data => {
                    if (!data.success) {
                        importBtn.disabled = false; importBtn.textContent = 'Import Chapters';
                        previewDiv.innerHTML = '<div style="color:#d00">'+(data.data?.msg||data.data||'Error')+'</div>';
                        return;
                    }

                    const d = data.data || {};
                    const importedThis = d.chapters_imported || 0;
                    const skippedThis = d.chapters_skipped || 0;
                    aggregated.imported += importedThis;
                    aggregated.skipped += skippedThis;

                    // Update progress UI
                    previewDiv.innerHTML = `
                        <div style="color:green; font-weight:600">${mangayummy_escapeHtml(d.msg || 'Batch processed')}</div>
                        <div>Batch: ${d.current_batch || '?'} / ${d.total_batches || '?'} — Imported in batch: ${importedThis} — Total imported: ${aggregated.imported}</div>
                        <div>Skipped (batch): ${skippedThis} • Skipped (total): ${aggregated.skipped}</div>
                        <div>Remaining: ${d.chapters_remaining ?? 0}</div>
                    `;

                    if (d.has_more) {
                        // Continue with next batch
                        setTimeout(() => mangayummy_importLocalBatches(d.next_offset || (startOffset + (d.batch_size || 20)), aggregated), 250);
                    } else {
                        importBtn.disabled = false; importBtn.textContent = 'Import Chapters';
                        previewDiv.innerHTML = `
                            <div style="color:green; font-weight:700">Import Complete</div>
                            <div>Chapters created: ${aggregated.imported} • Skipped: ${aggregated.skipped}</div>
                            <div><a href="${d.edit_link || '#'}" target="_blank">Edit Manga</a></div>
                        `;
                    }
                })
                .catch(err => {
                    importBtn.disabled = false; importBtn.textContent = 'Import Chapters';
                    previewDiv.innerHTML = '<div style="color:#d00">Network Error</div>';
                    console.error(err);
                });
            }

            if (source === 'mangaterra') {
                // Start batch import from offset 0 and continue automatically
                mangayummy_importLocalBatches(0, { imported: 0, skipped: 0 });
            } else {
                // Default: MangaDex external import (single request)
                const fd = new FormData();
                fd.append('action','mangayummy_import_url');
                fd.append('url', url);
                fd.append('target_post_id', postId);
                fd.append('nonce', nonce);
                fetch(ajaxUrl,{method:'POST',body:fd})
                .then(r=>r.json())
                .then(data=>{
                    importBtn.disabled=false; importBtn.textContent='Importă capitole';
                    if (!data.success) { previewDiv.innerHTML = '<div style="color:#d00">'+(data.data?.msg||data.data||'Eroare')+'</div>'; return; }
                    previewDiv.innerHTML = `<div style="color:green">Succes: ${mangayummy_escapeHtml(data.data.msg || 'Import complet')}</div><div>Capitole create: ${data.data.chapters_created ?? data.data.chapters_imported ?? 0}</div>`;
                })
                .catch(err=>{ importBtn.disabled=false; importBtn.textContent='Importă capitole'; previewDiv.innerHTML = '<div style="color:#d00">Eroare rețea</div>'; console.error(err);});
            }
        });

        function mangayummy_escapeHtml(t){ return String(t).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
    })();
    </script>
    <?php
}

// External importer preview endpoint removed per request.

// utility: convert a chapter URL into the parent manga URL if needed
if (!function_exists('mangayummy_normalize_import_url')) {
    function mangayummy_normalize_import_url($url) {
        // match anything like /manga/slug/ followed by chapter or capitolul
        if (preg_match('#^(https?://[^/]+/manga/[^/]+)/(?:capitolul|chapter)[\-_]?\d#i', $url, $m)) {
            return rtrim($m[1], '/') . '/';
        }
        return $url;
    }
}

if (!function_exists('mangayummy_normalize_chapter_image_url')) {
    function mangayummy_normalize_chapter_image_url($url) {
        $url = trim($url);

        if (empty($url)) {
            return $url;
        }

        // Normalize whitespace to %20
        $url = preg_replace('/\s+/', '%20', $url);

        $parts = parse_url($url);
        if ($parts === false || empty($parts['scheme']) || empty($parts['host'])) {
            return $url;
        }

        // For external CDN URLs (like i3.wp.com), be conservative with encoding
        // to avoid double-encoding issues that cause 400 errors
        $is_external_cdn = (strpos($parts['host'], 'i3.wp.com') !== false || 
                            strpos($parts['host'], 'wp.com') !== false ||
                            strpos($parts['host'], 'cdn') !== false);

        $normalized_path = '';
        if (!empty($parts['path'])) {
            $segments = explode('/', ltrim($parts['path'], '/'));
            $normalized_segments = array();
            foreach ($segments as $segment) {
                if ($is_external_cdn) {
                    // For CDN URLs: only encode if clearly needed, avoid double-encoding
                    if (strpos($segment, '%') === false && preg_match('/[^a-zA-Z0-9._\-~]/', $segment)) {
                        $normalized_segments[] = rawurlencode($segment);
                    } else {
                        $normalized_segments[] = $segment;
                    }
                } else {
                    // For non-CDN URLs: decode then re-encode for consistency
                    $decoded = rawurldecode($segment);
                    $normalized_segments[] = rawurlencode($decoded);
                }
            }
            $normalized_path = '/' . implode('/', $normalized_segments);
        }

        $normalized_url = $parts['scheme'] . '://' . $parts['host'];

        if (!empty($parts['port'])) {
            $normalized_url .= ':' . intval($parts['port']);
        }

        $normalized_url .= $normalized_path;

        // Keep query and fragment as originally found
        if (!empty($parts['query'])) {
            $normalized_url .= '?' . $parts['query'];
        }
        if (!empty($parts['fragment'])) {
            $normalized_url .= '#' . $parts['fragment'];
        }

        return $normalized_url;
    }
}


function mangayummy_admin_preview_import() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    $post_id = intval($_POST['post_id'] ?? 0);
    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(__('Permisiuni insuficiente', 'mangayummy'));
    }

    $url = sanitize_text_field($_POST['url'] ?? '');
    $source = sanitize_text_field($_POST['source'] ?? 'auto');

    // allow entering a chapter link and still target the manga page
    $url = mangayummy_normalize_import_url($url);

    if (empty($url)) {
        wp_send_json_error(__('URL invalid', 'mangayummy'));
    }

    // Auto-detect source from URL when requested
    if ($source === 'auto') {
        if (strpos($url, 'mangadex.org') !== false) {
            $source = 'mangadex';
        } else {
            $source = 'mangaterra';
        }
    }

    // Ensure importer helper functions are available
    if ($source === 'mangadex') {
        if (!function_exists('mangayummy_fetch_from_external')) {
            wp_send_json_error(__('Plugin importer inactiv sau lipsesc funcții (mangadex)', 'mangayummy'));
        }
        if (!preg_match('/mangadex\.org\/title\/([a-f0-9-]+)/i', $url, $m)) {
            wp_send_json_error(__('URL MangaDex invalid', 'mangayummy'));
        }
        $manga_id = $m[1];
        $manga_data = mangayummy_fetch_from_external($manga_id);
        if (is_wp_error($manga_data)) wp_send_json_error($manga_data->get_error_message());
    } else {
        if (!function_exists('mangayummy_fetch_from_local')) {
            wp_send_json_error(__('Plugin importer inactiv sau lipsesc funcții (local)', 'mangayummy'));
        }
        $manga_data = mangayummy_fetch_from_local($url);
        if (is_wp_error($manga_data)) wp_send_json_error($manga_data->get_error_message());
    }

    $chapters = $manga_data['chapters'] ?? array();
    $preview = array();
    $counts = array('total' => count($chapters), 'ro_total' => 0, 'would_import' => 0, 'exists' => 0, 'skipped_non_ro' => 0);
    global $wpdb;

    foreach ($chapters as $ch) {
        $lang = !empty($ch['language']) ? $ch['language'] : 'ro';

        // debug log raw and normalized chapter numbers
        $raw_num = $ch['number'] ?? '';
        $norm_num = mangayummy_normalize_chapter_number($raw_num);
        mangayummy_debug_log("IMPORT PREVIEW DEBUG: post {$post_id} raw_num='{$raw_num}' norm='{$norm_num}' lang='{$lang}'");

        $entry = array(
            'number' => $norm_num,
            'title' => $ch['title'] ?? '',
            'language' => $lang,
            'external_id' => $ch['external_id'] ?? '',
            'status' => 'new',
        );

        if ($lang !== 'ro') {
            $entry['status'] = 'skipped_non_ro';
            $counts['skipped_non_ro']++;
            $preview[] = $entry;
            continue;
        }

        $counts['ro_total']++;
        $exists = false;

        // If external id provided, check by external meta
        if (!empty($ch['external_id'])) {
            $found = $wpdb->get_var($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id WHERE p.post_type = 'chapter' AND p.post_parent = %d AND pm.meta_key IN ('_source_id','_mangadex_chapter_id') AND pm.meta_value = %s LIMIT 1",
                $post_id,
                $ch['external_id']
            ));
            if (!empty($found)) $exists = true;
        }

        // Fallback: check by chapter number + language (use normalized value)
        if (!$exists && $norm_num !== '') {
            $found2 = $wpdb->get_var($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p WHERE p.post_type = 'chapter' AND p.post_parent = %d AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm1 WHERE pm1.post_id = p.ID AND pm1.meta_key = '_chapter_number' AND pm1.meta_value = %s) AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm2 WHERE pm2.post_id = p.ID AND pm2.meta_key = '_chapter_language' AND pm2.meta_value = %s) LIMIT 1",
                $post_id,
                $norm_num,
                'ro'
            ));
            mangayummy_debug_log("IMPORT PREVIEW DEBUG: query for normalized_num='{$norm_num}', found_chapter_id='" . ($found2 ?: 'none') . "'");
            if (!empty($found2)) $exists = true;
        }

        if ($exists) {
            $entry['status'] = 'exists';
            $counts['exists']++;
        } else {
            $entry['status'] = 'would_import';
            $counts['would_import']++;
        }

        $preview[] = $entry;
    }

    wp_send_json_success(array('counts' => $counts, 'chapters' => $preview, 'title' => $manga_data['title'] ?? ''));
}

// If importer plugin is absent or deactivated we still provide the local
// MangaTerra scraping and batch-import functionality directly in the theme.
// This keeps the "Import extern" metabox working without requiring the
// separate `mangayummy-importer` plugin.

/**
 * Fetch manga data from a local MangaTerra-like source by URL.
 * Copied/adapted from mangayummy-importer/includes/local-import.php
 */
if (!function_exists('mangayummy_fetch_from_local')) {
    function mangayummy_fetch_from_local($url) {
        // make sure parsing helpers are available (in case theme is handling import)
        if (!function_exists('mangayummy_mangaterra_parse_manga_page') || !function_exists('mangayummy_mangaterra_fetch_chapters')) {
            $path = get_template_directory() . '/inc/local-import.php';
            if (file_exists($path)) {
                require_once $path;
            }
        }
        if (!preg_match('/(?:example\.com|mangaterra\.ro)\/manga\/([^\/\?]+)/i', $url, $matches)) {
            return new WP_Error('invalid_url', 'Invalid URL. Expected format: https://example.com/manga/SLUG or https://mangaterra.ro/manga/SLUG');
        }
        $manga_slug = isset($matches[1]) ? sanitize_text_field($matches[1]) : '';
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'headers' => array(
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'ro-RO,ro;q=0.9,en;q=0.8',
            ),
        ));
        if (is_wp_error($response)) {
            return new WP_Error('fetch_error', 'Failed to fetch page: ' . $response->get_error_message());
        }
        $status = wp_remote_retrieve_response_code($response);
        if ($status !== 200) {
            return new WP_Error('http_error', 'Source returned HTTP ' . $status);
        }
        $html = wp_remote_retrieve_body($response);
        if (empty($html)) {
            return new WP_Error('empty_response', 'Empty response from source');
        }
        libxml_use_internal_errors(true);
        $doc = new DOMDocument();
        $doc->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();
        $xpath = new DOMXPath($doc);
        $manga_data = mangayummy_mangaterra_parse_manga_page($xpath, $doc, $url, $manga_slug);
        if (is_wp_error($manga_data)) {
            return $manga_data;
        }
        $chapters = mangayummy_mangaterra_fetch_chapters($url, $manga_slug);
        $manga_data['chapters'] = $chapters;
        return $manga_data;
    }
}

// Import helpers (simplified, plugin version is more comprehensive)
if (!function_exists('mangayummy_sanitize_chapter_data')) {
    function mangayummy_sanitize_chapter_data($data) {
        $clean = array();
        if (!is_array($data)) return $clean;
        $clean['number'] = isset($data['number']) ? mangayummy_normalize_chapter_number($data['number']) : '';
        $clean['title']  = isset($data['title']) ? sanitize_text_field($data['title']) : '';
        $clean['language'] = isset($data['language']) ? sanitize_text_field($data['language']) : '';
        $clean['translation_group'] = isset($data['translation_group']) ? sanitize_text_field($data['translation_group']) : '';
        $clean['external_id'] = isset($data['external_id']) ? sanitize_text_field($data['external_id']) : '';
        $clean['images'] = isset($data['images']) && is_array($data['images']) ? $data['images'] : array();
        $clean['force_local_images'] = !empty($data['force_local_images']);
        return $clean;
    }
}

if (!function_exists('mangayummy_create_chapter')) {
    function mangayummy_create_chapter($manga_id_or_data, $chapter_data_optional = null) {
        if (is_array($manga_id_or_data)) {
            $chapter_data = $manga_id_or_data;
            $manga_id = isset($chapter_data['manga_id']) ? intval($chapter_data['manga_id']) : 0;
        } else {
            $manga_id = intval($manga_id_or_data);
            $chapter_data = $chapter_data_optional ?: array();
        }
        $chapter_data = mangayummy_sanitize_chapter_data($chapter_data);
        if (empty($chapter_data['title'])) {
            return new WP_Error('missing_title', 'Chapter title is required');
        }
        if ($chapter_data['number'] === '') {
            return new WP_Error('missing_number', 'Chapter number is required');
        }
        if ($manga_id <= 0) {
            return new WP_Error('invalid_manga', 'Invalid manga ID');
        }
        // skip if exists
        $existing = mangayummy_chapter_exists($manga_id, $chapter_data['number']);
        if ($existing) {
            return $existing;
        }
        $title = !empty($chapter_data['title']) ? "Capitolul {$chapter_data['number']} - {$chapter_data['title']}" : "Capitolul {$chapter_data['number']}";
        $parent_slug = sanitize_title(get_post_field('post_name', $manga_id));
        $chapter_slug = 'capitolul-' . intval($chapter_data['number']);
        $slug = $parent_slug ? ($parent_slug . '-' . $chapter_slug) : $chapter_slug;
        mangayummy_debug_log("MangaTerra import: creating chapter for manga_id={$manga_id}, number={$chapter_data['number']}, title={$chapter_data['title']}, slug={$slug}");
        $post_arr = array(
            'post_type' => 'chapter',
            'post_title' => $title,
            'post_name' => $slug,
            'post_content' => '',
            'post_status' => 'publish',
            'post_parent' => $manga_id,
        );
        $chapter_id = wp_insert_post($post_arr);
        if (is_wp_error($chapter_id)) {
            return $chapter_id;
        }
        update_post_meta($chapter_id, '_manga_id', $manga_id);
        update_post_meta($chapter_id, '_chapter_number', (string)$chapter_data['number']);
        if (!empty($chapter_data['translation_group'])) {
            update_post_meta($chapter_id, '_translation_group', $chapter_data['translation_group']);
        }
        if (!empty($chapter_data['external_id'])) {
            update_post_meta($chapter_id, '_source_id', $chapter_data['external_id']);
        }
        update_post_meta($chapter_id, '_comment_count', 0);
        if (!empty($chapter_data['images'])) {
            $force_local_images = !empty($chapter_data['force_local_images']);
            mangayummy_import_chapter_images($chapter_id, $chapter_data['images'], $force_local_images);
        }
        return $chapter_id;
    }
}

if (!function_exists('mangayummy_import_chapter_images')) {
    function mangayummy_import_chapter_images($chapter_id, $image_urls, $force_local_images = false) {
        if (!is_array($image_urls)) {
            return new WP_Error('invalid_images', 'Images must be an array');
        }
        $valid = array();
        foreach ($image_urls as $index => $img) {
            if (empty($img)) {
                continue;
            }
            $img = mangayummy_normalize_chapter_image_url($img);
            if (empty($img) || !filter_var($img, FILTER_VALIDATE_URL)) {
                continue;
            }

            if ($force_local_images && !mangayummy_is_local_chapter_image_url($img)) {
                $downloaded_url = mangayummy_download_remote_chapter_image($chapter_id, $img, (int) $index);
                if (!is_wp_error($downloaded_url)) {
                    $valid[] = $downloaded_url;
                }
                continue;
            }

            $valid[] = $img;
        }
        if (!empty($valid)) {
            update_post_meta($chapter_id, '_chapter_images', $valid);
        }
        return count($valid);
    }
}

if (!function_exists('mangayummy_chapter_exists')) {
    function mangayummy_chapter_exists($manga_id, $chapter_number) {
        global $wpdb;
        $chapter_number = sanitize_text_field($chapter_number);
        if ($chapter_number !== '') {
            $found = $wpdb->get_var($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key='_chapter_number' AND pm1.meta_value=%s WHERE p.post_type='chapter' AND p.post_parent=%d LIMIT 1",
                $chapter_number,
                $manga_id
            ));
            if ($found) {
                return intval($found);
            }
        }
        return false;
    }
}

function mangayummy_manga_18_callback($post) {
    wp_nonce_field('mangayummy_manga_18', 'mangayummy_manga_18_nonce');
    $is_18 = get_post_meta($post->ID, '_manga_18', true);
    ?>
    <label>
        <input type="checkbox" name="manga_18" value="1" <?php checked($is_18, 1); ?> />
        <strong>18+ Content</strong>
    </label>
    <p class="description">Mark if manga contains adult/explicit content.</p>
    <?php
}

function mangayummy_manga_details_callback($post) {
    wp_nonce_field('mangayummy_manga_details', 'mangayummy_manga_details_nonce');
    $alternative_titles = get_post_meta($post->ID, '_alternative_titles', true);
    $status = get_post_meta($post->ID, '_status', true);
    $release_year = get_post_meta($post->ID, '_release_year', true);
    $release_year_end = get_post_meta($post->ID, '_release_year_end', true);
    $manga_type = get_post_meta($post->ID, '_manga_type', true);
    $anilist_url = get_post_meta($post->ID, '_anilist_url', true);
    $myanimelist_url = get_post_meta($post->ID, '_myanimelist_url', true);
    $official_raw_urls = get_post_meta($post->ID, '_official_raw_urls', true);
    if (!is_array($official_raw_urls)) {
        $official_raw_url = get_post_meta($post->ID, '_official_raw_url', true); // Get old single URL format
        $official_raw_urls = $official_raw_url ? [$official_raw_url] : []; // Migrate old single URL
    }
    $official_raw_text = implode("\n", $official_raw_urls);
    
    $alternative_titles = get_post_meta($post->ID, '_alternative_titles', true);
    if (!is_array($alternative_titles)) {
        $alternative_titles = $alternative_titles ? [$alternative_titles] : []; // Migrate old single title
    }
    $alternative_titles_text = implode("\n", $alternative_titles);
    
    // English title field handled separately
    $english_title = get_post_meta($post->ID, 'english_title', true);
    
    // Ensure search version exists
    $search_version = get_post_meta($post->ID, '_alternative_titles_search', true);
    if (empty($search_version) && !empty($alternative_titles)) {
        update_post_meta($post->ID, '_alternative_titles_search', implode(' ', $alternative_titles));
    }
    
    $recommended = get_post_meta($post->ID, '_recommended', true);
    $translator_donation_enabled = get_post_meta($post->ID, '_translator_donation_enabled', true);
    $translator_donation_url = get_post_meta($post->ID, '_translator_donation_url', true);
    
    echo '<p><label>Manga Type:</label><select name="manga_type"><option value="">-- Select --</option><option value="manga" ' . selected($manga_type, 'manga', false) . '>Manga</option><option value="manhua" ' . selected($manga_type, 'manhua', false) . '>Manhua</option><option value="manhwa" ' . selected($manga_type, 'manhwa', false) . '>Manhwa</option></select></p>';
    echo '<p><label>Alternative Titles (one per line):</label><textarea name="alternative_titles" rows="3" style="width:100%;">' . esc_textarea($alternative_titles_text) . '</textarea></p>';
    echo '<p><label>Status:</label><select name="status"><option value="ongoing" ' . selected($status, 'ongoing', false) . '>Ongoing</option><option value="completed" ' . selected($status, 'completed', false) . '>Completed</option><option value="hiatus" ' . selected($status, 'hiatus', false) . '>Hiatus</option><option value="cancelled" ' . selected($status, 'cancelled', false) . '>Cancelled</option></select></p>';
    echo '<p><label>Release Year:</label><input type="number" name="release_year" value="' . esc_attr($release_year) . '" placeholder="Start Year"> - <input type="number" name="release_year_end" value="' . esc_attr($release_year_end) . '" placeholder="End Year (optional)"></p>';
    // new translator field for server user who translated to Romanian
    // We allow selecting a user from the site (datalist) so the value can be stored as user ID.
    $translator_user = get_post_meta($post->ID, '_translator_user', true);
    $translator_user_display = $translator_user;
    $translator_user_id = 0;
    if (is_numeric($translator_user)) {
        // If stored as a user ID, show the user login for clarity
        $translator_user_id = intval($translator_user);
        $translator_obj = get_user_by('ID', $translator_user_id);
        if ($translator_obj) {
            $translator_user_display = $translator_obj->user_login;
        }
    }

    // Build a datalist of site users so the admin can select an existing user
    $user_list = get_users(array(
        'orderby' => 'display_name',
        'order'   => 'ASC',
        'fields'  => array('ID', 'display_name', 'user_login'),
    ));

    $translator_status = get_post_meta($post->ID, '_translator_status', true);
    echo '<p><label>Translator User (Romanian):</label> <input list="translator_user_list" name="translator_user" value="' . esc_attr($translator_user_display) . '" placeholder="ex: username123" style="width:100%;" autocomplete="off" />';
    echo '<datalist id="translator_user_list">';
    foreach ($user_list as $user) {
        $label = $user->display_name ? $user->display_name : $user->user_login;
        echo '<option value="' . esc_attr($user->user_login) . '" label="' . esc_attr($label) . '"></option>';
    }
    echo '</datalist></p>';
    echo '<p><label>Translation Status:</label> <select name="translator_status" style="width:100%;">'
        . '<option value="in_progress" ' . selected($translator_status, 'in_progress', false) . '>Translating (1)</option>'
        . '<option value="completed" ' . selected($translator_status, 'completed', false) . '>Completed</option>'
        . '<option value="abandoned" ' . selected($translator_status, 'abandoned', false) . '>Abandoned</option>'
        . '</select></p>';
    echo '<p><label><input type="checkbox" name="translator_donation_enabled" value="1" ' . checked($translator_donation_enabled, '1', false) . '> Show translator donation message at end of chapter</label></p>';
    echo '<p><label>Translator Wallet Link:</label><input type="url" name="translator_donation_url" value="' . esc_attr($translator_donation_url) . '" placeholder="https://..." style="width:100%;"></p>';
    echo '<p><label><input type="checkbox" name="recommended" value="1" ' . checked($recommended, '1', false) . '> Recommended (appears in Recommended section)</label></p>';
    
    echo '<hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">';
    echo '<p><label><strong>🔗 External Links (Optional)</strong></label></p>';
    echo '<p><label>AniList url:</label><input type="url" name="anilist_url" value="' . esc_attr($anilist_url) . '" placeholder="https://example.com/manga/..." style="width:100%;"></p>';
    echo '<p><label>MyAnimeList URL:</label><input type="url" name="myanimelist_url" value="' . esc_attr($myanimelist_url) . '" placeholder="https://myanimelist.net/manga/..." style="width:100%;"></p>';
    echo '<p><label>Official Raw URLs (one per line):</label><textarea name="official_raw_urls" placeholder="https://site.com/manga/..." style="width:100%; height: 80px;">' . esc_textarea($official_raw_text) . '</textarea></p>';

    // New redirect option for chapter links
    $redirect_enabled = get_post_meta($post->ID, '_redirect_chapters_enabled', true);
    $redirect_url = get_post_meta($post->ID, '_redirect_chapters_url', true);
    echo '<hr style="margin: 20px 0; border: none; border-top: 1px solid #ddd;">';
    echo '<p><label><strong>🚀 Redirect capitole către site extern</strong></label></p>';
    echo '<p><label><input type="checkbox" name="redirect_chapters_enabled" value="1" ' . checked($redirect_enabled, '1', false) . '> Activează redirect</label></p>';
    echo '<p><label>URL redirect capitol (opțional):</label><input type="url" name="redirect_chapters_url" value="' . esc_attr($redirect_url) . '" placeholder="https://extern-site.com/manga/ocazie/" style="width:100%;"></p>';
    echo '<p style="font-size: 12px; color: #666; margin-top: -10px;">Dacă include %chapter% sau {chapter}, va înlocui cu numărul capitolului selectat. Daca nu, va redirecționa mereu către același URL.</p>';
}

function mangayummy_manga_english_title_callback($post) {
    wp_nonce_field('mangayummy_manga_english_title', 'mangayummy_manga_english_title_nonce');
    $english_title = get_post_meta($post->ID, 'english_title', true);
    echo '<p><label>English Title (used for SEO):</label> <input type="text" name="english_title" value="' . esc_attr($english_title) . '" style="width:100%;" /></p>';
    // helpful note showing the replacement variable for quick copy
    echo '<p class="description">Variable Yoast&nbsp;– copie rapid: <code>%%cf_english_title%% (%%title%%)</code></p>';
}

function mangayummy_chapter_details_callback($post) {
    wp_nonce_field('mangayummy_chapter_details', 'mangayummy_chapter_details_nonce');
    $manga_id = get_post_meta($post->ID, '_manga_id', true);
    $chapter_number = get_post_meta($post->ID, '_chapter_number', true);
    $translation_group = get_post_meta($post->ID, '_translation_group', true);
    $chapter_language = get_post_meta($post->ID, '_chapter_language', true) ?: 'ro';
    $mangadex_chapter_id = get_post_meta($post->ID, '_mangadex_chapter_id', true);
    
    echo '<p><label>Serie Manga:</label><select name="manga_id" id="manga-select">';
    
    // Use transient cache for manga list (admin only, 10 min cache)
    $cache_key = 'admin_manga_list';
    $mangas = get_transient($cache_key);
    
    if ($mangas === false) {
        $mangas = get_posts(array(
            'post_type' => 'manga', 
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'post_status' => 'publish',
            'fields' => 'ids', // Only get IDs first
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false
        ));
        set_transient($cache_key, $mangas, 10 * MINUTE_IN_SECONDS);
    }
    
    foreach($mangas as $m_id) {
        $m_id = is_object($m_id) ? $m_id->ID : $m_id;
        $title = get_the_title($m_id);
        echo '<option value="' . $m_id . '" ' . selected($manga_id, $m_id, false) . '>' . esc_html($title) . '</option>';
    }
    echo '</select></p>';
    echo '<p><label>Număr Capitol:</label><input type="number" step="0.1" name="chapter_number" value="' . esc_attr($chapter_number) . '"></p>';
    echo '<p><label>Grup de traducere:</label><input type="text" name="translation_group" value="' . esc_attr($translation_group) . '" placeholder="ex: Team Yummy, Scanlation Group..."></p>';
    echo '<p><label>Limbă:</label><select name="chapter_language">
        <option value="ro" ' . selected($chapter_language, 'ro', false) . '>Română 🇷🇴</option>
        <option value="en" ' . selected($chapter_language, 'en', false) . '>English 🇺🇸</option>
    </select></p>';
    
    // MangaDex integration UI removed per request
}

function mangayummy_chapter_zip_upload_callback($post) {
    wp_nonce_field('mangayummy_chapter_zip_upload', 'mangayummy_chapter_zip_upload_nonce');

    // Check if chapter already has images
    $existing_images = get_post_meta($post->ID, '_chapter_images', true);
    $has_images = !empty($existing_images) && is_array($existing_images);

    ?>
    <div id="zip-upload-section" style="background: #f9f9f9; padding: 15px; border-radius: 8px; border: 1px solid #e1e1e1;">
        <h4 style="margin-top: 0; color: #333;">📦 Upload ZIP with Images</h4>

        <?php if ($has_images): ?>
            <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
                <strong>⚠️ Attention:</strong> This chapter already has images uploaded. New upload will replace existing images.
            </div>
        <?php endif; ?>

        <div style="margin-bottom: 15px;">
            <label for="chapter_zip_file" style="display: block; margin-bottom: 8px; font-weight: 600;">
                Select ZIP file:
            </label>
            <input
                type="file"
                id="chapter_zip_file"
                name="chapter_zip_file"
                accept=".zip"
                style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; background: #fff;"
            />
            <p style="font-size: 12px; color: #666; margin-top: 5px;">
                Select a ZIP file that contains chapter images (formats: .jpg, .jpeg, .png, .gif, .webp).<br>
                Images will be automatically sorted alphabetically in the ZIP.
            </p>
        </div>

        <button type="button" id="process-zip-upload" class="button button-primary" style="background: #28a745; border-color: #28a745;">
            📦 Process ZIP
        </button>
        <button type="button" id="delete-chapter-images" class="button button-secondary" style="margin-left: 10px; background: #dc3545; border-color: #dc3545; color: white;">
            🗑️ Delete All Images
        </button>

        <div id="zip-upload-progress" style="display: none; margin-top: 15px;">
            <div style="background: #f0f0f0; border-radius: 4px; overflow: hidden; height: 20px;">
                <div id="zip-upload-progress-bar" style="background: #28a745; height: 100%; width: 0%; transition: width 0.3s;"></div>
            </div>
            <p id="zip-upload-progress-text" style="margin-top: 10px; color: #666; font-size: 12px;">Procesare...</p>
        </div>

        <div id="zip-upload-result" style="display: none; margin-top: 15px; padding: 10px; border-radius: 4px;"></div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#process-zip-upload').on('click', function(e) {
            e.preventDefault();

            var $btn = $(this);
            var $progress = $('#zip-upload-progress');
            var $progressBar = $('#zip-upload-progress-bar');
            var $progressText = $('#zip-upload-progress-text');
                        <p id="zip-upload-progress-text" style="margin-top: 10px; color: #666; font-size: 12px;">Processing...</p>
            var $result = $('#zip-upload-result');
            var $fileInput = $('#chapter_zip_file');

            var file = $fileInput[0].files[0];

            if (!file) {
                $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">Please select a ZIP file!</div>');
                return;
            }

            if (file.type !== 'application/zip' && file.type !== 'application/x-zip-compressed' && !file.name.toLowerCase().endsWith('.zip')) {
                $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">Please select a valid ZIP file!</div>');
                return;
            }

            if (file.size > 200 * 1024 * 1024) { // 200MB limit
                $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">ZIP file is too large! Limit is 200MB.</div>');
                return;
            }

            $btn.prop('disabled', true).text('📦 Procesare...');
                        $btn.prop('disabled', true).text('📦 Processing...');
            $progress.show();
            $progressBar.css('width', '30%');
            $progressText.text('Loading file...');
            $result.show().html('<div style="background: #e3f2fd; border: 1px solid #bbdefb; color: #1976d2; padding: 10px; border-radius: 4px;">Processing ZIP...</div>');

            var formData = new FormData();
            formData.append('action', 'mangayummy_process_zip_upload');
            formData.append('nonce', '<?php echo wp_create_nonce("ya_ajax_nonce"); ?>');
            formData.append('post_id', <?php echo $post->ID; ?>);
            formData.append('zip_file', file);

            $.ajax({
                url: ajaxurl || '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                xhr: function() {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            var percentComplete = (e.loaded / e.total) * 30;
                            $progressBar.css('width', percentComplete + '%');
                            $progressText.text('Uploading: ' + Math.round(percentComplete) + '%');
                        }
                    });
                    return xhr;
                },
                success: function(response) {
                    $progressBar.css('width', '100%');
                    $progressText.text('Complete!');

                    setTimeout(function() {
                        $progress.hide();
                        $btn.prop('disabled', false).html('📦 Process ZIP');
                        $fileInput.val('');

                        if (response.success) {
                            $result.show().html('<div style="background: #efe; border: 1px solid #cfc; color: #363; padding: 10px; border-radius: 4px;">✅ ' + response.data.message + '</div>');

                            // Reload the images meta box
                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        } else {
                            $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">❌ ' + (response.data.message || 'Unknown error') + '</div>');
                        }
                    }, 500);
                },
                error: function(xhr, status, errorMsg) {
                    $progress.hide();
                    $btn.prop('disabled', false).html('📦 Process ZIP');
                    $fileInput.val('');
                    $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">❌ Connection error: ' + errorMsg + '</div>');
                }
            });
        });

        // Delete all chapter images
        $('#delete-chapter-images').on('click', function(e) {
            e.preventDefault();

            var $btn = $(this);
            var $result = $('#zip-upload-result');

            if (!confirm('Ești sigur că vrei să ștergi TOATE imaginile din acest capitol?\n\nAceastă acțiune este ireversibilă!')) {
                            if (!confirm('Are you sure you want to delete ALL images from this chapter?\n\nThis action is irreversible!')) {
                return;
            }

            $btn.prop('disabled', true).text('🗑️ Se șterg...');
                        $btn.prop('disabled', true).text('🗑️ Deleting...');
            $result.show().html('<div style="background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 10px; border-radius: 4px;">Se șterg imaginile...</div>');
            $result.show().html('<div style="background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 10px; border-radius: 4px;">Deleting images...</div>');

            $.ajax({
                url: ajaxurl || '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'mangayummy_delete_chapter_images',
                    nonce: '<?php echo wp_create_nonce("ya_ajax_nonce"); ?>',
                    post_id: <?php echo $post->ID; ?>
                },
                success: function(response) {
                    $btn.prop('disabled', false).html('🗑️ Delete All Images');

                    if (response.success) {
                        $result.show().html('<div style="background: #efe; border: 1px solid #cfc; color: #363; padding: 10px; border-radius: 4px;">✅ ' + response.data.message + '</div>');

                        // Reload the images meta box
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">❌ ' + (response.data.message || 'Unknown error') + '</div>');
                    }
                },
                error: function(xhr, status, errorMsg) {
                    $btn.prop('disabled', false).html('🗑️ Delete All Images');
                    $result.show().html('<div style="background: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px;">❌ Connection error: ' + errorMsg + '</div>');
                }
            });
        });
    });
    </script>
    <?php
}

function mangayummy_save_meta_boxes($post_id) {
    $post = get_post($post_id);
    
    // Skip autosaves
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Skip auto-draft posts (don't save meta until post is actually created)
    if ($post->post_status === 'auto-draft') {
        mangayummy_debug_log('mangapress: SKIP chapter_save for post ' . $post_id . ' (status=auto-draft)');
        return;
    }
    
    // Verify nonce for chapter details metabox
    if ($post->post_type === 'chapter') {
        if (!isset($_POST['mangayummy_chapter_details_nonce']) || 
            !wp_verify_nonce($_POST['mangayummy_chapter_details_nonce'], 'mangayummy_chapter_details')) {
            return;
        }
    }
    
    // Verify nonce for manga details metabox (and english title box)
    if ($post->post_type === 'manga') {
        if (isset($_POST['mangayummy_manga_english_title_nonce']) &&
            !wp_verify_nonce($_POST['mangayummy_manga_english_title_nonce'], 'mangayummy_manga_english_title')) {
            return;
        }
        if (!isset($_POST['mangayummy_manga_details_nonce']) || 
            !wp_verify_nonce($_POST['mangayummy_manga_details_nonce'], 'mangayummy_manga_details')) {
            return;
        }
    }
    
    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['chapter_image_urls'])) {
        // Get array of URLs and sanitize
        $image_urls = $_POST['chapter_image_urls'];

        // Filter out empty URLs, normalize path and sanitize each one
        $sanitized_urls = array_filter(
            array_map(function($url) {
                $url = mangayummy_normalize_chapter_image_url($url);
                // Validate it's a proper URL
                if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                    return esc_url_raw($url);
                }
                return '';
            }, $image_urls)
        );

        // Save as comma-separated string for backward compatibility
        update_post_meta($post_id, '_chapter_images', implode(',', $sanitized_urls));
    }
    // MangaDex chapter ID saving removed (integration disabled)
    if (isset($_POST['manga_18'])) {
        update_post_meta($post_id, '_manga_18', 1);
    } else {
        update_post_meta($post_id, '_manga_18', 0);
    }
    if (isset($_POST['english_title'])) {
        $eng = trim(sanitize_text_field($_POST['english_title']));
        if ($eng !== '') {
            update_post_meta($post_id, 'english_title', $eng);
        } else {
            delete_post_meta($post_id, 'english_title');
        }
    }
    if (isset($_POST['alternative_titles'])) {
        $alt_titles_text = sanitize_textarea_field($_POST['alternative_titles']);
        $alt_titles_array = array_filter(array_map('trim', explode("\n", $alt_titles_text)));
        update_post_meta($post_id, '_alternative_titles', $alt_titles_array);
        // Store searchable version for search functionality
        update_post_meta($post_id, '_alternative_titles_search', implode(' ', $alt_titles_array));
    }
    if (isset($_POST['manga_type'])) {
        update_post_meta($post_id, '_manga_type', sanitize_text_field($_POST['manga_type']));
    }
    if (isset($_POST['status'])) {
        update_post_meta($post_id, '_status', sanitize_text_field($_POST['status']));
    }
    if (isset($_POST['release_year'])) {
        update_post_meta($post_id, '_release_year', intval($_POST['release_year']));
    }
    if (isset($_POST['release_year_end'])) {
        update_post_meta($post_id, '_release_year_end', intval($_POST['release_year_end']));
    }
    if (isset($_POST['anilist_url'])) {
        update_post_meta($post_id, '_anilist_url', esc_url_raw($_POST['anilist_url']));
    }
    if (isset($_POST['myanimelist_url'])) {
        update_post_meta($post_id, '_myanimelist_url', esc_url_raw($_POST['myanimelist_url']));
    }
    // External importer meta fields removed per request.
    if (isset($_POST['official_raw_urls'])) {
        $raw_urls_text = sanitize_textarea_field($_POST['official_raw_urls']);
        $raw_urls = array_filter(array_map('trim', explode("\n", $raw_urls_text)));
        $raw_urls = array_filter($raw_urls, function($url) {
            return !empty($url) && filter_var($url, FILTER_VALIDATE_URL);
        });
        $raw_urls = array_map('esc_url_raw', $raw_urls);
        if (!empty($raw_urls)) {
            update_post_meta($post_id, '_official_raw_urls', $raw_urls);
        } else {
            delete_post_meta($post_id, '_official_raw_urls');
        }
        // Remove old single URL field
        delete_post_meta($post_id, '_official_raw_url');
    }
    // save new translator meta
    if (isset($_POST['translator_user'])) {
        $translator = trim(sanitize_text_field($_POST['translator_user']));
        if ($translator !== '') {
            $translator_id = 0;

            // If the input is a numeric ID, use it directly (if it exists), otherwise try lookup by login/display name.
            if (is_numeric($translator)) {
                $possible_id = intval($translator);
                $user_obj = get_user_by('ID', $possible_id);
                if ($user_obj) {
                    $translator_id = $possible_id;
                }
            }

            if (!$translator_id) {
                // Try login first
                $user_obj = get_user_by('login', $translator);
                if (!$user_obj) {
                    // Fallback to display_name (may not be unique)
                    $user_query = new WP_User_Query(array(
                        'search'         => esc_attr($translator),
                        'search_columns' => array('display_name'),
                        'number'         => 1,
                    ));
                    $users_found = $user_query->get_results();
                    if (!empty($users_found)) {
                        $user_obj = $users_found[0];
                    }
                }

                if ($user_obj) {
                    $translator_id = $user_obj->ID;
                }
            }

            $user_obj_log = $user_obj ? sprintf('ID=%d login=%s display_name=%s', $user_obj->ID, $user_obj->user_login, $user_obj->display_name) : 'null';
            $save_value = $translator_id ? $translator_id : $translator;

            if ($translator_id) {
                update_post_meta($post_id, '_translator_user', $translator_id);
            } else {
                // Preserve legacy behavior when no matching user exists
                update_post_meta($post_id, '_translator_user', $translator);
            }
        } else {
            delete_post_meta($post_id, '_translator_user');
        }
    }

    if (isset($_POST['translator_status'])) {
        $translator_status = sanitize_text_field($_POST['translator_status']);
        if (in_array($translator_status, array('in_progress', 'completed', 'abandoned'), true)) {
            update_post_meta($post_id, '_translator_status', $translator_status);
        } else {
            delete_post_meta($post_id, '_translator_status');
        }
    } else {
        delete_post_meta($post_id, '_translator_status');
    }

    if (isset($_POST['translator_donation_enabled'])) {
        update_post_meta($post_id, '_translator_donation_enabled', '1');
    } else {
        delete_post_meta($post_id, '_translator_donation_enabled');
    }

    if (isset($_POST['translator_donation_url'])) {
        $translator_donation_url = trim($_POST['translator_donation_url']);
        $sanitized_donation_url = $translator_donation_url ? esc_url_raw($translator_donation_url) : '';
        if ($sanitized_donation_url !== '') {
            update_post_meta($post_id, '_translator_donation_url', $sanitized_donation_url);
        } else {
            delete_post_meta($post_id, '_translator_donation_url');
        }
    } else {
        delete_post_meta($post_id, '_translator_donation_url');
    }

    if (isset($_POST['recommended'])) {
        update_post_meta($post_id, '_recommended', '1');
    } else {
        delete_post_meta($post_id, '_recommended');
    }

    // New fields for chapter redirect behavior
    if (isset($_POST['redirect_chapters_enabled']) && $_POST['redirect_chapters_enabled'] === '1') {
        update_post_meta($post_id, '_redirect_chapters_enabled', '1');
    } else {
        delete_post_meta($post_id, '_redirect_chapters_enabled');
    }

    if (isset($_POST['redirect_chapters_url'])) {
        $redirect_url = trim(sanitize_text_field($_POST['redirect_chapters_url']));
        if (!empty($redirect_url)) {
            update_post_meta($post_id, '_redirect_chapters_url', esc_url_raw($redirect_url));
        } else {
            delete_post_meta($post_id, '_redirect_chapters_url');
        }
    }

    if (isset($_POST['manga_id'])) {
        $manga_id = intval($_POST['manga_id']);
        update_post_meta($post_id, '_manga_id', $manga_id);
        mangayummy_debug_log('✅ Chapter Save: manga_id = ' . $manga_id . ' (post_id: ' . $post_id . ')');
        // Clear caches
        delete_transient('manga_first_chapters_' . $manga_id);
        delete_transient('manga_chapters_list_' . $manga_id);
    } else {
        mangayummy_debug_log('⚠️ Chapter Save: manga_id MISSING! (post_id: ' . $post_id . ')');
    }
    if (isset($_POST['chapter_number'])) {
        $num = trim((string) $_POST['chapter_number']);
        if (function_exists('mangayummy_normalize_chapter_number')) {
            $num = mangayummy_normalize_chapter_number($num);
        }
        update_post_meta($post_id, '_chapter_number', $num);
        // Clear caches
        $manga_id_for_cache = get_post_meta($post_id, '_manga_id', true);
        if ($manga_id_for_cache) {
            delete_transient('manga_first_chapters_' . $manga_id_for_cache);
            delete_transient('manga_chapters_list_' . $manga_id_for_cache);
        }
    }
    if (isset($_POST['translation_group'])) {
        // Sanitize and trim whitespace
        $group_value = trim(sanitize_text_field($_POST['translation_group']));
        // Force UTF-8 encoding in case de issues
        if (!mb_check_encoding($group_value, 'UTF-8')) {
            $group_value = mb_convert_encoding($group_value, 'UTF-8');
        }
        update_post_meta($post_id, '_translation_group', $group_value);
        mangayummy_debug_log('✅ Chapter Save: translation_group = ' . $group_value . ' (post_id: ' . $post_id . ')');
    } else {
        mangayummy_debug_log('⚠️ Chapter Save: translation_group MISSING! (post_id: ' . $post_id . ')');
    }
    if (isset($_POST['chapter_language'])) {
        $language = sanitize_text_field($_POST['chapter_language']);
        if (in_array($language, ['ro', 'en'])) {
            update_post_meta($post_id, '_chapter_language', $language);
        }
    }
}
add_action('save_post_manga', 'mangayummy_save_meta_boxes', 10);
add_action('save_post_chapter', 'mangayummy_save_meta_boxes', 10);

// ===== AUTO-FLUSH CACHE WHEN CHAPTER IS PUBLISHED =====
// Ensures new chapters appear instantly without cache delays
// ===== AUTO-SYNC CHAPTER NUMBER TO YOAST SEO =====
// Run at priority 20 (after meta box save at priority 10)
add_action('save_post_chapter', function ($post_id) {
    // Skip autosaves and revisions
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    // Get the chapter post
    $chapter = get_post($post_id);
    if (!$chapter || $chapter->post_type !== 'chapter') {
        return;  // Not a chapter, stop
    }

    // CRITICAL: Verify _manga_id exists and is valid
    $manga_id = get_post_meta($post_id, '_manga_id', true);
    $manga_id = intval($manga_id);

    // VALIDATE: _manga_id must exist, be > 0, and point to a valid manga post
    if (empty($manga_id)) {
        return;
    }

    // Verify the manga exists and is post_type = 'manga'
    $manga = get_post($manga_id);
    if (!$manga || $manga->post_type !== 'manga' || $manga->post_status === 'trash') {
        return;
    }

    // SUCCESS: Valid chapter-to-manga relationship
    
    // ===== AUTO-SYNC CHAPTER_NUMBER TO YOAST SEO =====
    $chapter_number = get_post_meta($post_id, '_chapter_number', true);
    
    // Only sync if chapter_number is set (including 0 for prolog)
    if ($chapter_number !== '') {
        $manga_title = $manga->post_title;
        
        // YOAST SEO TITLE: "{Manga Title} – Capitolul {number} | MangaYummy"
        $seo_title = $manga_title . " – Capitolul " . $chapter_number . " | MangaYummy";
        update_post_meta($post_id, '_yoast_wpseo_title', $seo_title);
        
        // YOAST META DESCRIPTION - simplificat conform cerinței
        $seo_description = "Citește cea mai recentă manga " . $manga_title . " in romana, capitolul " . $chapter_number . ", pe MangaYummy.";
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $seo_description);
        
        // NOTIFY YOAST OF CHANGE: Apply filter so Yoast sees updated values
        apply_filters('wpseo_title', $seo_title, $post_id);
        apply_filters('wpseo_metadesc', $seo_description, $post_id);
    }
    
    // Clear only the specific object cache keys we know are used by chapter-related queries.
    // Avoid full cache flush because it can be slow and block the publish process.
    wp_cache_delete('chapter_number_' . intval($post_id), 'mangayummy');
    wp_cache_delete('manga_chapters_list_' . $manga_id, 'mangayummy');
    wp_cache_delete('manga_latest_chapters_' . $manga_id, 'mangayummy');
    wp_cache_delete('manga_first_last_' . $manga_id, 'mangayummy');
    wp_cache_delete('chapter_nav_' . $manga_id, 'mangayummy');

    // Update last chapter timestamp to invalidate any cache keys based on this
    update_post_meta($manga_id, '_last_chapter_update', time());
    
    // Clear any post-specific cache
    clean_post_cache($manga_id);
    clean_post_cache($post_id);
    
    // Delete transient caches for this manga (chapters list, first/last chapters, navigation)
    delete_transient('manga_chapters_list_' . $manga_id);
    delete_transient('manga_latest_chapters_' . $manga_id);
    delete_transient('manga_first_last_' . $manga_id);
    delete_transient('chapter_nav_' . $manga_id);
    
    // SEO: Ping search engines about sitemap update (only on publish, not draft)
    if ($chapter->post_status === 'publish') {
        $sitemap_url = home_url('/sitemap_index.xml');
        $chapter_url = get_permalink($post_id);
        
        // Ping Google sitemap
        wp_remote_get('https://www.google.com/ping?sitemap=' . urlencode($sitemap_url), [
            'timeout' => 3,
            'blocking' => false
        ]);
        
        // IndexNow ping for faster Bing/Yandex indexing
        // Note: Requires IndexNow key file at root (indexnow-key.txt)
        $indexnow_key = get_option('mangayummy_indexnow_key', '');
        if ($indexnow_key) {
            wp_remote_post('https://api.indexnow.org/IndexNow', [
                'timeout' => 3,
                'blocking' => false,
                'headers' => ['Content-Type' => 'application/json'],
                'body' => wp_json_encode([
                    'host' => wp_parse_url(home_url(), PHP_URL_HOST),
                    'key' => $indexnow_key,
                    'keyLocation' => home_url('/' . $indexnow_key . '.txt'),
                    'urlList' => [$chapter_url, get_permalink($manga_id)]
                ])
            ]);
        }
    }
}, 20); // Priority 20 - run AFTER meta box save (priority 10)

// ===== ENQUEUE CHAPTER LIVE PREVIEW SCRIPT =====
add_action('admin_enqueue_scripts', function($hook) {
    global $post;
    
    // Only on chapter edit page
    if ($hook !== 'post.php' && $hook !== 'post-new.php') {
        return;
    }
    
    if (!isset($post) || $post->post_type !== 'chapter') {
        return;
    }
    
    // Enqueue chapter autosave script (salvează ultimo manga_id și translation_group per capitol)
    $autosave_script = get_template_directory() . '/js/chapter-admin-autosave.js';
    $autosave_version = file_exists($autosave_script) ? filemtime($autosave_script) : '1.0';
    wp_enqueue_script('chapter-admin-autosave', get_template_directory_uri() . '/js/chapter-admin-autosave.js', array(), $autosave_version, true);
    
    // Localize to pass post ID
    wp_localize_script('chapter-admin-autosave', 'chapterAutosaveData', array(
        'postId' => $post->ID
    ));
    
    // Enqueue live preview script with filemtime to force cache busting
    $script_path = get_template_directory() . '/js/chapter-live-preview.js';
    $script_version = file_exists($script_path) ? filemtime($script_path) : '1.0';
    wp_enqueue_script('chapter-live-preview', get_template_directory_uri() . '/js/chapter-live-preview.js', array('jquery'), $script_version, true);
    
    // Localize script with nonces and AJAX URL
    wp_localize_script('chapter-live-preview', 'chapterPreviewData', array(
        'nonce' => wp_create_nonce('chapter_preview_nonce'),
        'saveNonce' => wp_create_nonce('chapter_save_seo_nonce'),
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'postId' => $post->ID
    ));

    // Enqueue a small script that fetches the generated focus keyphrase and
    // populates Yoast/RankMath focus inputs on page load (so Update appears automatic)
    $focus_script_path = get_template_directory() . '/js/chapter-focus-populate.js';
    $focus_version = file_exists($focus_script_path) ? filemtime($focus_script_path) : '1.0';
    wp_enqueue_script('chapter-focus-populate', get_template_directory_uri() . '/js/chapter-focus-populate.js', array('chapter-live-preview'), $focus_version, true);
});

// ===== AJAX HANDLER: Get manga title for chapter preview =====
add_action('wp_ajax_mangayummy_get_manga_title', function() {
    // Verify nonce and permissions
    check_ajax_referer('chapter_preview_nonce', 'nonce');

    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    $manga_id = intval($_POST['manga_id'] ?? 0);
    if ($manga_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid manga ID'));
    }

    $manga = get_post($manga_id);
    if (!$manga || $manga->post_type !== 'manga') {
        wp_send_json_error(array('message' => 'Manga not found'));
    }

    wp_send_json_success(array(
        'title' => $manga->post_title
    ));
});

// ===== AJAX HANDLER: Return generated focus keyphrase for a chapter =====
add_action('wp_ajax_mangayummy_get_chapter_focus', 'mangayummy_get_chapter_focus_ajax');
function mangayummy_get_chapter_focus_ajax() {
    check_ajax_referer('chapter_preview_nonce', 'nonce');

    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        wp_send_json_error(array('message' => 'Invalid post_id'));
    }

    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'chapter') {
        wp_send_json_error(array('message' => 'Post not found or not a chapter'));
    }

    // If a focus key already exists in any known meta, prefer that
    $focus_keys = array(
        '_yoast_wpseo_focuskw', 'yoast_wpseo_focuskw', 'yoast_wpseo_focus_keyword',
        '_yoast_wpseo_primary_keyword', 'yoast_focuskw', 'wpseo_focuskw', 'focus_keyword',
        'rank_math_focus_keyword'
    );

    foreach ($focus_keys as $k) {
        $val = get_post_meta($post_id, $k, true);
        if (is_string($val) && trim($val) !== '') {
            wp_send_json_success(array('keyphrase' => trim($val)));
        }
    }

    // Build keyphrase same as auto-fill function
    $manga_id = get_post_meta($post_id, '_manga_id', true);
    if (empty($manga_id)) {
        $manga_id = $post->post_parent;
    }
    $manga_title = '';
    if ($manga_id) {
        $m = get_post($manga_id);
        if ($m) $manga_title = $m->post_title;
    }
    if (!$manga_title) {
        $manga_title = get_the_title($post_id);
    }

    $ch_num = function_exists('mangayummy_get_chapter_number') ? mangayummy_get_chapter_number($post_id) : get_post_meta($post_id, '_chapter_number', true);
    if ($ch_num === null || $ch_num === '') {
        wp_send_json_success(array('keyphrase' => ''));
    }

    $ch_display = str_replace('-', '.', (string)$ch_num);
    // Format requested: no dash and lowercase 'capitolul'
    $keyphrase = trim($manga_title) . ' capitolul ' . $ch_display;
    $keyphrase = sanitize_text_field($keyphrase);

    wp_send_json_success(array('keyphrase' => $keyphrase));
}

// ===== AJAX HANDLER: Save chapter SEO meta for Yoast live preview =====
add_action('wp_ajax_mangayummy_save_chapter_seo', 'mangayummy_save_chapter_seo_ajax');
function mangayummy_save_chapter_seo_ajax() {
    // Verify nonce and permissions
    check_ajax_referer('chapter_save_seo_nonce', 'nonce');

    if (!isset($_POST['post_id']) || !isset($_POST['title']) || !isset($_POST['description'])) {
        wp_send_json_error(array('message' => 'Missing parameters'));
    }

    $post_id = intval($_POST['post_id']);
    $seo_title = sanitize_text_field($_POST['title']);
    $seo_desc = sanitize_text_field($_POST['description']);

    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    // Save meta fields
    update_post_meta($post_id, '_yoast_wpseo_title', $seo_title);
    update_post_meta($post_id, '_yoast_wpseo_metadesc', $seo_desc);

    // Notify Yoast of changes
    apply_filters('wpseo_title', $seo_title, $post_id);
    apply_filters('wpseo_metadesc', $seo_desc, $post_id);

    wp_send_json_success(array('message' => 'SEO meta updated'));
};

/**
 * Attempt to dequeue Hostinger chatbot/admin scripts on specified admin pages
 * to avoid external script errors in the post editor and dashboard.
 * This is a best-effort heuristic that checks registered script src for
 * the substring "hostinger" and removes the script when on the pages
 * requested by the admin: post.php, post-new.php, index.php (dashboard).
 */
add_action('admin_enqueue_scripts', function() {
    global $pagenow, $wp_scripts;

    $skip_pages = array('post.php', 'post-new.php', 'index.php');
    if (!in_array($pagenow, $skip_pages, true)) {
        return;
    }

    if (!isset($wp_scripts) || !is_object($wp_scripts)) {
        return;
    }

    foreach ($wp_scripts->registered as $handle => $obj) {
        $src = isset($obj->src) ? $obj->src : '';
        if (!$src) continue;
        $lower = strtolower($src);
        if (strpos($lower, 'hostinger') !== false || strpos($lower, 'hostinger-chatbot') !== false) {
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }
    }
}, 1);

// (Debug admin notices removed)
 
// ===== Ensure Yoast SEO slug meta is populated for chapter CPT =====
add_action('save_post_chapter', function($post_id, $post, $update) {
    // Skip autosaves and revisions
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    // Only operate on chapter posts
    if (!$post || $post->post_type !== 'chapter') {
        return;
    }

    // Get existing Yoast slug meta
    $yoast_slug = get_post_meta($post_id, '_yoast_wpseo_slug', true);

    // If Yoast slug already present and non-empty, do nothing
    if ($yoast_slug !== '' && $yoast_slug !== null) {
        return;
    }

    // Prefer the canonical chapter number (treat 0 as valid). Do NOT fallback to post_name.
    if (function_exists('mangayummy_get_chapter_number')) {
        $num = mangayummy_get_chapter_number($post_id);
    } else {
        $meta_num = get_post_meta($post_id, '_chapter_number', true);
        $num = (isset($meta_num) && $meta_num !== '') ? trim((string)$meta_num) : null;
    }

    // Strict check: accept 0 as valid, ignore only null/empty
    if ($num === null || $num === '') {
        // Nothing to set
        return;
    }

    $slug_num = mangayummy_normalize_chapter_number($num);
    $slug_to_set = sanitize_title('capitolul-' . $slug_num);

    if (!empty($slug_to_set)) {
        update_post_meta($post_id, '_yoast_wpseo_slug', $slug_to_set);
    }

}, 99, 3);

// Notify followers when a chapter transitions to publish
add_action('transition_post_status', 'mangayummy_notify_followers_on_new_chapter', 10, 3);

function mangayummy_notify_followers_on_new_chapter($new_status, $old_status, $post) {
    if (!$post || $post->post_type !== 'chapter') {
        return;
    }

    if ($new_status !== 'publish' || $old_status === 'publish') {
        return;
    }

    // Only notify when a chapter becomes published for the first time.
    mangayummy_maybe_notify_followers_on_chapter($post->ID);
}

function mangayummy_maybe_notify_followers_on_chapter($post_id) {
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'chapter') {
        return;
    }

    // Only notify for published chapters
    if ($post->post_status !== 'publish') {
        return;
    }

    global $wpdb;
    $notifications_table = $wpdb->prefix . 'manga_notifications';

    // Avoid duplicate notifications for the same chapter
    // Avoid inserting duplicate notification records for the same user/chapter.
    // We'll check per user below, but if the table has an index on (user_id, chapter_id)
    // this is a no-op and is just a safe fallback.

    $manga_id = get_post_meta($post_id, '_manga_id', true);
    if (!$manga_id) {
        // Some chapters (especially older or manually-created ones) may not have _manga_id meta.
        // Fallback to the post's parent (manga) to ensure follows still work.
        $manga_id = wp_get_post_parent_id($post_id);
    }
    if (!$manga_id) {
        return;
    }

    $chapter_title = get_the_title($post_id);
    $chapter_number = '';
    if (function_exists('mangayummy_get_chapter_number')) {
        $chapter_number = mangayummy_get_chapter_number($post_id);
    } else {
        $chapter_number = get_post_meta($post_id, '_chapter_number', true);
    }

    $manga = get_post($manga_id);
    if (!$manga) {
        return;
    }

    // Discord webhook notification for newly published chapters.
    if (!get_post_meta($post_id, '_discord_chapter_notification_sent', true)) {
        $discord_chapter_number = $chapter_number !== '' ? sanitize_text_field($chapter_number) : get_the_title($post_id);
        $discord_chapter_link   = get_permalink($post_id);

        if (mangayummy_sendDiscordNotification($manga->post_title, $discord_chapter_number, $discord_chapter_link, $manga_id)) {
            update_post_meta($post_id, '_discord_chapter_notification_sent', '1');
        }
    }

    $followers_table = $wpdb->prefix . 'manga_follows';
    $followers = $wpdb->get_col($wpdb->prepare(
        "SELECT user_id FROM $followers_table WHERE manga_id = %d",
        $manga_id
    ));

    if (empty($followers)) {
        return;
    }

    $chapter_link = get_permalink($post_id);
    $subject = sprintf('A apărut un capitol nou la %s', $manga->post_title);

    foreach ($followers as $user_id) {
        // Avoid duplicates for the same user + chapter
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $notifications_table WHERE user_id = %d AND chapter_id = %d LIMIT 1",
            $user_id,
            $post_id
        ));
        if ($exists) {
            continue;
        }

        // Insert notification record
        $wpdb->insert($notifications_table, [
            'user_id' => $user_id,
            'manga_id' => $manga_id,
            'chapter_id' => $post_id,
            'chapter_title' => $chapter_title,
            'chapter_number' => $chapter_number,
            'is_read' => 0,
            'created_at' => current_time('mysql', 1)
        ], ['%d','%d','%d','%s','%s','%d','%s']);

        // Send email
        $user = get_userdata($user_id);
        if (!$user || empty($user->user_email)) {
            continue;
        }

        $body  = "Salut " . esc_html($user->display_name) . ",\n\n";
        $body .= "A apărut un capitol nou în manga \"" . esc_html($manga->post_title) . "\".\n\n";
        $body .= "Capitol: " . esc_html($chapter_title) . "\n";
        if ($chapter_number !== '') {
            $body .= "Număr capitol: " . esc_html($chapter_number) . "\n";
        }
        $body .= "Link: " . esc_url($chapter_link) . "\n\n";
        $body .= "Distracție plăcută!\n";

        if (get_user_meta($user_id, 'mangayummy_email_notif_chapters', true) === '1') {
            wp_mail($user->user_email, $subject, $body);
        }
    }
}

// ===== YOAST SEO INTEGRATION FOR TRANSLATOR GROUP PAGES =====n// Ensure Yoast recognizes translator group pages as indexable content
add_action('wp', function() {
    if (get_query_var('translator_group')) {
        // This ensures translator group pages are indexable
        // Tell Yoast this is crawlable content
        add_filter('wpseo_robots', function($robots) {
            return 'index, follow';
        });
        
        // Set canonical URL for translator group pages
        add_filter('wpseo_canonical', function($canonical) {
            $group_slug = sanitize_title(get_query_var('translator_group'));
            return get_home_url() . '/translator/' . $group_slug . '/';
        });
    }
});

// Add translator group pages to Yoast sitemap
add_filter('wpseo_sitemap_entry', function($entry, $post_id, $type) {
    // This allows translator group pages to appear in sitemap
    return $entry;
}, 10, 3);

// Register translator groups for sitemap inclusion
add_filter('wpseo_enable_xml_sitemap', '__return_true');

// Add custom sitemap entries for translator groups
add_action('init', function() {
    // Skip if transient exists (performance optimization)
    if (get_transient('mangayummy_translator_groups') !== false) {
        return;
    }
    
    // Get all unique translation groups
    $groups = array();
    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'numberposts' => 500, // Limit to recent 500 chapters
        'fields' => 'ids',
        'no_found_rows' => true,
        'update_post_meta_cache' => true,
        'update_post_term_cache' => false
    ));
    
    foreach ($chapters as $chapter_id) {
        $group = get_post_meta($chapter_id, '_translation_group', true);
        if ($group && !in_array($group, $groups)) {
            $groups[] = $group;
        }
    }
    
    // Store groups for sitemap generation (if using custom sitemap)
    if (!empty($groups)) {
        set_transient('mangayummy_translator_groups', $groups, DAY_IN_SECONDS);
    }
});

// Fallback AJAX handler for tag search (autocomplete) specifically for admin genre filter.
// This avoids relying on other plugins or core differences that may return HTTP 400.
add_action('wp_ajax_mangayummy_ajax-tag-search', function() {
    // Accept both POST and GET
    $q = isset($_REQUEST['q']) ? sanitize_text_field(wp_unslash($_REQUEST['q'])) : '';
    $taxonomy = isset($_REQUEST['tax']) ? sanitize_text_field($_REQUEST['tax']) : (isset($_REQUEST['taxonomy']) ? sanitize_text_field($_REQUEST['taxonomy']) : 'genre');

    // Nonce is optional for convenience in admin, but require basic capability check
    $nonce_ok = false;
    if (isset($_REQUEST['security']) && check_ajax_referer('ajax-tag-search', 'security', false)) {
        $nonce_ok = true;
    }

    if (!current_user_can('edit_posts') && !$nonce_ok) {
        wp_send_json_error(array('message' => 'Unauthorized'), 403);
    }

    if (empty($taxonomy)) $taxonomy = 'genre';

    $args = array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
        'number' => 10,
    );
    if ($q !== '') {
        $args['name__like'] = $q;
    }

    $terms = get_terms($args);
    if (is_wp_error($terms)) {
        wp_send_json_error(array('message' => $terms->get_error_message()));
    }

    $out = array();
    foreach ($terms as $t) {
        $out[] = array(
            'term_id' => $t->term_id,
            'id' => $t->term_id,
            'value' => $t->slug,
            'text' => $t->name,
            'name' => $t->name,
        );
    }

    wp_send_json_success($out);
});

// Prevent Yoast from noindexing translator group pages
add_filter('wpseo_robots', function($robots) {
    if (get_query_var('translator_group')) {
        return 'index, follow';
    }
    return $robots;
});

// Set correct meta robots for translator group archive
add_action('template_redirect', function() {
    if (get_query_var('translator_group')) {
        // Ensure not noindexed
        remove_action('wp_head', array(WPSEO_Frontend::get_instance(), 'noindex_page'));
    }
});

// ===== RETROACTIVE CHAPTER SEO MIGRATION =====
// AJAX handler to update Yoast meta for all existing chapters
add_action('wp_ajax_mangayummy_migrate_chapter_seo', function() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    
    // Admin only
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Unauthorized']);
    }
    
    // Get all chapters
    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'numberposts' => -1,
        'post_status' => 'any'
    ));
    
    $updated = 0;
    $skipped = 0;
    $errors = [];
    
    foreach ($chapters as $chapter) {
        $chapter_id = $chapter->ID;
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        $chapter_number = get_post_meta($chapter_id, '_chapter_number', true);
        
        // Skip if missing critical data
        if (!$manga_id || !$chapter_number) {
            $skipped++;
            continue;
        }
        
        // Verify manga exists
        $manga = get_post($manga_id);
        if (!$manga || $manga->post_type !== 'manga') {
            $errors[] = "Chapter {$chapter_id}: Invalid manga_id {$manga_id}";
            $skipped++;
            continue;
        }
        
        $manga_title = $manga->post_title;
        
        // Update Yoast SEO meta
        $seo_title = $manga_title . " – Capitolul " . $chapter_number;
        $seo_description = "Citește " . $manga_title . " Capitolul " . $chapter_number . " online in Romana, gratuit pe MangaYummy.";
        
        update_post_meta($chapter_id, '_yoast_wpseo_title', $seo_title);
        update_post_meta($chapter_id, '_yoast_wpseo_metadesc', $seo_description);
        
        // DO NOT force slug here - let save_post handle it
        
        $updated++;
    }
    
    wp_send_json_success(array(
        'updated' => $updated,
        'skipped' => $skipped,
        'total' => count($chapters),
        'errors' => $errors
    ));
});

// User functions for progress and bookmarks
// Enqueue admin helper: genre search/filter on manga edit screen
add_action('admin_enqueue_scripts', function($hook) {
    global $post;
    if (($hook === 'post.php' || $hook === 'post-new.php') && isset($post) && $post->post_type === 'manga') {
        $script_path = get_template_directory() . '/js/admin-genre-filter.js';
        $script_version = file_exists($script_path) ? filemtime($script_path) : '1.0';
        // Depend on core admin utilities so wp.ajax is available
        wp_enqueue_script('mangayummy-admin-genre-filter', get_template_directory_uri() . '/js/admin-genre-filter.js', array('jquery','wp-util'), $script_version, true);
        // Provide the ajax URL for backward compatibility if wp.ajax not configured
        wp_localize_script('mangayummy-admin-genre-filter', 'mangayummy_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'post_id' => isset($post->ID) ? $post->ID : 0,
            'nonce' => wp_create_nonce('ajax-tag-search'),
        ));
    }
});

function mangayummy_get_first_chapter($manga_id) {
    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'meta_key' => '_chapter_number',
        'orderby' => 'meta_value_num',
        'order' => 'ASC',
        'meta_query' => array(
            array('key' => '_manga_id', 'value' => $manga_id)
        ),
        'numberposts' => 1,
        'cache_results' => false
    ));
    return $chapters ? $chapters[0] : null;
}

function mangayummy_get_last_read_chapter($manga_id, $user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return null;
    $progress = get_user_meta($user_id, 'manga_progress_' . $manga_id, true);
    return $progress ? get_post($progress) : null;
}

function mangayummy_is_manga_bookmarked($manga_id, $user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return false;
    $bookmarks = get_user_meta($user_id, 'bookmarked_mangas', true);
    return is_array($bookmarks) && in_array($manga_id, $bookmarks);
}

function mangayummy_toggle_manga_bookmark($manga_id) {
    $user_id = get_current_user_id();
    if (!$user_id) return false;
    
    // Validate manga_id
    if (!$manga_id || !get_post($manga_id)) return false;
    
    $bookmarks = get_user_meta($user_id, 'bookmarked_mangas', true);
    if (!is_array($bookmarks)) $bookmarks = array();
    
    $key = array_search($manga_id, $bookmarks);
    if ($key !== false) {
        // Remove from bookmarks
        unset($bookmarks[$key]);
        $bookmarks = array_values($bookmarks); // Reindex array
    } else {
        // Add to bookmarks
        $bookmarks[] = $manga_id;
    }
    
    update_user_meta($user_id, 'bookmarked_mangas', $bookmarks);
    return true;
}

function mangayummy_get_bookmark_count($manga_id) {
    return (int) get_post_meta($manga_id, '_bookmark_count', true);
}

// AJAX handlers - login required
add_action('wp_ajax_mangayummy_toggle_bookmark', 'mangayummy_toggle_bookmark');

function mangayummy_ya_get_recent_searches() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $user_id = get_current_user_id();
    $terms = get_user_meta($user_id, 'manga_recent_searches', true);
    if (!is_array($terms)) {
        $terms = [];
    }

    wp_send_json_success(['terms' => array_values($terms)]);
}

function mangayummy_ya_save_recent_searches() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $raw = $_POST['terms'] ?? '[]';
    if (!is_array($raw)) {
        $raw = json_decode(stripslashes($raw), true);
    }
    if (!is_array($raw)) {
        wp_send_json_error(['message' => 'Invalid terms']);
    }

    $terms = array_map('sanitize_text_field', $raw);
    $terms = array_values(array_unique(array_filter($terms, function($v){ return $v !== ''; })));
    if (count($terms) > 20) {
        $terms = array_slice($terms, 0, 20);
    }

    update_user_meta(get_current_user_id(), 'manga_recent_searches', $terms);
    wp_send_json_success(['terms' => $terms]);
}

add_action('wp_ajax_mangayummy_ya_get_recent_searches', 'mangayummy_ya_get_recent_searches');
add_action('wp_ajax_mangayummy_ya_save_recent_searches', 'mangayummy_ya_save_recent_searches');

// Follow / unfollow manga (requires manga_follows table)
function mangayummy_is_following($user_id, $manga_id) {
    if (!$user_id || !$manga_id) {
        return false;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'manga_follows';
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE user_id = %d AND manga_id = %d LIMIT 1",
        $user_id,
        $manga_id
    ));

    return (bool) $exists;
}

function mangayummy_get_manga_follow_count($manga_id) {
    if (!$manga_id) {
        return 0;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'manga_follows';
    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE manga_id = %d",
        $manga_id
    ));
}

function mangayummy_follow_manga() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'mangayummy_follow_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $user_id = get_current_user_id();
    $manga_id = intval($_POST['manga_id'] ?? 0);
    if (!$manga_id || !get_post($manga_id)) {
        wp_send_json_error(['message' => 'Invalid manga ID']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'manga_follows';

    // Insert (ignore duplicates)
    $wpdb->query($wpdb->prepare(
        "INSERT IGNORE INTO $table (user_id, manga_id, created_at) VALUES (%d, %d, %s)",
        $user_id,
        $manga_id,
        current_time('mysql', 1)
    ));

    $count = mangayummy_get_manga_follow_count($manga_id);
    wp_send_json_success(['following' => true, 'count' => $count]);
}

function mangayummy_unfollow_manga() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'mangayummy_follow_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $user_id = get_current_user_id();
    $manga_id = intval($_POST['manga_id'] ?? 0);
    if (!$manga_id || !get_post($manga_id)) {
        wp_send_json_error(['message' => 'Invalid manga ID']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'manga_follows';
    $wpdb->delete($table, ['user_id' => $user_id, 'manga_id' => $manga_id], ['%d', '%d']);

    $count = mangayummy_get_manga_follow_count($manga_id);
    wp_send_json_success(['following' => false, 'count' => $count]);
}

add_action('wp_ajax_mangayummy_follow_manga', 'mangayummy_follow_manga');
add_action('wp_ajax_mangayummy_unfollow_manga', 'mangayummy_unfollow_manga');
add_action('wp_ajax_nopriv_mangayummy_like_chapter', 'mangayummy_like_chapter');
add_action('wp_ajax_mangayummy_like_chapter', 'mangayummy_like_chapter');

function mangayummy_like_chapter() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii conectat pentru a da like.', 'login_required' => true]);
    }

    $user_id = get_current_user_id();
    if (get_user_meta($user_id, '_banned', true)) {
        wp_send_json_error(['message' => 'Contul este blocat.']);
    }

    $chapter_id = intval($_POST['chapter_id'] ?? 0);
    if (!$chapter_id || get_post_type($chapter_id) !== 'chapter') {
        wp_send_json_error(['message' => 'Capitol invalid.']);
    }

    $user_like_key = 'chapter_liked_' . $chapter_id;
    $has_liked = get_user_meta($user_id, $user_like_key, true);
    $like_count = (int) get_post_meta($chapter_id, '_chapter_likes', true);

    if ($has_liked) {
        delete_user_meta($user_id, $user_like_key);
        $like_count = max(0, $like_count - 1);
        update_post_meta($chapter_id, '_chapter_likes', $like_count);
        wp_send_json_success([ 'liked' => false, 'like_count' => $like_count, 'message' => 'Like eliminat.' ]);
    }

    update_user_meta($user_id, $user_like_key, 1);
    $like_count++;
    update_post_meta($chapter_id, '_chapter_likes', $like_count);

    wp_send_json_success([ 'liked' => true, 'like_count' => $like_count, 'message' => 'Like înregistrat! Mulțumim.' ]);
}

// Easter egg achievement unlock (bug hunter)
add_action('wp_ajax_mangayummy_unlock_achievement', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $achievement = sanitize_text_field($_POST['achievement'] ?? '');
    if (!$achievement) {
        wp_send_json_error(['message' => 'Missing achievement']);
    }

    $allowed = array('bug_hunter');
    if (!in_array($achievement, $allowed, true)) {
        wp_send_json_error(['message' => 'Invalid achievement']);
    }

    $awarded = mangayummy_award_achievement(get_current_user_id(), $achievement);
    if ($awarded) {
        wp_send_json_success(['message' => 'Achievement unlocked']);
    } else {
        wp_send_json_success(['message' => 'Already unlocked']);
    }
});

// Remove achievement (e.g., Bug Hunter)
add_action('wp_ajax_mangayummy_remove_achievement', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in', 'login_required' => true]);
    }

    $achievement = sanitize_text_field($_POST['achievement'] ?? '');
    if (!$achievement) {
        wp_send_json_error(['message' => 'Missing achievement']);
    }

    $allowed = array('bug_hunter');
    if (!in_array($achievement, $allowed, true)) {
        wp_send_json_error(['message' => 'Invalid achievement']);
    }

    // Remove from user meta
    $user_id = get_current_user_id();
    $achievements = get_user_meta($user_id, 'mangayummy_achievements', true);
    if (!is_array($achievements)) $achievements = array();

    $key = $achievement;
    if (isset($achievements[$key])) {
        unset($achievements[$key]);
        update_user_meta($user_id, 'mangayummy_achievements', $achievements);
        wp_send_json_success(['message' => 'Achievement removed']);
    }

    wp_send_json_success(['message' => 'Achievement not found']);
});

// Check if user has a specific achievement
add_action('wp_ajax_mangayummy_has_achievement', function() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_success(['hasAchievement' => false]);
    }

    $achievement = sanitize_text_field($_POST['achievement'] ?? '');
    if (!$achievement) {
        wp_send_json_error(['message' => 'Missing achievement']);
    }

    $has = mangayummy_user_has_achievement(get_current_user_id(), $achievement);
    wp_send_json_success(['hasAchievement' => $has]);
});

// REMOVED DUPLICATE: rate_manga() - using mangayummy_manga_rate() instead (line 3577)
// Old hook redirected to new function - login required
add_action('wp_ajax_mangayummy_rate_manga', 'mangayummy_manga_rate');

// Handle bookmark toggle and rating submission
add_action('init', function() {
    if (isset($_POST['submit_rating']) && is_user_logged_in()) {
        $manga_id = intval($_POST['manga_id']);
        $rating = intval($_POST['rating']);
        if ($rating >= 1 && $rating <= 10) {
            mangayummy_set_user_rating($manga_id, get_current_user_id(), $rating);
        }
        wp_redirect(get_permalink($manga_id));
        exit;
    }
    if (isset($_POST['toggle_bookmark'])) {
        if (!is_user_logged_in()) {
            wp_redirect(wp_login_url($_SERVER['REQUEST_URI']));
            exit;
        }
        $manga_id = intval($_POST['toggle_bookmark']);
        if (!$manga_id || !get_post($manga_id)) {
            wp_redirect($_SERVER['REQUEST_URI']);
            exit;
        }
        mangayummy_toggle_manga_bookmark($manga_id);
        // Redirect back to current page
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }
});

// Track manga views
function mangayummy_increment_manga_views($manga_id) {
    // lightweight total per-chapter/post counter (kept for compatibility)
    $views = get_post_meta($manga_id, '_manga_views', true);
    $views = $views ? intval($views) + 1 : 1;
    update_post_meta($manga_id, '_manga_views', $views);

    // Maintain hourly buckets so we can compute an exact last-72-hours sum.
    // Key: 'views_hourly' => array( <hour_timestamp> => count, ... )
    $hour = floor(time() / 3600) * 3600;
    $buckets = get_post_meta($manga_id, 'views_hourly', true);
    if (!is_array($buckets)) $buckets = array();

    if (!isset($buckets[$hour])) {
        $buckets[$hour] = 0;
    }
    $buckets[$hour] = intval($buckets[$hour]) + 1;

    // retain only the last 72 hours of buckets; drop older view records but leave the manga itself intact
    $threshold = time() - 72 * 3600;
    foreach ($buckets as $h => $cnt) {
        if (intval($h) < $threshold) {
            unset($buckets[$h]);
        }
    }
    update_post_meta($manga_id, 'views_hourly', $buckets);

    // Maintain daily buckets for longer period stats (7 days, 1 month, 1 year, etc.)
    // Key: 'views_daily' => array( <day_timestamp> => count, ... )
    $day = strtotime('today midnight');
    $daily_buckets = get_post_meta($manga_id, 'views_daily', true);
    if (!is_array($daily_buckets)) $daily_buckets = array();

    if (!isset($daily_buckets[$day])) {
        $daily_buckets[$day] = 0;
    }
    $daily_buckets[$day] = intval($daily_buckets[$day]) + 1;

    // retain only the last 400 days of buckets (over 1 year)
    $daily_threshold = time() - 400 * 24 * 3600;
    foreach ($daily_buckets as $d => $cnt) {
        if (intval($d) < $daily_threshold) {
            unset($daily_buckets[$d]);
        }
    }
    update_post_meta($manga_id, 'views_daily', $daily_buckets);

    // compute strict last-72-hours sum from whatever buckets exist
    $now = time();
    $last72 = 0;
    $threshold = $now - 72 * 3600;
    foreach ($buckets as $h => $cnt) {
        $ht = intval($h);
        if ($ht >= $threshold) {
            $last72 += intval($cnt);
        }
    }

    // store integer meta for fast SQL queries
    update_post_meta($manga_id, 'views_last72', $last72);

    // keep legacy keys in sync if other code expects them (safe to set to same value)
    update_post_meta($manga_id, 'views_last3', $last72);
    update_post_meta($manga_id, 'views_last4', $last72);
}

// Handle user ratings
function mangayummy_get_manga_rating($manga_id) {
    $total = (float) get_post_meta($manga_id, '_rating_total', true);
    $votes = (int) get_post_meta($manga_id, '_rating_count', true);
    if ($votes == 0) return array('average' => 0, 'count' => 0);
    $average = round($total / $votes, 1);
    return array('average' => $average, 'count' => $votes);
}

function mangayummy_set_user_rating($manga_id, $user_id, $rating) {
    $ratings = get_post_meta($manga_id, '_user_ratings', true);
    if (!is_array($ratings)) $ratings = array();
    $ratings[$user_id] = intval($rating);
    update_post_meta($manga_id, '_user_ratings', $ratings);
}

function mangayummy_get_user_rating($manga_id, $user_id) {
    $ratings = get_post_meta($manga_id, '_user_ratings', true);
    return isset($ratings[$user_id]) ? $ratings[$user_id] : 0;
}

// Register widget areas
function mangayummy_register_widgets() {
    register_sidebar(array(
        'name' => 'Banner Principal Homepage',
        'id' => 'homepage-top-banner',
        'description' => 'Zona banner principal pentru homepage',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => 'Manga Featured Homepage',
        'id' => 'homepage-featured-manga',
        'description' => 'Secțiune manga featured',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => 'Manga Popular Homepage',
        'id' => 'homepage-popular-manga',
        'description' => 'Secțiune manga popular',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => 'Actualizări Recente Homepage',
        'id' => 'homepage-latest-updates',
        'description' => 'Actualizări recente capitole',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
    register_sidebar(array(
        'name' => 'Sidebar Manga',
        'id' => 'sidebar-manga',
        'description' => 'Sidebar pentru pagini manga',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'mangayummy_register_widgets');

// Custom Widgets
class Manga_Slider_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'manga_slider',
            'Slider Manga',
            array('description' => 'Afișează manga într-un slider/carousel')
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        $source = $instance['source'] ?? 'newest';
        $number = $instance['number'] ?? 5;
        $autoplay = $instance['autoplay'] ?? 'off';

        $query_args = array(
            'post_type' => 'manga',
            'posts_per_page' => $number,
        );

        if ($source == 'popular') {
            $query_args['meta_key'] = '_manga_views';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = 'DESC';
        } elseif ($source == 'rating') {
            $query_args['meta_key'] = '_rating';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = 'DESC';
        } else {
            $query_args['orderby'] = 'date';
            $query_args['order'] = 'DESC';
        }

        $mangas = new WP_Query($query_args);

        if ($mangas->have_posts()) {
            echo '<div class="manga-slider" data-autoplay="' . esc_attr($autoplay) . '">';
            while ($mangas->have_posts()) {
                $mangas->the_post();
                echo '<div class="slider-item">';
                if (has_post_thumbnail()) {
                    echo '<a href="' . get_permalink() . '"><img src="' . get_the_post_thumbnail_url(get_the_ID(), 'full') . '" alt="' . get_the_title() . '"></a>';
                }
                echo '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
                echo '</div>';
            }
            echo '</div>';
            wp_reset_postdata();
        }
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = $instance['title'] ?? '';
        $source = $instance['source'] ?? 'newest';
        $number = $instance['number'] ?? 5;
        $autoplay = $instance['autoplay'] ?? 'off';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('source'); ?>">Sursă:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('source'); ?>" name="<?php echo $this->get_field_name('source'); ?>">
                <option value="newest" <?php selected($source, 'newest'); ?>>Cele mai noi</option>
                <option value="popular" <?php selected($source, 'popular'); ?>>Populare</option>
                <option value="rating" <?php selected($source, 'rating'); ?>>Cele mai bine evaluate</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>">Număr de itemi:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="20">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('autoplay'); ?>">Redare automată:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('autoplay'); ?>" name="<?php echo $this->get_field_name('autoplay'); ?>">
                <option value="on" <?php selected($autoplay, 'on'); ?>>Activ</option>
                <option value="off" <?php selected($autoplay, 'off'); ?>>Inactiv</option>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['source'] = sanitize_text_field($new_instance['source']);
        $instance['number'] = intval($new_instance['number']);
        $instance['autoplay'] = sanitize_text_field($new_instance['autoplay']);
        return $instance;
    }
}

function mangayummy_register_manga_widgets() {
    register_widget('Manga_Slider_Widget');
    register_widget('Popular_Manga_Widget');
    register_widget('Latest_Updates_Widget');
}
add_action('widgets_init', 'mangayummy_register_manga_widgets');

class Popular_Manga_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'popular_manga',
            'Manga Popular',
            array('description' => 'Afișează manga popular în grilă')
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        $number = $instance['number'] ?? 6;
        $criteria = $instance['criteria'] ?? 'views';

        $query_args = array(
            'post_type' => 'manga',
            'posts_per_page' => $number,
        );

        if ($criteria == 'views') {
            $query_args['meta_key'] = '_manga_views';
            $query_args['orderby'] = 'meta_value_num';
            $query_args['order'] = 'DESC';
        } elseif ($criteria == 'rating') {
            // For rating, we need to sort by average rating, but since it's calculated, we can use a custom query or sort in PHP
            $query_args['meta_key'] = '_user_ratings';
            $query_args['orderby'] = 'meta_value';
            $query_args['order'] = 'DESC';
            // Note: This is approximate, as meta_value sorts by serialized array. For better accuracy, we might need a custom query.
        }

        $mangas = new WP_Query($query_args);

        if ($mangas->have_posts()) {
            echo '<div class="popular-manga-grid">';
            while ($mangas->have_posts()) {
                $mangas->the_post();
                echo '<div class="manga-item">';
                if (has_post_thumbnail()) {
                    echo '<a href="' . get_permalink() . '"><img src="' . get_the_post_thumbnail_url(get_the_ID(), 'full') . '" alt="' . get_the_title() . '"></a>';
                }
                echo '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
                echo '</div>';
            }
            echo '</div>';
            wp_reset_postdata();
        }
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = $instance['title'] ?? '';
        $number = $instance['number'] ?? 6;
        $criteria = $instance['criteria'] ?? 'views';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('criteria'); ?>">Criteriu:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('criteria'); ?>" name="<?php echo $this->get_field_name('criteria'); ?>">
                <option value="views" <?php selected($criteria, 'views'); ?>>Vizualizări</option>
                <option value="rating" <?php selected($criteria, 'rating'); ?>>Evaluare utilizatori</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>">Număr de itemi:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="20">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['criteria'] = sanitize_text_field($new_instance['criteria']);
        $instance['number'] = intval($new_instance['number']);
        return $instance;
    }
}

class Latest_Updates_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'latest_updates',
            'Actualizări Recente',
            array('description' => 'Afișează ultimele capitole actualizate')
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        $number = $instance['number'] ?? 10;

        $chapters = new WP_Query(array(
            'post_type' => 'chapter',
            'posts_per_page' => $number,
            'orderby' => 'date',
            'order' => 'DESC',
        ));

        if ($chapters->have_posts()) {
            echo '<ul class="latest-updates-list">';
            while ($chapters->have_posts()) {
                $chapters->the_post();
                $manga_id = get_post_meta(get_the_ID(), '_manga_id', true);
                $manga_title = $manga_id ? get_the_title($manga_id) : 'Unknown';
                $chapter_number = get_post_meta(get_the_ID(), '_chapter_number', true);
                echo '<li>';
                echo '<a href="' . get_permalink() . '">' . esc_html($manga_title) . ' - Chapter ' . esc_html($chapter_number) . '</a>';
                echo '<span class="update-date">' . get_the_date() . '</span>';
                echo '</li>';
            }
            echo '</ul>';
            wp_reset_postdata();
        }
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = $instance['title'] ?? '';
        $number = $instance['number'] ?? 10;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>">Număr de itemi:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>" min="1" max="50">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['number'] = intval($new_instance['number']);
        return $instance;
    }
}

// Enable comments for manga and chapter posts (one-time setup on theme activation)
function mangayummy_enable_comments_for_posts() {
    if (get_option('mangayummy_comments_enabled') === 'yes') {
        return; // Already done
    }
    
    $post_types = array('manga', 'chapter');
    
    foreach ($post_types as $post_type) {
        $posts = get_posts(array(
            'post_type' => $post_type,
            'posts_per_page' => 100, // Process in batches
            'post_status' => 'any',
            'fields' => 'ids',
            'no_found_rows' => true
        ));
        
        foreach ($posts as $post_id) {
            wp_update_post(array(
                'ID' => $post_id,
                'comment_status' => 'open'
            ));
        }
    }
    
    update_option('mangayummy_comments_enabled', 'yes');
}
add_action('after_switch_theme', 'mangayummy_enable_comments_for_posts');

// Handle guest comments
function mangayummy_preprocess_comment($commentdata) {
    // If user is not logged in, set author to 'Guest'
    if (!is_user_logged_in()) {
        $commentdata['comment_author'] = 'Guest';
        $commentdata['comment_author_email'] = '';
        $commentdata['comment_author_url'] = '';
    }
    return $commentdata;
}
add_filter('preprocess_comment', 'mangayummy_preprocess_comment');

// Allow comments without registration and without name/email
function mangayummy_allow_guest_comments() {
    update_option('comment_registration', 0);
    update_option('require_name_email', 0);
}
add_action('init', 'mangayummy_allow_guest_comments');

// Handle image uploads in comments
function mangayummy_handle_comment_image($comment_id) {
    if (isset($_FILES['comment_image']) && !empty($_FILES['comment_image']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $attachment_id = media_handle_upload('comment_image', 0);
        
        if (!is_wp_error($attachment_id)) {
            update_comment_meta($comment_id, 'comment_image', $attachment_id);
        }
    }
}
add_action('comment_post', 'mangayummy_handle_comment_image');

/**
 * HOOK: Save chapter comment metadata when commenting on a chapter
 * Links chapter comments to parent manga via comment_meta
 */
add_action('comment_post', 'mangayummy_save_chapter_comment_meta', 10, 3);
function mangayummy_save_chapter_comment_meta($comment_id, $comment_approved, $commentdata) {
    $post_id = $commentdata['comment_post_ID'] ?? 0;
    
    // Only process if this is a comment on a chapter
    if (get_post_type($post_id) !== 'chapter') {
        return;
    }
    
    // Get the manga ID from chapter post meta
    $manga_id = get_post_meta($post_id, '_manga_id', true);
    if (!$manga_id) {
        return;
    }
    
    // Save manga info to comment meta
    add_comment_meta($comment_id, '_manga_id', $manga_id);
    add_comment_meta($comment_id, '_chapter_id', $post_id);
    add_comment_meta($comment_id, '_chapter_title', get_the_title($post_id));
    add_comment_meta($comment_id, '_chapter_number', get_post_meta($post_id, '_chapter_number', true));
}

// Display comment images
function mangayummy_display_comment_image($comment_content) {
    $image_id = get_comment_meta(get_comment_ID(), 'comment_image', true);
    if ($image_id) {
        $image_url = wp_get_attachment_url($image_id);
        $comment_content .= '<div class="comment-image"><img src="' . esc_url($image_url) . '" alt="Comment image" style="max-width: 300px; border-radius: 8px; margin-top: 1rem;"></div>';
    }
    return $comment_content;
}
add_filter('comment_text', 'mangayummy_display_comment_image');

/* ===== ACHIEVEMENT & LEVELING SYSTEM ===== */

// Calculate user level from XP
function mangayummy_calculate_level($xp) {
    if ($xp < 100) return 1;
    if ($xp < 250) return 2;
    if ($xp < 450) return 3;
    if ($xp < 700) return 4;
    if ($xp < 1000) return 5;
    
    // Progressive scaling for higher levels
    $level = 5;
    $required_xp = 1000;
    while ($xp >= $required_xp && $level < 999) {
        $level++;
        $required_xp += 200 + ($level * 50); // Increasing XP requirements
    }
    
    return min($level, 999);
}

// ========== MUTING SYSTEM ==========
// Mute a user for spam (1 hour default)
function mangayummy_mute_user($user_id, $duration = 3600) {
    $muted_until = time() + $duration;
    update_user_meta($user_id, '_muted_until', $muted_until);
    
    // Send notification message to user
    $user = get_user_by('ID', $user_id);
    $message = sprintf(
        'Ai fost mutat pentru spam pe 1 oră. Revii la: %s',
        date('H:i', $muted_until)
    );
    
    mangayummy_send_system_message($user_id, 'MUTING', $message, $muted_until);
}

// Send system message (with auto-expiry)
function mangayummy_send_system_message($recipient_id, $subject, $content, $expires_at = null) {
    if (!$recipient_id) return;
    
    $message_data = [
        'recipient_id' => $recipient_id,
        'sender_id' => 0, // 0 = System message
        'subject' => $subject,
        'content' => $content,
        'timestamp' => current_time('mysql'),
        'is_read' => 0,
        'expires_at' => $expires_at ? date('Y-m-d H:i:s', $expires_at) : null,
    ];
    
    // Store as user meta (serialized JSON array)
    $messages = get_user_meta($recipient_id, 'system_messages', true);
    if (!is_array($messages)) {
        $messages = [];
    }
    $messages[] = $message_data;
    update_user_meta($recipient_id, 'system_messages', $messages);
    
    return true;
}

// Cleanup expired messages
add_action('wp_scheduled_event', 'mangayummy_cleanup_expired_messages');
function mangayummy_cleanup_expired_messages() {
    $args = [
        'fields' => 'ID',
        'number' => 999,
    ];
    
    $users = get_users($args);
    foreach ($users as $user_id) {
        $messages = get_user_meta($user_id, 'system_messages', true);
        if (!is_array($messages)) continue;
        
        $filtered = [];
        foreach ($messages as $msg) {
            // Keep if no expiry or not yet expired
            if (empty($msg['expires_at']) || strtotime($msg['expires_at']) > time()) {
                $filtered[] = $msg;
            }
        }
        
        update_user_meta($user_id, 'system_messages', $filtered);
        
        // Also check if mute time is expired - remove the meta
        $muted_until = get_user_meta($user_id, '_muted_until', true);
        if ($muted_until && time() >= intval($muted_until)) {
            delete_user_meta($user_id, '_muted_until');
        }
    }
}

// Cleanup on hourly cron
add_action('wp_loaded', function() {
    if (!wp_next_scheduled('mangayummy_cleanup')) {
        wp_schedule_event(time(), 'hourly', 'mangayummy_cleanup');
    }
});

add_action('mangayummy_cleanup', 'mangayummy_cleanup_expired_messages');




// one-time clean-up: remove unused monthly_views metadata
add_action('init', function() {
    if (!get_option('mangayummy_monthly_meta_removed')) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key = 'monthly_views'");
        update_option('mangayummy_monthly_meta_removed', 1);
    }
});

// Calculate XP needed to reach a specific level
function mangayummy_calculate_xp_for_level($target_level) {
    if ($target_level <= 1) return 0;
    if ($target_level > 999) $target_level = 999;
    
    $total_xp = 0;
    $level = 1;
    $required_xp = 1000;
    
    while ($level < $target_level) {
        $total_xp = $required_xp;
        $level++;
        $required_xp += 200 + ($level * 50);
    }
    
    return max($total_xp, 0);
}

// Get XP required for next level
function mangayummy_get_xp_for_next_level($level) {
    if ($level <= 0) return 0;
    return $level * 150;
}

// Award achievement
function mangayummy_award_achievement($user_id, $achievement_type, $manga_id = null) {
    if (!$user_id) return false;
    
    $achievements = get_user_meta($user_id, 'mangayummy_achievements', true);
    if (!is_array($achievements)) $achievements = array();
    
    $achievement_key = $achievement_type . ($manga_id ? '_' . $manga_id : '');
    
    // Check if already awarded
    if (isset($achievements[$achievement_key])) return false;
    
    $achievements[$achievement_key] = array(
        'type' => $achievement_type,
        'manga_id' => $manga_id,
        'date' => current_time('timestamp')
    );
    
    update_user_meta($user_id, 'mangayummy_achievements', $achievements);
    
    // Set notification
    update_user_meta($user_id, 'mangayummy_new_achievement', $achievement_key);
    
    return true;
}

// Get user achievements
function mangayummy_get_user_achievements($user_id = null) {
    if (!$user_id) $user_id = get_current_user_id();
    if (!$user_id) return array();
    
    return get_user_meta($user_id, 'mangayummy_achievements', true) ?: array();
}

// Check if user has a specific achievement
function mangayummy_user_has_achievement($user_id, $achievement_type, $manga_id = null) {
    if (!$user_id) return false;
    $achievements = mangayummy_get_user_achievements($user_id);
    if (!is_array($achievements)) return false;

    $achievement_key = $achievement_type . ($manga_id ? '_' . $manga_id : '');
    return isset($achievements[$achievement_key]);
}

// Get total chapters for a manga (optimized with cache)
function mangayummy_get_total_chapters($manga_id) {
    // Try cache first
    $cache_key = 'manga_chapter_count_' . $manga_id;
    $count = wp_cache_get($cache_key);
    
    if ($count === false) {
        global $wpdb;
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} 
             WHERE meta_key = '_manga_id' AND meta_value = %s",
            $manga_id
        ));
        wp_cache_set($cache_key, $count, '', 3600); // Cache for 1 hour
    }
    
    return $count;
}

// Get manga reading progress
function mangayummy_get_manga_progress($user_id, $manga_id) {
    if (!$user_id || !$manga_id) return 0;
    
    // Use the CORRECT key: manga_progress_[MANGA_ID]
    $progress = get_user_meta($user_id, 'manga_progress_' . $manga_id, true);
    return $progress ?: 0;
}

// Update manga reading progress
function mangayummy_update_manga_progress($user_id, $manga_id, $chapter_number) {
    if (!$user_id || !$manga_id) return;
    
    // Update using the CORRECT key that Recent Activity uses
    // USE: manga_progress_[MANGA_ID] (NOT mangapress_progress_)
    update_user_meta($user_id, 'manga_progress_' . $manga_id, $chapter_number);
}

// Award XP for comments
function mangayummy_award_comment_xp($comment_id, $comment) {
    if (!is_user_logged_in()) return;
    
    $user_id = get_current_user_id();
    mangayummy_update_user_xp($user_id, 5);
}
add_action('wp_insert_comment', 'mangayummy_award_comment_xp', 10, 2);

// Update progress when reading chapter
function mangayummy_track_chapter_reading() {
    if (!is_user_logged_in() || !is_singular('chapter')) return;
    
    $user_id = get_current_user_id();
    $chapter_id = get_the_ID();
    $manga_id = get_post_meta($chapter_id, '_manga_id', true);
    $chapter_number = (int) get_post_meta($chapter_id, '_chapter_number', true);
    
    if ($manga_id && $chapter_number !== '') {
        // DISABLED: Auto-add chapter to progress - users now add manually
        // mangapress_update_manga_progress($user_id, $manga_id, $chapter_number);
        
        // DISABLED: Auto-set status to "reading" - users must explicitly choose status
        // Manga only appears in user list if they manually set a status
        
        // Award XP for reading this chapter (only once per chapter per user)
        // Check if user already got XP for this chapter
        $xp_key = 'chapter_xp_' . $chapter_id;
        $has_xp = get_user_meta($user_id, $xp_key, true);
        if (!$has_xp) {
            // Award 10 XP per chapter read
            mangayummy_update_user_xp($user_id, 10);
            // Mark that this user got XP for this chapter
            update_user_meta($user_id, $xp_key, time());
        }

        // Save the reading event in history
        mangayummy_log_chapter_reading_event($user_id, $manga_id, $chapter_id);
    }
}
add_action('wp', 'mangayummy_track_chapter_reading');

// ===== AUTOMATIC PAGES (NO ADMIN PAGES NEEDED) =====

// Add rewrite rules for automatic pages
add_action('init', function () {
    add_rewrite_rule('^random/?$', 'index.php?automatic_page=random_manga', 'top');
    add_rewrite_rule('^top-100-manga/?$', 'index.php?automatic_page=top_100_manga', 'top');
});

// Add query vars for automatic pages
add_filter('query_vars', function ($vars) {
    $vars[] = 'automatic_page';
    return $vars;
});

// Handle automatic page templates
add_action('template_redirect', function () {
    $request_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    if ($request_path === 'aleatoriu') {
        wp_redirect(home_url('/random/'), 301);
        exit;
    }
    if ($request_path === 'top-100-manga-in-romana') {
        wp_redirect(home_url('/top-100-manga/'), 301);
        exit;
    }

    $page_type = get_query_var('automatic_page');

    if ($page_type === 'random_manga') {
        // Random manga redirect
        $args = [
            'post_type'      => 'manga',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'rand',
            'fields'         => 'ids',
        ];

        $query = new WP_Query($args);

        if (!empty($query->posts)) {
            wp_redirect(get_permalink($query->posts[0]));
            exit;
        }

        // Fallback to home if no manga found
        wp_redirect(home_url());
        exit;
    }

    if ($page_type === 'top_100_manga') {
        // Force custom template for TOP 100 MANGA
        $template = locate_template('template-top-100-manga.php');
        if ($template) {
            include($template);
            exit;
        }
    }
});

// ===== SIMPLE MANGA VIEWS (5s IP + COOKIE) =====
function mangayummy_manga_add_view_safe() {
    if (!is_singular('manga') || is_admin()) return;

    $post_id = get_the_ID();
    if (!$post_id) return;

    $ip = mangayummy_get_client_ip();
    $cookie_key = 'manga_view_' . md5($ip . '_' . $post_id);

    // dacă există cookie → NU adăuga view
    if (isset($_COOKIE[$cookie_key])) return;

    // setează cookie 5 sec (timpul minim dintre două vizualizări consecutive pe același IP)
    setcookie($cookie_key, '1', time() + 5, COOKIEPATH, COOKIE_DOMAIN);

    // incrementează total views
    $views = (int) get_post_meta($post_id, 'manga_views_total', true);
    update_post_meta($post_id, 'manga_views_total', $views + 1);

    // also update detailed counters (daily/3‑day) so "popular recent" can work
    if (function_exists('mangayummy_increment_manga_views')) {
        mangayummy_increment_manga_views($post_id);
    }
}
add_action('template_redirect', 'mangayummy_manga_add_view_safe');

// Get level color
function mangayummy_get_level_color($level) {
    if ($level >= 50) return '#ff6b35';
    if ($level >= 25) return '#ffb400';
    if ($level >= 10) return '#4CAF50';
    return '#2196F3';
}

// AJAX handler for notifications
function mangayummy_check_notifications() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');
    
    $user_id = intval($_POST['user_id']);
    if (!$user_id || $user_id !== get_current_user_id()) {
        wp_die();
    }
    
    $response = array(
        'success' => true,
        'data' => array(
            'new_achievement' => false,
            'level_up' => false,
            'new_level' => 0,
            'achievement_data' => array()
        )
    );
    
    // Check for new achievements
    $last_check = get_user_meta($user_id, 'mangayummy_last_notification_check', true);
    $current_time = current_time('timestamp');
    
    if (!$last_check) {
        $last_check = $current_time - 3600; // Check last hour if no previous check
    }
    
    $recent_achievements = get_user_meta($user_id, 'mangayummy_achievements', true);
    if ($recent_achievements && is_array($recent_achievements)) {
        foreach ($recent_achievements as $achievement) {
            if ($achievement['timestamp'] > $last_check) {
                $response['data']['new_achievement'] = true;
                $response['data']['achievement_data'] = $achievement;
                break;
            }
        }
    }
    
    // Check for level up
    $current_xp = get_user_meta($user_id, 'reader_xp', true) ?: 0;
    $current_level = mangayummy_calculate_level($current_xp);
    $stored_level = get_user_meta($user_id, 'reader_level', true) ?: 1;
    
    if ($current_level > $stored_level) {
        $response['data']['level_up'] = true;
        $response['data']['new_level'] = $current_level;
        update_user_meta($user_id, 'reader_level', $current_level);
    }
    
    // Update last check time
    update_user_meta($user_id, 'mangayummy_last_notification_check', $current_time);
    
    wp_send_json($response);
}
add_action('wp_ajax_mangayummy_check_notifications', 'mangayummy_check_notifications');

// Custom user registration handler
function mangayummy_handle_registration() {
    if (!wp_verify_nonce($_POST['register_nonce'], 'register')) {
        wp_die(esc_html__('Nonce verification failed', 'mangayummy'));
    }

    // Validate Cloudflare Turnstile (anti-bot)
    $cf_token = $_POST['cf-turnstile-response'] ?? $_POST['cf_turnstile_response'] ?? '';
    if (empty($cf_token)) {
        wp_redirect(add_query_arg('registration', 'captcha_missing', wp_get_referer()));
        exit;
    }

    if (defined('CLOUDFLARE_TURNSTILE_SECRET')) {
        $cf_verify = wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'body' => [
                'secret' => CLOUDFLARE_TURNSTILE_SECRET,
                'response' => $cf_token,
                'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
            ],
        ]);
        
        if (!is_wp_error($cf_verify)) {
            $cf_result = json_decode(wp_remote_retrieve_body($cf_verify), true);
            if (!isset($cf_result['success']) || $cf_result['success'] !== true) {
                wp_redirect(add_query_arg('registration', 'captcha_failed', wp_get_referer()));
                exit;
            }
        }
    }

    $username = sanitize_user($_POST['user_login']);
    $email = sanitize_email($_POST['user_email']);
    $password = $_POST['user_pass'];
    $password_confirm = $_POST['user_pass_confirm'];
    $gender = sanitize_text_field($_POST['gender'] ?? '');
    $gender = mangayummy_normalize_gender_value($gender);

    if (empty($username) || empty($email) || empty($password)) {
        wp_redirect(add_query_arg('registration', 'empty_fields', wp_get_referer()));
        exit;
    }

    // Validate gender
    if (!in_array($gender, ['masculin', 'feminin'], true)) {
        wp_redirect(add_query_arg('registration', 'invalid_gender', wp_get_referer()));
        exit;
    }

    if (!is_email($email)) {
        wp_redirect(add_query_arg('registration', 'invalid_email', wp_get_referer()));
        exit;
    }

    if (strlen($password) < 6) {
        wp_redirect(add_query_arg('registration', 'password_too_short', wp_get_referer()));
        exit;
    }

    if ($password !== $password_confirm) {
        wp_redirect(add_query_arg('registration', 'password_mismatch', wp_get_referer()));
        exit;
    }

    if (username_exists($username)) {
        wp_redirect(add_query_arg('registration', 'username_exists', wp_get_referer()));
        exit;
    }

    // Validate username format (3-20 chars, letters, numbers, - and _ only)
    if (!preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $username)) {
        wp_redirect(add_query_arg('registration', 'invalid_username', wp_get_referer()));
        exit;
    }

    // Block spam usernames
    if (function_exists('mangayummy_ya_is_spam_username') && mangayummy_ya_is_spam_username($username)) {
        wp_redirect(add_query_arg('registration', 'spam_username', wp_get_referer()));
        exit;
    }
    
    // Additional case-insensitive check
    global $wpdb;
    $user_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM $wpdb->users WHERE LOWER(user_login) = LOWER(%s)",
        $username
    ));
    if ($user_exists) {
        wp_redirect(add_query_arg('registration', 'username_exists', wp_get_referer()));
        exit;
    }

    if (email_exists($email)) {
        wp_redirect(add_query_arg('registration', 'email_exists', wp_get_referer()));
        exit;
    }

    // Only allow gmail.com emails
    if (function_exists('mangayummy_ya_is_temp_email') && mangayummy_ya_is_temp_email($email)) {
        wp_redirect(add_query_arg('registration', 'invalid_email_domain', wp_get_referer()));
        exit;
    }

    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        wp_redirect(add_query_arg('registration', 'creation_failed', wp_get_referer()));
        exit;
    }

    // Initialize user meta for gamification
    update_user_meta($user_id, 'reader_xp', 0);
    update_user_meta($user_id, 'reader_level', 1);
    update_user_meta($user_id, 'mangayummy_achievements', array());
    update_user_meta($user_id, 'bookmarked_mangas', array());

    // Set avatar based on gender
    $avatar_file = ($gender === 'feminin') ? 'default-avatar-female.png' : 'default-avatar-male.png';
    update_user_meta($user_id, 'profile_avatar', get_template_directory_uri() . '/assets/img/' . $avatar_file);
    update_user_meta($user_id, 'user_gender', $gender);
    update_user_meta($user_id, 'gender', $gender);

    // Email verification token (same as auth-register.php)
    $token = wp_generate_password(32, false, false);
    $expires = time() + DAY_IN_SECONDS;
    update_user_meta($user_id, 'email_verified', 0);
    update_user_meta($user_id, 'email_verify_token', $token);
    update_user_meta($user_id, 'email_verify_expires', $expires);

    // Send verification email
    if (function_exists('mangayummy_ya_send_verification_email') && !mangayummy_ya_send_verification_email($email, $token)) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
        wp_delete_user($user_id);
        wp_redirect(add_query_arg('registration', 'email_failed', wp_get_referer()));
        exit;
    }

    wp_redirect(add_query_arg('registration', 'verify_email', wp_get_referer()));
    exit;
}
add_action('admin_post_nopriv_mangayummy_register', 'mangayummy_handle_registration');
add_action('admin_post_mangayummy_register', 'mangayummy_handle_registration');

// Create default pages on theme activation
function mangayummy_create_default_pages() {
    $pages = array(
        array(
            'title' => 'About',
            'slug' => 'about',
            'template' => 'page-despre.php'
        ),
        array(
            'title' => 'Users',
            'slug' => 'users',
            'template' => 'page-utilizatori.php'
        ),
        array(
            'title' => 'Profile',
            'slug' => 'profile',
            'template' => 'page-profile.php'
        ),
        array(
            'title' => 'Messages',
            'slug' => 'messages',
            'template' => 'page-mesaje.php'
        ),
        array(
            'title' => 'Login',
            'slug' => 'login', 
            'template' => 'page-login.php'
        ),
        array(
            'title' => 'Register',
            'slug' => 'register',
            'template' => 'page-register.php'
        ),
        array(
            'title' => 'Settings',
            'slug' => 'settings',
            'template' => 'page-settings.php'
        )
    );

    // Migrate legacy notifications page to new Messages page if it exists.
    $legacy = get_page_by_path('notificari', OBJECT, 'page');
    $existing_messages = get_page_by_path('messages', OBJECT, 'page');
    if ($legacy && !$existing_messages) {
        wp_update_post(array(
            'ID' => $legacy->ID,
            'post_name' => 'messages',
            'post_title' => 'Messages',
        ));
        update_post_meta($legacy->ID, '_wp_page_template', 'page-mesaje.php');
    }

    foreach ($pages as $page) {
        // Check if page exists
        $query = new WP_Query([
            'post_type' => 'page',
            'name' => $page['slug'],
            'posts_per_page' => 1
        ]);
        $existing_page = $query->posts ? $query->posts[0] : null;
        
        if (!$existing_page) {
            // Create the page
            $page_id = wp_insert_post(array(
                'post_title' => $page['title'],
                'post_name' => $page['slug'],
                'post_content' => '',
                'post_status' => 'publish',
                'post_type' => 'page',
                'page_template' => $page['template']
            ));
            
            if ($page_id && !is_wp_error($page_id)) {
                update_post_meta($page_id, '_wp_page_template', $page['template']);
            }
        }
    }
}
add_action('after_switch_theme', 'mangayummy_create_default_pages');

// Ensure critical pages exist on upgrades too (runs once).
function mangayummy_ensure_default_pages_once() {
    if (get_option('mangayummy_default_pages_ensured')) {
        return;
    }

    mangayummy_create_default_pages();
    update_option('mangayummy_default_pages_ensured', 1);
}
add_action('init', 'mangayummy_ensure_default_pages_once', 25);

// Migrate legacy Romanian slugs to English canonical slugs.
function mangayummy_migrate_legacy_romanian_slugs_once() {
    if (get_option('mangayummy_ro_slug_migration_done_v1')) {
        return;
    }

    $slug_map = array(
        'despre' => array('new' => 'about', 'template' => 'page-despre.php'),
        'utilizatori' => array('new' => 'users', 'template' => 'page-utilizatori.php'),
        'mesaje' => array('new' => 'messages', 'template' => 'page-mesaje.php'),
        'stiri' => array('new' => 'news', 'template' => 'page-stiri.php'),
        'recomandate' => array('new' => 'recommended', 'template' => 'page-recomandate.php'),
        'recente-actualizari' => array('new' => 'recent-updates', 'template' => 'page-recente-actualizari.php'),
        'cele-mai-noi-capitole' => array('new' => 'latest-chapters', 'template' => 'page-cele-mai-noi-capitole.php'),
        'cautare-avansata' => array('new' => 'advanced-search', 'template' => 'page-cautare-avansata.php'),
        'mangauri-2026' => array('new' => 'manga-2026', 'template' => 'page-mangauri-2026.php'),
    );

    foreach ($slug_map as $old_slug => $cfg) {
        $new_slug = $cfg['new'];
        $existing_new = get_page_by_path($new_slug, OBJECT, 'page');
        $legacy = get_page_by_path($old_slug, OBJECT, 'page');

        if (!$existing_new && $legacy) {
            wp_update_post(array(
                'ID' => $legacy->ID,
                'post_name' => $new_slug,
            ));
            if (!empty($cfg['template'])) {
                update_post_meta($legacy->ID, '_wp_page_template', $cfg['template']);
            }
        }
    }

    // Migrate legacy child page /stiri/creaza to /news/create.
    $news_page = get_page_by_path('news', OBJECT, 'page');
    if (!$news_page) {
        $news_page = get_page_by_path('stiri', OBJECT, 'page');
    }
    if ($news_page) {
        $legacy_create = get_page_by_path('stiri/creaza', OBJECT, 'page');
        $new_create = get_page_by_path('news/create', OBJECT, 'page');
        if ($legacy_create && !$new_create) {
            wp_update_post(array(
                'ID' => $legacy_create->ID,
                'post_name' => 'create',
                'post_parent' => $news_page->ID,
            ));
            update_post_meta($legacy_create->ID, '_wp_page_template', 'page-creaza.php');
        }
    }

    update_option('mangayummy_ro_slug_migration_done_v1', 1);
}
add_action('init', 'mangayummy_migrate_legacy_romanian_slugs_once', 24);

// Redirect legacy Romanian slugs to English canonical slugs.
add_action('template_redirect', function () {
    if (is_admin()) {
        return;
    }

    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim((string) parse_url($request_uri, PHP_URL_PATH), '/');
    if ($path === '') {
        return;
    }

    $redirect_map = array(
        'despre' => 'about',
        'utilizatori' => 'users',
        'mesaje' => 'messages',
        'stiri' => 'news',
        'stiri/creaza' => 'news/create',
        'recomandate' => 'recommended',
        'recente-actualizari' => 'recent-updates',
        'cele-mai-noi-capitole' => 'latest-chapters',
        'cautare-avansata' => 'advanced-search',
        'mangauri-2026' => 'manga-2026',
    );

    if (!isset($redirect_map[$path])) {
        return;
    }

    $target = home_url('/' . $redirect_map[$path] . '/');
    if (!empty($_SERVER['QUERY_STRING'])) {
        $target .= '?' . sanitize_text_field($_SERVER['QUERY_STRING']);
    }
    wp_safe_redirect($target, 301);
    exit;
}, 2);

// Ensure settings page exists even on sites where older ensure flags already ran.
function mangayummy_ensure_settings_page_exists() {
    $settings_page = get_page_by_path('settings', OBJECT, 'page');

    if (!$settings_page) {
        $page_id = wp_insert_post(array(
            'post_title'   => 'Settings',
            'post_name'    => 'settings',
            'post_content' => '',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ));

        if ($page_id && !is_wp_error($page_id)) {
            update_post_meta($page_id, '_wp_page_template', 'page-settings.php');
        }
        return;
    }

    if (get_post_meta($settings_page->ID, '_wp_page_template', true) !== 'page-settings.php') {
        update_post_meta($settings_page->ID, '_wp_page_template', 'page-settings.php');
    }
}
add_action('init', 'mangayummy_ensure_settings_page_exists', 26);

// Pages are created on theme activation, not on every load (production optimized)

// Custom comment callback to show user levels
function mangayummy_comment_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    $commenter = wp_get_current_commenter();
    $user = $comment->user_id ? get_userdata($comment->user_id) : null;
    
    // Get user level if commenter is registered
    $user_level = '';
    if ($user && $user->ID) {
        $user_data = mangayummy_get_user_xp_level($user->ID);
        $level_tier_class = mangayummy_get_user_level_tier_class($user->ID);
        $level_class = 'comment-user-level';
        if ($level_tier_class) {
            $level_class .= ' ' . $level_tier_class;
        }
        $user_level = '<span class="' . esc_attr($level_class) . '">Level ' . $user_data['level'] . '</span>';
    }
    
    echo '<li ' . comment_class('', $comment->comment_ID, null, false) . ' id="comment-' . get_comment_ID() . '">';
    echo '<article class="comment-body">';
    
    // Comment author avatar
    echo '<div class="comment-avatar-wrapper">';
    // Generate avatar HTML directly - bypass all filters temporarily
    $comment_user_id = intval($comment->user_id);
    if ($comment_user_id > 0) {
        $user = get_user_by('id', $comment_user_id);
        $avatar_url = $user ? get_user_meta($user->ID, 'profile_avatar', true) : '';
        if (!$avatar_url) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }
    } else {
        $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
    }
    echo '<img src="' . esc_url($avatar_url) . '" class="comment-avatar" width="48" height="48" alt="avatar" />';
    echo '</div>';
    
    // Comment content
    echo '<div class="comment-content-wrapper">';
    echo '<div class="comment-meta">';
    echo '<span class="comment-author">';
    if ($user && $user->ID) {
        echo '<a href="' . esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user->ID), home_url('/'))) . '">' . esc_html($comment->comment_author) . '</a>';
    } else {
        echo esc_html($comment->comment_author);
    }
    if ($user_level) {
        echo ' ' . $user_level;
    }
    echo '</span>';
    echo '</div>';
    
    echo '<div class="comment-content">';
    comment_text();
    echo '</div>';
    
    // Comment reply link
    comment_reply_link(array_merge($args, array(
        'depth' => $depth,
        'max_depth' => $args['max_depth'],
        'reply_text' => 'Răspunde'
    )));
    
    echo '</div>';
    echo '</article>';
}

// Custom Navigation Walker to exclude login/register menu items
class Custom_Nav_Walker extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        // Skip menu items that contain 'login' or 'register' in the title
        if (stripos($item->title, 'login') !== false || stripos($item->title, 'register') !== false) {
            return;
        }
        
        parent::start_el($output, $item, $depth, $args, $id);
    }
}

// ===== GAMIFICATION FUNCTIONS =====

// Get user XP and level data
function mangayummy_get_user_xp_level($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!$user_id) return array('xp' => 0, 'level' => 1);
    
    $xp = (int) get_user_meta($user_id, 'reader_xp', true);
    $level = 1;
    
    // Calculate level based on XP
    while ($xp >= mangayummy_get_xp_for_next_level($level) && $level < 999) {
        $level++;
    }
    
    // Ensure level doesn't exceed calculated level
    if ($level > 1 && $xp < mangayummy_get_xp_for_next_level($level - 1)) {
        $level--;
    }
    
    return array('xp' => $xp, 'level' => $level);
}

// Update user XP
function mangayummy_update_user_xp($user_id, $xp_amount) {
    if (!$user_id || $xp_amount <= 0) return;
    
    $current_xp = (int) get_user_meta($user_id, 'reader_xp', true);
    $new_xp = $current_xp + $xp_amount;
    
    update_user_meta($user_id, 'reader_xp', $new_xp);
    
    // Check for level up
    $user_data = mangayummy_get_user_xp_level($user_id);
    $old_level = (int) get_user_meta($user_id, 'reader_level', true);
    
    if ($user_data['level'] > $old_level) {
        update_user_meta($user_id, 'reader_level', $user_data['level']);
        // Could add level up notification here
    }
}

// Get total chapters read by user (only count manga with actual progress > 0)
function mangayummy_get_user_read_count($user_id) {
    if (!$user_id) return 0;
    
    $read_count = 0;
    $progress_meta_keys = get_user_meta($user_id);
    
    foreach ($progress_meta_keys as $key => $value) {
        if (strpos($key, 'manga_progress_') === 0) {
            // Only count if progress is > 0 (actual chapter read)
            $chapter = intval($value[0] ?? 0);
            if ($chapter > 0) {
                $read_count++;
            }
        }
    }
    
    return $read_count;
}

function mangayummy_get_user_type_stats($user_id) {
    global $wpdb;
    
    $stats = ['manga' => 0, 'manhwa' => 0, 'manhua' => 0];
    
    // Get unique manga IDs from reading history
    $manga_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT manga_id FROM {$wpdb->prefix}reading_history 
         WHERE user_id = %d",
        $user_id
    ));
    
    if (empty($manga_ids)) return $stats;
    
    foreach ($manga_ids as $manga_id) {
        $type = strtolower(get_post_meta((int)$manga_id, '_manga_type', true));
        if (isset($stats[$type])) {
            $stats[$type]++;
        }
    }
    
    return $stats;
}

// Live search AJAX handler
function mangayummy_ya_custom_search_join($join, $wp_query) {
    global $wpdb;
    
    $search_term = $wp_query->get('ya_search_query') ?: $wp_query->get('s');
    
    if ($search_term) {
        $post_types = $wp_query->get('post_type');
        $is_manga_search = false;
        if (is_array($post_types)) {
            $is_manga_search = in_array('manga', $post_types) || in_array('anime', $post_types);
        } elseif (in_array($post_types, ['manga', 'anime', 'any'])) {
            $is_manga_search = true;
        } elseif ($wp_query->is_search()) {
            $is_manga_search = true;
        }
        
        if ($is_manga_search) {
            $join .= " LEFT JOIN {$wpdb->postmeta} mt1 ON ({$wpdb->posts}.ID = mt1.post_id AND mt1.meta_key = '_alternative_titles_search')";
            $join .= " LEFT JOIN {$wpdb->postmeta} mt2 ON ({$wpdb->posts}.ID = mt2.post_id AND mt2.meta_key = 'alternative_names')";
        }
    }
    
    return $join;
}

function mangayummy_ya_custom_search_where($where, $wp_query) {
    global $wpdb;

    $search_term = $wp_query->get('ya_search_query') ?: $wp_query->get('s');

    if ($search_term) {
        $post_types = $wp_query->get('post_type');
        $is_manga_search = false;
        if (is_array($post_types)) {
            $is_manga_search = in_array('manga', $post_types) || in_array('anime', $post_types);
        } elseif (in_array($post_types, ['manga', 'anime', 'any'])) {
            $is_manga_search = true;
        } elseif ($wp_query->is_search()) {
            $is_manga_search = true;
        }

        if ($is_manga_search) {
            $phrase = '%' . esc_sql($search_term) . '%';
            $conditions = [];
            $conditions[] = "{$wpdb->posts}.post_title LIKE '{$phrase}'";
            $conditions[] = "mt1.meta_value LIKE '{$phrase}'";
            $conditions[] = "mt2.meta_value LIKE '{$phrase}'";

            $words = array_filter(explode(' ', $search_term));
            if (!empty($words)) {
                $word_conditions = [];
                foreach ($words as $word) {
                    $word_esc = '%' . esc_sql(trim($word)) . '%';
                    $word_conditions[] = "({$wpdb->posts}.post_title LIKE '{$word_esc}' OR mt1.meta_value LIKE '{$word_esc}' OR mt2.meta_value LIKE '{$word_esc}')";
                }
                $conditions[] = '(' . implode(' AND ', $word_conditions) . ')';
            }

            $where .= ' AND (' . implode(' OR ', $conditions) . ')';
        }
    }

    return $where;
}

function mangayummy_ya_live_search() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    $query = sanitize_text_field($_POST['query']);

    mangayummy_debug_log('AJAX HIT: ' . $query);
    
    if (strlen($query) < 2) {
        wp_send_json_success(array('html' => ''));
        wp_die();
    }

    // Search for manga posts only (do not rely on core s= because short tokens may fail; fallback custom where always applies next)
    $args = array(
        'post_type' => array('manga'),
        'post_status' => 'publish',
        's' => '',
        'ya_search_query' => $query,
        'posts_per_page' => 6, // limit preview to 6 manga
        'orderby' => 'date',
    );

    // Add custom search filter for title and alternative titles
    add_filter('posts_where', 'mangayummy_ya_custom_search_where', 10, 2);
    add_filter('posts_join', 'mangayummy_ya_custom_search_join', 10, 2);
    add_filter('posts_orderby', 'mangayummy_ya_live_search_orderby', 10, 2);
    
    $search_query = new WP_Query($args);
    $html = '';
    
    
    // Remove filters
    remove_filter('posts_where', 'mangayummy_ya_custom_search_where', 10);
    remove_filter('posts_join', 'mangayummy_ya_custom_search_join', 10);
    remove_filter('posts_orderby', 'mangayummy_ya_live_search_orderby', 10);
    $items = array();

    if ($search_query->have_posts()) {
        while ($search_query->have_posts()) {
            $search_query->the_post();
            // Guard against stray non-manga results (should not happen, but just in case)
            if (get_post_type(get_the_ID()) !== 'manga') {
                continue;
            }
            // Prefer post thumbnail; fall back to theme placeholder
            $thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'manga-card') ?: get_the_post_thumbnail_url(get_the_ID(), 'medium') ?: get_template_directory_uri() . '/assets/img/default-manga.jpg';
            
            $year = get_post_meta(get_the_ID(), '_release_year', true);
            $year_end = get_post_meta(get_the_ID(), '_release_year_end', true);
            $rating = get_post_meta(get_the_ID(), '_rating_avg', true);
            $views = get_post_meta(get_the_ID(), '_manga_views_total', true);
            $status = get_post_meta(get_the_ID(), '_status', true);
            
            // Format rating
            $rating_display = $rating ? number_format($rating, 2) : 'N/A';
            
            // Format views - same as carousel
            $views_display = '0';
            $views = get_post_meta(get_the_ID(), 'monthly_views', true);
            if (!$views) {
                $views = get_post_meta(get_the_ID(), 'manga_views_total', true);
            }
            if (!$views) {
                $views = get_post_meta(get_the_ID(), '_manga_views_total', true);
            }
            if (!$views) {
                $views = get_post_meta(get_the_ID(), 'manga_views', true);
            }
            if (!$views) {
                $views = get_post_meta(get_the_ID(), '_views', true);
            }
            
            if ($views && is_numeric($views)) {
                if ($views >= 1000000) {
                    $views_display = number_format($views / 1000000, 1) . 'M';
                } elseif ($views >= 1000) {
                    $views_display = number_format($views / 1000, 0) . 'k';
                } else {
                    $views_display = number_format($views);
                }
            }
            
            // Format status
            $status_display = 'N/A';
            if ($status) {
                switch ($status) {
                    case 'ongoing':
                        $status_display = 'În curs';
                        break;
                    case 'completed':
                        $status_display = 'Finalizat';
                        break;
                    case 'hiatus':
                        $status_display = 'În pauză';
                        break;
                    default:
                        $status_display = ucfirst(esc_html($status));
                }
            }
            
            $year_end = get_post_meta(get_the_ID(), '_release_year_end', true);
            $year_display = $year ? esc_html($year_end ? $year . '-' . $year_end : $year) : 'N/A';
            
            // Get bookmark count
            $bookmark_count = mangayummy_bookmark_count(get_the_ID());
            $bookmark_display = $bookmark_count ? number_format($bookmark_count) : '0';
            
            $html .= '<div class="ya-result-item" data-url="' . esc_url(get_permalink()) . '">
                <img src="' . esc_url($thumbnail) . '" alt="' . esc_attr(get_the_title()) . '">
                <div class="ya-result-details">
                    <div class="ya-result-title">
                        <span class="sr-title">' . esc_html(get_the_title()) . '</span>
                    </div>
                    <div class="ya-result-meta">
                        <span class="meta-rating">' . $rating_display . '</span>
                        <span class="meta-views">' . $views_display . '</span>
                        <span class="meta-bookmarks"><svg class="meta-svg-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M17 3H7a2 2 0 0 0-2 2v16l7-3 7 3V5a2 2 0 0 0-2-2z"/></svg>' . $bookmark_display . '</span>
                        <span class="meta-year">' . $year_display . '</span>
                    </div>
                    <div class="ya-result-status">
                        <span class="status-badge" data-status="' . esc_attr($status) . '">' . $status_display . '</span>
                    </div>
                </div>
            </div>';
        }
        
        // Add "vezi mai multe" link (advanced search destination)
        $html .= '<div class="ya-result-all" data-url="' . esc_url(home_url('/browse/?s=' . urlencode($query))) . '">
            Vezi mai multe
        </div>';
    }

    wp_reset_postdata();
    wp_send_json_success(array('html' => $html));
    wp_die();
}

function mangayummy_ya_live_search_orderby($orderby, $wp_query) {
    if (! $wp_query->get('ya_search_query')) {
        return $orderby;
    }

    global $wpdb;
    $query = $wp_query->get('ya_search_query');
    $query_text = $wpdb->esc_like($query);

    // Prioritize titles that start with the search term, then fallback to title alphabetical
    $custom_order = "CASE WHEN {$wpdb->posts}.post_title LIKE '{$query_text}%' THEN 1 ELSE 2 END ASC, LENGTH({$wpdb->posts}.post_title) ASC, {$wpdb->posts}.post_title ASC";

    return $custom_order;
}

function mangayummy_test_manga_orderby_prefix($orderby, $wp_query) {
    if (empty($GLOBALS['mangayummy_test_manga_search_prefix'])) {
        return $orderby;
    }

    global $wpdb;
    $prefix = $wpdb->esc_like($GLOBALS['mangayummy_test_manga_search_prefix']);

    // Add prefix priority in front of existing orderby (if present)
    $prefix_order = "CASE WHEN {$wpdb->posts}.post_title LIKE '{$prefix}%' THEN 1 ELSE 2 END ASC, LENGTH({$wpdb->posts}.post_title) ASC";

    if (trim($orderby) === '') {
        return $prefix_order . ', ' . $wpdb->posts . '.post_title ASC';
    }

    return $prefix_order . ', ' . $orderby;
}

function mangayummy_test_manga_language_filter($where, $query) {
    // Get the language from a global variable since we can't pass it directly
    if (!empty($GLOBALS['mangayummy_test_manga_language_filter'])) {
        $language = $GLOBALS['mangayummy_test_manga_language_filter'];
        global $wpdb;

        if ($language === 'ro') {
            // For Romanian, include chapters that have language set to 'ro' OR don't have language set at all (defaults to 'ro')
            $where .= " AND {$wpdb->posts}.ID IN (
                SELECT DISTINCT p.post_parent
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_chapter_language'
                WHERE p.post_type = 'chapter'
                AND p.post_status = 'publish'
                AND (pm.meta_value = 'ro' OR pm.meta_value IS NULL)
            )";
        } else {
            // For other languages, only include chapters explicitly set to that language
            $where .= $wpdb->prepare(" AND {$wpdb->posts}.ID IN (
                SELECT DISTINCT p.post_parent
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_type = 'chapter'
                AND p.post_status = 'publish'
                AND pm.meta_key = '_chapter_language'
                AND pm.meta_value = %s
            )", $language);
        }
    }
    return $where;
}

function mangayummy_test_manga_orderby_views($orderby, $query) {
    global $wpdb;
    // Order by views, checking multiple possible meta keys in order of preference
    $orderby = "COALESCE(
        (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = {$wpdb->posts}.ID AND meta_key = 'monthly_views'),
        (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = {$wpdb->posts}.ID AND meta_key = 'manga_views_total'),
        (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = {$wpdb->posts}.ID AND meta_key = '_manga_views_total'),
        (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = {$wpdb->posts}.ID AND meta_key = '_manga_views'),
        (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = {$wpdb->posts}.ID AND meta_key = '_views'),
        0
    ) + 0 DESC";
    return $orderby;
}

function mangayummy_test_manga_orderby_follows($orderby, $query) {
    global $wpdb;
    // Order by cached bookmark count (much faster than counting usermeta)
    $orderby = "COALESCE((SELECT meta_value FROM {$wpdb->postmeta} WHERE {$wpdb->postmeta}.post_id = {$wpdb->posts}.ID AND {$wpdb->postmeta}.meta_key = '_mangayummy_bookmark_count'), 0) + 0 DESC";
    return $orderby;
}

function mangayummy_load_genres() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    $genres = get_terms(array(
        'taxonomy' => 'genre',
        'hide_empty' => true,
        'orderby' => 'name',
        'order' => 'ASC'
    ));

    $options = '';
    foreach ($genres as $genre) {
        $options .= '<div class="dropdown-option" data-value="' . esc_attr($genre->slug) . '">' . esc_html($genre->name) . '</div>';
    }

    wp_send_json_success(array('options' => $options));
}

function mangayummy_load_authors() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    global $wpdb;
    $rows = $wpdb->get_col(
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_author' AND meta_value != '' ORDER BY meta_value ASC"
    );

    // Also include taxonomy terms from 'author' taxonomy (covers most series where author is stored as term)
    $term_names = [];
    $terms = get_terms(['taxonomy' => 'author', 'hide_empty' => false]);
    if (!is_wp_error($terms) && !empty($terms)) {
        foreach ($terms as $t) {
            $term_names[] = $t->name;
        }
    }

    $excluded_names = ['setsu', 'anr720x', 'meishu', 'neguramagura']; // Known usernames to exclude (lowercase)

    $names = [];

    $seen = [];
    $options = '';

    // Add taxonomy terms first (use term slug as data-value so URL like ?author=slug matches)
    foreach ($terms as $t) {
        $label = trim($t->name);
        if ($label === '' || strlen($label) > 100) continue;
        $lc = strtolower($label);
        if (isset($seen[$lc])) continue;
        $seen[$lc] = true;
        $options .= '<div class="dropdown-option" data-value="' . esc_attr($t->slug) . '">' . esc_html($label) . '</div>';
    }

    // Then add meta-based author names (use name as data-value)
    foreach ($rows as $row) {
        $row = trim($row);
        if ($row === '') continue;

        $parts = preg_split('/\s*(?:,|;|\/|\\\\|&|\band\b|\bwith\b|\bfeat\b\.?|\bft\b\.?|\+)\s*/i', $row);
        foreach ($parts as $part) {
            $name = trim(preg_replace('/\s+/', ' ', $part));
            if ($name === '') continue;
            if (preg_match('/<[^>]*>/', $name)) continue;
            if (strlen($name) > 100) continue;
            if (in_array(strtolower($name), $excluded_names)) continue;
            if (preg_match('/(adx|pubad|pubfuture|pubadxtag|window\.pub|window\.pubad|zoneid|unit:|math\.|mathfloor|http:\/\/|https:\/\/|www\.|push\(|document\.|eval\(|onclick=|<script|iframe|adsbygoogle|googletag|gpt|advert|bg-ssp|adslot)/i', $name)) continue;
            if (preg_match('/[=\{\};\\\[\]]/', $name)) continue;
            if (substr_count($name, ' ') > 6) continue;
            if (preg_match('/^[\d\W_]+$/', $name)) continue;

            $lc = strtolower($name);
            if (isset($seen[$lc])) continue;
            $seen[$lc] = true;
            $options .= '<div class="dropdown-option" data-value="' . esc_attr($name) . '">' . esc_html($name) . '</div>';
        }
    }

    wp_send_json_success(array('options' => $options));
}

function mangayummy_load_artists() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    global $wpdb;
    $rows = $wpdb->get_col(
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_artist' AND meta_value != '' ORDER BY meta_value ASC"
    );

    // Also include taxonomy 'artist' terms
    $term_names = [];
    $terms = get_terms(['taxonomy' => 'artist', 'hide_empty' => false]);
    if (!is_wp_error($terms) && !empty($terms)) {
        foreach ($terms as $t) $term_names[] = $t->name;
    }

    $excluded_names = ['setsu', 'anr720x', 'meishu']; // Known usernames to exclude (lowercase)

    $names = [];

    $seen = [];
    $options = '';

    // Add taxonomy 'artist' terms first (use slug as data-value)
    foreach ($terms as $t) {
        $label = trim($t->name);
        if ($label === '' || strlen($label) > 100) continue;
        $lc = strtolower($label);
        if (isset($seen[$lc])) continue;
        $seen[$lc] = true;
        $options .= '<div class="dropdown-option" data-value="' . esc_attr($t->slug) . '">' . esc_html($label) . '</div>';
    }

    // Then add meta-based artist names (use name as data-value)
    foreach ($rows as $row) {
        $row = trim($row);
        if ($row === '') continue;

        $parts = preg_split('/\s*(?:,|;|\/|\\\\|&|\band\b|\bwith\b|\bfeat\b\.?|\bft\b\.?|\+)\s*/i', $row);
        foreach ($parts as $part) {
            $name = trim(preg_replace('/\s+/', ' ', $part));
            if ($name === '') continue;
            if (preg_match('/<[^>]*>/', $name)) continue;
            if (strlen($name) > 100) continue;
            if (in_array(strtolower($name), $excluded_names)) continue;
            if (preg_match('/(adx|pubad|pubfuture|pubadxtag|window\.pub|window\.pubad|zoneid|unit:|math\.|mathfloor|http:\/\/|https:\/\/|www\.|push\(|document\.|eval\(|onclick=|<script|iframe|adsbygoogle|googletag|gpt|advert|bg-ssp|adslot)/i', $name)) continue;
            if (preg_match('/[=\{\};\\\[\]]/', $name)) continue;
            if (substr_count($name, ' ') > 6) continue;
            if (preg_match('/^[\d\W_]+$/', $name)) continue;

            $lc = strtolower($name);
            if (isset($seen[$lc])) continue;
            $seen[$lc] = true;
            $options .= '<div class="dropdown-option" data-value="' . esc_attr($name) . '">' . esc_html($name) . '</div>';
        }
    }

    // We already built $options while collecting taxonomy terms and meta names
    wp_send_json_success(array('options' => $options));
}

add_action('wp_ajax_mangayummy_load_genres', 'mangayummy_load_genres');
add_action('wp_ajax_nopriv_mangayummy_load_genres', 'mangayummy_load_genres');
add_action('wp_ajax_mangayummy_load_authors', 'mangayummy_load_authors');
add_action('wp_ajax_nopriv_mangayummy_load_authors', 'mangayummy_load_authors');
add_action('wp_ajax_mangayummy_load_artists', 'mangayummy_load_artists');
add_action('wp_ajax_nopriv_mangayummy_load_artists', 'mangayummy_load_artists');
add_action('wp_ajax_mangayummy_ya_live_search', 'mangayummy_ya_live_search');
add_action('wp_ajax_nopriv_mangayummy_ya_live_search', 'mangayummy_ya_live_search');

// AJAX: Load popular manga by time period
add_action('wp_ajax_mangayummy_ya_popular_by_period', 'mangayummy_ya_popular_by_period');
add_action('wp_ajax_nopriv_mangayummy_ya_popular_by_period', 'mangayummy_ya_popular_by_period');

function mangayummy_get_popular_recent_ids($period = '1day', $limit = 100) {
    global $wpdb;

    $period_days = [
        '1day' => 1,
        '7days' => 7,
        '1month' => 30,
        '3months' => 90,
        '6months' => 180,
        '1year' => 365,
    ];

    $period = isset($period_days[$period]) ? $period : '1day';
    $limit = max(1, min(200, intval($limit)));

    $cache_key = 'mgy_popular_recent_ids_' . $period . '_' . $limit;
    $cached_ids = get_transient($cache_key);
    if (is_array($cached_ids)) {
        return $cached_ids;
    }

    $days = $period_days[$period];
    $now = time();
    $manga_views = [];

    if ($days <= 3) {
        $threshold = $now - ($days * 24 * 3600);
        $manga_with_views = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_hourly FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_hourly'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        foreach ($manga_with_views as $m) {
            $buckets = maybe_unserialize($m->views_hourly);
            if (!is_array($buckets)) {
                continue;
            }

            $views_period = 0;
            foreach ($buckets as $hour => $count) {
                if (intval($hour) >= $threshold) {
                    $views_period += intval($count);
                }
            }

            if ($views_period > 0) {
                $manga_views[intval($m->ID)] = $views_period;
            }
        }
    } else {
        $threshold_daily = strtotime('-' . ($days - 1) . ' days midnight');
        $today_midnight = strtotime('today midnight');

        $manga_daily = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_daily FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_daily'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        $manga_hourly = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_hourly FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_hourly'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        $today_hourly_views = [];
        foreach ($manga_hourly as $m) {
            $buckets = maybe_unserialize($m->views_hourly);
            if (!is_array($buckets)) {
                continue;
            }

            $views_today = 0;
            foreach ($buckets as $hour => $count) {
                if (intval($hour) >= $today_midnight) {
                    $views_today += intval($count);
                }
            }

            if ($views_today > 0) {
                $today_hourly_views[intval($m->ID)] = $views_today;
            }
        }

        foreach ($manga_daily as $m) {
            $buckets = maybe_unserialize($m->views_daily);
            if (!is_array($buckets)) {
                continue;
            }

            $views_period = 0;
            foreach ($buckets as $day => $count) {
                $day_ts = intval($day);
                if ($day_ts >= $threshold_daily && $day_ts < $today_midnight) {
                    $views_period += intval($count);
                }
            }

            if ($views_period > 0) {
                $manga_views[intval($m->ID)] = $views_period;
            }
        }

        foreach ($today_hourly_views as $manga_id => $today_count) {
            if (!isset($manga_views[$manga_id])) {
                $manga_views[$manga_id] = 0;
            }
            $manga_views[$manga_id] += $today_count;
        }

        if (empty($manga_views)) {
            $fallback_rows = $wpdb->get_results(
                "SELECT p.ID, CAST(pm.meta_value AS UNSIGNED) as cnt FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                    AND pm.meta_key = '_manga_views'
                 WHERE p.post_type = 'manga' AND p.post_status = 'publish'
                   AND CAST(pm.meta_value AS UNSIGNED) > 0
                 ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
                 LIMIT {$limit}"
            );

            foreach ($fallback_rows as $row) {
                $manga_views[intval($row->ID)] = intval($row->cnt);
            }
        }
    }

    if (empty($manga_views)) {
        set_transient($cache_key, [], MINUTE_IN_SECONDS);
        return [];
    }

    arsort($manga_views);
    $top_ids = array_slice(array_keys($manga_views), 0, $limit, true);
    $top_ids = array_map('intval', $top_ids);

    set_transient($cache_key, $top_ids, MINUTE_IN_SECONDS);
    return $top_ids;
}

function mangayummy_ya_popular_by_period() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    $period = sanitize_text_field($_POST['period'] ?? '1day');
    $unique_manga_ids = mangayummy_get_popular_recent_ids($period, 100);
    $latest_chapters_map = mangayummy_prefetch_latest_chapters($unique_manga_ids);
    $ratings_map = mangayummy_prefetch_ratings($unique_manga_ids);
    $post_meta_map = mangayummy_prefetch_post_meta_bulk($unique_manga_ids, ['_manga_type', '_status', '_manga_18', '_manga_id']);
    
    ob_start();
    
    $manga_count = 0;
    // always limit response to the same number shown on page (16 manga)
    $max_manga = 16;
    
    if (!empty($unique_manga_ids)) {
        foreach ($unique_manga_ids as $manga_id) {
            $manga_id = intval($manga_id);
            
            if ($manga_count >= $max_manga) break;
            
            if (function_exists('mangayummy_manga_matches_prefs') && !mangayummy_manga_matches_prefs($manga_id)) {
                continue;
            }
            
            $manga = get_post($manga_id);
            if (!$manga || $manga->post_status !== 'publish' || $manga->post_type !== 'manga') continue;
            $meta = $post_meta_map[$manga_id] ?? [];
            if (!empty($meta['_manga_id'])) continue;
            
            $manga_count++;
            
            $rating_data = $ratings_map[$manga_id] ?? ['average' => 0, 'count' => 0];
            if (floatval($rating_data['average']) <= 0) {
                $rating_data['average'] = floatval(get_post_meta($manga_id, '_rating_avg', true));
                $rating_data['count'] = max(intval($rating_data['count'] ?? 0), intval(get_post_meta($manga_id, '_rating_count', true)));
            }
            
            $chapter_posts = $latest_chapters_map[$manga_id] ?? [];
            
            $manga_type = $meta['_manga_type'] ?? '';
            $manga_status = $meta['_status'] ?? '';
            $type_labels = ['manga' => 'Manga', 'manhua' => 'Manhua', 'manhwa' => 'Manhwa'];
            $type_display = $manga_type ? ($type_labels[$manga_type] ?? '') : '';
            $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
            $status_labels = ['ongoing' => 'În curs', 'completed' => 'Finalizat', 'hiatus' => 'Pus pe pauză', 'dropped' => 'Abandonat'];
            $status_display = $manga_status ? ($status_labels[$manga_status] ?? '') : '';
            $is_18_content = $meta['_manga_18'] ?? '';
            ?>
            <div class="latest-manga-item">
              <div class="manga-poster-wrap">
                <a href="<?php echo esc_url(get_permalink($manga_id)); ?>">
                    <?php 
                    $poster_attrs = ['loading' => 'lazy', 'decoding' => 'async'];
                    echo get_the_post_thumbnail($manga_id, 'manga-card', $poster_attrs); 
                    ?>
                    <?php if (!empty($rating_data['average']) && floatval($rating_data['average']) > 0): ?>
                      <div class="cover-rating-badge">
                        <span class="cover-rating-star">★</span>
                        <span class="cover-rating-value"><?php echo esc_html(number_format(floatval($rating_data['average']), 1)); ?></span>
                      </div>
                    <?php endif; ?>
                    <div class="item-text">
                      <div class="item-text-inner">
                        <a class="item-title" href="<?php echo esc_url(get_permalink($manga_id)); ?>"><?php echo esc_html($manga->post_title); ?></a>
                        <?php
                        if (!empty($chapter_posts)) {
                            $latest = $chapter_posts[0];
                            $latest_num = mangayummy_get_chapter_number($latest->ID);
                            if ($latest_num !== '' && $latest_num !== null) {
                                echo '<a class="item-volch" href="' . esc_url(get_permalink($latest->ID)) . '">Ch.' . esc_html($latest_num) . '</a>';
                            }
                        }
                        ?>
                      </div>
                    </div>
                </a>
              </div>
                <?php if (!empty($chapter_posts)): ?>
                  <?php foreach ($chapter_posts as $chapter_post): ?>
                    <?php
                    $chapter_number = function_exists('mangayummy_get_chapter_number') ? mangayummy_get_chapter_number($chapter_post->ID) : '';
                    $chapter_title = $chapter_post->post_title;
                    $chapter_permalink = get_permalink($chapter_post->ID);
                    $post_time = strtotime($chapter_post->post_date);
                    $is_new = (current_time('timestamp') - $post_time) <= DAY_IN_SECONDS;
                    ?>
                    <div class="chapter-link">
                      <a href="<?php echo esc_url($chapter_permalink); ?>">
                        <div class="chapter-row">
                          <span class="chapter-title" title="<?php echo esc_attr(($chapter_number !== '' && $chapter_number !== null ? 'Cap. ' . $chapter_number . (($chapter_title !== '') ? ' – ' . $chapter_title : '') : $chapter_title)); ?>">
                            <?php
                            if ($chapter_number !== '' && $chapter_number !== null) {
                                echo 'Cap. ' . esc_html($chapter_number) . ($chapter_title !== '' ? ' – ' . esc_html($chapter_title) : '');
                            } else {
                                echo esc_html($chapter_title);
                            }
                            ?>
                          </span>
                                                    <?php if ($is_new): ?>
                                                        <span class="chapter-badge">NEW</span>
                                                    <?php endif; ?>
                        </div>
                      </a>
                    </div>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>
            <?php
        }
    }
    
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}

// Dashboard widget: Popular Recent manga views
function mangayummy_get_popular_manga_by_period($period = '1day', $limit = 10) {
    global $wpdb;

    $period_days = [
        '1day' => 1,
        '7days' => 7,
        '1month' => 30,
        '3months' => 90,
        '6months' => 180,
        '1year' => 365,
    ];

    $days = $period_days[$period] ?? 1;
    $now = time();
    $manga_views = [];

    if ($days <= 3) {
        $threshold = $now - ($days * 24 * 3600);
        $manga_with_views = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_hourly FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_hourly'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        foreach ($manga_with_views as $m) {
            $buckets = maybe_unserialize($m->views_hourly);
            if (!is_array($buckets)) continue;
            $views_period = 0;
            foreach ($buckets as $hour => $count) {
                if (intval($hour) >= $threshold) {
                    $views_period += intval($count);
                }
            }
            if ($views_period > 0) {
                $manga_views[intval($m->ID)] = $views_period;
            }
        }
    } else {
        $threshold_daily = strtotime("-" . ($days - 1) . " days midnight");
        $today_midnight = strtotime('today midnight');
        $threshold_hourly = $today_midnight;

        $manga_daily = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_daily FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_daily'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        $manga_hourly = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as views_hourly FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                AND pm.meta_key = 'views_hourly'
             WHERE p.post_type = 'manga' AND p.post_status = 'publish'"
        );

        $today_hourly_views = [];
        foreach ($manga_hourly as $m) {
            $buckets = maybe_unserialize($m->views_hourly);
            if (!is_array($buckets)) continue;
            $views_today = 0;
            foreach ($buckets as $hour => $count) {
                if (intval($hour) >= $threshold_hourly) {
                    $views_today += intval($count);
                }
            }
            if ($views_today > 0) {
                $today_hourly_views[intval($m->ID)] = $views_today;
            }
        }

        foreach ($manga_daily as $m) {
            $buckets = maybe_unserialize($m->views_daily);
            if (!is_array($buckets)) continue;
            $views_period = 0;
            foreach ($buckets as $day => $count) {
                $day_ts = intval($day);
                if ($day_ts >= $threshold_daily && $day_ts < $today_midnight) {
                    $views_period += intval($count);
                }
            }
            if ($views_period > 0) {
                $manga_views[intval($m->ID)] = $views_period;
            }
        }

        foreach ($today_hourly_views as $manga_id => $today_count) {
            if (!isset($manga_views[$manga_id])) {
                $manga_views[$manga_id] = 0;
            }
            $manga_views[$manga_id] += $today_count;
        }

        if (empty($manga_views)) {
            $manga_views = $wpdb->get_results(
                "SELECT p.ID, CAST(pm.meta_value AS UNSIGNED) as cnt FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                    AND pm.meta_key = '_manga_views'
                 WHERE p.post_type = 'manga' AND p.post_status = 'publish'
                   AND CAST(pm.meta_value AS UNSIGNED) > 0
                 ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
                 LIMIT 100"
            );
            $tmp = [];
            foreach ($manga_views as $m) {
                $tmp[intval($m->ID)] = intval($m->cnt);
            }
            $manga_views = $tmp;
        }
    }

    if (empty($manga_views)) {
        return [];
    }

    arsort($manga_views);
    $top_ids = array_slice(array_keys($manga_views), 0, $limit, true);

    $results = [];
    foreach ($top_ids as $id) {
        $results[] = [
            'id' => intval($id),
            'title' => get_the_title($id),
            'url' => get_permalink($id),
            'views' => intval($manga_views[$id] ?? 0),
        ];
    }

    return $results;
}

function mangayummy_render_dashboard_popular_recent() {
    $items = mangayummy_get_popular_manga_by_period('1day', 10);
    echo '<p>'; esc_html_e('Top 10 cele mai vizitate manga în ultimele 24 de ore:', 'mangayummy'); echo '</p>';
    echo '<ul style="list-style: disc;margin-left: 18px;">';

    if (empty($items)) {
        echo '<li>' . esc_html__('Nu sunt date disponibile', 'mangayummy') . '</li>';
    } else {
        foreach ($items as $item) {
            echo '<li>' . sprintf('<a href="%s" target="_blank">%s</a> — %s vizualizări', esc_url($item['url']), esc_html($item['title']), number_format_i18n($item['views'])) . '</li>';
        }
    }

    echo '</ul>';

    $now = current_time('timestamp');
    $next_hour = ceil(($now + 1) / 3600) * 3600;

    echo '<p><strong>' . esc_html__('Următorul reset de interval (oră):', 'mangayummy') . '</strong> ' . esc_html(date_i18n('Y-m-d H:00', $next_hour)) . '</p>';
    echo '<p><strong>' . esc_html__('Ultima actualizare:', 'mangayummy') . '</strong> ' . esc_html(date_i18n('Y-m-d H:i:s', $now)) . '</p>';
    echo '<p><em>' . esc_html__('Datele hourly sunt păstrate 72h, datele daily 400 zile.', 'mangayummy') . '</em></p>';
}

function mangayummy_register_dashboard_widgets() {
    wp_add_dashboard_widget(
        'mangayummy_popular_recent_widget',
        esc_html__('MangaYummy Popular Recent', 'mangayummy'),
        'mangayummy_render_dashboard_popular_recent'
    );
}
add_action('wp_dashboard_setup', 'mangayummy_register_dashboard_widgets');

// Fix chapters query - force filtering by post_parent
add_filter('wp_manga_chapters_query_args', function($args, $post_id) {
    $args['post_parent'] = $post_id;
    return $args;
}, 10, 2);

add_action('wp_enqueue_scripts', function () {
  if (is_singular('manga') || is_singular('chapter')) {
        $rating_ver = filemtime(get_template_directory() . '/js/rating.js'); // Use file modification time for versioning
        wp_enqueue_script(
            'manga-rating',
            get_template_directory_uri() . '/js/rating.js?v=' . $rating_ver,
            [],
            $rating_ver,
            true
        );

        wp_localize_script('manga-rating', 'mangaRating', [
            'ajax' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('manga_rate_nonce'),
            'ver' => $rating_ver
        ]);
  }
});

add_action('wp_ajax_mangayummy_manga_rate', 'mangayummy_manga_rate');
add_action('wp_ajax_nopriv_mangayummy_manga_rate', 'mangayummy_manga_rate');
add_action('wp_ajax_manga_rate', 'mangayummy_manga_rate');
add_action('wp_ajax_nopriv_manga_rate', 'mangayummy_manga_rate');
function mangayummy_manga_rate() {

  if (!wp_verify_nonce($_POST['nonce'], 'manga_rate_nonce')) {
    wp_send_json_error(['message' => 'Nonce invalid']);
  }

  // Require login to rate
  if (!is_user_logged_in()) {
    wp_send_json_error(['message' => 'Trebuie să fii logat pentru a evalua.']);
  }

  $user_id = get_current_user_id();
  if (get_user_meta($user_id, '_banned', true)) {
    wp_send_json_error(['message' => 'User is banned']);
  }
  $muted_until = get_user_meta($user_id, '_muted_until', true);
  if ($muted_until && time() < intval($muted_until)) {
    wp_send_json_error(['message' => 'User is muted']);
  }

  $post   = intval($_POST['post']);
  $rating = floatval($_POST['rating']);

    if ($rating < 0.5 || $rating > 10) {
    wp_send_json_error(['message' => 'Rating invalid']);
  }

  // Get existing ratings
  $ratings = get_post_meta($post, '_manga_ratings', true);
  if (!is_array($ratings)) $ratings = [];

  $sum = floatval(get_post_meta($post, '_rating_sum', true));
  $cnt = intval(get_post_meta($post, '_rating_count', true));

  // Logged-in user: store in user meta
  $user = get_current_user_id();
  $old = floatval(get_user_meta($user, 'rating_' . $post, true));
  
  if ($old) {
    $sum = $sum - $old + $rating;
    $key = array_search($old, $ratings);
    if ($key !== false) unset($ratings[$key]);
  } else {
    $sum += $rating;
    $cnt++;
  }
  update_user_meta($user, 'rating_' . $post, $rating);

  // Add new rating
  $ratings[] = $rating;

  $avg = round($sum / $cnt, 1);

  update_post_meta($post, '_rating_sum', $sum);
  update_post_meta($post, '_rating_count', $cnt);
  update_post_meta($post, '_rating_avg', $avg);
  update_post_meta($post, '_manga_ratings', $ratings);

  // Invalidate cached rating and rank values so the UI reflects changes immediately.
  delete_transient('mangayummy_rating_' . $post);
  delete_transient('mangayummy_manga_rank_' . $post);

  wp_send_json_success([
        'avg' => $avg,
        'count' => $cnt
    ]);
}

// Bookmark helpers (safe)
if ( ! function_exists('mangayummy_is_bookmarked') ) {
    function mangayummy_is_bookmarked($post_id) {
        if (!is_user_logged_in()) return false;

        $user_id = get_current_user_id();
        $bookmarks = get_user_meta($user_id, 'mangayummy_bookmarks', true);

        if (!is_array($bookmarks)) return false;
        return in_array($post_id, $bookmarks);
    }
}

if ( ! function_exists('mangayummy_bookmark_count') ) {
    function mangayummy_bookmark_count($post_id) {
        return (int) get_post_meta($post_id, '_mangayummy_bookmark_count', true);
    }
}

// AJAX handler for bookmark toggle (safe)
add_action('wp_ajax_mangayummy_toggle_bookmark', 'mangayummy_toggle_bookmark');

if ( ! function_exists('mangayummy_toggle_bookmark') ) {
    function mangayummy_toggle_bookmark() {
        if (!is_user_logged_in()) {
            wp_send_json_success(['login_required' => true]);
            return;
        }

        check_ajax_referer('mangayummy_bookmark_nonce', 'nonce');

        $user_id = get_current_user_id();
        if (get_user_meta($user_id, '_banned', true)) {
            wp_send_json_error(['message' => 'User is banned']);
        }

        $post_id = intval($_POST['post_id']);

        $bookmarks = get_user_meta($user_id, 'mangayummy_bookmarks', true);
        if (!is_array($bookmarks)) $bookmarks = [];

        $count = (int) get_post_meta($post_id, '_mangayummy_bookmark_count', true);

        if (in_array($post_id, $bookmarks)) {
            $bookmarks = array_diff($bookmarks, [$post_id]);
            $count = max(0, $count - 1);
            $status = 'removed';
        } else {
            $bookmarks[] = $post_id;
            $count++;
            $status = 'added';
        }

        // log bookmark action with full array state

        update_user_meta($user_id, 'mangayummy_bookmarks', $bookmarks);
        update_post_meta($post_id, '_mangayummy_bookmark_count', $count);

        wp_send_json_success([
            'status' => $status,
            'count'  => $count
        ]);
    }
}

if (!function_exists('mangayummy_comment_callback')) {
function mangayummy_comment_callback($comment) {
    $comment_id = $comment->comment_ID;

    $likes    = (int) get_comment_meta($comment_id, 'likes', true);
    $dislikes = (int) get_comment_meta($comment_id, 'dislikes', true);

    if ($likes < 0) $likes = 0;
    if ($dislikes < 0) $dislikes = 0;
    ?>
    <div class="comment" id="comment-<?php echo $comment_id; ?>" data-id="<?php echo $comment_id; ?>">
        
        <div class="comment-meta">
            <?php echo get_avatar($comment, 48); ?>
            <div class="comment-info">
                <strong><?php echo esc_html($comment->comment_author); ?></strong>
                <span><?php echo date('d F Y H:i', strtotime($comment->comment_date)); ?></span>
            </div>
        </div>

        <div class="comment-body">
            <?php echo wp_kses_post($comment->comment_content); ?>
        </div>

        <div class="comment-actions">
            <!-- LIKE -->
            <button class="comment-action-btn like-btn"
                data-comment="<?php echo $comment_id; ?>"
                data-action="like"
                title="Appreciate">
                <i class="fa fa-heart-o"></i>
                <span class="like-count"><?php echo $likes; ?></span>
            </button>

            <!-- DISLIKE -->
            <button class="comment-action-btn dislike-btn"
                data-comment="<?php echo $comment_id; ?>"
                data-action="dislike"
                title="Dislike">
                <i class="fa fa-heart-broken"></i>
                <span class="dislike-count"><?php echo $dislikes; ?></span>
            </button>

            <!-- REPLY -->
            <button class="comment-action-btn reply-btn"
                data-comment="<?php echo $comment_id; ?>"
                title="Răspunde">
                <i class="fa fa-reply"></i>
            </button>
        </div>
    </div>
    <?php
}
}

if (!function_exists('mangayummy_comment_react')) {
function mangayummy_comment_react() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mangayummy_comment_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'User not logged in']);
    }

    $comment_id = intval($_POST['comment_id']);
    $action     = sanitize_text_field($_POST['reaction']);

    if (!$comment_id || !in_array($action, ['like', 'dislike'])) {
        wp_send_json_error(['message' => 'Invalid parameters']);
    }

    $meta_key = ($action === 'like') ? 'likes' : 'dislikes';
    $count = (int) get_comment_meta($comment_id, $meta_key, true);

    $count++;
    update_comment_meta($comment_id, $meta_key, $count);

    wp_send_json_success([
        'count' => $count
    ]);
}
add_action('wp_ajax_mangayummy_comment_react', 'mangayummy_comment_react');
}

if (!function_exists('mangayummy_sort_comments')) {
function mangayummy_sort_comments() {
    check_ajax_referer('mangayummy_comment_nonce', 'nonce');

    $post_id = intval($_POST['post_id']);
    $sort    = sanitize_text_field($_POST['sort']);

    $args = [
        'post_id' => $post_id,
        'status'  => 'approve',
        'parent'  => 0,
    ];

    if ($sort === 'newest') {
        $args['orderby'] = 'comment_date';
        $args['order']   = 'DESC';
    } elseif ($sort === 'oldest') {
        $args['orderby'] = 'comment_date';
        $args['order']   = 'ASC';
    } elseif ($sort === 'liked') {
        $args['meta_key'] = 'likes';
        $args['orderby']  = 'meta_value_num';
        $args['order']    = 'DESC';
    }

    $comments = get_comments($args);

    ob_start();
    foreach ($comments as $comment) {
        echo mangayummy_render_comment($comment);
    }
    wp_send_json_success(ob_get_clean());
}
add_action('wp_ajax_mangayummy_sort_comments', 'mangayummy_sort_comments');
}

/**
 * AJAX: Post comment (returns server-rendered HTML)
 */
add_action('wp_ajax_mangayummy_post_comment', 'mangayummy_post_comment');

// Save user email notification preferences (replies + new chapters)
add_action('wp_ajax_mangayummy_save_email_prefs', 'mangayummy_save_email_prefs');
function mangayummy_save_email_prefs() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'You are not authenticated.']);
    }

    $user_id = get_current_user_id();
    $replies = isset($_POST['replies']) ? sanitize_text_field($_POST['replies']) : '0';
    $chapters = isset($_POST['chapters']) ? sanitize_text_field($_POST['chapters']) : '0';

    update_user_meta($user_id, 'mangayummy_email_notif_replies', $replies === '1' ? '1' : '0');
    update_user_meta($user_id, 'mangayummy_email_notif_chapters', $chapters === '1' ? '1' : '0');

    wp_send_json_success(['message' => 'Preferences saved.']);
}

function mangayummy_post_comment() {
    check_ajax_referer('mangayummy_comment_nonce', 'nonce');

    // Require login to comment
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat pentru a comenta.']);
    }

    // Get current user ID
    $user_id = get_current_user_id();
    
    // Check if user is banned
    if (get_user_meta($user_id, '_banned', true)) {
        wp_send_json_error(['message' => 'User is banned']);
    }
    
    // ========== CHECK IF USER IS MUTED ==========
    $muted_until = get_user_meta($user_id, '_muted_until', true);
    if ($muted_until && time() < intval($muted_until)) {
        $remaining = intval($muted_until) - time();
        $minutes = ceil($remaining / 60);
        wp_send_json_error(['message' => 'Ești mutat pentru spam. Revine în ' . $minutes . ' minute.']);
    }

    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $content = isset($_POST['content']) ? wp_kses_post($_POST['content']) : '';
    $parent  = isset($_POST['parent']) ? intval($_POST['parent']) : 0;

    if (!$post_id || empty($content)) {
        wp_send_json_error(['message' => 'Invalid data']);
    }
    
    // ========== ANTI-SPAM: Check comment frequency ==========
    $recent_comments = get_comments([
        'user_id' => $user_id,
        'post_id' => $post_id,
        'number'  => 5,
        'orderby' => 'comment_date_gmt',
        'order'   => 'DESC',
        'status'  => 'approve',
    ]);
    
    // If user posted 5+ comments in last 5 minutes = SPAM
    if (count($recent_comments) >= 5) {
        $oldest = end($recent_comments);
        $time_diff = time() - strtotime($oldest->comment_date_gmt);
        if ($time_diff < 300) { // 5 minutes = 300 seconds
            mangayummy_mute_user($user_id, 3600); // Mute for 1 hour
            wp_send_json_error(['message' => 'Ai fost mutat pentru spam pe 1 oră.']);
        }
    }
    
    // Add guest ID to guest name (Oaspete 1, Oaspete 2, etc.)
    if (!$user_id) {
        $guest_id = mangayummy_get_guest_id();
        $guest_name = 'Oaspete ' . $guest_id;
    }

    if (!$post_id || empty($content)) {
        wp_send_json_error(['message' => 'Invalid data']);
    }

    // ✅ 1️⃣ ADD @TAG if reply (only for logged-in users, not guests)
    if ($parent > 0 && $user_id) {  // Only add @TAG for logged-in users
        $parent_comment = get_comment($parent);
        if ($parent_comment) {
            $parent_author = get_comment_author($parent);
            // Prepend @username as TEXT ONLY (no HTML)
            if (strpos($content, '@' . $parent_author) === false) {
                $content = '@' . esc_html($parent_author) . ' ' . $content;
            }
        }
    }

    // Prepare author fields for both logged-in users and guests to avoid edge-case validation
    $author_name  = $user_id ? '' : $guest_name;  // Empty for logged-in, WordPress uses user display_name
    $author_email = $user_id ? '' : 'guest@example.com';
    $comment_data = [
        'comment_post_ID'      => $post_id,
        'comment_content'      => $content,
        'user_id'              => $user_id,
        'comment_parent'       => $parent,
        'comment_approved'     => 1,
        'comment_author'       => $author_name,
        'comment_author_email' => $author_email,
        'comment_author_url'   => '',
    ];

// Prevent exact duplicate comments from the same user on the same post
    if ($user_id) {
        $recent = get_comments([
            'user_id' => $user_id,
            'post_id' => $post_id,
            'number'  => 1,
            'orderby' => 'comment_date_gmt',
            'order'   => 'DESC',
            'status'  => 'approve',
        ]);
        if (!empty($recent)) {
            $last = $recent[0];
            $last_text = trim(wp_strip_all_tags($last->comment_content));
            $curr_text = trim(wp_strip_all_tags($content));
            if ($last_text !== '' && $last_text === $curr_text) {
                wp_send_json_error(['message' => 'Ai trimis deja același răspuns. Încearcă să îl modifici puțin.']);
            }
        }
    }

    global $mangayummy_skip_discord_comment_notification;
    $mangayummy_skip_discord_comment_notification = true;
    $comment_id = wp_new_comment($comment_data);
    $mangayummy_skip_discord_comment_notification = false;

    if (!$comment_id) {
        wp_send_json_error(['message' => 'Nu am putut crea comentariul (posibil duplicat sau flood). Încearcă din nou.']);
    }

    add_comment_meta($comment_id, 'likes', 0, true);
    add_comment_meta($comment_id, 'dislikes', 0, true);

    if (function_exists('mangayummy_sendDiscordCommentNotification') && !get_comment_meta($comment_id, 'discord_comment_notification_sent', true)) {
        if (mangayummy_sendDiscordCommentNotification($comment_id)) {
            add_comment_meta($comment_id, 'discord_comment_notification_sent', '1', true);
        }
    }
    
    // Store guest IP hash for editing/deleting later
    if (!$user_id) {
        $ip_hash = md5(mangayummy_get_client_ip());
        if ($ip_hash) {
            add_comment_meta($comment_id, '_guest_ip_hash', $ip_hash, true);
        }
    }

    // ✅ 2️⃣ CREATE MESSAGE if reply (but not self-reply)
    if ($parent > 0) {
        $parent_comment = get_comment($parent);
        if ($parent_comment && $parent_comment->user_id && $parent_comment->user_id != $user_id) {
            global $wpdb;
            // Get comment link
            $comment_link = get_comment_link($comment_id);
            // Insert notification with [NOTIF:link] prefix
            $wpdb->insert(
                $wpdb->prefix . 'private_messages',
                [
                    'sender_id'   => $user_id, // Keep real user ID for avatar/name display
                    'receiver_id' => $parent_comment->user_id,
                    'message'     => '[NOTIF:' . $comment_link . ']a răspuns la comentariul tău: ' . wp_trim_words(get_comment_text($comment_id), 20),
                    'is_read'     => 0,
                    'created_at'  => current_time('mysql')
                ],
                ['%d', '%d', '%s', '%d', '%s']
            );

            // Send email notification to parent comment author when the reply is from another user
            $parent_user_id = intval($parent_comment->user_id);
            if ($parent_user_id && $parent_user_id !== $user_id) {
                $parent_user = get_user_by('ID', $parent_user_id);
                $parent_email = $parent_user ? $parent_user->user_email : '';

                if ($parent_email) {
                    $replier_name = $user_id ? get_the_author_meta('display_name', $user_id) : __('Utilizator', 'mangayummy');
                    $subject = 'Cineva a răspuns la comentariul tău pe MangaYummy';
                    $body = "{$replier_name} a răspuns la comentariul tău:\n\n";
                    $body .= "Comentariu: " . wp_strip_all_tags($content) . "\n\n";
                    $body .= "Vezi aici: " . $comment_link . "\n";

                    if (get_user_meta($parent_user_id, 'mangayummy_email_notif_replies', true) === '1') {
                wp_mail($parent_email, $subject, $body);
            }
                }
            }
        }
    }

    $comment = get_comment($comment_id);

    ob_start();
    // Return HTML from the single renderer so AJAX matches page render
    echo mangayummy_render_comment($comment);
    $html = ob_get_clean();

    wp_send_json_success(['html' => $html, 'comment_id' => $comment_id]);
}

/**
 * AJAX: Edit comment (users only)
 */
add_action('wp_ajax_mangayummy_edit_comment', 'mangayummy_edit_comment');
function mangayummy_edit_comment() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat.']);
    }

    $comment_id = isset($_POST['comment_id']) ? intval($_POST['comment_id']) : 0;
    $new_content = isset($_POST['content']) ? wp_kses_post($_POST['content']) : '';

    if (!$comment_id || empty($new_content)) {
        wp_send_json_error(['message' => 'Invalid data']);
    }

    $comment = get_comment($comment_id);
    if (!$comment) {
        wp_send_json_error(['message' => 'Comment not found']);
    }

    $user_id = get_current_user_id();
    $is_owner = false;

    if ($user_id) {
        // Check if logged-in user owns the comment
        $is_owner = ($comment->user_id == $user_id);
    } else {
        // Check if guest (based on IP)
        $ip_hash = md5(mangayummy_get_client_ip());
        $stored_ip = get_comment_meta($comment_id, '_guest_ip_hash', true);
        $is_owner = ($ip_hash && $stored_ip && $ip_hash === $stored_ip);
    }

    if (!$is_owner) {
        wp_send_json_error(['message' => 'You cannot edit this comment']);
    }

    // Update comment
    wp_update_comment([
        'comment_ID' => $comment_id,
        'comment_content' => $new_content,
    ]);

    // Mark as edited with current timestamp
    update_comment_meta($comment_id, '_edited_at', current_time('mysql'));

    $comment = get_comment($comment_id);
    // Return just the rendered comment text (not full HTML)
    $rendered = mangayummy_parse_comment_text($new_content);

    wp_send_json_success(['rendered' => $rendered, 'message' => 'Comentariu editat']);
}

/**
 * AJAX: Delete comment (users only)
 */
add_action('wp_ajax_mangayummy_delete_comment', 'mangayummy_delete_comment');
function mangayummy_delete_comment() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat.']);
    }

    $comment_id = isset($_POST['comment_id']) ? intval($_POST['comment_id']) : 0;

    if (!$comment_id) {
        wp_send_json_error(['message' => 'Invalid comment ID']);
    }

    $comment = get_comment($comment_id);
    if (!$comment) {
        wp_send_json_error(['message' => 'Comment not found']);
    }

    $user_id = get_current_user_id();
    $is_owner = false;

    if ($user_id) {
        // Check if logged-in user owns the comment
        $is_owner = ($comment->user_id == $user_id);
    } else {
        // Check if guest (based on IP)
        $ip_hash = md5(mangayummy_get_client_ip());
        $stored_ip = get_comment_meta($comment_id, '_guest_ip_hash', true);
        $is_owner = ($ip_hash && $stored_ip && $ip_hash === $stored_ip);
    }

    if (!$is_owner) {
        wp_send_json_error(['message' => 'You cannot delete this comment']);
    }

    // Soft delete - set comment as spam or just mark as deleted
    wp_delete_comment($comment_id, true);  // true = force delete

    wp_send_json_success(['message' => 'Comentariu șters']);
}

/**
 * AJAX: React to comment (like/dislike) - login required
 */
add_action('wp_ajax_mangayummy_react_comment', 'mangayummy_react_comment');
function mangayummy_react_comment() {
    check_ajax_referer('mangayummy_comment_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat.']);
    }

    $comment_id = isset($_POST['comment_id']) ? intval($_POST['comment_id']) : 0;
    // Accept `reaction` (preferred) or legacy `react`/`action_type`
    $action = '';
    if (isset($_POST['reaction'])) {
        $action = sanitize_text_field($_POST['reaction']);
    } elseif (isset($_POST['react'])) {
        $action = sanitize_text_field($_POST['react']);
    } elseif (isset($_POST['action_type'])) {
        $action = sanitize_text_field($_POST['action_type']);
    }

    if (!$comment_id || !in_array($action, ['like', 'dislike'], true)) {
        wp_send_json_error(['message' => 'Invalid parameters']);
    }

    // Get comment and check if user is trying to react to own comment
    $comment = get_comment($comment_id);
    if (!$comment) {
        wp_send_json_error(['message' => 'Comment not found']);
    }

    $user_id = get_current_user_id();
    
    // Block logged-in users from reacting to their own comments
    if ($user_id && $comment->user_id && $user_id == $comment->user_id) {
        wp_send_json_error(['message' => 'Nu poți vota la propriile comentarii']);
    }

    $ip_hash = md5(mangayummy_get_client_ip());
    $react_key_user = "reacted_{$comment_id}";
    $react_key_guest = "reacted_{$comment_id}_{$ip_hash}";

    // current counts
    $likes = (int) get_comment_meta($comment_id, 'likes', true);
    $dislikes = (int) get_comment_meta($comment_id, 'dislikes', true);

    // existing reaction
    $existing = '';
    if ($user_id) {
        $existing = get_user_meta($user_id, $react_key_user, true) ?: '';
    } else {
        if ($ip_hash) $existing = get_comment_meta($comment_id, $react_key_guest, true) ?: '';
    }

    $active = '';

    // If user clicked the same reaction, remove it
    if ($existing === $action) {
        if ($action === 'like') {
            $likes = max(0, $likes - 1);
            update_comment_meta($comment_id, 'likes', $likes);
        } else {
            $dislikes = max(0, $dislikes - 1);
            update_comment_meta($comment_id, 'dislikes', $dislikes);
        }

        if ($user_id) {
            delete_user_meta($user_id, $react_key_user, ''); // Delete specific value
        } else {
            if ($ip_hash) delete_comment_meta($comment_id, $react_key_guest, ''); // Delete specific value
        }
        $active = '';
    } else {
        // remove previous if any
        if ($existing === 'like') {
            $likes = max(0, $likes - 1);
            update_comment_meta($comment_id, 'likes', $likes);
        } elseif ($existing === 'dislike') {
            $dislikes = max(0, $dislikes - 1);
            update_comment_meta($comment_id, 'dislikes', $dislikes);
        }

        // add new reaction
        if ($action === 'like') {
            $likes++;
            update_comment_meta($comment_id, 'likes', $likes);
        } else {
            $dislikes++;
            update_comment_meta($comment_id, 'dislikes', $dislikes);
        }

        if ($user_id) {
            update_user_meta($user_id, $react_key_user, $action);
        } else {
            if ($ip_hash) update_comment_meta($comment_id, $react_key_guest, $action);
        }

        $active = $action;
    }

    // Return counts and the currently active reaction for the caller (or null)
    wp_send_json_success([
        'likes' => $likes,
        'dislikes' => $dislikes,
        'current' => $active ?: null
    ]);
}

add_action('wp_ajax_nopriv_mangayummy_react_stire', 'mangayummy_react_stire');
add_action('wp_ajax_mangayummy_react_stire', 'mangayummy_react_stire');
function mangayummy_react_stire() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce') && !wp_verify_nonce($nonce, 'mangayummy_comment_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $action = isset($_POST['reaction']) ? sanitize_text_field($_POST['reaction']) : '';

    if (!$post_id || !in_array($action, ['like', 'dislike'], true)) {
        wp_send_json_error(['message' => 'Invalid parameters']);
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'stire') {
        wp_send_json_error(['message' => 'Știre invalidă']);
    }

    $ip_hash = md5(mangayummy_get_client_ip());
    $user_id = get_current_user_id();
    $react_key_user = 'reacted_stire_' . $post_id;
    $react_key_guest = 'reacted_stire_' . $post_id . '_' . $ip_hash;

    $likes = (int) get_post_meta($post_id, '_stire_likes', true);
    $dislikes = (int) get_post_meta($post_id, '_stire_dislikes', true);

    $existing = '';
    if ($user_id) {
        $existing = get_user_meta($user_id, $react_key_user, true) ?: '';
    } else {
        if ($ip_hash) {
            $existing = get_post_meta($post_id, $react_key_guest, true) ?: '';
        }
    }

    $active = '';
    if ($existing === $action) {
        if ($action === 'like') {
            $likes = max(0, $likes - 1);
            update_post_meta($post_id, '_stire_likes', $likes);
        } else {
            $dislikes = max(0, $dislikes - 1);
            update_post_meta($post_id, '_stire_dislikes', $dislikes);
        }

        if ($user_id) {
            delete_user_meta($user_id, $react_key_user, $existing);
        } elseif ($ip_hash) {
            delete_post_meta($post_id, $react_key_guest, $existing);
        }
    } else {
        if ($existing === 'like') {
            $likes = max(0, $likes - 1);
            update_post_meta($post_id, '_stire_likes', $likes);
        } elseif ($existing === 'dislike') {
            $dislikes = max(0, $dislikes - 1);
            update_post_meta($post_id, '_stire_dislikes', $dislikes);
        }

        if ($action === 'like') {
            $likes++;
            update_post_meta($post_id, '_stire_likes', $likes);
        } else {
            $dislikes++;
            update_post_meta($post_id, '_stire_dislikes', $dislikes);
        }

        if ($user_id) {
            update_user_meta($user_id, $react_key_user, $action);
        } elseif ($ip_hash) {
            update_post_meta($post_id, $react_key_guest, $action);
        }
        $active = $action;
    }

    wp_send_json_success([
        'likes' => $likes,
        'dislikes' => $dislikes,
        'current' => $active ?: null
    ]);
}

/**
 * AJAX endpoint to update manga reading status
 */
if (!function_exists('mangayummy_update_manga_status_ajax')) {
function mangayummy_update_manga_status_ajax() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed']);
    }
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'User not logged in']);
    }
    
    $user_id = get_current_user_id();
    $manga_id = isset($_POST['manga_id']) ? intval($_POST['manga_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
    
    // log ajax request

    if (!$manga_id) {
        wp_send_json_error(['message' => 'Invalid manga ID']);
    }
    
    // Check if status is 'remove'
    if ($status === 'remove') {
        if (function_exists('mangayummy_remove_manga_status')) {
            mangayummy_remove_manga_status($user_id, $manga_id);
            wp_send_json_success(['message' => 'Status șters', 'status' => false]);
        }
    } else {
        // Set the status
        if (function_exists('mangayummy_set_manga_status')) {
            $result = mangayummy_set_manga_status($user_id, $manga_id, $status);
            if ($result) {
                wp_send_json_success(['message' => 'Status actualizat', 'status' => $status]);
            } else {
                wp_send_json_error(['message' => 'Eroare la actualizarea statusului']);
            }
        }
    }
}
add_action('wp_ajax_mangayummy_update_manga_status', 'mangayummy_update_manga_status_ajax');
add_action('wp_ajax_nopriv_mangayummy_update_manga_status', 'mangayummy_update_manga_status_ajax');
}

// AJAX endpoint to update manga reading progress (used on profile page)
if (!function_exists('mangayummy_update_manga_progress_ajax')) {
function mangayummy_update_manga_progress_ajax() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed']);
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'User not logged in']);
    }
    $user_id = get_current_user_id();
    $manga_id = isset($_POST['manga_id']) ? intval($_POST['manga_id']) : 0;
    $progress = isset($_POST['progress']) ? intval($_POST['progress']) : 0;
    if (!$manga_id) {
        wp_send_json_error(['message' => 'Invalid manga ID']);
    }
    if ($progress < 0) {
        wp_send_json_error(['message' => 'Invalid progress']);
    }
    // update user meta
    mangayummy_update_manga_progress($user_id, $manga_id, $progress);
    wp_send_json_success(['message' => 'Progres actualizat', 'progress' => $progress]);
}
add_action('wp_ajax_mangayummy_update_manga_progress', 'mangayummy_update_manga_progress_ajax');
add_action('wp_ajax_nopriv_mangayummy_update_manga_progress', 'mangayummy_update_manga_progress_ajax');
}

// Check username availability for settings
function mangayummy_check_username_available_ajax() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $current_user_id = isset($_POST['current_user_id']) ? intval($_POST['current_user_id']) : 0;

    // Basic validation
    if (empty($username) || strlen($username) < 3 || strlen($username) > 20) {
        wp_send_json_error(['available' => false, 'message' => 'Numele trebuie să aibă 3-20 caractere']);
    }

    // Check if username contains only allowed characters (letters, numbers, underscore, dash)
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
        wp_send_json_error(['available' => false, 'message' => 'Numele poate conține doar litere, cifre, _ și -']);
    }

    // Check if display name is already taken by another user
    global $wpdb;
    $existing_user = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->users} WHERE LOWER(display_name) = LOWER(%s) AND ID != %d LIMIT 1",
        $username,
        $current_user_id
    ));
    if ($existing_user) {
        wp_send_json_error(['available' => false, 'message' => 'Numele este deja folosit']);
    }

    // Username is available
    wp_send_json_success(['available' => true]);
}
add_action('wp_ajax_mangayummy_check_username_available', 'mangayummy_check_username_available_ajax');

// Change username for settings
function mangayummy_change_username_ajax() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }

    // Check if user is logged in
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fiți autentificat']);
    }

    $user_id = get_current_user_id();
    $new_username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';

    // Basic validation (3-20 characters)
    if (empty($new_username) || strlen($new_username) < 3 || strlen($new_username) > 20) {
        wp_send_json_error(['message' => 'Numele trebuie să aibă 3-20 caractere']);
    }

    // Check if username contains only allowed characters
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $new_username)) {
        wp_send_json_error(['message' => 'Numele poate conține doar litere, cifre, _ și -']);
    }

    // Block spam usernames
    if (function_exists('mangayummy_ya_is_spam_username') && mangayummy_ya_is_spam_username($new_username)) {
        wp_send_json_error(['message' => 'Acest nume nu este permis']);
    }

    // Check if display name is already taken by another user
    global $wpdb;
    $existing_user = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->users} WHERE LOWER(display_name) = LOWER(%s) AND ID != %d LIMIT 1",
        $new_username,
        $user_id
    ));
    if ($existing_user) {
        wp_send_json_error(['message' => 'Acest nume este deja folosit']);
    }

    // Update display name
    $user_data = array(
        'ID' => $user_id,
        'display_name' => $new_username,
        'user_nicename' => sanitize_title($new_username)
    );

    $result = wp_update_user($user_data);

    if (is_wp_error($result)) {
        wp_send_json_error(['message' => 'Eroare la actualizarea numelui: ' . $result->get_error_message()]);
    }

    wp_send_json_success(['message' => 'Nume actualizat cu succes']);
}
add_action('wp_ajax_mangayummy_change_username', 'mangayummy_change_username_ajax');



if (!function_exists('mangayummy_get_manga_status')) {
/**
 * Get the reading status of a manga for a user
 * 
 * @param int $user_id User ID
 * @param int $manga_id Manga post ID
 * @return string|false Status (reading, planned, completed, paused, abandoned) or false if not set
 */
function mangayummy_get_manga_status($user_id, $manga_id) {
    $statuses = array('reading', 'planned', 'completed', 'paused', 'abandoned');
    
    foreach ($statuses as $status) {
        $meta_key = 'manga_status_' . $status;
        $status_list = get_user_meta($user_id, $meta_key, true);
        
        if (!is_array($status_list)) {
            $status_list = array();
        }
        
        if (in_array($manga_id, $status_list)) {
            return $status;
        }
    }
    
    return false;
}
}

if (!function_exists('mangayummy_set_manga_status')) {
/**
 * Set the reading status of a manga for a user
 * Removes from other statuses automatically
 * 
 * @param int $user_id User ID
 * @param int $manga_id Manga post ID
 * @param string $status New status (reading, planned, completed, paused, abandoned)
 * @return bool True on success
 */
function mangayummy_set_manga_status($user_id, $manga_id, $status) {
    $manga_id = intval($manga_id);
    $valid_statuses = array('reading', 'planned', 'completed', 'paused', 'abandoned');
    
    // Validate status
    if (!in_array($status, $valid_statuses)) {
        return false;
    }

    // log change request
    
    // Remove from all statuses first
    foreach ($valid_statuses as $s) {
        $meta_key = 'manga_status_' . $s;
        $status_list = get_user_meta($user_id, $meta_key, true);
        
        if (!is_array($status_list)) {
            $status_list = array();
        }
        
        $status_list = array_diff($status_list, array($manga_id));
        update_user_meta($user_id, $meta_key, $status_list);
    }
    
    // Add to new status
    $meta_key = 'manga_status_' . $status;
    $status_list = get_user_meta($user_id, $meta_key, true);
    
    if (!is_array($status_list)) {
        $status_list = array();
    }
    
    if (!in_array($manga_id, $status_list)) {
        $status_list[] = $manga_id;
    }
    
    update_user_meta($user_id, $meta_key, $status_list);
    
    // Update timestamp when status changes (for activity log sorting)
    update_user_meta($user_id, 'manga_progress_timestamp_' . $manga_id, current_time('timestamp'));
    
    return true;
}
}

if (!function_exists('mangayummy_remove_manga_status')) {
/**
 * Remove manga from all reading status lists AND from bookmarks/favorites
 * Also clears progress and timestamps
 * 
 * @param int $user_id User ID
 * @param int $manga_id Manga post ID
 * @return bool True on success
 */
function mangayummy_remove_manga_status($user_id, $manga_id) {
    $manga_id = intval($manga_id);
    $valid_statuses = array('reading', 'planned', 'completed', 'paused', 'abandoned');

    
    // Remove from all status lists
    foreach ($valid_statuses as $status) {
        $meta_key = 'manga_status_' . $status;
        $status_list = get_user_meta($user_id, $meta_key, true);
        
        if (!is_array($status_list)) {
            $status_list = array();
        }
        
        $status_list = array_diff($status_list, array($manga_id));
        update_user_meta($user_id, $meta_key, $status_list);
    }
    
    // Remove from all bookmark/favorites lists (all possible meta keys)
    // Also decrement the bookmark count on the manga
    $bookmark_keys = array('mangayummy_bookmarks', 'bookmarked_manga', 'bookmarked_mangas');
    $already_decremented = false; // Prevent double decrement if manga is in multiple keys
    foreach ($bookmark_keys as $bm_key) {
        $bookmarks = get_user_meta($user_id, $bm_key, true);
        if (is_array($bookmarks) && in_array($manga_id, $bookmarks)) {
            $bookmarks = array_values(array_diff($bookmarks, array($manga_id)));
            update_user_meta($user_id, $bm_key, $bookmarks);
            
            // Decrement bookmark count on manga (only once)
            if (!$already_decremented) {
                $count = (int) get_post_meta($manga_id, '_mangayummy_bookmark_count', true);
                $count = max(0, $count - 1);
                update_post_meta($manga_id, '_mangayummy_bookmark_count', $count);
                $already_decremented = true;
            }
        }
    }
    
    // Also clear progress and timestamps
    delete_user_meta($user_id, 'manga_progress_' . $manga_id);
    delete_user_meta($user_id, 'manga_progress_timestamp_' . $manga_id);

    // after cleanup log remaining status arrays
    $remaining = [];
    foreach ($valid_statuses as $status) {
        $list = get_user_meta($user_id, 'manga_status_' . $status, true);
        $remaining[$status] = is_array($list) ? $list : [];
    }
    
    return true;
}

// AJAX handler for updating manga progress
function mangayummy_update_progress() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(__('User not logged in', 'mangayummy'));
        return;
    }
    
    $user_id = get_current_user_id();
    $manga_id = intval($_POST['manga_id']);
    $chapter_number = floatval($_POST['chapter_number']);
    
    if (!$manga_id || $chapter_number < 0) {
        wp_send_json_error(__('Invalid data', 'mangayummy'));
        return;
    }
    
    // Update progress in both systems
    mangayummy_update_manga_progress($user_id, $manga_id, $chapter_number);
    update_user_meta($user_id, 'manga_progress_' . $manga_id, $chapter_number);
    
    // Save timestamp when chapter was read (for activity log sorting)
    update_user_meta($user_id, 'manga_progress_timestamp_' . $manga_id, current_time('timestamp'));
    
    // DISABLED: Auto-setting status - users must manually set status for manga to appear in their list
    // Only auto-mark as completed if _final_chapter is set (explicit)
    $total_chapters = get_post_meta($manga_id, '_final_chapter', true);
    $total_chapters = $total_chapters ? floatval($total_chapters) : 0;
    
    $status_changed = false;
    $new_status = null;
    
    // Only auto-mark as completed if final chapter is explicitly set and reached
    if ($total_chapters > 0 && $chapter_number >= $total_chapters) {
        mangayummy_set_manga_status($user_id, $manga_id, 'completed');
        $status_changed = true;
        $new_status = 'completed';
    }
    
    // Get updated progress
    $current_progress = mangayummy_get_manga_progress($user_id, $manga_id);
    
    wp_send_json_success(array(
        'progress' => $current_progress,
        'total' => $total_chapters,
        'percentage' => $total_chapters > 0 ? round(($current_progress / $total_chapters) * 100, 1) : 0,
        'status_changed' => $status_changed,
        'new_status' => $new_status
    ));
}
add_action('wp_ajax_mangayummy_update_progress', 'mangayummy_update_progress');

// ==========================================
// TIME-BASED DATA SENDING (AFTER 12:00)
// ==========================================

/**
 * Check if current time is after 12:00 (noon)
 * @return bool True if after 12:00, false otherwise
 */
function mangayummy_is_after_noon() {
    $current_hour = (int) date('H');
    return $current_hour >= 12;
}

/**
 * Example usage for analytics data:
 * 
 * mangayummy_send_data_after_noon(
 *     function() {
 *         // Collect analytics data
 *         return array(
 *             'pageviews' => get_pageview_count(),
 *             'users_online' => get_online_user_count(),
 *             'timestamp' => time()
 *         );
 *     },
 *     function($data) {
 *         // Send to external service
 *         return wp_remote_post('https://analytics.example.com/api/track', array(
 *             'body' => json_encode($data),
 *             'headers' => array('Content-Type' => 'application/json')
 *         ));
 *     }
 * );
 */

/**
 * Example usage for daily user activity report:
 * 
 * mangayummy_send_data_after_noon(
 *     function() {
 *         global $wpdb;
 *         // Get daily activity data
 *         return $wpdb->get_results("
 *             SELECT user_id, COUNT(*) as actions
 *             FROM user_activity_log
 *             WHERE DATE(created_at) = CURDATE()
 *             GROUP BY user_id
 *         ");
 *     },
 *     function($data) {
 *         // Send email report
 *         $message = "Daily User Activity Report:\n\n";
 *         foreach ($data as $row) {
 *             $message .= "User {$row->user_id}: {$row->actions} actions\n";
 *         }
 *         return wp_mail('admin@example.com', 'Daily Activity Report', $message);
 *     }
 * );
 */

// Track guest activity
function mangayummy_track_guest_activity() {
    // Don't track in admin or if user is logged in
    if (is_admin() || is_user_logged_in()) {
        return;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        return;
    }

    // Create unique key for this guest
    $guest_key = 'guest_online_' . md5($ip . $user_agent);

    // Store guest data with 1 minute expiration
    $guest_data = [
        'ip' => $ip,
        'user_agent' => substr($user_agent, 0, 200), // Limit length
        'last_active' => time(),
        'first_visit' => time(),
    ];

    // Check if guest already exists
    $existing = get_transient($guest_key);
    if ($existing) {
        $guest_data['first_visit'] = $existing['first_visit'] ?? time();
    }

    set_transient($guest_key, $guest_data, 1 * MINUTE_IN_SECONDS); // 1 minute
}

// Track user activity on every page load
add_action('init', function() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $now = current_time('timestamp');
        update_user_meta($user_id, 'last_active', $now);
        update_user_meta($user_id, 'last_activity', $now);
        update_user_meta($user_id, 'is_online', true);

        // Track IP address
        $user_ip = $_SERVER['REMOTE_ADDR'];
        if (!empty($user_ip) && filter_var($user_ip, FILTER_VALIDATE_IP)) {
            update_user_meta($user_id, 'last_ip', $user_ip);
        }
    } else {
        // Track guest activity
        mangayummy_track_guest_activity();
    }
});

// Track IP on login
add_action('wp_login', function($user_login, $user) {
    $user_ip = $_SERVER['REMOTE_ADDR'];
    if (!empty($user_ip) && filter_var($user_ip, FILTER_VALIDATE_IP)) {
        update_user_meta($user->ID, 'last_ip', $user_ip);
        update_user_meta($user->ID, 'last_login_ip', $user_ip);
    }
    $now = current_time('timestamp');
    update_user_meta($user->ID, 'last_active', $now);
    update_user_meta($user->ID, 'last_activity', $now);

    // Remove any guest transient for this IP to avoid duplication
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (!empty($user_agent)) {
        $guest_key = 'guest_online_' . md5($user_ip . $user_agent);
        delete_transient($guest_key);
    }
}, 10, 2);

// Mark user as offline on logout
add_action('wp_logout', function() {
    $user_id = get_current_user_id();
    update_user_meta($user_id, 'is_online', false);
});

// Clean up offline guests (run this periodically)
function mangayummy_cleanup_offline_guests() {
    global $wpdb;

    // Delete expired guest transients
    $expired_time = time() - (1 * MINUTE_IN_SECONDS);

    // Get all guest transients
    $transient_keys = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            '_transient_guest_online_%'
        )
    );

    foreach ($transient_keys as $key) {
        $transient_name = str_replace('_transient_', '', $key);
        $guest_data = get_transient($transient_name);
        if ($guest_data && isset($guest_data['last_active']) && $guest_data['last_active'] < $expired_time) {
            delete_transient($transient_name);
        }
    }
}

// Clean up offline users (run this periodically)
function mangayummy_cleanup_offline_users() {
    global $wpdb;

    // Mark users as offline if they haven't been active for 1 minute
    $one_minute_ago = time() - 60;

    // Use prepare() correctly - only for direct values, not subqueries
    $query = $wpdb->prepare(
        "UPDATE {$wpdb->usermeta} SET meta_value = %d
         WHERE meta_key = %s
         AND meta_value = %s
         AND user_id IN (
             SELECT user_id FROM {$wpdb->usermeta}
             WHERE meta_key = %s
             AND CAST(meta_value AS UNSIGNED) < %d
         )",
        0,
        'is_online',
        '1',
        'last_active',
        $one_minute_ago
    );
    $wpdb->query($query);
}

// Get user online status
function mangayummy_get_user_online_status($user_id) {
    $is_online = get_user_meta($user_id, 'is_online', true);
    if ($is_online) {
        return '<span class="user-status online"><span class="status-dot"></span>Online</span>';
    } else {
        return '<span class="user-status offline">Offline</span>';
    }
}

// ==========================================
// ADMIN DASHBOARD - ONLINE USERS WIDGET
// ==========================================

// Update IP addresses for existing users who don't have one
function mangayummy_update_missing_ips() {
    global $wpdb;

    // Get users who don't have last_ip meta
    $users_without_ip = $wpdb->get_col("
        SELECT u.ID
        FROM {$wpdb->users} u
        LEFT JOIN {$wpdb->usermeta} um ON u.ID = um.user_id AND um.meta_key = 'last_ip'
        WHERE um.meta_value IS NULL OR um.meta_value = ''
    ");

    if (!empty($users_without_ip)) {
        // For existing users without IP, we can't get their real IP
        // But we can set a placeholder or try to get from login logs if available
        foreach ($users_without_ip as $user_id) {
            // Set a placeholder for users who never logged in with the new system
            update_user_meta($user_id, 'last_ip', 'Unknown (pre-existing user)');
        }
    }
}

// Track manga reading activity
function mangayummy_track_manga_reading($manga_id, $chapter_id = null) {
    if (empty($manga_id)) {
        return;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    // skip bots/crawlers so they don't show up in "currently reading"
    if (preg_match('/bot|crawl|spider|facebook|meta-webindexer|googlebot|bingbot|curl|wget/i', $user_agent)) {
        return;
    }

    if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
        return;
    }

    // Create unique key for this reader
    $reader_key = 'reading_manga_' . md5($ip . $user_agent . $manga_id);

    // Get manga title
    $manga_title = get_the_title($manga_id);
    if (empty($manga_title)) {
        $manga_title = 'Manga #' . $manga_id;
    }

    // Store reading data with 2 hours expiration
    $reading_data = [
        'manga_id' => $manga_id,
        'manga_title' => $manga_title,
        'chapter_id' => $chapter_id,
        'ip' => $ip,
        'user_agent' => substr($user_agent, 0, 200),
        'last_active' => time(),
        'first_visit' => time(),
        'is_logged_in' => is_user_logged_in(),
        'user_id' => is_user_logged_in() ? get_current_user_id() : null,
        'user_name' => is_user_logged_in() ? wp_get_current_user()->display_name : null,
    ];

    // Check if already reading this manga
    $existing = get_transient($reader_key);
    if ($existing) {
        $reading_data['first_visit'] = $existing['first_visit'] ?? time();
    }

    set_transient($reader_key, $reading_data, 2 * HOUR_IN_SECONDS); // 2 hours
}

// Get currently reading manga
function mangayummy_get_currently_reading_manga() {
    global $wpdb;

    // Get all transients with reading_manga_ prefix
    $readers = [];

    // Use WordPress transients table
    $transient_keys = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            '_transient_reading_manga_%'
        )
    );

    foreach ($transient_keys as $key) {
        $transient_name = str_replace('_transient_', '', $key);
        $reading_data = get_transient($transient_name);
        if ($reading_data && is_array($reading_data)) {
            $readers[] = $reading_data;
        }
    }

    return $readers;
}

// Clean up expired reading sessions
function mangayummy_cleanup_expired_reading_sessions() {
    global $wpdb;

    $expired_time = time() - (2 * HOUR_IN_SECONDS);

    // Get all reading transients
    $transient_keys = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            '_transient_reading_manga_%'
        )
    );

    foreach ($transient_keys as $key) {
        $transient_name = str_replace('_transient_', '', $key);
        $reading_data = get_transient($transient_name);
        if ($reading_data && isset($reading_data['last_active']) && $reading_data['last_active'] < $expired_time) {
            delete_transient($transient_name);
        }
    }
}

// Add dashboard widget
add_action('wp_dashboard_setup', 'mangayummy_add_dashboard_widgets');

function mangayummy_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'mangayummy_online_users_widget',
        'Status Utilizatori',
        'mangayummy_display_online_users_widget'
    );
    
    wp_add_dashboard_widget(
        'mangayummy_reading_manga_widget',
        'Manga Citite Acum',
        'mangayummy_display_reading_manga_widget'
    );
}


// Get online guests
function mangayummy_get_online_guests() {
    global $wpdb;

    // Get all transients with guest_online_ prefix
    $guests = [];

    // Use WordPress transients table
    $transient_keys = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            '_transient_guest_online_%'
        )
    );

    foreach ($transient_keys as $key) {
        $transient_name = str_replace('_transient_', '', $key);
        $guest_data = get_transient($transient_name);
        if ($guest_data && is_array($guest_data)) {
            $guests[] = $guest_data;
        }
    }

    return $guests;
}

// Display the dashboard widget
function mangayummy_display_online_users_widget() {
    global $wpdb;

    // Clean up offline users first
    mangayummy_cleanup_offline_users();

    // Clean up offline guests
    mangayummy_cleanup_offline_guests();

    // Get online guests
    $online_guests = mangayummy_get_online_guests();

    // filter out bots and count human guests separately
    $bot_count = 0;
    $human_guests = [];
    foreach ($online_guests as $g) {
        $ua = isset($g['user_agent']) ? strtolower($g['user_agent']) : '';
        if (preg_match('/bot|crawl|spider|facebook|meta-webindexer|googlebot|bingbot|curl|wget/i', $ua)) {
            $bot_count++;
        } else {
            $human_guests[] = $g;
        }
    }
    $guest_count = count($human_guests);
    $online_guests = $human_guests;

    // Get all users with their online status and last activity
    $all_users = $wpdb->get_results("
        SELECT u.ID, u.user_login, u.display_name, u.user_email,
               COALESCE(um1.meta_value, '0') as is_online,
               COALESCE(um2.meta_value, '0') as last_active,
               u.user_registered
        FROM {$wpdb->users} u
        LEFT JOIN {$wpdb->usermeta} um1 ON u.ID = um1.user_id AND um1.meta_key = 'is_online'
        LEFT JOIN {$wpdb->usermeta} um2 ON u.ID = um2.user_id AND um2.meta_key = 'last_active'
        ORDER BY
            CASE WHEN um1.meta_value = '1' THEN 1 ELSE 0 END DESC,
            COALESCE(CAST(um2.meta_value AS UNSIGNED), 0) DESC
        LIMIT 100
    ");

    $now = current_time('timestamp');
    $online_count = 0;
    $offline_count = 0;
    // $guest_count already computed above

    foreach ($all_users as $user) {
        $last_active = intval($user->last_active);
        $is_online = ($last_active > 0 && ($now - $last_active) < MINUTE_IN_SECONDS);
        if ($is_online) {
            $online_count++;
        } else {
            $offline_count++;
        }
    }

    echo '<div class="mangayummy-online-users-widget">';
    echo '<style>
    .mangayummy-online-users-widget .guest-row { background-color: #f9f9f9; }
    .mangayummy-online-users-widget .guest-row td { border-top: 1px solid #e0e0e0; }
    .mangayummy-online-users-widget .guest-stat { color: #28a745; }
    .mangayummy-online-users-widget .status-indicator.online { color: #28a745; font-weight: bold; }
    .mangayummy-online-users-widget .status-indicator.offline { color: #6c757d; }
    </style>';
    echo '<div class="online-users-header">';
    echo '<h4>Status Utilizatori</h4>';
    echo '<div class="user-stats">';
    echo '<span class="online-stat">Utilizatori Online: <strong>' . $online_count . '</strong></span>';
    echo '<span class="guest-stat">Vizitatori Online: <strong>' . $guest_count . '</strong></span>';
    echo '<span class="bot-stat">Boti Online: <strong>' . $bot_count . '</strong></span>';
    echo '<span class="offline-stat">Utilizatori Offline: <strong>' . $offline_count . '</strong></span>';
    echo '<span class="total-stat">Total Utilizatori: <strong>' . count($all_users) . '</strong></span>';
    echo '</div>';
    echo '<p class="online-subtitle">Ultimii 100 utilizatori înregistrați + vizitatori online (botii sunt numărați separat)</p>';

    // Add refresh button
    echo '<div class="widget-actions">';
    echo '<button type="button" id="refresh-user-status" class="button button-small">Actualizează Status</button>';
    echo '</div>';

    echo '</div>';

    if (!empty($all_users)) {
        echo '<div class="online-users-list">';
        echo '<table class="widefat striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Nume/IP</th>';
        echo '<th>Tip</th>';
        echo '<th>Status</th>';
        echo '<th>Ultima Activitate</th>';
        echo '<th>Detalii</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        foreach ($all_users as $user) {
            $last_active = intval($user->last_active);
            $is_online = ($last_active > 0 && ($now - $last_active) < MINUTE_IN_SECONDS);

            if ($last_active > 0) {
                $time_ago = human_time_diff($last_active, $now) . ' în urmă';
                $last_active_formatted = date_i18n('d M Y, H:i', $last_active);
            } else {
                $time_ago = 'Niciodată';
                $last_active_formatted = 'Niciodată';
            }

            $registered_date = date_i18n('d M Y', strtotime($user->user_registered));
            $status_class = $is_online ? 'online' : 'offline';
            $status_text = $is_online ? '● Online' : '○ Offline';

            echo '<tr class="' . esc_attr($status_class) . '">';
            echo '<td>';
            echo '<strong>' . esc_html($user->display_name) . '</strong>';
            echo '<br><small style="color:#666;">@' . esc_html($user->user_login) . '</small>';
            echo '</td>';
            echo '<td>Utilizator</td>';
            echo '<td><span class="status-indicator ' . esc_attr($status_class) . '">' . esc_html($status_text) . '</span></td>';
            echo '<td>';
            echo '<span title="' . esc_attr($last_active_formatted) . '">' . esc_html($time_ago) . '</span>';
            echo '</td>';
            echo '<td>';
            echo '<small>Email: ' . esc_html($user->user_email) . '</small><br>';
            echo '<small>Înregistrat: ' . esc_html($registered_date) . '</small>';
            echo '</td>';
            echo '</tr>';
        }

        // Add online guests
        if (!empty($online_guests)) {
            foreach ($online_guests as $guest) {
                $last_active = intval($guest['last_active']);
                $time_ago = human_time_diff($last_active, time()) . ' în urmă';
                $last_active_formatted = date_i18n('d M Y, H:i', $last_active);
                $first_visit = intval($guest['first_visit']);
                $first_visit_formatted = date_i18n('d M Y, H:i', $first_visit);

                echo '<tr class="online guest-row">';
                echo '<td>';
                echo '<strong>' . esc_html($guest['ip']) . '</strong>';
                echo '<br><small style="color:#666;">Vizitator</small>';
                echo '</td>';
                echo '<td>Vizitator</td>';
                echo '<td><span class="status-indicator online">● Online</span></td>';
                echo '<td>';
                echo '<span title="' . esc_attr($last_active_formatted) . '">' . esc_html($time_ago) . '</span>';
                echo '</td>';
                echo '<td>';
                echo '<small>Prima vizită: ' . esc_html($first_visit_formatted) . '</small><br>';
                echo '<small>User Agent: ' . esc_html(substr($guest['user_agent'], 0, 50)) . '...</small>';
                echo '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo '<div class="no-online-users">';
        echo '<p>Nu există utilizatori în sistem.</p>';
        echo '</div>';
    }

    echo '<div class="online-users-footer">';
    echo '<p><small>Utilizatorii sunt considerați offline după 1 minut de inactivitate. Vizitatorii sunt considerați offline după 1 minut. IP-urile se înregistrează doar când utilizatorii vizitează site-ul fiind logați.</small></p>';
    echo '</div>';

    echo '</div>';

    // Add JavaScript for refresh functionality
    echo '<script>
        document.getElementById("refresh-user-status").addEventListener("click", function() {
            this.textContent = "Actualizare...";
            this.disabled = true;
            location.reload();
        });
    </script>';

    // Add some CSS for the widget
    echo '<style>
        .mangayummy-online-users-widget .user-stats {
            display: flex;
            gap: 15px;
            margin: 10px 0;
            font-size: 13px;
        }
        .mangayummy-online-users-widget .online-stat {
            color: #28a745;
        }
        .mangayummy-online-users-widget .offline-stat {
            color: #6c757d;
        }
        .mangayummy-online-users-widget .total-stat {
            color: #007cba;
        }
        .mangayummy-online-users-widget .bot-stat {
            color: #ff9800;
        }
        .mangayummy-online-users-widget .widget-actions {
            margin: 10px 0;
            padding: 8px 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .mangayummy-online-users-widget .online-users-header {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .mangayummy-online-users-widget .online-subtitle {
            color: #666;
            margin: 5px 0 0 0;
            font-size: 12px;
        }
        .mangayummy-online-users-widget .online-users-list {
            max-height: 500px;
            overflow-y: auto;
        }
        .mangayummy-online-users-widget table {
            margin: 0;
        }
        .mangayummy-online-users-widget table td {
            vertical-align: top;
            padding: 8px;
        }
        .mangayummy-online-users-widget table code {
            background: #f1f1f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
            font-size: 12px;
        }
        .mangayummy-online-users-widget .status-indicator.online {
            color: #28a745;
            font-weight: bold;
        }
        .mangayummy-online-users-widget .status-indicator.offline {
            color: #6c757d;
        }
        .mangayummy-online-users-widget tr.online {
            background-color: rgba(40, 167, 69, 0.05);
        }
        .mangayummy-online-users-widget tr.offline {
            background-color: rgba(108, 117, 125, 0.05);
        }
        .mangayummy-online-users-widget .online-users-footer {
            margin-top: 15px;
            padding-top: 10px;
            border-top: 1px solid #eee;
        }
        .mangayummy-online-users-widget .online-users-footer small {
            color: #666;
        }
    </style>';
}

// Display the reading manga dashboard widget
function mangayummy_display_reading_manga_widget() {
    global $wpdb;

    // Clean up expired reading sessions first
    mangayummy_cleanup_expired_reading_sessions();

    // Get currently reading manga
    $currently_reading = mangayummy_get_currently_reading_manga();

    // remove any bot sessions from data
    $filtered = [];
    foreach ($currently_reading as $reader) {
        $ua = isset($reader['user_agent']) ? strtolower($reader['user_agent']) : '';
        if (preg_match('/bot|crawl|spider|facebook|meta-webindexer|googlebot|bingbot|curl|wget/i', $ua)) {
            continue;
        }
        $filtered[] = $reader;
    }
    $currently_reading = $filtered;

    // Group by manga
    $manga_readers = [];
    foreach ($currently_reading as $reader) {
        $manga_id = $reader['manga_id'];
        if (!isset($manga_readers[$manga_id])) {
            $manga_readers[$manga_id] = [
                'manga_title' => $reader['manga_title'],
                'manga_id' => $manga_id,
                'readers' => [],
                'total_readers' => 0,
                'logged_in_count' => 0,
                'guest_count' => 0,
            ];
        }
        $manga_readers[$manga_id]['readers'][] = $reader;
        $manga_readers[$manga_id]['total_readers']++;
        if ($reader['is_logged_in']) {
            $manga_readers[$manga_id]['logged_in_count']++;
        } else {
            $manga_readers[$manga_id]['guest_count']++;
        }
    }

    // Sort by total readers (most popular first)
    uasort($manga_readers, function($a, $b) {
        return $b['total_readers'] <=> $a['total_readers'];
    });

    echo '<div class="mangayummy-reading-manga-widget">';
    echo '<style>
    .mangayummy-reading-manga-widget .reading-stats {
        display: flex;
        gap: 15px;
        margin: 10px 0;
        font-size: 13px;
    }
    .mangayummy-reading-manga-widget .total-reading-stat {
        color: #28a745;
    }
    .mangayummy-reading-manga-widget .unique-manga-stat {
        color: #007cba;
    }
    .mangayummy-reading-manga-widget .widget-actions {
        margin: 10px 0;
        padding: 8px 0;
        border-top: 1px solid #eee;
        border-bottom: 1px solid #eee;
    }
    .mangayummy-reading-manga-widget .reading-manga-header {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }
    .mangayummy-reading-manga-widget .reading-subtitle {
        color: #666;
        margin: 5px 0 0 0;
        font-size: 12px;
    }
    .mangayummy-reading-manga-widget .reading-manga-list {
        max-height: 500px;
        overflow-y: auto;
    }
    .mangayummy-reading-manga-widget table {
        margin: 0;
    }
    .mangayummy-reading-manga-widget table td {
        vertical-align: top;
        padding: 8px;
    }
    .mangayummy-reading-manga-widget .manga-title {
        font-weight: bold;
        color: #007cba;
    }
    .mangayummy-reading-manga-widget .reader-count {
        background: #f1f1f1;
        padding: 2px 6px;
        border-radius: 3px;
        font-family: monospace;
        font-size: 12px;
        color: #28a745;
    }
    .mangayummy-reading-manga-widget .reader-details {
        margin-top: 5px;
    }
    .mangayummy-reading-manga-widget .reader-item {
        margin: 2px 0;
        font-size: 12px;
    }
    .mangayummy-reading-manga-widget .user-type.logged-in {
        color: #28a745;
    }
    .mangayummy-reading-manga-widget .user-type.guest {
        color: #6c757d;
    }
    .mangayummy-reading-manga-widget .reading-manga-footer {
        margin-top: 15px;
        padding-top: 10px;
        border-top: 1px solid #eee;
    }
    .mangayummy-reading-manga-widget .reading-manga-footer small {
        color: #666;
    }
    </style>';

    echo '<div class="reading-manga-header">';
    echo '<h4>Manga Citite Acum</h4>';
    echo '<div class="reading-stats">';
    echo '<span class="total-reading-stat">Total cititori: <strong>' . count($currently_reading) . '</strong></span>';
    echo '<span class="unique-manga-stat">Manga unice: <strong>' . count($manga_readers) . '</strong></span>';
    echo '</div>';
    echo '<p class="reading-subtitle">Manga citite în ultimele 30 de minute (ordonate după popularitate)</p>';

    // Add refresh button
    echo '<div class="widget-actions">';
    echo '<button type="button" id="refresh-reading-manga" class="button button-small">Actualizează</button>';
    echo '</div>';

    echo '</div>';

    if (!empty($manga_readers)) {
        echo '<div class="reading-manga-list">';
        echo '<table class="widefat striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Manga</th>';
        echo '<th>Cititori</th>';
        echo '<th>Detalii</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        foreach ($manga_readers as $manga_data) {
            $manga_permalink = get_permalink($manga_data['manga_id']);
            echo '<tr>';
            echo '<td>';
            echo '<div class="manga-title">';
            if ($manga_permalink) {
                echo '<a href="' . esc_url($manga_permalink) . '" target="_blank">' . esc_html($manga_data['manga_title']) . '</a>';
            } else {
                echo esc_html($manga_data['manga_title']);
            }
            echo '</div>';
            echo '<div class="reader-count">Total: ' . $manga_data['total_readers'] . '</div>';
            echo '</td>';
            echo '<td>';
            echo '<small>Utilizatori: ' . $manga_data['logged_in_count'] . '<br>';
            echo 'Vizitatori: ' . $manga_data['guest_count'] . '</small>';
            echo '</td>';
            echo '<td>';
            echo '<div class="reader-details">';
            foreach (array_slice($manga_data['readers'], 0, 3) as $reader) {
                $user_type = $reader['is_logged_in'] ? 'logged-in' : 'guest';
                $user_display = $reader['is_logged_in'] ? 
                    ($reader['user_name'] ? esc_html($reader['user_name']) : 'Utilizator') : 
                    'Vizitator (' . esc_html($reader['ip']) . ')';
                $time_ago = human_time_diff($reader['last_active'], time()) . ' în urmă';
                echo '<div class="reader-item user-type ' . $user_type . '">';
                echo esc_html($user_display) . ' - ' . esc_html($time_ago);
                echo '</div>';
            }
            if ($manga_data['total_readers'] > 3) {
                echo '<div class="reader-item">...și încă ' . ($manga_data['total_readers'] - 3) . ' cititori</div>';
            }
            echo '</div>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo '<div class="no-reading-activity">';
        echo '<p>Nicio activitate de citire în ultimele 2 ore.</p>';
        echo '</div>';
    }

    echo '<div class="reading-manga-footer">';
    echo '<p><small>Sesiunile de citire expiră după 30 de minute de inactivitate. Sunt afișați maxim 3 cititori per manga.</small></p>';
    echo '</div>';

    echo '</div>';

    // Add JavaScript for refresh functionality
    echo '<script>
        document.getElementById("refresh-reading-manga").addEventListener("click", function() {
            this.textContent = "Actualizare...";
            this.disabled = true;
            location.reload();
        });
    </script>';
}

// ==========================================
// TIME AGO FUNCTION
// ==========================================

function mangayummy_yummy_time_ago($timestamp) {
    if (!$timestamp) return 'Niciodată';

    $diff = current_time('timestamp') - $timestamp;

    if ($diff < 60) return 'Acum';
    if ($diff < 3600) return floor($diff / 60) . ' minute';
    if ($diff < 86400) return floor($diff / 3600) . ' ore';
    return floor($diff / 86400) . ' zile';
}

// ==========================================
// PROFILE AJAX HANDLERS
// ==========================================

// Save Birthday
add_action('wp_ajax_mangayummy_save_birthday', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_save_birthday', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(__('Nonce error', 'mangayummy'));
    }
    
    if (!is_user_logged_in()) wp_send_json_error(__('Not logged in', 'mangayummy'));
    
    $birthday = sanitize_text_field($_POST['birthday'] ?? '');
    update_user_meta(get_current_user_id(), 'birthday', $birthday);
    wp_send_json_success(['message' => 'Data nașterii salvată']);
});

// Save Gender
add_action('wp_ajax_mangayummy_save_gender', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_save_gender', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(__('Nonce error', 'mangayummy'));
    }
    
    if (!is_user_logged_in()) wp_send_json_error(__('Not logged in', 'mangayummy'));
    
    $gender = sanitize_text_field($_POST['gender'] ?? '');
    update_user_meta(get_current_user_id(), 'gender', $gender);
    wp_send_json_success(['message' => 'Sex salvat']);
});

// Save Bio
add_action('wp_ajax_mangayummy_save_bio', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_save_bio', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(__('Nonce error', 'mangayummy'));
    }
    
    if (!is_user_logged_in()) wp_send_json_error(__('Not logged in', 'mangayummy'));
    
    $bio = sanitize_textarea_field($_POST['bio'] ?? '');
    
    if (empty($bio)) {
        // Delete the bio meta if it's empty
        delete_user_meta(get_current_user_id(), 'bio');
    } else {
        // Save the bio
        update_user_meta(get_current_user_id(), 'bio', $bio);
    }
    
    wp_send_json_success(['message' => 'Bio salvată']);
});

// Disconnect Discord from current account
add_action('wp_ajax_mangayummy_ya_discord_disconnect', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_ya_discord_disconnect', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Eroare de securitate.']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Neautorizat.']);
    }

    $user_id = get_current_user_id();
    delete_user_meta($user_id, 'discord_id');
    delete_user_meta($user_id, 'discord_avatar');

    wp_send_json_success(['message' => 'Discord account disconnected.']);
});

// Generate Discord verification link for profile confirmation
add_action('wp_ajax_mangayummy_generate_discord_verification_link', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_generate_discord_verification_link', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Eroare de securitate.']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Neautorizat.']);
    }

    $user_id = get_current_user_id();
    $token = get_user_meta($user_id, 'discord_verification_token', true);
    if (empty($token)) {
        $token = wp_generate_password(40, false, false);
        update_user_meta($user_id, 'discord_verification_token', $token);
    }

    $link = add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user_id, 'verify' => rawurlencode($token)), home_url('/'));
    wp_send_json_success(['link' => $link]);
});

// Save reader preferences
add_action('wp_ajax_mangayummy_save_reader_prefs', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_save_reader_prefs', function() {
    $nonce = $_POST['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'ya_ajax_nonce')) {
        wp_send_json_error('Nonce error');
    }
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    // Sanitize incoming arrays
    $prefs = [];
    $prefs['explicit'] = array_map('sanitize_text_field', (array)($_POST['explicit'] ?? []));
    $prefs['genres'] = array_map('sanitize_text_field', (array)($_POST['genres'] ?? []));

    // always save prefs even if arrays are empty – empty means "hide everything" explicitly
    update_user_meta(get_current_user_id(), 'reader_prefs', $prefs);
    wp_send_json_success(['message' => 'Preferences saved']);
});

// Change email (requires current password)
function mangayummy_change_email() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $email = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $user = wp_get_current_user();

    if (empty($email) || !is_email($email)) {
        wp_send_json_error('Email invalid');
    }
    
    if (empty($password)) {
        wp_send_json_error('Introdu parola curentă pentru confirmare');
    }
    
    // Verify current password
    if (!wp_check_password($password, $user->user_pass, $user->ID)) {
        wp_send_json_error('Parola curentă este incorectă');
    }

    if (email_exists($email) && email_exists($email) !== $user->ID) {
        wp_send_json_error('Email-ul este deja folosit de alt cont');
    }

    $result = wp_update_user([
        'ID' => $user->ID,
        'user_email' => $email
    ]);

    if (is_wp_error($result)) {
        wp_send_json_error('Eroare la actualizare: ' . $result->get_error_message());
    }

    wp_send_json_success('Email actualizat cu succes');
}
add_action('wp_ajax_mangayummy_change_email', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_change_email', 'mangayummy_change_email');

// Change password (requires current password)
function mangayummy_change_password() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $user = wp_get_current_user();

    if (empty($current_password)) {
        wp_send_json_error('Introdu parola curentă');
    }
    
    if (empty($new_password) || strlen($new_password) < 6) {
        wp_send_json_error('Parola nouă trebuie să aibă cel puțin 6 caractere');
    }
    
    // Verify current password
    if (!wp_check_password($current_password, $user->user_pass, $user->ID)) {
        wp_send_json_error('Parola curentă este incorectă');
    }

    wp_set_password($new_password, $user->ID);

    // Keep user logged in after password change
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID);

    wp_send_json_success('Parolă schimbată cu succes');
}
add_action('wp_ajax_mangayummy_change_password', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_change_password', 'mangayummy_change_password');

// Update bio
function mangayummy_update_bio() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $bio = sanitize_textarea_field($_POST['bio'] ?? '');
    
    if (empty($bio)) {
        // Delete the bio meta if it's empty
        delete_user_meta(get_current_user_id(), 'bio');
    } else {
        // Save the bio
        update_user_meta(get_current_user_id(), 'bio', $bio);
    }

    wp_send_json_success('Bio actualizată cu succes');
}
add_action('wp_ajax_mangayummy_update_bio', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_update_bio', 'mangayummy_update_bio');

// Update birthday
function mangayummy_update_birthday() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $birthday = sanitize_text_field($_POST['birthday'] ?? '');
    
    // Validate date format
    if ($birthday && !DateTime::createFromFormat('Y-m-d', $birthday)) {
        wp_send_json_error('Format de dată invalid');
    }

    update_user_meta(get_current_user_id(), 'birthday', $birthday);

    wp_send_json_success('Data nașterii actualizată cu succes');
}
add_action('wp_ajax_mangayummy_update_birthday', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_update_birthday', 'mangayummy_update_birthday');

function mangayummy_normalize_gender_value($gender) {
    $gender = strtolower(trim((string)$gender));
    $map = array(
        'male'      => 'masculin',
        'female'    => 'feminin',
        'masculin'  => 'masculin',
        'feminin'   => 'feminin',
        'm'         => 'masculin',
        'f'         => 'feminin',
        'bărbat'    => 'masculin',
        'barbat'    => 'masculin',
        'băiat'     => 'masculin',
        'baiat'     => 'masculin',
        'fată'      => 'feminin',
        'fata'      => 'feminin',
        'femeie'    => 'feminin',
    );

    return $map[$gender] ?? '';
}

function mangayummy_get_user_gender($user_id) {
    $keys = array('gender', 'user_gender', 'profile_gender', 'sex');
    foreach ($keys as $key) {
        $value = get_user_meta($user_id, $key, true);
        if ($value !== '') {
            $normalized = mangayummy_normalize_gender_value($value);
            if ($normalized !== '') {
                return $normalized;
            }
        }
    }

    return '';
}

// Update gender
function mangayummy_update_gender() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $gender = sanitize_text_field($_POST['gender'] ?? '');
    $gender = mangayummy_normalize_gender_value($gender);

    // Validate gender value
    if (!in_array($gender, array('masculin', 'feminin'), true)) {
        wp_send_json_error('Valoare sex invalidă');
    }

    update_user_meta(get_current_user_id(), 'gender', $gender);
    update_user_meta(get_current_user_id(), 'user_gender', $gender);

    wp_send_json_success('Sex actualizat cu succes');
}
add_action('wp_ajax_mangayummy_update_gender', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_update_gender', 'mangayummy_update_gender');

// Upload profile banner (click-based)
function mangayummy_detect_real_mime_type($tmp_path) {
    if (empty($tmp_path) || !file_exists($tmp_path)) {
        return '';
    }

    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $tmp_path);
            finfo_close($finfo);
            if (!empty($mime)) {
                return $mime;
            }
        }
    }

    if (function_exists('exif_imagetype')) {
        $image_type = @exif_imagetype($tmp_path);
        if ($image_type) {
            $mime = image_type_to_mime_type($image_type);
            if (!empty($mime)) {
                return $mime;
            }
        }
    }

    return '';
}

function mangayummy_upload_profile_banner() {
    // Verifică autentificare
    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
        return;
    }

    // Verifică nonce
    if (!isset($_POST['nonce'])) {
        wp_send_json_error('Nonce lipsă');
        return;
    }
    if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error('Nonce invalid');
        return;
    }

    // Verifică user_id
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    if (!$user_id || $user_id !== get_current_user_id()) {
        wp_send_json_error('Nu ești autorizat să încarci pentru acest utilizator');
        return;
    }

    // *** RESTRICȚIE CRITICĂ: DOAR UTILIZATORI CU GRUP POT ÎNCĂRCA BANNERE ***
    $group_info = mangayummy_get_user_group($user_id);
    if (!$group_info) {
        wp_send_json_error('Doar utilizatori cu grup pot încărca bannere');
        return;
    }

    // Verifică fișierul
    if (empty($_FILES['banner'])) {
        wp_send_json_error('Niciun fișier selectat');
        return;
    }

    $file = $_FILES['banner'];

    // Validare tip fișier (grup + GIF suportat)
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];

    $detected_mime = mangayummy_detect_real_mime_type($file['tmp_name'] ?? '');
    if (!$detected_mime || !in_array($detected_mime, $allowed_types, true)) {
        wp_send_json_error('Tip de fișier invalid. Permise: JPG, PNG, WebP, GIF');
        return;
    }

    // Validare dimensiune (max 5MB)
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        wp_send_json_error('Fișier prea mare. Maximum 5MB');
        return;
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';

    // Upload
    $upload_overrides = [
        'test_form' => false,
        'upload_error_handler' => function($file, $message) {
            wp_send_json_error('Eroare upload: ' . $message);
        }
    ];

    // For GIF files, bypass image processing to preserve animation
    if (preg_match('/\.gif$/i', $file['name'])) {
        $upload_dir = wp_upload_dir();
        $filename = wp_unique_filename($upload_dir['path'], $file['name']);
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $upload = [
                'file' => $filepath,
                'url' => $upload_dir['url'] . '/' . $filename,
                'type' => $detected_mime
            ];
        } else {
            wp_send_json_error('Eroare la salvarea fișierului');
        }
    } else {
        $upload = wp_handle_upload($file, $upload_overrides);
    }

    if ($upload && !isset($upload['error'])) {
        // Șterge bannerul vechi dacă există
        $old_banner = get_user_meta($user_id, 'profile_banner', true);
        if ($old_banner) {
            $upload_dir = wp_upload_dir();
            $old_file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $old_banner);
            if (file_exists($old_file_path)) {
                unlink($old_file_path);
            }
        }

        // Salvează URL-ul nou
        update_user_meta($user_id, 'profile_banner', $upload['url']);

        wp_send_json_success(['url' => $upload['url'] . '?t=' . time()]);
    } else {
        $error_message = isset($upload['error']) ? $upload['error'] : 'Eroare necunoscută la upload';
        wp_send_json_error($error_message);
    }
}
add_action('wp_ajax_mangayummy_upload_profile_banner', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_upload_profile_banner', 'mangayummy_upload_profile_banner');

// Remove profile banner
function mangayummy_remove_banner() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $user_id = get_current_user_id();
    $old_banner = get_user_meta($user_id, 'profile_banner', true);

    if ($old_banner) {
        // Delete the file if it exists
        $upload_dir = wp_upload_dir();
        $file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $old_banner);
        if (file_exists($file_path)) {
            @unlink($file_path);
        }

        // Remove the meta
        delete_user_meta($user_id, 'profile_banner');
    }

    $default_url = get_template_directory_uri() . '/images/default-banner.jpg';
    wp_send_json_success(['default_url' => $default_url]);
}
add_action('wp_ajax_mangayummy_remove_banner', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_remove_banner', 'mangayummy_remove_banner');

// Avatar upload
function mangayummy_ya_upload_avatar() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error('Nu ești autentificat');
    }

    $user_id = get_current_user_id();

    if (empty($_FILES['avatar'])) {
        wp_send_json_error('Niciun fișier selectat');
    }

    $file = $_FILES['avatar'];

    // Validare tip fișier
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    
    // Check if user is in a group (allow GIF only for groups)
    $user_group = get_user_meta($user_id, 'user_group', true);
    if ($user_group && !empty($user_group)) {
        // Utilizatori din grupuri pot folosi GIF
        $allowed_types[] = 'image/gif';
    }

    $detected_mime = mangayummy_detect_real_mime_type($file['tmp_name'] ?? '');
    if (!$detected_mime || !in_array($detected_mime, $allowed_types, true)) {
        $gif_message = $user_group ? '' : ' (GIF nu este permis pentru useri normali)';
        wp_send_json_error('Tip de fișier invalid. Permise: JPG, PNG, WebP' . $gif_message);
    }

    // Validare dimensiune (max 2MB)
    $max_size = 2 * 1024 * 1024; // 2MB
    if ($file['size'] > $max_size) {
        wp_send_json_error('Fișier prea mare. Maximum 2MB');
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';

    // Upload
    $upload_overrides = [
        'test_form' => false,
        'upload_error_handler' => function($file, $message) {
            wp_send_json_error('Eroare upload: ' . $message);
        }
    ];

    // For GIF files, bypass image processing to preserve animation
    if (preg_match('/\.gif$/i', $file['name'])) {
        $upload_dir = wp_upload_dir();
        $filename = wp_unique_filename($upload_dir['path'], $file['name']);
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $upload = [
                'file' => $filepath,
                'url' => $upload_dir['url'] . '/' . $filename,
                'type' => $detected_mime
            ];
        } else {
            wp_send_json_error('Eroare la salvarea fișierului');
        }
    } else {
        $upload = wp_handle_upload($file, $upload_overrides);
    }

    if ($upload && !isset($upload['error'])) {
        // Șterge avatarul vechi dacă există
        $old_avatar = get_user_meta($user_id, 'profile_avatar', true);
        if ($old_avatar) {
            $upload_dir = wp_upload_dir();
            $old_file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $old_avatar);
            if (file_exists($old_file_path)) {
                unlink($old_file_path);
            }
        }

        // Salvează URL-ul nou
        update_user_meta($user_id, 'profile_avatar', $upload['url']);

        wp_send_json_success(['url' => $upload['url']]);
    } else {
        $error_message = isset($upload['error']) ? $upload['error'] : 'Eroare necunoscută la upload';
        wp_send_json_error($error_message);
    }
}
add_action('wp_ajax_mangayummy_ya_upload_avatar', 'mangayummy_block_profile_hijack', 0);
add_action('wp_ajax_mangayummy_ya_upload_avatar', 'mangayummy_ya_upload_avatar');

// New unified upload handlers
add_action('wp_ajax_mangayummy_upload_avatar', 'mangayummy_upload_avatar');
add_action('wp_ajax_mangayummy_upload_banner', 'mangayummy_upload_banner');

function mangayummy_upload_avatar() {
    if (!check_ajax_referer('ya_ajax_nonce', 'nonce', false)) {
        wp_send_json_error('Nonce invalid');
    }
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    $user_id = get_current_user_id();

    if (!isset($_FILES['file'])) {
        wp_send_json_error('Fișier lipsă');
    }

    // Check if user has a group assigned (can upload GIF and larger files)
    $user_group = get_user_meta($user_id, 'user_group', true);
    $has_group = !empty($user_group);

    // Check file size
    $max_size = $has_group ? 10 * 1024 * 1024 : 2 * 1024 * 1024; // 10MB for users with group, 2MB otherwise
    if ($_FILES['file']['size'] > $max_size) {
        $max_mb = $has_group ? '10MB' : '2MB';
        wp_send_json_error("Fișier prea mare (max {$max_mb})");
    }

    // Validate file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if ($has_group) {
        $allowed_types[] = 'image/gif';
    }
    
    $file_type = $_FILES['file']['type'];
    if (!in_array($file_type, $allowed_types)) {
        $msg = $has_group ? 'Format neacceptat. Folosiți JPG, PNG, WebP sau GIF' : 'Format neacceptat. Folosiți JPG, PNG sau WebP (nu GIF)';
        wp_send_json_error($msg);
    }

    // Check file extension (only block GIF for users without group)
    $file_name = strtolower($_FILES['file']['name']);
    if (!$has_group && preg_match('/\.gif$/i', $file_name)) {
        wp_send_json_error('GIF nu este acceptat. Folosiți JPG, PNG sau WebP');
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $file = $_FILES['file'];
    
    // For GIF files, bypass image processing to preserve animation
    if (preg_match('/\.gif$/i', $file['name'])) {
        $upload_dir = wp_upload_dir();
        $filename = wp_unique_filename($upload_dir['path'], $file['name']);
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $upload = [
                'file' => $filepath,
                'url' => $upload_dir['url'] . '/' . $filename,
                'type' => $file['type']
            ];
        } else {
            wp_send_json_error('Eroare la salvarea fișierului');
        }
    } else {
        $upload = wp_handle_upload($file, ['test_form' => false]);
    }
    
    if (isset($upload['error'])) wp_send_json_error($upload['error']);

    update_user_meta(get_current_user_id(), 'profile_avatar', $upload['url']);
    wp_send_json_success(['url' => $upload['url']]);
}

function mangayummy_upload_banner() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    $user_id = get_current_user_id();

    if (!isset($_FILES['file'])) {
        wp_send_json_error('Fișier lipsă');
    }

    // Check if user has a group assigned (can upload GIF and larger files)
    $user_group = get_user_meta($user_id, 'user_group', true);
    $has_group = !empty($user_group);

    // Check file size
    $max_size = $has_group ? 10 * 1024 * 1024 : 2 * 1024 * 1024; // 10MB for users with group, 2MB otherwise
    if ($_FILES['file']['size'] > $max_size) {
        $max_mb = $has_group ? '10MB' : '2MB';
        wp_send_json_error("Fișier prea mare (max {$max_mb})");
    }
    $user_group = get_user_meta($user_id, 'user_group', true);
    $has_group = !empty($user_group);

    // Validate file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if ($has_group) {
        $allowed_types[] = 'image/gif';
    }
    
    $file_type = $_FILES['file']['type'];
    if (!in_array($file_type, $allowed_types)) {
        $msg = $has_group ? 'Format neacceptat. Folosiți JPG, PNG, WebP sau GIF' : 'Format neacceptat. Folosiți JPG, PNG sau WebP (nu GIF)';
        wp_send_json_error($msg);
    }

    // Check file extension (only block GIF for users without group)
    $file_name = strtolower($_FILES['file']['name']);
    if (!$has_group && preg_match('/\.gif$/i', $file_name)) {
        wp_send_json_error('GIF nu este acceptat. Folosiți JPG, PNG sau WebP');
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $file = $_FILES['file'];
    
    // For GIF files, bypass image processing to preserve animation
    if (preg_match('/\.gif$/i', $file['name'])) {
        $upload_dir = wp_upload_dir();
        $filename = wp_unique_filename($upload_dir['path'], $file['name']);
        $filepath = $upload_dir['path'] . '/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $upload = [
                'file' => $filepath,
                'url' => $upload_dir['url'] . '/' . $filename,
                'type' => $file['type']
            ];
        } else {
            wp_send_json_error('Eroare la salvarea fișierului');
        }
    } else {
        $upload = wp_handle_upload($file, ['test_form' => false]);
    }
    
    if (isset($upload['error'])) wp_send_json_error($upload['error']);

    update_user_meta($user_id, 'profile_banner', $upload['url']);
    wp_send_json_success(['url' => $upload['url']]);
}

// Remove avatar handler
add_action('wp_ajax_mangayummy_remove_avatar', 'mangayummy_remove_avatar');
function mangayummy_remove_avatar() {
    if (!check_ajax_referer('ya_ajax_nonce', 'nonce', false)) {
        wp_send_json_error('Nonce invalid');
    }
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    $user_id = get_current_user_id();
    
    // Delete old file if exists
    $old_avatar = get_user_meta($user_id, 'profile_avatar', true);
    if ($old_avatar) {
        $upload_dir = wp_upload_dir();
        $old_file_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $old_avatar);
        if (file_exists($old_file_path)) {
            @unlink($old_file_path);
        }
    }
    
    delete_user_meta($user_id, 'profile_avatar');
    
    $default_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
    wp_send_json_success(['default_url' => $default_url]);
}

// Social user search
add_action('wp_ajax_mangayummy_social_user_search', 'mangayummy_social_user_search');
add_action('wp_ajax_nopriv_mangayummy_social_user_search', 'mangayummy_social_user_search');
// Dedicated function for mentions autocomplete (removed duplicate registration)

function mangayummy_social_user_search() {
    if (!isset($_POST['q'])) {
        wp_send_json([]);
    }

    global $wpdb;
    $search = sanitize_text_field($_POST['q']);
    
    // Prevent search for empty or very short queries (performance)
    if (strlen($search) < 2) {
        wp_send_json([]);
    }

    $users = $wpdb->get_results($wpdb->prepare("
        SELECT ID, user_login, display_name
        FROM {$wpdb->users}
        WHERE user_login LIKE %s
           OR display_name LIKE %s
        LIMIT 10
    ", "%$search%", "%$search%"));

    $results = [];

    foreach ($users as $user) {
        // Get custom avatar from user meta ONLY
        $avatar = get_user_meta($user->ID, 'mangayummy_avatar', true);

        // Fallback la default avatar (dynamic path for production)
        if (empty($avatar)) {
            $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }

        $results[] = [
            'id' => $user->ID,
            'name' => $user->display_name,
            'avatar' => esc_url($avatar),
            'level' => get_user_meta($user->ID, 'reader_level', true) ?: 1,
            'online' => get_user_meta($user->ID, 'is_online', true) ? true : false,
            'profile_url' => site_url('/users/' . $user->ID)
        ];
    }

    wp_send_json($results);
}

// New simplified user search returning HTML
add_action('wp_ajax_mangayummy_user_search', 'mangayummy_user_search');
add_action('wp_ajax_nopriv_mangayummy_user_search', 'mangayummy_user_search');

// ===== GET ALL GENRES =====
add_action('wp_ajax_mangayummy_get_all_genres', 'mangayummy_get_all_genres');
add_action('wp_ajax_nopriv_mangayummy_get_all_genres', 'mangayummy_get_all_genres');

add_action('wp_ajax_mangayummy_get_all_authors', 'mangayummy_get_all_authors');
add_action('wp_ajax_nopriv_mangayummy_get_all_authors', 'mangayummy_get_all_authors');

add_action('wp_ajax_mangayummy_get_all_artists', 'mangayummy_get_all_artists');
add_action('wp_ajax_nopriv_mangayummy_get_all_artists', 'mangayummy_get_all_artists');

function mangayummy_get_all_genres() {
    // Cache genres for 1 hour (rarely change)
    $cache_key = 'mangayummy_all_genres';
    $cached = get_transient($cache_key);
    
    if ($cached !== false) {
        wp_send_json($cached);
        return;
    }
    
    $genres = get_terms([
        'taxonomy' => 'genre',
        'hide_empty' => true, // Only show genres with manga
        'orderby' => 'name',
        'order' => 'ASC'
    ]);

    if (is_wp_error($genres)) {
        wp_send_json([]);
        return;
    }

    $result = [];
    foreach ($genres as $genre) {
        $result[] = [
            'id' => $genre->term_id,
            'name' => $genre->name,
            'slug' => $genre->slug,
            'count' => $genre->count
        ];
    }


    set_transient($cache_key, $result, HOUR_IN_SECONDS);
    wp_send_json($result);
}

function mangayummy_get_all_years() {
    global $wpdb;

    // Cache years for 1 hour
    $cache_key = 'mangayummy_all_years';
    $cached = get_transient($cache_key);
    
    if ($cached !== false) {
        wp_send_json($cached);
        return;
    }

    // Get all unique years from manga _release_year postmeta, sorted descending
    $query = $wpdb->prepare(
        "SELECT DISTINCT CAST(meta_value AS SIGNED) AS year
         FROM $wpdb->postmeta pm
         JOIN $wpdb->posts p ON pm.post_id = p.ID
         WHERE pm.meta_key = %s
         AND p.post_type = %s
         AND p.post_status = %s
         AND pm.meta_value IS NOT NULL
         AND pm.meta_value != ''
         ORDER BY year DESC",
        '_release_year',
        'manga',
        'publish'
    );

    $years = $wpdb->get_results($query);
    
    if (empty($years)) {
        wp_send_json([]);
        return;
    }

    $result = [];
    foreach ($years as $year_obj) {
        $year = (int)$year_obj->year;
        if ($year > 0) {
            $result[] = [
                'year' => $year,
                'label' => (string)$year
            ];
        }
    }

    set_transient($cache_key, $result, HOUR_IN_SECONDS);
    wp_send_json($result);
}

// Note: wp_ajax actions for genres registered above at line ~6636
add_action('wp_ajax_mangayummy_get_all_years', 'mangayummy_get_all_years');
add_action('wp_ajax_nopriv_mangayummy_get_all_years', 'mangayummy_get_all_years');

function mangayummy_get_all_authors() {
    // Cache authors for 1 hour
    $cache_key = 'mangayummy_all_authors';
    $cached = get_transient($cache_key);
    
    if ($cached !== false) {
        wp_send_json($cached);
        return;
    }
    
    $authors = get_terms([
        'taxonomy' => 'author',
        'hide_empty' => true,
        'orderby' => 'name',
        'order' => 'ASC'
    ]);

    if (is_wp_error($authors)) {
        wp_send_json([]);
        return;
    }

    $result = [];
    foreach ($authors as $author) {
        $result[] = [
            'id' => $author->term_id,
            'name' => $author->name,
            'slug' => $author->slug,
            'count' => $author->count
        ];
    }

    set_transient($cache_key, $result, HOUR_IN_SECONDS);
    wp_send_json($result);
}

function mangayummy_get_all_artists() {
    // Cache artists for 1 hour
    $cache_key = 'mangayummy_all_artists';
    $cached = get_transient($cache_key);
    
    if ($cached !== false) {
        wp_send_json($cached);
        return;
    }
    
    $artists = get_terms([
        'taxonomy' => 'artist',
        'hide_empty' => true,
        'orderby' => 'name',
        'order' => 'ASC'
    ]);

    if (is_wp_error($artists)) {
        wp_send_json([]);
        return;
    }

    $result = [];
    foreach ($artists as $artist) {
        $result[] = [
            'id' => $artist->term_id,
            'name' => $artist->name,
            'slug' => $artist->slug,
            'count' => $artist->count
        ];
    }

    set_transient($cache_key, $result, HOUR_IN_SECONDS);
    wp_send_json($result);
}

/**
 * AJAX Handler: Get filtered manga for search/filter pages
 * Accepts: author, artist, genre, sort POST parameters
 */
function mangayummy_get_filtered_manga() {
    $author = isset($_POST['author']) ? sanitize_text_field($_POST['author']) : '';
    $artist = isset($_POST['artist']) ? sanitize_text_field($_POST['artist']) : '';
    $genres_str = isset($_POST['genres']) ? sanitize_text_field($_POST['genres']) : '';
    $genres = !empty($genres_str) ? array_filter(array_map('trim', explode(',', $genres_str))) : [];
    $year = isset($_POST['year']) ? intval($_POST['year']) : 0;
    $sort = isset($_POST['sort']) ? sanitize_text_field($_POST['sort']) : '';
    $page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;

    // Cache key must be unique per combination of filters and page.
    $cache_version = intval(get_option('mangayummy_search_cache_version', 1));
    $cache_params = compact('author', 'artist', 'genres', 'year', 'sort', 'page', 'cache_version');
    $cache_key = 'mangayummy_search_' . md5(serialize($cache_params));
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        wp_send_json_success($cached);
        return;
    }

    $args = [
        'post_type' => 'manga',
        'posts_per_page' => 100,
        'paged' => $page,
        'post_status' => 'publish',
        'no_found_rows' => true, // OPTIMIZATION: Skip counting total rows
        'update_post_term_cache' => false, // OPTIMIZATION: Skip term cache
    ];

    // Build tax_query for author/artist/genre filtering
    $tax_query = [];

    if (!empty($author)) {
        $tax_query[] = [
            'taxonomy' => 'author',
            'field' => 'slug',
            'terms' => $author,
        ];
    }

    if (!empty($artist)) {
        $tax_query[] = [
            'taxonomy' => 'artist',
            'field' => 'slug',
            'terms' => $artist,
        ];
    }

    // Handle multiple genres with AND logic (all genres must match - intersection)
    // Each genre becomes a separate condition with AND
    if (!empty($genres)) {
        foreach ($genres as $genre_slug) {
            $tax_query[] = [
                'taxonomy' => 'genre',
                'field' => 'slug',
                'terms' => $genre_slug,
                'operator' => 'IN',  // This genre must match
            ];
        }
        // Make sure all genre conditions must be true
        $tax_query['relation'] = 'AND';
    }

    // Set relation to AND between different taxonomies (author AND artist AND genres)
    if (count($tax_query) > 1 && !isset($tax_query['relation'])) {
        $tax_query['relation'] = 'AND';
    }

    if (!empty($tax_query)) {
        $args['tax_query'] = $tax_query;
    }

    // Handle year filtering by post meta
    if ($year > 0) {
        $args['meta_query'] = [
            [
                'key' => '_release_year',
                'value' => $year,
                'type' => 'NUMERIC',
                'compare' => '='
            ]
        ];
    }

    // Handle sorting
    if (!empty($sort)) {
        if ($sort === 'date-desc') {
            $args['orderby'] = 'date';
            $args['order'] = 'DESC';
        } elseif ($sort === 'date-asc') {
            $args['orderby'] = 'date';
            $args['order'] = 'ASC';
        } elseif ($sort === 'title-asc') {
            $args['orderby'] = 'title';
            $args['order'] = 'ASC';
        } elseif ($sort === 'title-desc') {
            $args['orderby'] = 'title';
            $args['order'] = 'DESC';
        } else {
            // Default: sort by views
            $args['meta_key'] = 'manga_views_total';
            $args['orderby'] = 'meta_value_num';
            $args['order'] = 'DESC';
        }
    } else {
        // Default sorting by views
        $args['meta_key'] = 'manga_views_total';
        $args['orderby'] = 'meta_value_num';
        $args['order'] = 'DESC';
    }

    $query = new WP_Query($args);
    $manga_list = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $manga_id = get_the_ID();
            // OPTIMIZATION: Use manga-card size instead of full
            $image = get_the_post_thumbnail_url($manga_id, 'manga-card');
            if (!$image) {
                $image = get_the_post_thumbnail_url($manga_id, 'medium');
            }
            if (!$image) {
                $image = get_template_directory_uri() . '/assets/img/default-manga.jpg';
            }

            $manga_list[] = [
                'id' => $manga_id,
                'title' => get_the_title(),
                'url' => get_permalink(),
                'image' => $image,
            ];
        }
    }

    wp_reset_postdata();

    set_transient($cache_key, $manga_list, 5 * MINUTE_IN_SECONDS);
    wp_send_json_success($manga_list);
}
add_action('wp_ajax_mangayummy_get_filtered_manga', 'mangayummy_get_filtered_manga');
add_action('wp_ajax_nopriv_mangayummy_get_filtered_manga', 'mangayummy_get_filtered_manga');

// Invalidate cached search results when a manga is created/updated
function mangayummy_invalidate_search_cache() {
    $version = intval(get_option('mangayummy_search_cache_version', 1));
    update_option('mangayummy_search_cache_version', $version + 1);
}
add_action('save_post_manga', 'mangayummy_invalidate_search_cache');
add_action('transition_post_status', function($new_status, $old_status, $post) {
    if ($post->post_type !== 'manga') {
        return;
    }
    if ($new_status === 'publish' || $old_status === 'publish') {
        mangayummy_invalidate_search_cache();
    }
}, 10, 3);

function mangayummy_user_search() {
    if (!isset($_POST['query'])) {
        wp_die();
    }

    $search = sanitize_text_field($_POST['query']);

    $users = get_users([
        'search' => '*' . esc_attr($search) . '*',
        'search_columns' => ['user_login', 'display_name'],
        'number' => 10
    ]);

    if (empty($users)) {
        echo '<div class="social-empty">Nimic...</div>';
        wp_die();
    }

    foreach ($users as $user) {
        // Get profile avatar from user meta
        $avatar = get_user_meta($user->ID, 'profile_avatar', true);

        // Fallback to default avatar
        if (empty($avatar)) {
            $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }

        // Get user level
        $level = get_user_meta($user->ID, 'reader_level', true) ?: 1;
        
        // Get user status
        list($status, $status_text) = mangayummy_user_status($user->ID);

        echo '
        <div class="social-user" data-user-id="' . esc_attr($user->ID) . '">
            <img src="' . esc_url($avatar) . '" class="user-avatar" alt="' . esc_attr($user->display_name) . '">
            <div>
                <b>' . esc_html($user->display_name) . '</b>
                <span>Lv.' . intval($level) . '</span>
                <small class="user-status ' . esc_attr($status) . '">' . esc_html($status_text) . '</small>
            </div>
        </div>';
    }

    wp_die();
}

// Block profile hijacking for edit actions
function mangayummy_block_profile_hijack() {
    $target = intval($_POST['user_id'] ?? 0);
    
    // If no user_id specified in POST, allow the action
    // (Some handlers like settings don't require explicit user_id)
    if ($target === 0) return;
    
    $me = get_current_user_id();

    if ($target && $target !== $me) {
        wp_send_json_error(['error'=>'Forbidden']);
        exit;
    }
}

// Clean up offline users every hour
if (!wp_next_scheduled('mangayummy_cleanup_offline_users')) {
    wp_schedule_event(time(), 'hourly', 'mangayummy_cleanup_offline_users');
}
add_action('mangayummy_cleanup_offline_users', 'mangayummy_cleanup_offline_users');
}

/* ================================
   FRIEND SYSTEM + CHAT
   ================================ */

// Track last activity for online status
add_action('init', function () {
    if (is_user_logged_in()) {
        update_user_meta(get_current_user_id(), 'last_activity', current_time('timestamp'));
    }
});

// Get user online status
function mangayummy_user_status($user_id) {
    $last = get_user_meta($user_id, 'last_activity', true);
    if (!$last) {
        $last = get_user_meta($user_id, 'last_active', true);
    }

    if (!$last) {
        return ['offline', 'Niciodată conectat'];
    }

    $diff = current_time('timestamp') - intval($last);
    
    if ($diff < 60) { // 1 minute
        return ['online', 'Online acum'];
    }

    return [
        'offline',
        'Ultima dată online: ' . wp_date('d M Y H:i', intval($last))
    ];
}

// Invalidate chapter comment cache when new comment is posted
add_action('comment_post', function($comment_id, $comment_approved, $commentdata) {
    if (!$commentdata || empty($commentdata['comment_post_ID'])) {
        return;
    }

    $post_id = intval($commentdata['comment_post_ID']);
    if ($post_id <= 0) {
        return;
    }

    delete_transient('mangayummy_chapter_comments_' . $post_id);
}, 10, 3);

function mangayummy_clear_frontpage_recent_comments_cache() {
    delete_transient('mangayummy_recent_comments_frontpage_desktop');
    delete_transient('mangayummy_recent_comments_frontpage_tablet');
    delete_transient('mangayummy_recent_comments_frontpage_phone');
}

// Keep front-page recent comments in sync instantly after any comment change.
add_action('comment_post', 'mangayummy_clear_frontpage_recent_comments_cache', 20);
add_action('edit_comment', 'mangayummy_clear_frontpage_recent_comments_cache');
add_action('deleted_comment', 'mangayummy_clear_frontpage_recent_comments_cache');
add_action('trashed_comment', 'mangayummy_clear_frontpage_recent_comments_cache');
add_action('untrashed_comment', 'mangayummy_clear_frontpage_recent_comments_cache');
add_action('wp_set_comment_status', 'mangayummy_clear_frontpage_recent_comments_cache', 10, 2);

add_action('comment_post', 'mangayummy_send_discord_comment_notification_on_new_comment', 15, 3);
add_action('wp_set_comment_status', 'mangayummy_send_discord_comment_notification_on_status_change', 15, 2);

function mangayummy_send_discord_comment_notification_on_new_comment($comment_id, $comment_approved, $commentdata) {
    global $mangayummy_skip_discord_comment_notification;
    if (!empty($mangayummy_skip_discord_comment_notification)) {
        return;
    }

    if ((string) $comment_approved !== '1') {
        return;
    }

    if (!function_exists('mangayummy_sendDiscordCommentNotification')) {
        return;
    }

    if (get_comment_meta($comment_id, 'discord_comment_notification_sent', true)) {
        return;
    }

    if (mangayummy_sendDiscordCommentNotification($comment_id)) {
        add_comment_meta($comment_id, 'discord_comment_notification_sent', '1', true);
    }
}

function mangayummy_send_discord_comment_notification_on_status_change($comment_id, $status) {
    if ($status !== 'approve') {
        return;
    }

    if (!function_exists('mangayummy_sendDiscordCommentNotification')) {
        return;
    }

    if (get_comment_meta($comment_id, 'discord_comment_notification_sent', true)) {
        return;
    }

    if (mangayummy_sendDiscordCommentNotification($comment_id)) {
        add_comment_meta($comment_id, 'discord_comment_notification_sent', '1', true);
    }
}

// Get user group/role with badge styling
function mangayummy_get_user_group($user_id) {
    $group = get_user_meta($user_id, 'user_group', true);

    // Normalize the stored value so case/diacritics/spaces don't break the mapping
    $normalized = trim(strtolower((string) $group));
    $normalized = str_replace(['ă', 'â', 'î', 'ș', 'ț', 'ş', 'ţ'], ['a', 'a', 'i', 's', 't', 's', 't'], $normalized);
    $normalized = preg_replace('/[^a-z0-9_]+/', '_', $normalized);
    $normalized = trim($normalized, '_');

    $groups = [
        'owner' => ['label' => 'Proprietar', 'color' => 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)'],
        'fundator' => ['label' => 'Fondator', 'color' => 'linear-gradient(135deg, #ff9f43 0%, #e67e22 100%)'],
        'fondator' => ['label' => 'Fondator', 'color' => 'linear-gradient(135deg, #ff9f43 0%, #e67e22 100%)'],
        'designer' => ['label' => 'Designer', 'color' => 'linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%)'],
        'tester' => ['label' => 'Tester', 'color' => 'linear-gradient(135deg, #3498db 0%, #2980b9 100%)'],
        'editor' => ['label' => 'Editor', 'color' => 'linear-gradient(135deg, #f39c12 0%, #d68910 100%)'],
        'review_chief' => ['label' => 'Sef Recenzii', 'color' => 'linear-gradient(135deg, #2ecc71 0%, #27ae60 100%)'],
        'moderator' => ['label' => 'Moderator', 'color' => 'linear-gradient(135deg, #e67e22 0%, #d35400 100%)'],
        'discord_manager' => ['label' => 'Manager server discord', 'color' => 'linear-gradient(135deg, #8e44ad 0%, #7d3c98 100%)'],
    ];
    
    if (!$normalized || !isset($groups[$normalized])) {
        return null;
    }
    
    return $groups[$normalized];
}

// Get user level label in Romanian - returns "Level X"
function mangayummy_get_user_level_label($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    return 'Level ' . $level;
}

// ═══════════════════════════════════════════════════════════════════════════════
// AVATAR FRAME EFFECTS SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

// All available avatar frame effects with unlock requirements (every 100 levels)
function mangayummy_get_all_avatar_effects() {
    return [
        'none'       => ['name' => 'Fără Efect',           'unlock' => 1,    'class' => ''],
        'glow'       => ['name' => 'Strălucire Verde',     'unlock' => 100,  'class' => 'avatar-glow'],
        'fire'       => ['name' => 'Foc',                  'unlock' => 200,  'class' => 'avatar-fire'],
        'ice'        => ['name' => 'Gheață',               'unlock' => 300,  'class' => 'avatar-ice'],
        'lightning'  => ['name' => 'Fulger',               'unlock' => 400,  'class' => 'avatar-lightning'],
        'rainbow'    => ['name' => 'Curcubeu',             'unlock' => 500,  'class' => 'avatar-rainbow'],
        'shadow'     => ['name' => 'Umbră',                'unlock' => 600,  'class' => 'avatar-shadow'],
        'gold'       => ['name' => 'Auriu',                'unlock' => 700,  'class' => 'avatar-gold'],
        'plasma'     => ['name' => 'Plasmă',               'unlock' => 800,  'class' => 'avatar-plasma'],
        'cosmic'     => ['name' => 'Cosmic',               'unlock' => 900,  'class' => 'avatar-cosmic'],
    ];
}

// Get user's selected avatar effect class
function mangayummy_get_user_avatar_effect_class($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    $selected_effect = get_user_meta($user_id, 'avatar_effect_preference', true);
    $all_effects = mangayummy_get_all_avatar_effects();
    
    // If user has a manually selected effect and it's unlocked, use it
    if ($selected_effect && isset($all_effects[$selected_effect])) {
        if ($level >= $all_effects[$selected_effect]['unlock']) {
            return $all_effects[$selected_effect]['class'];
        }
    }
    
    // Default: return highest unlocked effect (auto-apply)
    $highest_class = '';
    foreach ($all_effects as $key => $effect) {
        if ($level >= $effect['unlock']) {
            $highest_class = $effect['class'];
        }
    }
    
    return $highest_class;
}

// AJAX handler to save avatar effect preference
add_action('wp_ajax_mangayummy_save_avatar_effect', 'mangayummy_save_avatar_effect_handler');
function mangayummy_save_avatar_effect_handler() {
    if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Eroare de securitate']);
    }
    
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii autentificat']);
    }
    
    $user_id = get_current_user_id();
    $effect = sanitize_text_field($_POST['effect'] ?? '');
    $all_effects = mangayummy_get_all_avatar_effects();
    
    // Validate effect exists
    if (!isset($all_effects[$effect])) {
        wp_send_json_error(['message' => 'Efect invalid']);
    }
    
    // Check if user has unlocked this effect
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    if ($level < $all_effects[$effect]['unlock']) {
        wp_send_json_error(['message' => 'Nu ai deblocat acest efect încă']);
    }
    
    // Save preference
    update_user_meta($user_id, 'avatar_effect_preference', $effect);
    
    wp_send_json_success([
        'message' => 'Efectul a fost salvat!',
        'effect' => $effect,
        'class' => $all_effects[$effect]['class']
    ]);
}

// ═══════════════════════════════════════════════════════════════════════════════
// LEVEL BADGE EFFECTS SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

// All available level effects with unlock requirements
function mangayummy_get_all_level_effects() {
    return [
        'default'    => ['name' => 'Default (Verde)',      'unlock' => 1,   'class' => ''],
        'uncommon'   => ['name' => 'Uncommon (Albastru)',  'unlock' => 50,  'class' => 'level-uncommon'],
        'rare'       => ['name' => 'Rare (Violet)',        'unlock' => 100, 'class' => 'level-rare'],
        'epic'       => ['name' => 'Epic (Portocaliu)',    'unlock' => 150, 'class' => 'level-epic'],
        'legendary'  => ['name' => 'Legendary (Rainbow)',  'unlock' => 200, 'class' => 'level-legendary'],
        'cosmic'     => ['name' => 'Cosmic (Nebula)',      'unlock' => 250, 'class' => 'level-cosmic'],
        'phoenix'    => ['name' => 'Phoenix (Foc)',        'unlock' => 300, 'class' => 'level-phoenix'],
        'frost'      => ['name' => 'Frost (Gheață)',       'unlock' => 350, 'class' => 'level-frost'],
        'shadow'     => ['name' => 'Shadow (Întuneric)',   'unlock' => 400, 'class' => 'level-shadow'],
        'divine'     => ['name' => 'Divine (Auriu)',       'unlock' => 450, 'class' => 'level-divine'],
        'plasma'     => ['name' => 'Plasma (Electric)',    'unlock' => 500, 'class' => 'level-plasma'],
        'nature'     => ['name' => 'Nature (Verde Neon)',  'unlock' => 550, 'class' => 'level-nature'],
        'blood'      => ['name' => 'Blood (Roșu Intens)',  'unlock' => 600, 'class' => 'level-blood'],
        'crystal'    => ['name' => 'Crystal (Prismatic)',  'unlock' => 650, 'class' => 'level-crystal'],
        'void'       => ['name' => 'Void (Negru)',         'unlock' => 700, 'class' => 'level-void'],
        'celestial'  => ['name' => 'Celestial (Roz)',      'unlock' => 750, 'class' => 'level-celestial'],
        'inferno'    => ['name' => 'Inferno (Lavă)',       'unlock' => 800, 'class' => 'level-inferno'],
        'arctic'     => ['name' => 'Arctic (Alb-Albastru)','unlock' => 850, 'class' => 'level-arctic'],
        'omega'      => ['name' => 'Omega (Ultra)',        'unlock' => 900, 'class' => 'level-omega'],
        'transcend'  => ['name' => 'Transcendent (Final)', 'unlock' => 950, 'class' => 'level-transcend'],
    ];
}

// Get unlocked effects for a user based on their level
function mangayummy_get_unlocked_effects($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    $all_effects = mangayummy_get_all_level_effects();
    $unlocked = [];
    
    foreach ($all_effects as $key => $effect) {
        if ($level >= $effect['unlock']) {
            $unlocked[$key] = $effect;
        }
    }
    
    return $unlocked;
}

// Get CSS tier class based on user level and preference
function mangayummy_get_user_level_tier_class($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    $selected_effect = get_user_meta($user_id, 'level_effect_preference', true);
    $all_effects = mangayummy_get_all_level_effects();
    
    // If user has a manually selected effect and it's unlocked, use it
    if ($selected_effect && isset($all_effects[$selected_effect])) {
        if ($level >= $all_effects[$selected_effect]['unlock']) {
            return $all_effects[$selected_effect]['class'];
        }
    }
    
    // Default: return highest unlocked effect (auto-apply)
    $highest_class = '';
    foreach ($all_effects as $key => $effect) {
        if ($level >= $effect['unlock']) {
            $highest_class = $effect['class'];
        }
    }

    $tier_class = $highest_class;

    return $tier_class;
}

// Create reading history table if it does not exist
function mangayummy_init_reading_history_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'reading_history';
    $charset = $wpdb->get_charset_collate();

    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $sql = "CREATE TABLE $table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            manga_id BIGINT(20) UNSIGNED NOT NULL,
            chapter_id BIGINT(20) UNSIGNED NOT NULL,
            read_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY manga_id (manga_id),
            KEY chapter_id (chapter_id),
            KEY read_at (read_at)
        ) $charset";
        dbDelta($sql);
    }
}
add_action('init', 'mangayummy_init_reading_history_table');

// Log chapter read event (one event per user+chapter+day)
function mangayummy_log_chapter_reading_event($user_id, $manga_id, $chapter_id) {
    if (!$user_id || !$manga_id || !$chapter_id) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'reading_history';
    $today = current_time('Y-m-d');

    // Avoid duplicate event for same chapter on same date
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE user_id = %d AND chapter_id = %d AND DATE(read_at) = %s",
        $user_id, $chapter_id, $today
    ));

    if ($exists) {
        return;
    }

    $wpdb->insert(
        $table,
        [
            'user_id' => $user_id,
            'manga_id' => $manga_id,
            'chapter_id' => $chapter_id,
            'read_at' => current_time('mysql'),
        ],
        ['%d', '%d', '%d', '%s']
    );
}

// Get daily reading activity for the last 12 weeks (84 days)
function mangayummy_get_reading_activity($user_id) {
    $user_id = intval($user_id);
    if ($user_id <= 0) {
        return [];
    }

    global $wpdb;
    $table = $wpdb->prefix . 'reading_history';

    // Ensure table exists and fail gracefully
    $activity_counts = [];
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) === $table) {
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(read_at) as read_date, COUNT(*) as read_count 
             FROM $table 
             WHERE user_id = %d 
               AND read_at >= DATE_SUB(CURDATE(), INTERVAL 83 DAY)
             GROUP BY DATE(read_at)
             ORDER BY DATE(read_at) ASC",
            $user_id
        ));

        foreach ($results as $row) {
            $activity_counts[$row->read_date] = intval($row->read_count);
        }
    }

    $activity = [];
    $today = new DateTime('today');

    for ($d = 83; $d >= 0; $d--) {
        $day = clone $today;
        $day->modify("-{$d} days");
        $date_key = $day->format('Y-m-d');

        $count = isset($activity_counts[$date_key]) ? intval($activity_counts[$date_key]) : 0;
        $class = '';

        if ($count > 0) {
            $class = ($count >= 3) ? 'active-high' : 'active';
        }

        $activity[$date_key] = [
            'count' => $count,
            'class' => $class,
        ];
    }

    return $activity;
}

// Get the active effect key (for settings display)
function mangayummy_get_active_level_effect_key($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    $selected_effect = get_user_meta($user_id, 'level_effect_preference', true);
    $all_effects = mangayummy_get_all_level_effects();
    
    // If user has a manually selected effect and it's unlocked, return it
    if ($selected_effect && isset($all_effects[$selected_effect])) {
        if ($level >= $all_effects[$selected_effect]['unlock']) {
            return $selected_effect;
        }
    }
    
    // Default: return highest unlocked effect key
    $highest_key = 'default';
    foreach ($all_effects as $key => $effect) {
        if ($level >= $effect['unlock']) {
            $highest_key = $key;
        }
    }
    
    return $highest_key;
}

// Get the active avatar effect key (for settings display)
function mangayummy_get_active_avatar_effect_key($user_id) {
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    $selected_effect = get_user_meta($user_id, 'avatar_effect_preference', true);
    $all_effects = mangayummy_get_all_avatar_effects();
    
    // If user has a manually selected effect and it's unlocked, return it
    if ($selected_effect && isset($all_effects[$selected_effect])) {
        if ($level >= $all_effects[$selected_effect]['unlock']) {
            return $selected_effect;
        }
    }
    
    // Default: return highest unlocked effect key
    $highest_key = 'none';
    foreach ($all_effects as $key => $effect) {
        if ($level >= $effect['unlock']) {
            $highest_key = $key;
        }
    }
    
    return $highest_key;
}

// AJAX handler to save level effect preference
add_action('wp_ajax_mangayummy_save_level_effect', 'mangayummy_save_level_effect_handler');
function mangayummy_save_level_effect_handler() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Eroare de securitate']);
    }
    
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii autentificat']);
    }

    $user_id = get_current_user_id();
    $effect = sanitize_text_field($_POST['effect'] ?? '');
    $all_effects = mangayummy_get_all_level_effects();

    // Validate effect exists
    if (!isset($all_effects[$effect])) {
        wp_send_json_error(['message' => 'Efect invalid']);
    }

    // Check if user has unlocked this effect
    $level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
    if ($level < $all_effects[$effect]['unlock']) {
        wp_send_json_error(['message' => 'Nu ai deblocat acest efect încă']);
    }

    // Save preference
    update_user_meta($user_id, 'level_effect_preference', $effect);

    wp_send_json_success([
        'message' => 'Efectul a fost salvat!',
        'effect' => $effect,
        'class' => $all_effects[$effect]['class']
    ]);
}

// AJAX handler for Despre Contact form
add_action('wp_ajax_nopriv_mangayummy_send_contact_form', 'mangayummy_send_contact_form_handler');
add_action('wp_ajax_mangayummy_send_contact_form', 'mangayummy_send_contact_form_handler');
function mangayummy_send_contact_form_handler() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Eroare de securitate - nonce invalid.']);
    }

    $name = sanitize_text_field($_POST['contact_name'] ?? '');
    $email = sanitize_email($_POST['contact_email'] ?? '');
    $message = sanitize_textarea_field($_POST['contact_message'] ?? '');

    if (!$name || !$email || !$message) {
        wp_send_json_error(['message' => 'Fill in all fields.']);
    }

    if (!is_email($email)) {
        wp_send_json_error(['message' => 'Adresa de email nu este validă.']);
    }

    $to = get_bloginfo('admin_email');
    $subject = 'Mesaj Contact MangaYummy: ' . $name;
    $body = "Nume: $name\nEmail: $email\n\nMesaj:\n$message\n";
    $headers = ['Content-Type: text/plain; charset=UTF-8', 'From: MangaYummy <' . sanitize_email($to) . '>'];

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(['message' => 'Mesaj trimis! Vom reveni în scurt timp.']);
    } else {
        wp_send_json_error(['message' => 'Nu am putut trimite mesajul. Încearcă mai târziu.']);
    }
}

// Check if two users are friends
function mangayummy_are_friends($user_id_1, $user_id_2) {
    if (!$user_id_1 || !$user_id_2) {
        return false;
    }
    
    $friends = get_user_meta($user_id_1, 'friends', true);
    if (!is_array($friends)) {
        return false;
    }
    
    return in_array(intval($user_id_2), $friends);
}

// Add friend AJAX - Returns status codes for UI handling
add_action('wp_ajax_mangayummy_add_friend', 'mangayummy_add_friend');
add_action('wp_ajax_nopriv_mangayummy_add_friend', 'mangayummy_add_friend');
function mangayummy_add_friend() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['status' => 'not_logged_in']);
    }

    $current = get_current_user_id();
    $target = intval($_POST['user_id'] ?? 0);

    if (!$target || $current === $target) {
        wp_send_json_error(['status' => 'invalid']);
    }

    // Check if already friends
    $my_friends = get_user_meta($current, 'friends', true);
    if (!is_array($my_friends)) {
        $my_friends = [];
    }
    if (in_array($target, $my_friends)) {
        wp_send_json_success(['status' => 'already_friend']);
    }

    // Get friend requests for target user
    $requests = get_user_meta($target, 'friend_requests', true);
    if (!is_array($requests)) {
        $requests = [];
    }

    // Check if already requested
    if (in_array($current, $requests)) {
        wp_send_json_success(['status' => 'already_requested']);
    }

    // Add to friend requests
    $requests[] = $current;
    update_user_meta($target, 'friend_requests', $requests);

    // Store on sender's side for UI state
    $sent_requests = get_user_meta($current, 'friend_requests_sent', true);
    if (!is_array($sent_requests)) {
        $sent_requests = [];
    }
    if (!in_array($target, $sent_requests)) {
        $sent_requests[] = $target;
        update_user_meta($current, 'friend_requests_sent', $sent_requests);
    }

    // Create notification message (prefix [NOTIF] to distinguish from direct chat)
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'private_messages',
        [
            'sender_id'   => $current, // Keep real user ID for avatar/name display
            'receiver_id' => $target,
            'message'     => '[NOTIF]ți-a trimis o cerere de prietenie',
            'is_read'     => 0,
            'created_at'  => current_time('mysql')
        ],
        ['%d', '%d', '%s', '%d', '%s']
    );

    // Send email notification to target user about friend request
    $target_user = get_user_by('ID', $target);
    $sender_user = get_user_by('ID', $current);
    if ($target_user && $sender_user) {
        $to = $target_user->user_email;
        $subject = __('Ai o cerere nouă de prietenie', 'mangayummy');
        $message = sprintf(
            /* translators: %1$s = sender name, %2$s = link to friends page */
            __('%1$s ți-a trimis o cerere de prietenie. Poți vedea și gestiona cererile aici: %2$s', 'mangayummy'),
            $sender_user->display_name,
            home_url('/messages#cereri-prietenie')
        );
        $headers = ['Content-Type: text/html; charset=UTF-8'];

        wp_mail($to, $subject, nl2br(esc_html($message)), $headers);
    }

    wp_send_json_success(['status' => 'requested']);
}

// Accept friend request
add_action('wp_ajax_mangayummy_accept_friend', 'mangayummy_accept_friend');
function mangayummy_accept_friend() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error();
    }

    $current = get_current_user_id();
    $requester = intval($_POST['user_id'] ?? 0);

    // Add to current user's friends
    $my_friends = get_user_meta($current, 'friends', true);
    if (!is_array($my_friends)) {
        $my_friends = [];
    }
    if (!in_array($requester, $my_friends)) {
        $my_friends[] = $requester;
        update_user_meta($current, 'friends', $my_friends);
    }

    // Add current user to requester's friends
    $their_friends = get_user_meta($requester, 'friends', true);
    if (!is_array($their_friends)) {
        $their_friends = [];
    }
    if (!in_array($current, $their_friends)) {
        $their_friends[] = $current;
        update_user_meta($requester, 'friends', $their_friends);
    }

    // Remove from requests (current user's incoming requests)
    $requests = get_user_meta($current, 'friend_requests', true);
    if (is_array($requests)) {
        $requests = array_filter($requests, fn($id) => $id !== $requester);
        update_user_meta($current, 'friend_requests', array_values($requests));
    }

    // Remove from requester's sent requests
    $sent_requests = get_user_meta($requester, 'friend_requests_sent', true);
    if (is_array($sent_requests)) {
        $sent_requests = array_filter($sent_requests, fn($id) => $id !== $current);
        update_user_meta($requester, 'friend_requests_sent', array_values($sent_requests));
    }

    // Also remove current user's request from requester's friend_requests (in case requester also had request from current user)
    $requester_requests = get_user_meta($requester, 'friend_requests', true);
    if (is_array($requester_requests)) {
        $requester_requests = array_filter($requester_requests, fn($id) => $id !== $current);
        update_user_meta($requester, 'friend_requests', array_values($requester_requests));
    }

    // Also remove requester from current user's sent requests (in case current user had sent request first)
    $my_sent_requests = get_user_meta($current, 'friend_requests_sent', true);
    if (is_array($my_sent_requests)) {
        $my_sent_requests = array_filter($my_sent_requests, fn($id) => $id !== $requester);
        update_user_meta($current, 'friend_requests_sent', array_values($my_sent_requests));
    }

    // Log acceptance in current user's request history
    $friend_request_log = get_user_meta($current, 'friend_requests_log', true);
    if (!is_array($friend_request_log)) {
        $friend_request_log = [];
    }
    $friend_request_log[] = [
        'user_id' => $requester,
        'status' => 'accepted',
        'timestamp' => current_time('mysql'),
    ];
    update_user_meta($current, 'friend_requests_log', $friend_request_log);

    wp_send_json_success();
}

// Reject friend request
add_action('wp_ajax_mangayummy_reject_friend', 'mangayummy_reject_friend');
function mangayummy_reject_friend() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error();
    }

    $current = get_current_user_id();
    $requester = intval($_POST['user_id'] ?? 0);

    // Remove from requests
    $requests = get_user_meta($current, 'friend_requests', true);
    if (is_array($requests)) {
        $requests = array_filter($requests, fn($id) => $id !== $requester);
        update_user_meta($current, 'friend_requests', array_values($requests));
    }

    // Remove from requester's sent requests
    $sent_requests = get_user_meta($requester, 'friend_requests_sent', true);
    if (is_array($sent_requests)) {
        $sent_requests = array_filter($sent_requests, fn($id) => $id !== $current);
        update_user_meta($requester, 'friend_requests_sent', array_values($sent_requests));
    }

    // Log rejection in current user's request history
    $friend_request_log = get_user_meta($current, 'friend_requests_log', true);
    if (!is_array($friend_request_log)) {
        $friend_request_log = [];
    }
    $friend_request_log[] = [
        'user_id' => $requester,
        'status' => 'rejected',
        'timestamp' => current_time('mysql'),
    ];
    update_user_meta($current, 'friend_requests_log', $friend_request_log);

    wp_send_json_success();
}

// Delete friend
add_action('wp_ajax_mangayummy_delete_friend', 'mangayummy_delete_friend');
function mangayummy_delete_friend() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['status' => 'not_logged_in']);
    }

    $current = get_current_user_id();
    $friend_id = intval($_POST['user_id'] ?? 0);

    if (!$friend_id || $current === $friend_id) {
        wp_send_json_error(['status' => 'invalid']);
    }

    // Remove from current user's friends
    $my_friends = get_user_meta($current, 'friends', true);
    if (is_array($my_friends)) {
        $my_friends = array_filter($my_friends, fn($id) => $id !== $friend_id);
        update_user_meta($current, 'friends', array_values($my_friends));
    }

    // Remove current user from friend's friends (mutual)
    $their_friends = get_user_meta($friend_id, 'friends', true);
    if (is_array($their_friends)) {
        $their_friends = array_filter($their_friends, fn($id) => $id !== $current);
        update_user_meta($friend_id, 'friends', array_values($their_friends));
    }

    wp_send_json_success(['status' => 'deleted']);
}

// Send message AJAX
add_action('wp_ajax_mangayummy_send_message', 'mangayummy_send_message');
function mangayummy_send_message() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii autentificat']);
    }

    global $wpdb;
    
    $sender = get_current_user_id();
    $receiver = intval($_POST['to'] ?? 0);
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($message) || $receiver <= 0) {
        wp_send_json_error(['message' => 'Date incomplete']);
    }
    
    // Verifică dacă sunt prieteni
    if (!mangayummy_are_friends($sender, $receiver)) {
        wp_send_json_error(['message' => 'Trebuie să fii prieten ca să trimiți mesaje']);
    }

    $result = $wpdb->insert(
        $wpdb->prefix . 'private_messages',
        [
            'sender_id' => $sender,
            'receiver_id' => $receiver,
            'message' => $message,
            'is_read' => 0,
            'created_at' => current_time('mysql')
        ],
        ['%d', '%d', '%s', '%d', '%s']
    );

    if ($result) {
        wp_send_json_success(['id' => $wpdb->insert_id]);
    } else {
        wp_send_json_error(['message' => 'Eroare la salvare']);
    }
}

// Get messages AJAX
add_action('wp_ajax_mangayummy_get_messages', 'mangayummy_get_messages');
function mangayummy_get_messages() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json([]);
        return;
    }

    global $wpdb;

    $me = get_current_user_id();
    $user_id = intval($_POST['user_id'] ?? 0);
    $limit = max(1, min(100, intval($_POST['limit'] ?? 50)));
    $offset = max(0, intval($_POST['offset'] ?? 0));
    $last_id = intval($_POST['last_id'] ?? 0);

    if ($user_id <= 0) {
        wp_send_json([]);
        return;
    }

    $table = $wpdb->prefix . 'private_messages';

    // Build WHERE clause for filtering
    $where_clause = "((sender_id = %d AND receiver_id = %d) OR (sender_id = %d AND receiver_id = %d))
                     AND message NOT LIKE '[NOTIF%%'";
    $where_params = [$me, $user_id, $user_id, $me];

    // If last_id is provided, get messages newer than this ID (for polling)
    if ($last_id > 0) {
        $where_clause .= " AND id > %d";
        $where_params[] = $last_id;
        $limit = 50; // Override limit for polling
        $offset = 0; // No offset for polling
    }

    // Get messages with pagination support
    $messages = $wpdb->get_results($wpdb->prepare(
        "SELECT id, sender_id, receiver_id, message, is_read, created_at
         FROM {$table}
         WHERE {$where_clause}
         ORDER BY created_at DESC
         LIMIT %d OFFSET %d",
        array_merge($where_params, [$limit, $offset])
    ));

    // Reverse to get chronological order (newest first, then reverse)
    $messages = array_reverse($messages);

    // Mark received messages as read (only for recent messages or polling)
    if ($offset === 0 || $last_id > 0) {
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET is_read = 1 WHERE sender_id = %d AND receiver_id = %d AND is_read = 0",
            $user_id, $me
        ));
    }

    // Enrich messages with sender names and avatars
    $enriched_messages = [];
    foreach ($messages as $msg) {
        $sender = get_user_by('ID', $msg->sender_id);
        $avatar = get_user_meta($msg->sender_id, 'profile_avatar', true);

        $enriched_messages[] = [
            'id' => $msg->id,
            'sender' => $msg->sender_id,
            'receiver' => $msg->receiver_id,
            'message' => $msg->message,
            'is_read' => $msg->is_read,
            'created_at' => $msg->created_at,
            'sender_name' => $sender ? $sender->display_name : 'User',
            'avatar' => $avatar ?: get_template_directory_uri() . '/assets/img/default-avatar.png'
        ];
    }

    wp_send_json($enriched_messages);
}

// Get user avatar AJAX
add_action('wp_ajax_mangayummy_get_user_avatar', 'mangayummy_get_user_avatar');
function mangayummy_get_user_avatar() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in']);
        return;
    }

    $user_id = intval($_POST['user_id'] ?? 0);
    if ($user_id <= 0) {
        wp_send_json_error(['message' => 'Invalid user ID']);
        return;
    }

    $avatar = get_user_meta($user_id, 'profile_avatar', true);
    $avatar_url = $avatar ?: get_template_directory_uri() . '/assets/img/default-avatar.png';

    wp_send_json_success(['avatar' => $avatar_url]);
}

// Get GIFs from GIPHY AJAX
add_action('wp_ajax_mangayummy_get_gifs', 'mangayummy_get_gifs');

/**
 * Resolve the configured GIPHY API key.
 */
function mangayummy_get_giphy_api_key() {
    // Resolution order:
    // 1) wp-config.php constant MANGAYUMMY_GIPHY_API_KEY
    // 2) environment variable MANGAYUMMY_GIPHY_API_KEY / GIPHY_API_KEY
    // 3) WordPress option mangayummy_giphy_api_key
    $api_key = '';

    if (defined('MANGAYUMMY_GIPHY_API_KEY') && MANGAYUMMY_GIPHY_API_KEY) {
        $api_key = MANGAYUMMY_GIPHY_API_KEY;
    }
    if (empty($api_key)) {
        $api_key = getenv('MANGAYUMMY_GIPHY_API_KEY') ?: getenv('GIPHY_API_KEY');
    }
    if (empty($api_key)) {
        $api_key = get_option('mangayummy_giphy_api_key', '');
    }

    return trim((string) $api_key);
}

function mangayummy_has_giphy_api_key() {
    return mangayummy_get_giphy_api_key() !== '';
}

function mangayummy_get_gifs() {
    // Some cached pages can carry stale nonce values; allow logged-in users to continue.
    if (!check_ajax_referer('ya_ajax_nonce', 'nonce', false) && !is_user_logged_in()) {
        wp_send_json_error(['message' => 'Security error']);
        return;
    }


    if (!is_user_logged_in()) {
        mangayummy_debug_log('GIF AJAX: User not logged in');
        wp_send_json_error(['message' => 'Not logged in']);
        return;
    }

    $query = sanitize_text_field($_POST['query'] ?? '');
    $type = sanitize_text_field($_POST['type'] ?? 'featured'); // 'featured' or 'search'

    mangayummy_debug_log("GIF AJAX: type=$type, query=$query");

    $api_key = mangayummy_get_giphy_api_key();

    if (empty($api_key)) {
        wp_send_json_error(['message' => 'GIF service not configured']);
        return;
    }

    if ($type === 'search' && !empty($query)) {
        $url = "https://api.giphy.com/v1/gifs/search?api_key={$api_key}&q=" . urlencode($query) . "&limit=20&rating=g";
    } else {
        $url = "https://api.giphy.com/v1/gifs/trending?api_key={$api_key}&limit=20&rating=g";
    }

    mangayummy_debug_log("GIF AJAX: API URL: $url");

    // Make the API request server-side to avoid CSP issues
    $response = wp_remote_get($url, array(
        'timeout' => 10,
        'headers' => array(
            'User-Agent' => 'MangaYummy/1.0'
        )
    ));

    if (is_wp_error($response)) {
        mangayummy_debug_log('GIF AJAX: API request failed: ' . $response->get_error_message());
        wp_send_json_error(['message' => 'Failed to fetch GIFs: ' . $response->get_error_message()]);
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    mangayummy_debug_log('GIF AJAX: API response status: ' . wp_remote_retrieve_response_code($response));
    mangayummy_debug_log('GIF AJAX: API response body length: ' . strlen($body));

    if (!$data || !isset($data['data'])) {
        mangayummy_debug_log('GIF AJAX: Invalid API response: ' . substr($body, 0, 500));
        wp_send_json_error(['message' => 'Invalid API response']);
        return;
    }

    // Process and return GIF data
    $gifs = array();
    foreach ($data['data'] as $gif) {
        $gifs[] = array(
            'id' => $gif['id'],
            'title' => $gif['title'] ?? '',
            'url' => $gif['images']['original']['url'],
            'preview' => $gif['images']['fixed_width_small']['url']
        );
    }

    mangayummy_debug_log('GIF AJAX: Returning ' . count($gifs) . ' GIFs');
    wp_send_json_success(['gifs' => $gifs]);
}

/* ================================
   MANGAYUMMY – ADMIN MENU & PAGE
   ================================ */

add_action('admin_menu', 'mangayummy_add_admin_menu');
function mangayummy_add_admin_menu() {
    // ===== TOP-LEVEL: MANGA TOOLS =====
    add_menu_page(
        'Manga Tools',
        'Manga Tools',
        'manage_options',
        'mangayummy-tools',
        'mangayummy_render_media_manager_page',
        'dashicons-admin-tools',
        62
    );

    add_submenu_page(
        'mangayummy-tools',
        'Media Manager - Convert & Manage Images',
        'Media Manager',
        'manage_options',
        'mangayummy-media-manager',
        'mangayummy_render_media_manager_page'
    );

    add_submenu_page(
        'mangayummy-tools',
        'WebP Media Converter',
        'Media Converter',
        'manage_options',
        'mangayummy-webp-converter',
        'mangayummy_render_media_converter_page'
    );

    add_submenu_page(
        'mangayummy-tools',
        'Delete Manga + Associated Chapters',
        'Delete Manga + Chapters',
        'manage_options',
        'mangayummy-delete-manga-with-chapters',
        'mangayummy_render_delete_manga_with_chapters_page'
    );

    // WordPress does not support nested submenus. We provide a Maintenance hub + items under Manga Tools.
    add_submenu_page(
        'mangayummy-tools',
        'Maintenance',
        'Maintenance',
        'manage_options',
        'mangayummy-maintenance',
        'mangayummy_render_maintenance_hub_page'
    );

    add_submenu_page(
        'mangayummy-tools',
        'Recalculate Bookmark Counts',
        'Maintenance: Recalculate Bookmarks',
        'manage_options',
        'recalculate-bookmarks',
        'mangayummy_recalculate_bookmarks_page'
    );

    add_submenu_page(
        'mangayummy-tools',
        'Migrate Translator Groups',
        'Maintenance: Migrate Groups',
        'manage_options',
        'mangayummy-migrate-groups',
        'mangayummy_render_migrate_groups_page'
    );

    // ===== TOP-LEVEL: ADMINISTRATION =====
    add_menu_page(
        'Administration',
        'Administration',
        'manage_options',
        'mangayummy-administration',
        'mangayummy_render_blocked_ips_page',
        'dashicons-admin-users',
        63
    );

    add_submenu_page(
        'mangayummy-administration',
        'Blocked IPs',
        'Blocked IPs',
        'manage_options',
        'mangayummy-administration',
        'mangayummy_render_blocked_ips_page'
    );

    add_submenu_page(
        'mangayummy-administration',
        'Manage User Groups',
        'User Groups',
        'manage_options',
        'mangayummy-user-groups',
        'mangayummy_render_user_groups_page'
    );

    add_submenu_page(
        'mangayummy-administration',
        'Cleanup Unverified Accounts',
        'Unverified Accounts',
        'manage_options',
        'mangayummy-unverified-accounts',
        'mangayummy_render_unverified_accounts_page'
    );

    add_submenu_page(
        'mangayummy-administration',
        'Reported Comments',
        'Reported Comments',
        'moderate_comments',
        'reported-comments',
        'mangayummy_reported_comments_page'
    );

    // ===== READER MANAGEMENT UNDER MANGA MANAGER =====
    add_submenu_page(
        'mangayummy-manga-manager',
        'Reset Reader Preferences',
        'Reset Reader Prefs',
        'manage_options',
        'ya-reset-reader-prefs',
        'mangayummy_ya_render_reset_prefs_page'
    );

    add_submenu_page(
        'mangayummy-manga-manager',
        'Adjust Manga View Counts',
        'Adjust Manga Views',
        'manage_options',
        'ya-adjust-manga-views',
        'mangayummy_ya_render_adjust_manga_views_page'
    );
}

function mangayummy_render_maintenance_hub_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    echo '<div class="wrap">';
    echo '<h1>Maintenance</h1>';
    echo '<p>Run one-time maintenance utilities from this section:</p>';
    echo '<ul>';
    echo '<li><a href="' . esc_url(admin_url('admin.php?page=recalculate-bookmarks')) . '">Recalculate Bookmarks</a></li>';
    echo '<li><a href="' . esc_url(admin_url('admin.php?page=mangayummy-migrate-groups')) . '">Migrate Groups</a></li>';
    echo '</ul>';
    echo '</div>';
}

// Keep old WebP converter URLs working after consolidation into Media Manager.
add_action('admin_init', function() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    $legacy_webp_pages = array(
        'tools-webp-convert',
        'mangayummy-webp-converter',
        'mangayummy-webp-convert',
    );

    if (!in_array($page, $legacy_webp_pages, true)) {
        return;
    }

    $target_url = add_query_arg(
        array(
            'page' => 'mangayummy-media-manager',
            'tool' => 'webp-converter',
        ),
        admin_url('admin.php')
    );

    wp_safe_redirect($target_url, 301);
    exit;
});

// ===== CONSOLIDATED MEDIA MANAGER PAGE =====
// Combines: Fix Profile Images (WebP) and WebP Converter
function mangayummy_render_media_manager_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    // Determine which tool to show based on $_GET parameter
    $tool = isset($_GET['tool']) ? sanitize_text_field($_GET['tool']) : 'profile-images';

    ?>
    <div class="wrap">
        <h1>📸 Media Manager</h1>
        <p style="font-size: 14px; color: #666;">Consolidation of image conversion and management tools.</p>
        
        <nav class="nav-tab-wrapper" style="margin-bottom: 20px;">
            <a href="?page=mangayummy-media-manager&tool=profile-images" class="nav-tab <?php echo ($tool === 'profile-images' ? 'nav-tab-active' : ''); ?>">
                Fix Profile Images (WebP)
            </a>
            <a href="?page=mangayummy-media-manager&tool=webp-converter" class="nav-tab <?php echo ($tool === 'webp-converter' ? 'nav-tab-active' : ''); ?>">
                WebP Converter
            </a>
        </nav>

        <div style="background: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 4px;">
            <?php
            switch ($tool) {
                case 'webp-converter':
                    mangayummy_render_webp_converter_page();
                    break;
                case 'profile-images':
                default:
                    mangayummy_render_fix_profile_images_page();
                    break;
            }
            ?>
        </div>
    </div>
    <?php
}

function mangayummy_render_media_converter_page() {
    $_GET['tool'] = 'webp-converter';
    mangayummy_render_media_manager_page();
}

// Render admin page
function mangayummy_render_user_groups_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    $groups = mangayummy_get_available_groups();
    $users = get_users(['orderby' => 'user_login']);
    ?>
    <div class="wrap">
        <h1>Manage User Groups</h1>
        
        <style>
            .users-groups-table {
                width: 100%;
                border-collapse: collapse;
                background: #fff;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .users-groups-table th,
            .users-groups-table td {
                padding: 12px;
                border-bottom: 1px solid #e0e0e0;
                text-align: left;
            }
            .users-groups-table th {
                background: #f5f5f5;
                font-weight: 600;
                color: #333;
            }
            .users-groups-table tr:hover {
                background: #fafafa;
            }
            .group-select {
                padding: 6px 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                font-size: 14px;
            }
            .group-badge {
                display: inline-block;
                padding: 4px 12px;
                border-radius: 12px;
                color: #fff;
                font-size: 12px;
                font-weight: 600;
                text-transform: uppercase;
            }
            .save-group-btn {
                padding: 6px 12px;
                background: #13667a;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-weight: 600;
                transition: all 0.2s;
            }
            .save-group-btn:hover {
                background: #02a044;
                transform: translateY(-1px);
            }
            .save-group-btn:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }
            .user-avatar {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                
                margin-right: 8px;
                vertical-align: middle;
            }
            .no-group {
                color: #999;
                font-style: italic;
            }
        </style>

        <table class="users-groups-table">
            <thead>
                <tr>
                    <th style="width: 40%;">User</th>
                    <th style="width: 30%;">Current Group</th>
                    <th style="width: 30%;">Assign Group</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): 
                    $current_group = get_user_meta($user->ID, 'user_group', true);
                    $group_info = $current_group && isset($groups[$current_group]) ? $groups[$current_group] : null;
                    $avatar = get_user_meta($user->ID, 'profile_avatar', true);
                    if (!$avatar) {
                        $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                    }
                ?>
                <tr>
                    <td>
                        <img src="<?php echo esc_url($avatar); ?>" alt="" class="user-avatar">
                        <strong><?php echo esc_html($user->user_login); ?></strong>
                        <br>
                        <small style="color: #999;"><?php echo esc_html($user->user_email); ?></small>
                    </td>
                    <td>
                        <?php if ($group_info): ?>
                            <span class="group-badge" style="background-color: <?php echo esc_attr($group_info['color']); ?>;">
                                <?php echo esc_html($group_info['label']); ?>
                            </span>
                        <?php else: ?>
                            <span class="no-group">No group</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display: flex; gap: 8px; align-items: center;">
                            <select class="group-select" data-user-id="<?php echo intval($user->ID); ?>">
                                <option value="">-- Select group --</option>
                                <?php foreach ($groups as $key => $group): ?>
                                    <option value="<?php echo esc_attr($key); ?>" 
                                        <?php selected($current_group, $key); ?>>
                                        <?php echo esc_html($group['label']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="save-group-btn" data-user-id="<?php echo intval($user->ID); ?>">
                                Save
                            </button>
                            <?php if ($current_group): ?>
                            <button class="remove-group-btn" data-user-id="<?php echo intval($user->ID); ?>" style="background-color: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer;">
                                Delete
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        document.querySelectorAll('.save-group-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const userId = this.dataset.userId;
                const select = document.querySelector(`select[data-user-id="${userId}"]`);
                const group = select.value;

                if (!group) {
                    alert('Select a group');
                    return;
                }

                this.disabled = true;
                this.textContent = 'Saving...';

                const formData = new FormData();
                formData.append('action', 'mangayummy_set_user_group');
                formData.append('user_id', userId);
                formData.append('group', group);

                fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('Group updated: ' + data.data.label);
                        location.reload();
                    } else {
                        alert('Error: ' + data.data);
                        this.disabled = false;
                        this.textContent = 'Save';
                    }
                })
                .catch(err => {
                    alert('Network error');
                    this.disabled = false;
                    this.textContent = 'Save';
                });
            });
        });

        document.querySelectorAll('.remove-group-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const userId = this.dataset.userId;

                if (!confirm('Are you sure you want to delete this user\'s group?')) {
                    return;
                }

                this.disabled = true;
                this.textContent = 'Deleting...';

                const formData = new FormData();
                formData.append('action', 'mangayummy_remove_user_group');
                formData.append('user_id', userId);

                fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('Group deleted successfully');
                        location.reload();
                    } else {
                        alert('Error: ' + data.data);
                        this.disabled = false;
                        this.textContent = 'Delete';
                    }
                })
                .catch(err => {
                    alert('Network error');
                    this.disabled = false;
                    this.textContent = 'Delete';
                });
            });
        });
    </script>
    <?php
}

// Admin page: delete all English chapters (global, moves posts to Trash)
function mangayummy_render_delete_en_chapters_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }
    global $wpdb;

    echo '<div class="wrap">';
    echo '<h1>Delete English Chapters (Global)</h1>';
    echo '<p>This action will <strong>move to trash</strong> all chapters marked as <code>en</code>. Only administrators can run this operation.</p>';

    // Handle form submit
    if (!empty($_POST['mangayummy_delete_en_chapters'])) {
        check_admin_referer('mangayummy_delete_en_chapters_action', 'mangayummy_delete_en_chapters_nonce');

        if (empty($_POST['confirm_delete'])) {
            echo '<div class="notice notice-error"><p>You must check the confirmation to continue.</p></div>';
        } else {
            $per_page = 200;
            $page = 1;
            $deleted = 0;
            $failed = array();

            do {
                $q = new WP_Query(array(
                    'post_type' => 'chapter',
                    'posts_per_page' => $per_page,
                    'paged' => $page,
                    'post_status' => array('publish','draft','pending','private'),
                    'fields' => 'ids',
                    'meta_query' => array(array('key' => '_chapter_language', 'value' => 'en', 'compare' => '='))
                ));

                if (!$q->have_posts()) break;

                foreach ($q->posts as $pid) {
                    if (wp_trash_post($pid)) {
                        $deleted++;
                    } else {
                        $failed[] = $pid;
                    }
                }

                wp_reset_postdata();
                $page++;
            } while ($q->post_count === $per_page);

            echo '<div class="notice notice-success"><p>Chapters moved to trash: <strong>' . esc_html(intval($deleted)) . '</strong></p></div>';
            if (!empty($failed)) {
                echo '<div class="notice notice-warning"><p>Could not move to trash the following IDs: ' . esc_html(implode(', ', $failed)) . '</p></div>';
            }
        }
    }

    // Current count of EN chapters (excluding trash)
    $total_en = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(pm.post_id) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = %s AND p.post_status != %s",
        '_chapter_language', 'en', 'chapter', 'trash'
    ));

    echo '<div style="background: #fff; padding: 18px; border: 1px solid #ddd; border-radius: 6px; margin-top: 12px;">';
    echo '<p>English chapters found: <strong>' . esc_html($total_en) . '</strong></p>';
    echo '<form method="post">';
    wp_nonce_field('mangayummy_delete_en_chapters_action', 'mangayummy_delete_en_chapters_nonce');
    echo '<p><label><input type="checkbox" name="confirm_delete" value="1"> Confirm — move all English chapters to trash</label></p>';
    echo '<p><button class="button button-primary" type="submit" name="mangayummy_delete_en_chapters" value="1">Delete EN Chapters (move to trash)</button></p>';
    echo '</form>';
    echo '<p><strong>Attention:</strong> You can restore chapters from Trash if you change your mind.</p>';
    echo '</div>';

    echo '</div>';
}


function mangayummy_delete_chapter_images_files($chapter_id) {
    $chapter_id = intval($chapter_id);
    if (!$chapter_id) {
        return false;
    }

    $upload_dir = wp_upload_dir();
    $chapter_dir = trailingslashit($upload_dir['basedir']) . 'chapters/' . $chapter_id . '/';

    if (is_dir($chapter_dir)) {
        mangayummy_recursive_rmdir($chapter_dir);
    }

    delete_post_meta($chapter_id, '_chapter_images');
    return true;
}

function mangayummy_remove_manga_from_user_meta($manga_id) {
    $manga_id = intval($manga_id);
    if (!$manga_id) {
        return;
    }

    $keys = array('mangayummy_bookmarks', 'bookmarked_manga', 'bookmarked_mangas', 'manga_status_reading', 'manga_status_planned', 'manga_status_completed', 'manga_status_paused', 'manga_status_abandoned');
    $users = get_users(array('fields' => 'ID'));

    foreach ($users as $user_id) {
        foreach ($keys as $key) {
            $val = get_user_meta($user_id, $key, true);
            if (!is_array($val)) {
                continue;
            }
            $new_val = array_values(array_filter($val, function($item) use ($manga_id) {
                return intval($item) !== $manga_id;
            }));

            if ($new_val !== $val) {
                update_user_meta($user_id, $key, $new_val);
            }
        }
    }
}

function mangayummy_render_delete_manga_with_chapters_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    echo '<div class="wrap">';
    echo '<h1>Delete Manga + Chapters</h1>';
    echo '<p>Enter the Manga series ID or slug. This operation deletes the manga, all associated chapters, and chapter images from the server.</p>';

    if (!empty($_POST['mangayummy_delete_manga'])) {
        check_admin_referer('mangayummy_delete_manga_action', 'mangayummy_delete_manga_nonce');

        $identifier = sanitize_text_field($_POST['mangayummy_manga_identifier']);
        $error = '';
        $success = '';

        // Optionally accept full manga URL, extract the slug
        if (!empty($identifier) && filter_var($identifier, FILTER_VALIDATE_URL)) {
            $url_path = trim(parse_url($identifier, PHP_URL_PATH), '/');
            if ($url_path !== '') {
                $parts = explode('/', $url_path);
                $identifier = end($parts);
            }
        }

        if (empty($identifier)) {
            $error = 'Enter a valid manga ID or slug.';
        } else {
            $manga = null;
            if (ctype_digit($identifier)) {
                $manga = get_post(intval($identifier));
            }
            if (!$manga) {
                $manga = get_page_by_path($identifier, OBJECT, 'manga');
            }
            if (!$manga) {
                $posts = get_posts(array(
                    'name' => sanitize_title($identifier),
                    'post_type' => 'manga',
                    'post_status' => array('publish','draft','pending','private'),
                    'numberposts' => 1
                ));
                if (!empty($posts)) {
                    $manga = $posts[0];
                }
            }

            if (!$manga || $manga->post_type !== 'manga') {
                $error = 'Manga not found.';
            } else {
                $manga_id = $manga->ID;

                // Find associated chapters (meta _manga_id + post_parent)
                $chapter_ids_meta = get_posts(array(
                    'post_type' => 'chapter',
                    'post_status' => array('publish','draft','pending','private','future'),
                    'numberposts' => -1,
                    'fields' => 'ids',
                    'meta_query' => array(array('key' => '_manga_id', 'value' => $manga_id, 'compare' => '='))
                ));

                $chapter_ids_parent = get_posts(array(
                    'post_type' => 'chapter',
                    'post_status' => array('publish','draft','pending','private','future'),
                    'numberposts' => -1,
                    'fields' => 'ids',
                    'post_parent' => $manga_id
                ));

                $chapter_ids = array_values(array_unique(array_merge($chapter_ids_meta, $chapter_ids_parent)));

                $deleted_chapters = 0;
                $deleted_images = 0;
                $failed_chapters = array();

                foreach ($chapter_ids as $chapter_id) {
                    if (mangayummy_delete_chapter_images_files($chapter_id)) {
                        $deleted_images++;
                    }

                    if (wp_delete_post($chapter_id, true)) {
                        $deleted_chapters++;
                    } else {
                        $failed_chapters[] = $chapter_id;
                    }
                }

                // Delete Manga
                $manga_deleted = false;
                if (wp_delete_post($manga_id, true)) {
                    $manga_deleted = true;
                }

                // Clean user references
                mangayummy_remove_manga_from_user_meta($manga_id);

                // Delete manga metadata
                delete_post_meta($manga_id, '_rating_avg');
                delete_post_meta($manga_id, '_rating_count');
                delete_post_meta($manga_id, '_rating_total');
                delete_post_meta($manga_id, '_manga_views');

                if ($manga_deleted) {
                    $success = sprintf('Manga (ID %d) and %d chapter(s) have been deleted. Images deleted for %d chapter(s).', $manga_id, $deleted_chapters, $deleted_images);
                    if (!empty($failed_chapters)) {
                        $success .= ' Could not delete chapters: ' . implode(', ', $failed_chapters) . '.';
                    }
                } else {
                    $error = 'Error deleting manga; chapters may have been deleted, but manga could not be (permissions or restrictions).';
                }
            }
        }

        if (!empty($error)) {
            echo '<div class="notice notice-error"><p>' . esc_html($error) . '</p></div>';
        } elseif (!empty($success)) {
            echo '<div class="notice notice-success"><p>' . esc_html($success) . '</p></div>';
        }
    }

    echo '<form method="post" style="max-width:760px; margin-top:16px;">';
    wp_nonce_field('mangayummy_delete_manga_action', 'mangayummy_delete_manga_nonce');
    echo '<p><label for="mangayummy_manga_identifier"><strong>Manga ID or slug:</strong></label><br>';
    echo '<input id="mangayummy_manga_identifier" name="mangayummy_manga_identifier" type="text" class="regular-text" required></p>';
    echo '<p><button type="submit" name="mangayummy_delete_manga" value="1" class="button button-primary">Delete Manga + Chapters</button></p>';
    echo '</form>';

    echo '<p><strong>Attention:</strong> This action is irreversible. Verify the manga identifier carefully before executing.</p>';
    echo '</div>';
}

function mangayummy_render_migrate_chapter_images_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce('ya_ajax_nonce');
    $manga_posts = get_posts(array(
        'post_type' => 'manga',
        'post_status' => array('publish', 'draft', 'pending', 'private'),
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ));

    echo '<div class="wrap">';
    echo '<h1>Migrate chapter images to your server</h1>';
    echo '<p>The utility searches for chapters that have external URLs in <code>_chapter_images</code>, downloads images to <code>/wp-content/uploads/chapters/&lt;chapter_id&gt;/</code> and rewrites meta to local URLs.</p>';
    echo '<p>You can select the series from the list or manually enter an ID / slug / URL if you want to quickly target a specific manga.</p>';

    echo '<table class="form-table" role="presentation">';
    echo '<tbody>';
    echo '<tr>';
    echo '<th scope="row"><label for="mangayummy_migrate_manga_select">Manga from list</label></th>';
    echo '<td><select id="mangayummy_migrate_manga_select" class="regular-text">';
    echo '<option value="">All series</option>';
    foreach ($manga_posts as $manga_post) {
        echo '<option value="' . intval($manga_post->ID) . '">' . esc_html(get_the_title($manga_post->ID)) . ' (ID ' . intval($manga_post->ID) . ')</option>';
        }
    echo '</select></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th scope="row"><label for="mangayummy_migrate_manga_identifier">Manual override</label></th>';
    echo '<td><input id="mangayummy_migrate_manga_identifier" type="text" class="regular-text" placeholder="optional: ID / slug / URL manga"> <span class="description">If you fill this in, the override has priority over the list above.</span></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th scope="row"><label for="mangayummy_migrate_start_chapter">Start from chapter</label></th>';
    echo '<td><input id="mangayummy_migrate_start_chapter" type="text" class="regular-text" placeholder="ID / slug / URL chapter (optional)"> <span class="description">If you fill this in, migration will start from the specified chapter.</span></td>';
    echo '</tr>';
    echo '<tr>';
    echo '<th scope="row"><label for="mangayummy_migrate_img_per_req">Images per request</label></th>';
    echo '<td><input id="mangayummy_migrate_img_per_req" type="number" min="1" max="30" value="5" class="small-text"> <span class="description">Images downloaded per request (default 5). Increase if the server is fast, decrease if you get timeout.</span></td>';
    echo '</tr>';
    echo '</tbody>';
    echo '</table>';

    echo '<p><button type="button" id="mangayummy-start-migration" class="button button-primary">Start migration</button></p>';
    echo '<div id="mangayummy-migration-status" style="max-width:920px; margin-top:16px; padding:12px; background:#fff; border:1px solid #dcdcde; min-height:120px; white-space:pre-wrap; overflow:auto;"></div>';

    echo '<script>';
    echo '(function(){';
    echo 'const ajaxUrl = ' . wp_json_encode($ajax_url) . ';';
    echo 'const nonce = ' . wp_json_encode($nonce) . ';';
    echo 'const startBtn = document.getElementById("mangayummy-start-migration");';
    echo 'const statusBox = document.getElementById("mangayummy-migration-status");';
    echo 'const mangaSelect = document.getElementById("mangayummy_migrate_manga_select");';
    echo 'const identifierInput = document.getElementById("mangayummy_migrate_manga_identifier");';
    echo 'const startChapterInput = document.getElementById("mangayummy_migrate_start_chapter");';
    echo 'const imgPerReqInput = document.getElementById("mangayummy_migrate_img_per_req");';
    echo 'function selectedScope(){';
    echo '  const manual = identifierInput.value.trim();';
    echo '  const startChapter = startChapterInput.value.trim();';
    echo '  const baseLabel = manual ? "manual override: " + manual : (mangaSelect.value ? mangaSelect.options[mangaSelect.selectedIndex].text : "All series");';
    echo '  return { value: manual || mangaSelect.value || "", label: baseLabel, startChapter: startChapter };';
    echo '}';
    echo 'function log(line){ statusBox.textContent += (statusBox.textContent ? "\n" : "") + line; statusBox.scrollTop = statusBox.scrollHeight; }';
    echo '/**';
    echo ' * Cursor: chapterOffset = index into candidate chapter list.';
    echo ' *         imageOffset   = index within current chapter images array.';
    echo ' * Each request downloads at most `images_per_request` remote images,';
    echo ' * so each round-trip completes in seconds, well under server proxy timeout.';
    echo ' */';
    echo 'var stopRequested = false;';
    echo 'function runBatch(chapterOffset, imageOffset, totals){';
    echo '  if (stopRequested) {';
    echo '    log("Migration stopped by user.");';
    echo '    startBtn.disabled = false; startBtn.textContent = "Start migration";';
    echo '    return;';
    echo '  }';
    echo '  const scope = selectedScope();';
    echo '  const imgPerReq = Math.max(1, Math.min(30, parseInt(imgPerReqInput.value || "5", 10) || 5));';
    echo '  const fd = new FormData();';
    echo '  fd.append("action", "mangayummy_migrate_chapter_images_batch");';
    echo '  fd.append("nonce", nonce);';
    echo '  fd.append("chapter_offset", String(chapterOffset));';
    echo '  fd.append("image_offset", String(imageOffset));';
    echo '  fd.append("images_per_request", String(imgPerReq));';
    echo '  fd.append("manga_identifier", scope.value);';
    echo '  fd.append("start_chapter_identifier", scope.startChapter || "");';
    echo '  fetch(ajaxUrl, { method: "POST", body: fd })';
    echo '    .then(function(res){ return res.text(); })';
    echo '    .then(function(raw){';
    echo '      var res;';
    echo '      try { res = JSON.parse(raw); }';
    echo '      catch(e) { throw new Error("Server timeout / HTML response. First 300 chars: " + raw.substring(0, 300).replace(/[\r\n]+/g," ")); }';
    echo '      if (!res.success) {';
    echo '        throw new Error((res.data && (res.data.message || JSON.stringify(res.data))) || "Unknown error");';
    echo '      }';
    echo '      const d = res.data || {};';
    echo '      totals.downloaded += d.downloaded || 0;';
    echo '      totals.already_local += d.already_local || 0;';
    echo '      totals.failed += d.failed || 0;';
    echo '      if (d.downloaded || d.failed) {';
    echo '        log("[Chapter " + ((d.chapter_offset||0)+1) + "/" + (d.total_chapters||"?") + "] " + (d.chapter_label || "") + " | page " + (d.image_offset||0) + "–" + ((d.next_image_offset||0)-1) + "/" + ((d.total_images||0)-1) + " | ↓" + (d.downloaded||0) + " ✓" + (d.already_local||0) + " ✗" + (d.failed||0) + " | total ↓" + totals.downloaded + " ✗" + totals.failed);';
    echo '        if (Array.isArray(d.details) && d.details.length) {';
    echo '          d.details.forEach(function(det){ log("  " + det); });';
    echo '        }';
    echo '      } else if (d.already_local) {';
    echo '        log("[Chapter " + ((d.chapter_offset||0)+1) + "/" + (d.total_chapters||"?") + "] " + (d.chapter_label || "") + " — all " + (d.already_local) + " images already local.");';
    echo '      }';
    echo '      if (d.has_more) {';
    echo '        runBatch(d.next_chapter_offset || 0, d.chapter_done ? 0 : (d.next_image_offset || 0), totals);';
    echo '        return;';
    echo '      }';
    echo '      log("✅ Migration complete! Downloaded images: " + totals.downloaded + " | already local: " + totals.already_local + " | failures: " + totals.failed);';
    echo '      startBtn.disabled = false; startBtn.textContent = "Start migration";';
    echo '    })';
    echo '    .catch(function(err){';
    echo '      log("❌ Error: " + (err && err.message ? err.message : String(err)));';
    echo '      startBtn.disabled = false; startBtn.textContent = "Start migration (retry)";';
    echo '    });';
    echo '}';
    echo 'startBtn.addEventListener("click", function(){';
    echo '  stopRequested = false;';
    echo '  startBtn.disabled = true;';
    echo '  startBtn.textContent = "Migrating... (click to stop)";';
    echo '  startBtn.onclick = function(){ stopRequested = true; };';
    echo '  statusBox.textContent = "";';
    echo '  log("Starting migration for: " + selectedScope().label);';
    echo '  runBatch(0, 0, { downloaded: 0, already_local: 0, failed: 0 });';
    echo '});';
    echo '})();';
    echo '</script>';
    echo '</div>';
}

function mangayummy_get_chapter_image_urls_for_migration($chapter_id) {
    $raw = get_post_meta($chapter_id, '_chapter_images', true);

    if (is_string($raw)) {
        $raw = array_filter(array_map('trim', explode(',', $raw)));
    } elseif (!is_array($raw)) {
        $raw = array();
    }

    $urls = array();
    foreach ($raw as $url) {
        $url = mangayummy_normalize_chapter_image_url((string) $url);
        if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
            $urls[] = $url;
        }
    }

    return array_values(array_unique($urls));
}

function mangayummy_is_local_chapter_image_url($url) {
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }

    $upload_dir = wp_upload_dir();
    if (empty($upload_dir['baseurl'])) {
        return false;
    }

    return strpos($url, trailingslashit($upload_dir['baseurl']) . 'chapters/') === 0;
}

function mangayummy_resolve_manga_identifier($identifier) {
    $identifier = trim((string) $identifier);
    if ($identifier === '') {
        return 0;
    }

    if (filter_var($identifier, FILTER_VALIDATE_URL)) {
        $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
        if ($path !== '') {
            $parts = explode('/', $path);
            $identifier = end($parts);
        }
    }

    $manga = null;
    if (ctype_digit($identifier)) {
        $manga = get_post((int) $identifier);
    }
    if (!$manga) {
        $manga = get_page_by_path($identifier, OBJECT, 'manga');
    }
    if (!$manga) {
        $posts = get_posts(array(
            'name' => sanitize_title($identifier),
            'post_type' => 'manga',
            'post_status' => array('publish', 'draft', 'pending', 'private'),
            'numberposts' => 1,
        ));
        if (!empty($posts)) {
            $manga = $posts[0];
        }
    }

    if (!$manga || $manga->post_type !== 'manga') {
        return new WP_Error('invalid_manga', 'Manga not found.');
    }

    return (int) $manga->ID;
}

function mangayummy_resolve_chapter_identifier($identifier) {
    $identifier = trim((string) $identifier);
    if ($identifier === '') {
        return 0;
    }

    if (filter_var($identifier, FILTER_VALIDATE_URL)) {
        $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
        if ($path !== '') {
            $parts = explode('/', $path);
            $identifier = end($parts);
        }
    }

    $chapter = null;
    if (ctype_digit($identifier)) {
        $chapter = get_post((int) $identifier);
    }

    if (!$chapter) {
        $slug = sanitize_title($identifier);
        $chapter = get_page_by_path($slug, OBJECT, 'chapter');
    }

    if (!$chapter) {
        $posts = get_posts(array(
            'name' => sanitize_title($identifier),
            'post_type' => 'chapter',
            'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'numberposts' => 1,
        ));
        if (!empty($posts)) {
            $chapter = $posts[0];
        }
    }

    if (!$chapter || $chapter->post_type !== 'chapter') {
        return new WP_Error('invalid_chapter', 'Chapter not found.');
    }

    return (int) $chapter->ID;
}

function mangayummy_get_remote_image_migration_candidates($manga_id = 0, $translator_group = '') {
    if ($manga_id > 0) {
        $chapter_ids_meta = get_posts(array(
            'post_type' => 'chapter',
            'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'numberposts' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                array('key' => '_manga_id', 'value' => $manga_id, 'compare' => '='),
                array('key' => '_chapter_images', 'compare' => 'EXISTS'),
            ),
        ));

        $chapter_ids_parent = get_posts(array(
            'post_type' => 'chapter',
            'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'numberposts' => -1,
            'fields' => 'ids',
            'post_parent' => $manga_id,
            'meta_query' => array(
                array('key' => '_chapter_images', 'compare' => 'EXISTS'),
            ),
        ));

        $chapter_ids = array_values(array_unique(array_merge($chapter_ids_meta, $chapter_ids_parent)));
    } else {
        $chapter_ids = get_posts(array(
            'post_type' => 'chapter',
            'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'numberposts' => -1,
            'fields' => 'ids',
            'orderby' => 'ID',
            'order' => 'ASC',
            'meta_query' => array(
                array('key' => '_chapter_images', 'compare' => 'EXISTS'),
            ),
        ));
    }

    $chapter_ids = array_values(array_unique($chapter_ids));
    sort($chapter_ids, SORT_NUMERIC);

    $candidate_ids = array();
    foreach ($chapter_ids as $chapter_id) {
        $urls = mangayummy_get_chapter_image_urls_for_migration($chapter_id);
        if (empty($urls)) {
            continue;
        }

        $candidate_ids[] = (int) $chapter_id;
    }

    return $candidate_ids;
}

function mangayummy_detect_image_extension_from_response($image_url, $response_body, $content_type = '') {
    $mime = '';
    if (!empty($content_type)) {
        $mime = strtolower(trim(explode(';', $content_type)[0]));
    }

    if (empty($mime) && function_exists('getimagesizefromstring')) {
        $image_info = @getimagesizefromstring($response_body);
        if (!empty($image_info['mime'])) {
            $mime = strtolower($image_info['mime']);
        }
    }

    $map = array(
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'image/bmp' => 'bmp',
    );

    if (!empty($mime) && isset($map[$mime])) {
        return $map[$mime];
    }

    $path = (string) parse_url($image_url, PHP_URL_PATH);
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (in_array($ext, array('jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'), true)) {
        return $ext === 'jpeg' ? 'jpg' : $ext;
    }

    return 'jpg';
}

function mangayummy_download_remote_chapter_image($chapter_id, $image_url, $position) {
    $chapter_id = (int) $chapter_id;
    $image_url = mangayummy_normalize_chapter_image_url((string) $image_url);
    $position = (int) $position;

    if ($chapter_id <= 0 || empty($image_url) || !filter_var($image_url, FILTER_VALIDATE_URL)) {
        return new WP_Error('invalid_input', 'Invalid data for image download.');
    }

    if (mangayummy_is_local_chapter_image_url($image_url)) {
        return $image_url;
    }

    $upload_dir = wp_upload_dir();
    if (empty($upload_dir['basedir']) || empty($upload_dir['baseurl'])) {
        return new WP_Error('upload_dir_error', 'Could not determine upload directory.');
    }

    $chapter_dir = trailingslashit($upload_dir['basedir']) . 'chapters/' . $chapter_id . '/';
    if (!is_dir($chapter_dir) && !wp_mkdir_p($chapter_dir)) {
        return new WP_Error('mkdir_failed', 'Could not create chapter directory.');
    }

    $base_name = sprintf('page-%04d', $position + 1);
    $existing_matches = glob($chapter_dir . $base_name . '.*');
    if (!empty($existing_matches)) {
        $existing_file = $existing_matches[0];
        if (is_file($existing_file) && filesize($existing_file) > 0) {
            return trailingslashit($upload_dir['baseurl']) . 'chapters/' . $chapter_id . '/' . basename($existing_file);
        }
    }

    $parsed = parse_url($image_url);
    $referer = '';
    if (!empty($parsed['scheme']) && !empty($parsed['host'])) {
        $referer = $parsed['scheme'] . '://' . $parsed['host'] . '/';
    }

    $response = wp_remote_get($image_url, array(
        'timeout' => 20,
        'redirection' => 5,
        'sslverify' => false,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'headers' => array_filter(array(
            'Accept' => 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
            'Referer' => $referer,
        )),
    ));

    if (is_wp_error($response)) {
        return $response;
    }

    $status = (int) wp_remote_retrieve_response_code($response);
    if ($status !== 200) {
        return new WP_Error('http_error', 'Source server responded with HTTP ' . $status . '.');
    }

    $body = wp_remote_retrieve_body($response);
    if ($body === '') {
        return new WP_Error('empty_file', 'Downloaded file is empty.');
    }

    if (function_exists('getimagesizefromstring') && @getimagesizefromstring($body) === false) {
        return new WP_Error('invalid_image', 'Response is not a valid image.');
    }

    $content_type = (string) wp_remote_retrieve_header($response, 'content-type');
    $extension = mangayummy_detect_image_extension_from_response($image_url, $body, $content_type);
    $filename = $base_name . '.' . $extension;
    $local_path = $chapter_dir . $filename;

    if (file_put_contents($local_path, $body) === false) {
        return new WP_Error('write_failed', 'Could not write image on server.');
    }

    return trailingslashit($upload_dir['baseurl']) . 'chapters/' . $chapter_id . '/' . $filename;
}

function mangayummy_migrate_chapter_images_to_local($chapter_id, $batch_start = null, $time_budget_seconds = 240) {
    $chapter_id = (int) $chapter_id;
    $urls = mangayummy_get_chapter_image_urls_for_migration($chapter_id);
    $chapter_number = get_post_meta($chapter_id, '_chapter_number', true);
    $manga_id = (int) get_post_meta($chapter_id, '_manga_id', true);
    $manga_title = $manga_id ? get_the_title($manga_id) : '';
    $chapter_title = get_the_title($chapter_id);
    $chapter_label = trim($manga_title) !== ''
        ? $manga_title . ' | Ch. ' . ($chapter_number !== '' ? $chapter_number : '?') . ' | ' . $chapter_title . ' | ID ' . $chapter_id
        : 'Chapter ID ' . $chapter_id;

    $result = array(
        'chapter_id' => $chapter_id,
        'label' => $chapter_label,
        'changed' => false,
        'downloaded' => 0,
        'already_local' => 0,
        'failed' => 0,
        'message' => '',
        'details' => array(),
    );

    if ($chapter_id <= 0 || empty($urls)) {
        $result['message'] = $chapter_label . ': chapter has no images.';
        return $result;
    }

    if ($batch_start === null) {
        $batch_start = microtime(true);
    }

    $new_urls = array();
    $time_aborted = false;
    foreach ($urls as $index => $url) {
        $page_number = $index + 1;

        // If we are approaching the time budget, stop downloading and keep existing URLs.
        if ((microtime(true) - $batch_start) > ($time_budget_seconds - 15)) {
            $new_urls[] = $url;
            $result['details'][] = 'Page ' . $page_number . ' skipped (time budget exceeded) - will be resumed.';
            $time_aborted = true;
            continue;
        }

        if (mangayummy_is_local_chapter_image_url($url)) {
            $new_urls[] = $url;
            $result['already_local']++;
            $result['details'][] = 'Page ' . $page_number . ' already local.';
            continue;
        }

        try {
            $downloaded_url = mangayummy_download_remote_chapter_image($chapter_id, $url, $index);
        } catch (Throwable $e) {
            $downloaded_url = new WP_Error('exception', $e->getMessage());
        }

        if (is_wp_error($downloaded_url)) {
            $new_urls[] = $url;
            $result['failed']++;
            $result['details'][] = 'Page ' . $page_number . ' FAILED: ' . $downloaded_url->get_error_message() . ' | source: ' . $url;
            continue;
        }

        $new_urls[] = $downloaded_url;
        $result['downloaded']++;
        $result['changed'] = true;
        $result['details'][] = 'Page ' . $page_number . ' OK -> ' . $downloaded_url;
    }

    if ($result['changed']) {
        update_post_meta($chapter_id, '_chapter_images', $new_urls);
        $result['details'][] = 'Meta _chapter_images updated with local URLs.';
    }

    if ($time_aborted) {
        $result['details'][] = 'WARNING: Some pages were omitted due to time limit. Run again to continue.';
    }

    $result['message'] = sprintf(
        '%s: %d images downloaded, %d already local, %d failed',
        $chapter_label,
        $result['downloaded'],
        $result['already_local'],
        $result['failed']
    );

    return $result;
}

add_action('wp_ajax_mangayummy_migrate_chapter_images_batch', 'mangayummy_migrate_chapter_images_batch');
/**
 * Per-image batch handler.
 *
 * Each AJAX call downloads at most `images_per_request` remote images and returns
 * immediately, so every request stays well within the web-server proxy timeout.
 *
 * Cursor: chapter_offset (index into candidate list) + image_offset (within chapter).
 * Already-local images are skipped instantly and do NOT consume the image budget.
 */
function mangayummy_migrate_chapter_images_batch() {
    ob_start();
    try {
        check_ajax_referer('ya_ajax_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            ob_end_clean();
            wp_send_json_error(array('message' => 'Insufficient permissions.'));
        }

        @ini_set('memory_limit', '256M');

        $identifier     = sanitize_text_field($_POST['manga_identifier'] ?? '');
        $chapter_offset = max(0, (int) ($_POST['chapter_offset']    ?? 0));
        $image_offset   = max(0, (int) ($_POST['image_offset']      ?? 0));
        $images_per_req = max(1, min(50, (int) ($_POST['images_per_request'] ?? 5)));

        $manga_id = 0;
        if ($identifier !== '') {
            $resolved = mangayummy_resolve_manga_identifier($identifier);
            if (is_wp_error($resolved)) {
                ob_end_clean();
                wp_send_json_error(array('message' => $resolved->get_error_message()));
            }
            $manga_id = (int) $resolved;
        }

        $start_chapter_identifier = sanitize_text_field($_POST['start_chapter_identifier'] ?? '');

        $scope_label      = $manga_id > 0 ? (get_the_title($manga_id) . ' (ID ' . $manga_id . ')') : 'All series';
        if ($start_chapter_identifier !== '') {
            $scope_label .= ' | Start from chapter: ' . $start_chapter_identifier;
        }

        $candidate_ids  = mangayummy_get_remote_image_migration_candidates($manga_id);
        $total_chapters = count($candidate_ids);

        if ($start_chapter_identifier !== '') {
            $start_chapter_id = mangayummy_resolve_chapter_identifier($start_chapter_identifier);
            if (is_wp_error($start_chapter_id)) {
                ob_end_clean();
                wp_send_json_error(array('message' => $start_chapter_id->get_error_message()));
            }
            if ($start_chapter_id > 0) {
                $start_offset = array_search($start_chapter_id, $candidate_ids, true);
                if ($start_offset === false) {
                    ob_end_clean();
                    wp_send_json_error(array('message' => 'Specified chapter has no external images to migrate or is not in the chapter list.'));
                }
                if ($chapter_offset < $start_offset) {
                    $chapter_offset = $start_offset;
                    $image_offset = 0;
                }
            }
        }

        if ($total_chapters === 0 || $chapter_offset >= $total_chapters) {
            ob_end_clean();
            wp_send_json_success(array(
                'has_more'            => false,
                'chapter_offset'      => $chapter_offset,
                'next_chapter_offset' => $chapter_offset,
                'image_offset'        => 0,
                'next_image_offset'   => 0,
                'total_chapters'      => $total_chapters,
                'chapter_done'        => true,
                'downloaded'          => 0,
                'already_local'       => 0,
                'failed'              => 0,
                'chapter_label'       => '',
                'total_images'        => 0,
                'details'             => array('No chapters with external images to migrate.'),
                'scope_label'         => $scope_label,
            ));
        }

        $chapter_id = (int) $candidate_ids[$chapter_offset];

        // Build human-readable label.
        $chapter_number = get_post_meta($chapter_id, '_chapter_number', true);
        $ch_manga_id    = (int) get_post_meta($chapter_id, '_manga_id', true);
        $manga_title    = $ch_manga_id ? get_the_title($ch_manga_id) : '';
        $chapter_title  = get_the_title($chapter_id);
        $chapter_label  = trim($manga_title) !== ''
            ? $manga_title . ' | Ch. ' . ($chapter_number !== '' ? $chapter_number : '?') . ' - ' . $chapter_title . ' (ID ' . $chapter_id . ')'
            : 'Chapter ID ' . $chapter_id;

        // Read current stored URLs (may already be partially migrated).
        $raw = get_post_meta($chapter_id, '_chapter_images', true);
        if (is_string($raw) && $raw !== '') {
            $current_urls = array_values(array_filter(array_map('trim', explode(',', $raw))));
        } elseif (is_array($raw)) {
            $current_urls = array_values($raw);
        } else {
            $current_urls = array();
        }
        $current_urls = array_map('mangayummy_normalize_chapter_image_url', $current_urls);

        $total_images = count($current_urls);
        $downloaded   = 0;
        $already_local = 0;
        $failed       = 0;
        $details      = array();
        $meta_changed = false;
        $budget       = $images_per_req; // counts only actual download attempts (not skips)
        $last_index   = $image_offset - 1;

        for ($i = $image_offset; $i < $total_images; $i++) {
            $url         = $current_urls[$i];
            $page_number = $i + 1;

            if (mangayummy_is_local_chapter_image_url($url)) {
                // Already local — free skip, advance cursor.
                $already_local++;
                $last_index = $i;
                continue;
            }

            // Remote URL: check budget before attempting download.
            if ($budget <= 0) {
                break; // resume from $i in the next request
            }

            try {
                $local_url = mangayummy_download_remote_chapter_image($chapter_id, $url, $i);
            } catch (Throwable $e) {
                $local_url = new WP_Error('exception', $e->getMessage());
            }

            $budget--;

            if (is_wp_error($local_url)) {
                $failed++;
                $details[] = 'Page ' . $page_number . ' FAILED: ' . $local_url->get_error_message();
            } else {
                $current_urls[$i] = $local_url;
                $downloaded++;
                $meta_changed = true;
                $details[] = 'Page ' . $page_number . ' OK';
            }
            $last_index = $i;
        }

        if ($meta_changed) {
            update_post_meta($chapter_id, '_chapter_images', array_values($current_urls));
        }

        $next_image_offset   = $last_index + 1;
        $chapter_done        = ($next_image_offset >= $total_images || $total_images === 0);
        $next_chapter_offset = $chapter_done ? $chapter_offset + 1 : $chapter_offset;
        $has_more            = !$chapter_done || ($next_chapter_offset < $total_chapters);

        ob_end_clean();
        wp_send_json_success(array(
            'has_more'            => $has_more,
            'chapter_offset'      => $chapter_offset,
            'next_chapter_offset' => $next_chapter_offset,
            'image_offset'        => $image_offset,
            'next_image_offset'   => $next_image_offset,
            'total_chapters'      => $total_chapters,
            'chapter_done'        => $chapter_done,
            'downloaded'          => $downloaded,
            'already_local'       => $already_local,
            'failed'              => $failed,
            'chapter_label'       => $chapter_label,
            'total_images'        => $total_images,
            'details'             => $details,
            'scope_label'         => $scope_label,
        ));
    } catch (Throwable $e) {
        ob_end_clean();
        wp_send_json_error(array('message' => 'PHP error: ' . $e->getMessage() . ' in ' . basename($e->getFile()) . ':' . $e->getLine()));
    }
}

// Fix Profile Images (convert JPG/PNG to WebP URLs)
function mangayummy_render_fix_profile_images_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    $upload_dir = wp_upload_dir();
    $basedir = $upload_dir['basedir'];
    $baseurl = $upload_dir['baseurl'];

    // Handle repair for specific user
    if (isset($_POST['fix_user_id']) && isset($_POST['action']) && $_POST['action'] === 'fix_images') {
        check_admin_referer('fix_profile_images_nonce');
        
        $user_id = intval($_POST['fix_user_id']);
        $user = get_user_by('ID', $user_id);
        
        if (!$user) {
            $error = "User not found";
        } else {
            $fixed = 0;
            $messages = array();
            
            // Fix avatar
            $avatar = get_user_meta($user_id, 'profile_avatar', true);
            if ($avatar && preg_match('/\.(jpg|jpeg|png)$/i', $avatar)) {
                $avatar_webp = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $avatar);
                $avatar_webp_path = str_replace($baseurl, $basedir, $avatar_webp);
                
                if (file_exists($avatar_webp_path)) {
                    update_user_meta($user_id, 'profile_avatar', $avatar_webp);
                    $messages[] = "✓ Avatar updated: " . basename($avatar) . " → " . basename($avatar_webp);
                    $fixed++;
                }
            }
            
            // Fix banner
            $banner = get_user_meta($user_id, 'profile_banner', true);
            if ($banner && preg_match('/\.(jpg|jpeg|png)$/i', $banner)) {
                $banner_webp = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $banner);
                $banner_webp_path = str_replace($baseurl, $basedir, $banner_webp);
                
                if (file_exists($banner_webp_path)) {
                    update_user_meta($user_id, 'profile_banner', $banner_webp);
                    $messages[] = "✓ Banner updated: " . basename($banner) . " → " . basename($banner_webp);
                    $fixed++;
                }
            }
            
            $success = $fixed > 0 ? "Fixed {$fixed} image(s) for user {$user_id}" : "No images needed fixing for this user";
        }
    }

    // Scan all users to find broken images
    $broken_users = array();
    $all_users = get_users(['fields' => 'ID']);

    foreach ($all_users as $uid) {
        $avatar = get_user_meta($uid, 'profile_avatar', true);
        $banner = get_user_meta($uid, 'profile_banner', true);
        
        $has_broken = false;
        $issues = array();
        
        if ($avatar && preg_match('/\.(jpg|jpeg|png)$/i', $avatar)) {
            $avatar_path = str_replace($baseurl, $basedir, $avatar);
            if (!file_exists($avatar_path)) {
                $has_broken = true;
                $issues[] = "Missing avatar: " . basename($avatar);
            }
        }
        
        if ($banner && preg_match('/\.(jpg|jpeg|png)$/i', $banner)) {
            $banner_path = str_replace($baseurl, $basedir, $banner);
            if (!file_exists($banner_path)) {
                $has_broken = true;
                $issues[] = "Missing banner: " . basename($banner);
            }
        }
        
        if ($has_broken) {
            $user = get_user_by('ID', $uid);
            $broken_users[] = array(
                'id' => $uid,
                'name' => $user ? $user->display_name : 'Unknown',
                'email' => $user ? $user->user_email : '',
                'issues' => $issues
            );
        }
    }
    ?>
    <div class="wrap">
        <h1>🔧 Fix Profile Images</h1>
        <p>This tool finds users with missing profile images (converted JPG/PNG → WebP) and repairs them.</p>
        
        <?php if (!empty($success)): ?>
            <div class="notice notice-success"><p><?php echo esc_html($success); ?></p></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="notice notice-error"><p><?php echo esc_html($error); ?></p></div>
        <?php endif; ?>
        
        <?php if (!empty($messages)): ?>
            <div class="notice notice-success">
                <?php foreach ($messages as $msg): ?>
                    <p><?php echo esc_html($msg); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <h2>Broken Images Found: <?php echo count($broken_users); ?></h2>
        
        <?php if (empty($broken_users)): ?>
            <p style="color: #27ae60;"><strong>✓ All profile images are OK!</strong></p>
        <?php else: ?>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Issues</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($broken_users as $item): ?>
                    <tr>
                        <td><?php echo intval($item['id']); ?></td>
                        <td><?php echo esc_html($item['name']); ?></td>
                        <td><?php echo esc_html($item['email']); ?></td>
                        <td style="font-size: 13px; color: #666;">
                            <?php foreach ($item['issues'] as $issue): ?>
                                <div>• <?php echo esc_html($issue); ?></div>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <form method="post" style="display: inline;">
                                <?php wp_nonce_field('fix_profile_images_nonce'); ?>
                                <input type="hidden" name="action" value="fix_images">
                                <input type="hidden" name="fix_user_id" value="<?php echo intval($item['id']); ?>">
                                <button type="submit" class="button button-primary">Fix Images</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

// Get available groups
function mangayummy_get_available_groups() {
    return [
        'fondator' => ['label' => 'Fondator', 'color' => '#e74c3c'],
        'designer' => ['label' => 'Designer', 'color' => '#9b59b6'],
        'tester' => ['label' => 'Tester', 'color' => '#3498db'],
        'editor' => ['label' => 'Editor', 'color' => '#f39c12'],
        'review_chief' => ['label' => 'Sef Recenzii', 'color' => '#2ecc71'],
        'moderator' => ['label' => 'Moderator', 'color' => '#e67e22'],
        'discord_manager' => ['label' => 'Manager server discord', 'color' => '#8e44ad'],
    ];
}

// Set user group (Admin only)
add_action('wp_ajax_mangayummy_set_user_group', 'mangayummy_set_user_group');
function mangayummy_set_user_group() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission');
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    $group = sanitize_text_field($_POST['group'] ?? '');
    $groups = mangayummy_get_available_groups();
    
    if (!$user_id || !$group || !isset($groups[$group])) {
        wp_send_json_error('Invalid data');
    }
    
    update_user_meta($user_id, 'user_group', $group);
    
    // Add notification
    $notifications = get_user_meta($user_id, 'notifications', true);
    $notifications = is_array($notifications) ? $notifications : [];
    $notifications[] = [
        'type' => 'group_assigned',
        'group_label' => $groups[$group]['label'],
        'time' => current_time('mysql')
    ];
    update_user_meta($user_id, 'notifications', $notifications);
    
    wp_send_json_success([
        'message' => 'Group updated',
        'label' => $groups[$group]['label']
    ]);
}

// Remove user group (Admin only)
add_action('wp_ajax_mangayummy_remove_user_group', 'mangayummy_remove_user_group');
function mangayummy_remove_user_group() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission');
    }
    
    $user_id = intval($_POST['user_id'] ?? 0);
    if (!$user_id) {
        wp_send_json_error('User invalid');
    }
    
    delete_user_meta($user_id, 'user_group');
    wp_send_json_success('Group deleted');
}

// Get all translator groups from posts
function mangayummy_get_translator_groups() {
    global $wpdb;
    $groups = $wpdb->get_col("
        SELECT DISTINCT meta_value 
        FROM {$wpdb->postmeta} 
        WHERE meta_key = '_translation_group' 
        AND meta_value != '' 
        ORDER BY meta_value ASC
    ");
    return array_filter($groups);
}

// Render blocked IPs admin page
function mangayummy_render_blocked_ips_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    if (isset($_POST['mangayummy_unblock_ip']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'mangayummy_unblock_ip')) {
        $ip_to_unblock = sanitize_text_field($_POST['mangayummy_unblock_ip']);
        mangayummy_unregister_blocked_ip($ip_to_unblock);
        echo '<div class="notice notice-success is-dismissible"><p>IP ' . esc_html($ip_to_unblock) . ' has been unblocked.</p></div>';
    }

    $blocked_ips = get_option('mangayummy_blocked_ips', []);
    if (!is_array($blocked_ips)) {
        $blocked_ips = [];
    }

    usort($blocked_ips, function($a, $b) {
        return intval($b['until'] ?? 0) - intval($a['until'] ?? 0);
    });

    ?>
    <div class="wrap">
        <h1>MangaYummy Blocked IPs</h1>
        <p>Manual management of IPs blocked automatically by the rate-limit system.</p>

        <table class="widefat fixed striped">
            <thead>
                <tr>
                    <th>IP</th>
                    <th>Reason</th>
                    <th>Technical Reason</th>
                    <th>Recent chapters / URLs</th>
                    <th>Until</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($blocked_ips)): ?>
                <tr><td colspan="7">No blocked IP in list.</td></tr>
            <?php else: ?>
                <?php foreach ($blocked_ips as $entry):
                    $ip = esc_html($entry['ip'] ?? '');
                    $title = esc_html($entry['title'] ?? '');
                    $message = esc_html($entry['message'] ?? '');
                    $reason = esc_html($entry['reason'] ?? '');
                    $until = intval($entry['until'] ?? 0);
                    $remaining = $until - time();
                    $status = ($remaining > 0) ? 'Active (' . gmdate('H:i:s', $remaining) . ' remaining)' : 'Expired';
                    $requests = $entry['requests'] ?? [];
                ?>
                <tr>
                    <td><?php echo $ip; ?></td>
                    <td><strong><?php echo $title; ?></strong><br><?php echo $message; ?></td>
                    <td><?php echo $reason !== '' ? $reason : '-'; ?></td>
                    <td>
                        <?php if (!empty($requests) && is_array($requests)): ?>
                            <details>
                                <summary>See recent accesses (<?php echo intval(count($requests)); ?>)</summary>
                                <ul style="margin:8px 0 0 16px;">
                                    <?php foreach ($requests as $req):
                                        $label = esc_html($req['label'] ?? '');
                                        $rt = intval($req['time'] ?? 0);
                                        $rt_text = $rt ? date_i18n('Y-m-d H:i:s', $rt) : '-';
                                    ?>
                                        <li>
                                            <code><?php echo $label; ?></code>
                                            <small style="color:#666;">(<?php echo esc_html($rt_text); ?>)</small>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </details>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?php echo $until ? date('Y-m-d H:i:s', $until) : '-'; ?></td>
                    <td><?php echo $status; ?></td>
                    <td>
                        <form method="post" style="display:inline">
                            <?php wp_nonce_field('mangayummy_unblock_ip'); ?>
                            <input type="hidden" name="mangayummy_unblock_ip" value="<?php echo esc_attr($ip); ?>">
                            <button type="submit" class="button button-primary">Unblock</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Render migrate groups admin page
function mangayummy_render_migrate_groups_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    $groups = mangayummy_get_translator_groups();
    ?>
    <div class="wrap">
        <h1>Translator Groups Migration</h1>
        <p>This tool allows migration of all content (manga and chapters) from one translator group to another.</p>
        
        <div style="background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 8px; margin-top: 20px;">
            <h3>Select groups for migration</h3>
            
            <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 20px;">
                <div>
                    <label for="source_group" style="display: block; margin-bottom: 5px; font-weight: 600;">Source group:</label>
                    <select id="source_group" style="min-width: 200px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- Select source group --</option>
                        <?php foreach ($groups as $group): ?>
                            <option value="<?php echo esc_attr($group); ?>"><?php echo esc_html($group); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="font-size: 24px; color: #666;">→</div>
                
                <div>
                    <label for="target_group" style="display: block; margin-bottom: 5px; font-weight: 600;">Target group:</label>
                    <select id="target_group" style="min-width: 200px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- Select target group --</option>
                        <?php foreach ($groups as $group): ?>
                            <option value="<?php echo esc_attr($group); ?>"><?php echo esc_html($group); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div id="migration_preview" style="background: #f9f9f9; padding: 15px; border-radius: 4px; margin-bottom: 20px; display: none;">
                <h4>Migration preview:</h4>
                <p id="preview_text"></p>
            </div>
            
            <button id="migrate_btn" class="button button-primary" disabled style="padding: 10px 20px; font-size: 16px;">
                Start migration
            </button>
            
            <div id="migration_progress" style="margin-top: 20px; display: none;">
                <div style="background: #f0f0f0; border-radius: 10px; height: 20px; overflow: hidden;">
                    <div id="progress_bar" style="background: #13667a; height: 100%; width: 0%; transition: width 0.3s;"></div>
                </div>
                <p id="progress_text" style="margin-top: 10px;">Preparing migration...</p>
            </div>
        </div>
    </div>

    <script>
        const sourceSelect = document.getElementById('source_group');
        const targetSelect = document.getElementById('target_group');
        const migrateBtn = document.getElementById('migrate_btn');
        const previewDiv = document.getElementById('migration_preview');
        const previewText = document.getElementById('preview_text');
        const progressDiv = document.getElementById('migration_progress');
        const progressBar = document.getElementById('progress_bar');
        const progressText = document.getElementById('progress_text');

        function mangayummy_updatePreview() {
            const source = sourceSelect.value;
            const target = targetSelect.value;
            
            if (source && target && source !== target) {
                migrateBtn.disabled = false;
                previewDiv.style.display = 'block';
                previewText.innerHTML = `All content from group <strong>${source}</strong> will be migrated to group <strong>${target}</strong>.`;
            } else {
                migrateBtn.disabled = true;
                previewDiv.style.display = 'none';
            }
        }

        sourceSelect.addEventListener('change', mangayummy_updatePreview);
        targetSelect.addEventListener('change', mangayummy_updatePreview);

        migrateBtn.addEventListener('click', function() {
            const source = sourceSelect.value;
            const target = targetSelect.value;
            
            if (!source || !target || source === target) {
                alert('Select valid and different groups');
                return;
            }
            
            if (!confirm(`Are you sure you want to migrate all content from "${source}" to "${target}"? This action cannot be undone.`)) {
                return;
            }
            
            migrateBtn.disabled = true;
            migrateBtn.textContent = 'Migrating...';
            progressDiv.style.display = 'block';
            progressText.textContent = 'Preparing migration...';
            progressBar.style.width = '0%';
            
            // Start migration
            mangayummy_performMigration(source, target);
        });

        function mangayummy_performMigration(source, target) {
            const formData = new FormData();
            formData.append('action', 'mangayummy_migrate_translator_group');
            formData.append('source_group', source);
            formData.append('target_group', target);
            
            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    progressBar.style.width = '100%';
                    progressText.textContent = `Migration complete! ${data.data.updated_count} content items migrated.`;
                    migrateBtn.textContent = 'Migration complete';
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    alert('Error: ' + data.data);
                    migrateBtn.disabled = false;
                    migrateBtn.textContent = 'Start migration';
                    progressDiv.style.display = 'none';
                }
            })
            .catch(err => {
                alert('Network error');
                migrateBtn.disabled = false;
                migrateBtn.textContent = 'Start migration';
                progressDiv.style.display = 'none';
            });
        }
    </script>
    <?php
}

// Migrate translator group (Admin only)
add_action('wp_ajax_mangayummy_migrate_translator_group', 'mangayummy_migrate_translator_group');
function mangayummy_migrate_translator_group() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission');
    }
    
    $source_group = sanitize_text_field($_POST['source_group'] ?? '');
    $target_group = sanitize_text_field($_POST['target_group'] ?? '');
    
    if (empty($source_group) || empty($target_group) || $source_group === $target_group) {
        wp_send_json_error('Invalid groups');
    }
    
    global $wpdb;
    
    // Update all posts with the source group to target group
    $updated = $wpdb->update(
        $wpdb->postmeta,
        ['meta_value' => $target_group],
        ['meta_key' => '_translation_group', 'meta_value' => $source_group]
    );
    
    if ($updated === false) {
        wp_send_json_error('Database update error');
    }
    
    wp_send_json_success([
        'message' => 'Migration complete',
        'updated_count' => $updated
    ]);
}

/* ===============================
   UNVERIFIED ACCOUNTS CLEANUP
   =============================== */

function mangayummy_render_unverified_accounts_page() {
    // Handle bulk actions
    if (isset($_POST['bulk_action']) && $_POST['bulk_action'] === 'bulk_delete' && isset($_POST['user_ids'])) {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'bulk_delete_unverified')) {
            echo '<div class="notice notice-error"><p>Nonce invalid!</p></div>';
        } else {
            require_once ABSPATH . 'wp-admin/includes/user.php';
            $deleted_count = 0;
            foreach ($_POST['user_ids'] as $user_id) {
                $user_id = intval($user_id);
                if ($user_id && wp_delete_user($user_id)) {
                    $deleted_count++;
                }
            }
            echo '<div class="notice notice-success"><p>' . sprintf(_n('%d account deleted.', '%d accounts deleted.', $deleted_count), $deleted_count) . '</p></div>';
        }
    }

    // Handle single delete
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['user_id'])) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'delete_unverified_' . $_GET['user_id'])) {
            echo '<div class="notice notice-error"><p>Nonce invalid!</p></div>';
        } else {
            require_once ABSPATH . 'wp-admin/includes/user.php';
            $user_id = intval($_GET['user_id']);
            if ($user_id && wp_delete_user($user_id)) {
                echo '<div class="notice notice-success"><p>Account deleted successfully.</p></div>';
            }
        }
    }

    // Get unverified accounts
    $unverified_users = get_users([
        'meta_key' => 'email_verified',
        'meta_value' => '0',
        'fields' => 'ID', // Returns array of IDs
    ]);

    ?>
    <div class="wrap">
        <h1>Cleanup Unverified Accounts</h1>
        <p>Here you can review and delete accounts that were not activated within 24 hours.</p>

        <?php if (empty($unverified_users)): ?>
            <div class="notice notice-info">
                <p>🎉 There are no unverified accounts! All accounts are active.</p>
            </div>
        <?php else: ?>
            <form method="post">
                <?php wp_nonce_field('bulk_delete_unverified'); ?>
                <input type="hidden" name="bulk_action" value="bulk_delete">

                <div class="tablenav top">
                    <div class="alignleft actions bulkactions">
                        <label for="bulk-action-selector-top" class="screen-reader-text">Select bulk action</label>
                        <select name="action" id="bulk-action-selector-top">
                            <option value="-1">Bulk actions</option>
                            <option value="bulk_delete">Delete selected</option>
                        </select>
                        <input type="submit" id="doaction" class="button action" value="Apply">
                    </div>
                    <br class="clear">
                </div>

                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <td id="cb" class="manage-column column-cb check-column">
                                <input id="cb-select-all-1" type="checkbox">
                            </td>
                            <th scope="col">Utilizator</th>
                            <th scope="col">Email</th>
                            <th scope="col">Registered</th>
                            <th scope="col">Expires in</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($unverified_users as $user_id): ?>
                            <?php
                            $user_data = get_userdata($user_id);
                            $registered = strtotime($user_data->user_registered);
                            $expires = get_user_meta($user_id, 'email_verify_expires', true);
                            $time_left = $expires - time();
                            $expired = $time_left <= 0;
                            ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="user_ids[]" value="<?php echo $user_id; ?>">
                                </th>
                                <td><?php echo esc_html($user_data->user_login); ?></td>
                                <td><?php echo esc_html($user_data->user_email); ?></td>
                                <td><?php echo date_i18n('d M Y H:i', $registered); ?></td>
                                <td>
                                    <?php if ($expired): ?>
                                        <span style="color: #dc3232; font-weight: bold;">EXPIRED</span>
                                    <?php else: ?>
                                        <span style="color: #46b450;"><?php echo human_time_diff(time(), $expires); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $expired ? 'expired' : 'pending'; ?>">
                                        <?php echo $expired ? 'Expired' : 'Pending'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo wp_nonce_url(add_query_arg(['action' => 'delete', 'user_id' => $user_id]), 'delete_unverified_' . $user_id); ?>"
                                       class="button button-small button-link-delete"
                                       onclick="return confirm('Are you sure you want to delete this account?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>

            <style>
                .status-badge {
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                .status-badge.pending {
                    background: #fff3cd;
                    color: #856404;
                }
                .status-badge.expired {
                    background: #f8d7da;
                    color: #721c24;
                }
            </style>
        <?php endif; ?>
    </div>
    <?php
}

// Set default avatar on user registration
add_action('user_register', 'mangayummy_set_default_avatar');
function mangayummy_set_default_avatar($user_id) {
    $default_avatar_path = get_template_directory() . '/images/default-avatar.png';
    
    if (file_exists($default_avatar_path)) {
        // Upload to media library
        $attachment_id = attachment_url_to_postid(get_template_directory_uri() . '/images/default-avatar.png');
        
        if (!$attachment_id) {
            // Dacă nu e în media library, copiează-l
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            
            $upload_dir = wp_upload_dir();
            $file_name = 'default-avatar-' . $user_id . '.png';
            $target_path = $upload_dir['path'] . '/' . $file_name;
            
            if (copy($default_avatar_path, $target_path)) {
                $attachment = [
                    'post_mime_type' => 'image/png',
                    'post_title' => preg_replace('/\.[^.]+$/', '', $file_name),
                    'post_content' => '',
                    'post_status' => 'inherit'
                ];
                $attachment_id = wp_insert_attachment($attachment, $target_path);
                
                if (!is_wp_error($attachment_id)) {
                    wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $target_path));
                }
            }
        }
        
        if ($attachment_id) {
            update_user_meta($user_id, 'profile_avatar', $attachment_id);
        }
    }
}

/* ================================
   MANGAYUMMY – RECENT ACTIVITY
   ================================ */

add_action('wp_ajax_nopriv_mangayummy_recent_activity', 'mangayummy_recent_activity');
add_action('wp_ajax_mangayummy_recent_activity', 'mangayummy_recent_activity');

function mangayummy_recent_activity() {
    // Validate manga_id
    if (!isset($_POST['manga_id'])) {
        wp_send_json_error('Manga ID missing');
    }

    $manga_id = intval($_POST['manga_id']);
    
    if ($manga_id <= 0) {
        wp_send_json_error('Invalid manga ID');
    }
    
    global $wpdb;
    
    try {
        // Step 1: Get users who have reading status for this manga (they have manifest interest)
        $statuses = array('reading', 'planned', 'completed', 'paused', 'abandoned');
        $activity = [];
        $processed_users = [];
        
        foreach ($statuses as $status) {
            // Get all users with this status
            $status_users = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT user_id, meta_value FROM {$wpdb->usermeta} 
                     WHERE meta_key = %s AND user_id > 0",
                    'manga_status_' . $status
                )
            );

            if (!empty($status_users)) {
                foreach ($status_users as $user_result) {
                    // Parse the serialized array
                    $status_list = maybe_unserialize($user_result->meta_value);
                    if (!is_array($status_list) || !in_array($manga_id, $status_list)) {
                        continue;
                    }
                    
                    // Skip if already processed with higher priority
                    if (isset($processed_users[$user_result->user_id])) {
                        continue;
                    }
                    
                    $user = get_user_by('ID', $user_result->user_id);
                    if (!$user) continue;

                    // Get avatar
                    $avatar = get_user_meta($user_result->user_id, 'profile_avatar', true);
                    if (!$avatar) {
                        $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                    }

                    // Get progress for this manga - check multiple possible keys
                    // Primary: manga_progress_[MANGA_ID]
                    $progress = intval(get_user_meta($user_result->user_id, 'manga_progress_' . $manga_id, true));
                    
                    // Fallback 1: mangapress_reading_progress (older format)
                    if ($progress <= 0) {
                        $reading_progress = get_user_meta($user_result->user_id, 'mangapress_reading_progress', true);
                        if (is_array($reading_progress) && isset($reading_progress[$manga_id])) {
                            $progress = intval($reading_progress[$manga_id]);
                        }
                    }
                    
                    // Fallback 2: For "completed" status, get total chapters if no progress set
                    if ($progress <= 0 && $status === 'completed') {
                        // Get total chapters for this manga
                        $total_chapters = get_post_meta($manga_id, '_chapters_total', true);
                        if (!$total_chapters) {
                            // Try alternative key
                            $total_chapters = get_post_meta($manga_id, 'total_chapters', true);
                        }
                        if ($total_chapters) {
                            $progress = intval($total_chapters);
                        }
                    }
                    
                    // Get timestamp
                    $timestamp = get_user_meta($user_result->user_id, 'manga_progress_timestamp_' . $manga_id, true);
                    if (!$timestamp) {
                        $timestamp = 0;
                    }

                    // Get user level
                    $user_level = get_user_meta($user_result->user_id, 'reader_level', true) ?: 1;
                    
                    // Get user's preferred level effect class
                    $level_class = mangayummy_get_user_level_tier_class($user_result->user_id);

                    // Get manga title
                    $manga_title = get_the_title($manga_id);
                    
                    // ONLY add if user has actual progress > 0 (manually added chapters)
                    // Don't show in recent activity if user just has status without reading chapters
                    if ($progress > 0) {
                        $activity[$user_result->user_id] = [
                            'user_id' => $user_result->user_id,
                            'user_name' => $user->display_name,
                            'user_login' => $user->user_login,
                            'avatar' => $avatar,
                            'chapter' => $progress,
                            'status' => $status,
                            'timestamp' => $timestamp,
                            'level' => $user_level,
                            'level_class' => $level_class,
                            'manga_title' => $manga_title
                        ];
                        $processed_users[$user_result->user_id] = true;
                    }
                }
            }
        }

        // Step 2: Also check for users with progress but maybe no status (edge case)
        // THIS IS THE SOURCE OF TRUTH FOR CHAPTER NUMBERS
        $progress_results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, meta_value as chapter FROM {$wpdb->usermeta} 
                 WHERE meta_key = %s AND user_id > 0",
                'manga_progress_' . $manga_id
            )
        );

        if (!empty($progress_results)) {
            foreach ($progress_results as $result) {
                $chapter = intval($result->chapter);
                
                // Force at least chapter 1 if result is 0 (defensive)
                if ($chapter <= 0) {
                    $chapter = 1;
                }
                
                // If already in activity from Step 1, UPDATE the chapter value (Step 2 is source of truth)
                if (isset($processed_users[$result->user_id])) {
                    $activity[$result->user_id]['chapter'] = $chapter; // Update with actual chapter
                    
                    // Also update timestamp if available
                    $timestamp = get_user_meta($result->user_id, 'manga_progress_timestamp_' . $manga_id, true);
                    if ($timestamp) {
                        $activity[$result->user_id]['timestamp'] = intval($timestamp);
                    }
                    continue;
                }
                
                $user = get_user_by('ID', $result->user_id);
                if (!$user) continue;
                
                $avatar = get_user_meta($result->user_id, 'profile_avatar', true);
                if (!$avatar) {
                    $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                }

                // Get reading status for this manga
                $reading_status = '';
                foreach ($statuses as $status) {
                    $status_list = get_user_meta($result->user_id, 'manga_status_' . $status, true);
                    if (is_array($status_list) && in_array($manga_id, $status_list)) {
                        $reading_status = $status;
                        break;
                    }
                }

                // Get timestamp
                $timestamp = get_user_meta($result->user_id, 'manga_progress_timestamp_' . $manga_id, true);
                if (!$timestamp) {
                    $timestamp = 0;
                }

                // Get user level
                $user_level = get_user_meta($result->user_id, 'reader_level', true) ?: 1;
                
                // Get user's preferred level effect class
                $level_class = mangayummy_get_user_level_tier_class($result->user_id);

                $manga_title = get_the_title($manga_id);
                
                $activity[$result->user_id] = [
                    'user_id' => $result->user_id,
                    'user_name' => $user->display_name,
                    'user_login' => $user->user_login,
                    'avatar' => $avatar,
                    'chapter' => $chapter,
                    'status' => $reading_status ?: 'reading',
                    'timestamp' => intval($timestamp),
                    'level' => $user_level,
                    'level_class' => $level_class,
                    'manga_title' => $manga_title
                ];
                $processed_users[$result->user_id] = true;
            }
        }

        if (empty($activity)) {
            wp_send_json_error('Nu sunt utilizatori care au citit această manga');
        }

        // Sort by timestamp descending (newest activity first)
        // Users with no timestamp go to the end
        usort($activity, function($a, $b) {
            $ts_a = intval($a['timestamp']);
            $ts_b = intval($b['timestamp']);
            
            // Both have no timestamp - don't change order
            if ($ts_a === 0 && $ts_b === 0) {
                return 0;
            }
            
            // One has no timestamp - put it at the end
            if ($ts_a === 0) return 1;
            if ($ts_b === 0) return -1;
            
            // Both have timestamps - sort by descending (most recent first)
            return $ts_b - $ts_a;
        });
        $activity = array_slice($activity, 0, 20); // Limit to 20

        // Add formatted time for each activity
        foreach ($activity as &$item) {
            $item['time_ago'] = mangayummy_time_ago($item['timestamp']);
        }

        wp_send_json_success(['activity' => $activity]);
    } catch (Exception $e) {
        wp_send_json_error('Database error: ' . $e->getMessage());
    }
}

/* ================================
   MANGAYUMMY – CHAPTER VIEWS
   ================================ */

function mangayummy_increment_chapter_views() {
    if (is_singular('chapter')) {
        $chapter_id = get_the_ID();
        
        // Get or create user/guest identifier
        if (is_user_logged_in()) {
            $identifier = 'user_' . get_current_user_id();
        } else {
            // For guests, use IP address
            $identifier = 'guest_' . mangayummy_get_client_ip();
        }
        
        // Check if this user/guest viewed this chapter in the last 10 seconds
        $last_view_key = 'chapter_view_' . $chapter_id . '_' . $identifier;
        $last_view_time = get_transient($last_view_key);
        
        // If no view in last 10 seconds, increment counter and set transient
        if ($last_view_time === false) {
            $view_count = intval(get_post_meta($chapter_id, '_chapter_views', true));
            update_post_meta($chapter_id, '_chapter_views', $view_count + 1);
            
            // Set transient for 10 seconds
            set_transient($last_view_key, time(), 10);
        }
    }
}
add_action('wp_head', 'mangayummy_increment_chapter_views');

function mangayummy_get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return sanitize_text_field($ip);
}

function mangayummy_get_chapter_views($chapter_id = null) {
    if (!$chapter_id) {
        $chapter_id = get_the_ID();
    }

    $cache_key = 'chapter_views_' . intval($chapter_id);
    $cached = wp_cache_get($cache_key, 'mangayummy');
    if ($cached !== false) {
        return intval($cached);
    }

    $views = intval(get_post_meta($chapter_id, '_chapter_views', true)) ?: 0;
    wp_cache_set($cache_key, $views, 'mangayummy', 60);
    return $views;
}

function mangayummy_get_total_manga_views($manga_id) {
    // Get manga views (includes carousel clicks and direct visits)
    $manga_views = intval(get_post_meta($manga_id, 'manga_views_total', true)) ?: 0;
    
    return $manga_views;
}

/* ================================
   MANGAYUMMY – CHAPTER COMMENTS
   ============================== */

function mangayummy_add_manga_comment() {
    // Security check - use standard nonce key
    check_ajax_referer('mangayummy_comment_nonce', 'nonce');
    
    // require login for commenting
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat pentru a comenta.']);
    }
    
    // Allow both logged-in users and guests (now that we know they're logged-in, $is_guest will be false)
    $is_guest = !is_user_logged_in();

    if (!isset($_POST['post_id']) || !isset($_POST['comment'])) {
        wp_send_json_error('Date incomplete');
    }

    $post_id = intval($_POST['post_id']);
    // TEMP: Try raw input
    $comment_text = $_POST['comment'];
    $parent_id = isset($_POST['parent']) ? intval($_POST['parent']) : 0;
    $user_id = get_current_user_id();
    
    // DEBUG: Log lengths and content
    mangayummy_debug_log("Manga comment - Raw length: " . strlen($comment_text) . ", Content preview: '" . substr($comment_text, 0, 200) . "'");
    // Quick trace when incoming comment contains an @mention (temporary debug)
    if (strpos($comment_text, '@') !== false) {
        mangayummy_debug_log("[mangayummy][mentions][incoming] manga post_id={$post_id} user_id={$user_id} preview='" . substr($comment_text, 0, 200) . "'");
    }
    
    // Generate guest name with ID for guests
    if ($is_guest) {
        $guest_id = mangayummy_get_guest_id();
        $guest_name = 'Oaspete ' . $guest_id;
    } else {
        $guest_name = '';
    }

    if (empty($comment_text)) {
        wp_send_json_error('Comentariul nu poate fi gol');
    }

    if (strlen($comment_text) > 1000) {
        wp_send_json_error('Comentariul nu poate depăși 1000 de caractere');
    }

    // Verify post exists and is a manga or stire
    $post = get_post($post_id);
    if (!$post || !in_array($post->post_type, array('manga', 'stire'), true)) {
        wp_send_json_error('Postare invalidă');
    }

    // Prepare comment data
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $comment_author = $is_guest ? $guest_name : get_the_author_meta('display_name', $user_id);
    $comment_email = $is_guest ? 'guest@example.com' : get_the_author_meta('user_email', $user_id);

    // Insert the comment
    global $mangayummy_skip_discord_comment_notification;
    $mangayummy_skip_discord_comment_notification = true;
    $comment_id = wp_insert_comment([
        'comment_post_ID'      => $post_id,
        'comment_author'       => $comment_author,
        'comment_author_email' => $comment_email,
        'comment_content'      => $comment_text,
        'comment_parent'       => $parent_id,
        'user_id'              => $user_id,
        'comment_approved'     => 1
    ]);

    if ($comment_id) {
        // Get the newly added comment
        $comment = get_comment($comment_id);
        
        // Award XP to logged-in users for commenting
        if (!$is_guest && $user_id) {
            mangayummy_update_user_xp($user_id, 10); // +10 XP per comment
        }
        
        // Store guest IP hash for editing/deleting later
        if ($is_guest) {
            $ip_hash = md5(mangayummy_get_client_ip());
            if ($ip_hash) {
                add_comment_meta($comment_id, '_guest_ip_hash', $ip_hash, true);
            }
        }

        // Process @username mentions and send notifications
        mangayummy_process_comment_mentions($comment_id, $comment_text, $post_id);

        // Send Discord notification for this new comment
        if (function_exists('mangayummy_sendDiscordCommentNotification') && !get_comment_meta($comment_id, 'discord_comment_notification_sent', true)) {
            if (mangayummy_sendDiscordCommentNotification($comment_id)) {
                add_comment_meta($comment_id, 'discord_comment_notification_sent', '1', true);
            }
        }
        
        // Get avatar HTML
        $avatar_html = get_avatar($comment, 48, '', '', array('class' => 'comment-avatar'));
        
        // Return full server-rendered HTML so client never constructs comment markup
        $html = mangayummy_render_comment($comment);
        wp_send_json_success([
            'message' => 'Comentariu adăugat cu succes!',
            'comment_id' => $comment_id,
            'html' => $html,
        ]);
    } else {
        wp_send_json_error('Eroare la adăugarea comentariului');
    }
}

/**
 * Format comment text with markdown-like syntax
 * Converts:
 * **text** → <b>text</b>
 * *text* → <i>text</i>
 * __text__ → <u>text</u>
 * ||text|| → <span class="spoiler">text</span>
 * `text` → <code>text</code>
 */
function mangayummy_format_comment_text($text) {
    // Delegate to the canonical parser so formatting is consistent
    return mangayummy_parse_comment_text($text);
}
add_action('wp_ajax_nopriv_mangayummy_add_manga_comment', 'mangayummy_add_manga_comment');
add_action('wp_ajax_mangayummy_add_manga_comment', 'mangayummy_add_manga_comment');

function mangayummy_add_chapter_comment() {
    // Security check
    check_ajax_referer('mangayummy_comment_nonce', 'nonce');
    
    // require login for commenting
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Trebuie să fii logat pentru a comenta.']);
    }
    
    // Allow both logged-in users and guests (now that we know they're logged-in, $is_guest will be false)
    $is_guest = !is_user_logged_in();

    if (!isset($_POST['post_id']) || !isset($_POST['comment'])) {
        wp_send_json_error('Date incomplete');
    }

    $post_id = intval($_POST['post_id']);
    $comment_text = sanitize_textarea_field($_POST['comment']);
    
    // Debug logging
    mangayummy_debug_log("Chapter comment - Raw length: " . strlen($comment_text) . ", Content preview: '" . substr($comment_text, 0, 200) . "'");
    // Quick trace when incoming comment contains an @mention (temporary debug)
    if (strpos($comment_text, '@') !== false) {
        mangayummy_debug_log("[mangayummy][mentions][incoming] chapter post_id={$post_id} user_id={$user_id} preview='" . substr($comment_text, 0, 200) . "'");
    }
    
    $parent_id = isset($_POST['parent']) ? intval($_POST['parent']) : 0;
    
    // Generate guest name with ID for guests
    if ($is_guest) {
        $guest_id = mangayummy_get_guest_id();
        $guest_name = 'Oaspete ' . $guest_id;
    } else {
        $guest_name = '';
    }

    if (empty($comment_text)) {
        wp_send_json_error('Comentariul nu poate fi gol');
    }

    if (strlen($comment_text) > 1000) {
        wp_send_json_error('Comentariul nu poate depăși 1000 de caractere');
    }

    // Verify post exists and is a chapter
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'chapter') {
        wp_send_json_error('Postare invalidă');
    }

    // Prepare comment data
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $comment_author = $is_guest ? $guest_name : get_the_author_meta('display_name', $user_id);
    $comment_email = $is_guest ? 'guest@example.com' : get_the_author_meta('user_email', $user_id);

    // Insert the comment
    global $mangayummy_skip_discord_comment_notification;
    $mangayummy_skip_discord_comment_notification = true;
    $comment_id = wp_insert_comment([
        'comment_post_ID'      => $post_id,
        'comment_author'       => $comment_author,
        'comment_author_email' => $comment_email,
        'comment_content'      => $comment_text,
        'comment_parent'       => $parent_id,
        'user_id'              => $user_id,
        'comment_approved'     => 1
    ]);

    if ($comment_id) {
        // Get the newly added comment
        $comment = get_comment($comment_id);
        
        // Debug logging
        mangayummy_debug_log("Chapter comment saved - ID: $comment_id, Saved length: " . strlen($comment->comment_content) . ", Content preview: '" . substr($comment->comment_content, 0, 200) . "'");
        
        // Save chapter/manga metadata for linking to parent manga
        $manga_id = get_post_meta($post_id, '_manga_id', true);
        if ($manga_id) {
            add_comment_meta($comment_id, '_manga_id', $manga_id);
            add_comment_meta($comment_id, '_chapter_id', $post_id);
            add_comment_meta($comment_id, '_chapter_title', get_the_title($post_id));
            add_comment_meta($comment_id, '_chapter_number', get_post_meta($post_id, '_chapter_number', true));
        }
        
        // Store guest IP hash for editing/deleting later
        if ($is_guest) {
            $ip_hash = md5(mangayummy_get_client_ip());
            if ($ip_hash) {
                add_comment_meta($comment_id, '_guest_ip_hash', $ip_hash, true);
            }
        }

        // Process @username mentions and send notifications
        mangayummy_process_comment_mentions($comment_id, $comment_text, $post_id);

        // Send Discord notification for this new comment
        if (function_exists('mangayummy_sendDiscordCommentNotification') && !get_comment_meta($comment_id, 'discord_comment_notification_sent', true)) {
            if (mangayummy_sendDiscordCommentNotification($comment_id)) {
                add_comment_meta($comment_id, 'discord_comment_notification_sent', '1', true);
            }
        }
        
        // Return full server-rendered HTML so client never constructs comment markup
        $html = mangayummy_render_comment($comment);
        wp_send_json_success([
            'message' => 'Comentariu adăugat cu succes!',
            'comment_id' => $comment_id,
            'html' => $html,
        ]);
    } else {
        wp_send_json_error('Eroare la adăugarea comentariului');
    }
}
add_action('wp_ajax_nopriv_mangayummy_add_chapter_comment', 'mangayummy_add_chapter_comment');
add_action('wp_ajax_mangayummy_add_chapter_comment', 'mangayummy_add_chapter_comment');
add_action('wp_ajax_mangayummy_search_users', 'mangayummy_search_users');
add_action('wp_ajax_nopriv_mangayummy_search_users', 'mangayummy_search_users');

add_action('wp_ajax_mangayummy_user_tooltip', 'mangayummy_user_tooltip');
add_action('wp_ajax_nopriv_mangayummy_user_tooltip', 'mangayummy_user_tooltip');

function mangayummy_search_users() {
    $query = sanitize_text_field($_GET['q'] ?? '');
    
    if (strlen($query) < 1) {
        wp_send_json([]);
        return;
    }
    
    $current_user_id = get_current_user_id();
    $results = [];
    
    // If user is logged in, only show friends (excluding current user)
    if ($current_user_id) {
        $friends = get_user_meta($current_user_id, 'friends', true);
        $friends = is_array($friends) ? $friends : [];
        
        // Remove current user from friends list if present
        $friends = array_diff($friends, [$current_user_id]);
        
        if (!empty($friends)) {
            // Get friends that match the query — search by display_name (best practice)
            $friend_users = get_users([
                'include' => $friends,
                'search' => '*' . $query . '*',
                'search_columns' => ['display_name'],
                'number' => 10,
                'fields' => ['ID', 'display_name']
            ]);
            
            foreach ($friend_users as $user) {
                // Return `username` as display_name for frontend compatibility
                $results[] = [
                    'id' => $user->ID,
                    'username' => $user->display_name,
                    'display_name' => $user->display_name,
                    'avatar' => get_user_meta($user->ID, 'profile_avatar', true) ?: get_template_directory_uri() . '/assets/img/default-avatar.png',
                    'is_friend' => true
                ];
            }
        }
    }
    
    wp_send_json($results);
}

function mangayummy_user_tooltip() {
    $user_id = intval($_GET['user_id'] ?? 0);
    // debug logging removed
    if (!$user_id) {
        wp_send_json_error();
        return;
    }
    $user = get_user_by('ID', $user_id);
    if (!$user) {
        wp_send_json_error();
        return;
    }
    $avatar = get_user_meta($user_id, 'profile_avatar', true) ?: get_template_directory_uri() . '/assets/img/default-avatar.png';
    $level = get_user_meta($user_id, 'reader_level', true) ?: 0;
    $xp = get_user_meta($user_id, 'reader_xp', true) ?: 0;
    $display_name = $user->display_name;
    // get online/offline status text
    list($ustatus, $ustatus_text) = mangayummy_user_status($user_id);
    if ($ustatus === 'offline') {
        $last = get_user_meta($user_id, 'last_activity', true);
        if ($last) {
            // show relative time instead of absolute date
            $relative = mangayummy_time_ago(intval($last));
            $ustatus_text = 'Ultima dată online: ' . $relative;
        }
    }
    $html = '<div class="tooltip-profile"><img src="' . esc_url($avatar) . '" class="tooltip-avatar"><div class="tooltip-info"><div class="tooltip-name">' . esc_html($display_name) . '</div>';
    if ($level) {
        $html .= '<div class="tooltip-level">Level ' . intval($level) . '</div>';
    }
    if ($xp) {
        $html .= '<div class="tooltip-xp">' . intval($xp) . ' XP</div>';
    }
    $html .= '<div class="tooltip-status ' . esc_attr($ustatus) . '">' . esc_html($ustatus_text) . '</div>';
    $html .= '</div></div>';
    wp_send_json_success(['html' => $html]);
}


// Monetag ads removed - functionality disabled

/* ================================
   MANGAYUMMY – COMMENT SYSTEM
   ================================ */

/**
 * Auto-approve comments made by logged-in users
 * This bypasses manual moderation for authenticated users across the site.
 */
add_filter('pre_comment_approved', function($approved, $commentdata) {
    if (!empty($commentdata['user_id']) && intval($commentdata['user_id']) > 0) {
        return 1; // approve immediately
    }
    return $approved;
}, 10, 2);

// Also bypass the global "hold comments for moderation" option for logged-in users
add_filter('pre_option_comment_moderation', function($value) {
    if (is_user_logged_in()) {
        return 0; // do not hold for moderation
    }
    return $value;
});

/**
 * Disable comment flood check for logged-in users
 * Hooks into the check_comment_flood_db filter to bypass WordPress' built-in throttle.
 */
add_filter('check_comment_flood_db', function($result, $comment_author_email, $comment_author_url, $comment_type, $comment_author) {
    if (is_user_logged_in()) {
        mangayummy_debug_log('✅ FLOOD CHECK BYPASSED for user ' . get_current_user_id());
        return false; // skip flood check for authenticated users
    }
    mangayummy_debug_log('⚠️ FLOOD CHECK ACTIVE - not logged in');
    return $result;
}, 10, 5);

/**
 * Explicitly set comment delay to 0 for logged-in users
 */
add_filter('comment_flood_filter', function($check_result) {
    if (is_user_logged_in()) {
        mangayummy_debug_log('✅ FLOOD FILTER BYPASSED for user ' . get_current_user_id());
        return false;
    }
    return $check_result;
});

/**
 * Localize scripts for AJAX operations
 */
function mangayummy_localize_comments() {
    if (is_singular('manga') || is_singular('chapter')) {
        wp_localize_script('mangayummy-comments', 'mangayummy_comments', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mangayummy_comment_nonce'),
            'post_id' => get_the_ID(),
        ]);
    }
}
add_action('wp_enqueue_scripts', 'mangayummy_localize_comments', 11);

/**
 * Custom comment callback for styled comments
 */
function mangayummy_manga_comment_callback($comment, $args = [], $depth = 1) {
    // Use the single renderer to ensure identical HTML for page and AJAX
    echo mangayummy_render_comment($comment);
}

/**
 * Backward-compatible alias used by older templates.
 */
if (!function_exists('manga_comment_callback')) {
    function manga_comment_callback($comment, $args = [], $depth = 1) {
        mangayummy_manga_comment_callback($comment, $args, $depth);
    }
}

/**
 * Parse comment text server-side into a small markdown-like HTML
 * Supports: **bold**, *italic*, __underline__, ||spoiler||, `code`, @username mentions
 */
function mangayummy_parse_comment_text($text) {
    if (!$text) return '';

    // Escape HTML first (security)
    $text = esc_html($text);

    // --- CODE (FIRST, protected) ---
    $text = preg_replace_callback('/`([^`]+)`/s', function ($m) {
        return '<code>' . $m[1] . '</code>';
    }, $text);

    // --- SPOILER ---
    $text = preg_replace('/\|\|(.+?)\|\|/s', '<span class="spoiler">$1</span>', $text);

    // --- BOLD ---
    $text = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $text);

    // --- UNDERLINE ---
    $text = preg_replace('/__(.+?)__/s', '<u>$1</u>', $text);

    // --- ITALIC (AFTER bold!) ---
    $text = preg_replace('/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/s', '<em>$1</em>', $text);

    // --- @MENTIONS (support display_name) ---
    // Accept Unicode letters, numbers, underscores, dots, hyphens and spaces in display_name
    $text = preg_replace_callback('/@([\p{L}0-9_\-\. ]{1,100})/u', function($matches) {
        $mention = trim($matches[1]);

        // Try lookup by login first for backward compatibility
        $user = get_user_by('login', $mention);

        // If not found, try exact (or LIKE) match on display_name
        if (!$user) {
            $found = get_users([
                'search' => $mention,
                'search_columns' => ['display_name'],
                'number' => 1,
                'fields' => ['ID', 'display_name']
            ]);
            if (!empty($found)) {
                $user = $found[0];
            }
        }

        if ($user) {
            $display = $user->display_name ?: $user->user_login;
            $profile_url = add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user->ID), home_url('/'));
            return '<a href="' . esc_url($profile_url) . '" class="mention-link" title="Visit profile of ' . esc_attr($display) . '">@' . esc_html($display) . '</a>';
        } else {
            // If user doesn't exist, return the original mention text
            return '@' . esc_html($mention);
        }
    }, $text);

    // --- GIF embedding for direct GIPHY media URLs ---
    $text = preg_replace_callback('/https?:\/\/(?:media\d*\.giphy\.com\/media\/[^\s<]+\.(?:gif|webp)|i\.giphy\.com\/[^\s<]+\.(?:gif|webp))/i', function($matches) {
        $url = esc_url($matches[0]);
        return '<img src="' . $url . '" alt="GIF" class="comment-gif" loading="lazy">';
    }, $text);

    // Line breaks
    return nl2br($text);
}

/**
 * Process @username mentions in comments and send notifications
 */
function mangayummy_process_comment_mentions($comment_id, $comment_content, $post_id) {
    // Debug trace (WP_DEBUG only)
    if (defined('WP_DEBUG') && WP_DEBUG) {
        mangayummy_debug_log("[mangayummy][mentions] process_comment_mentions called: comment_id={$comment_id}, post_id={$post_id}, len=" . strlen($comment_content));
    }

    // Extract @mentions (supports display_name-like tokens including spaces)
    preg_match_all('/@([\p{L}0-9_\-\. ]{1,100})/u', $comment_content, $matches);

    if (!empty($matches[1])) {
        // Trace mention tokens only in debug mode
        mangayummy_debug_log("[mangayummy][mentions][found] comment_id={$comment_id} matches=" . implode(',', array_map('trim', $matches[1])));
    } else {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            mangayummy_debug_log("[mangayummy][mentions] no mentions found for comment {$comment_id}");
        }
        return; // No mentions found
    }

    $mentioned_values = array_unique(array_map('trim', $matches[1]));
    $current_user_id = get_current_user_id();

    if (defined('WP_DEBUG') && WP_DEBUG) {
        mangayummy_debug_log("[mangayummy][mentions] mentions detected for comment {$comment_id}: " . implode(', ', $mentioned_values));
    }

    global $wpdb;

    foreach ($mentioned_values as $val) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            mangayummy_debug_log("[mangayummy][mentions] resolving mention '{$val}' for comment {$comment_id}");
        }

        // Try resolving by login first (backwards compatibility)
        $user = get_user_by('login', $val);
        if ($user) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] resolved by login: user_id={$user->ID}, display_name={$user->display_name}");
            }
        }

        // Fallback: resolve by display_name
        if (!$user) {
            $found = get_users([
                'search' => $val,
                'search_columns' => ['display_name'],
                'number' => 1,
                'fields' => ['ID', 'display_name']
            ]);
            if (!empty($found)) {
                $user = $found[0];
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    mangayummy_debug_log("[mangayummy][mentions] resolved by display_name: user_id={$user->ID}, display_name={$user->display_name}");
                }
            }
        }

        if (!$user) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] mention '{$val}' did not resolve to any user (comment {$comment_id})");
            }
            continue; // User doesn't exist, skip
        }

        $mentioned_user_id = $user->ID;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            mangayummy_debug_log("[mangayummy][mentions] mention resolved: '{$val}' -> user_id={$mentioned_user_id}");
        }

        // Don't notify if user mentions themselves
        if ($mentioned_user_id == $current_user_id) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] skipping self-mention for user_id={$mentioned_user_id}");
            }
            continue;
        }

        // Check if notification already exists for this comment to avoid duplicates
        $existing = 0;
        $col_check = $wpdb->get_results("SHOW COLUMNS FROM {$wpdb->prefix}comment_notifications LIKE 'type'");
        if (!empty($col_check)) {
            $existing = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}comment_notifications
                     WHERE user_id = %d AND comment_id = %d AND type = 'mention'",
                    $mentioned_user_id, $comment_id
                )
            );
        } else {
            // Older schema: check by user_id + comment_id only
            $existing = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}comment_notifications
                     WHERE user_id = %d AND comment_id = %d LIMIT 1",
                    $mentioned_user_id, $comment_id
                )
            );
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] comment_notifications missing 'type' column; using fallback check for user={$mentioned_user_id}, comment={$comment_id}");
            }
        }

        if ($existing) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] skipping insert: notification already exists (id=" . intval($existing) . ") for user {$mentioned_user_id}, comment {$comment_id}");
            }
            continue; // Already notified
        }

        // Insert mention notification
        $ok = $wpdb->insert(
            $wpdb->prefix . 'comment_notifications',
            [
                'user_id' => $mentioned_user_id,
                'comment_id' => $comment_id,
                'reply_id' => $comment_id, // For mentions, reply_id is the same as comment_id
                'type' => 'mention',
                'is_read' => 0,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%d', '%d', '%s', '%d', '%s']
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            if ($ok) {
                mangayummy_debug_log("[mangayummy][mentions] inserted comment_notification (id={$wpdb->insert_id}) for user {$mentioned_user_id}, comment {$comment_id}");
            } else {
                mangayummy_debug_log("[mangayummy][mentions] FAILED to insert comment_notification for user {$mentioned_user_id}, comment {$comment_id} - db_error=" . $wpdb->last_error);
            }
        }

        // Also create a private message entry so the mention appears in "Mesajele tale" (avoid duplicates)
        $comment_link = get_comment_link($comment_id);
        $existing_pm = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}private_messages WHERE receiver_id = %d AND message LIKE %s LIMIT 1",
            $mentioned_user_id,
            '%' . $wpdb->esc_like($comment_link) . '%'
        ));

        if (!$existing_pm) {
            $sender_id_for_msg = $current_user_id ?: 0;
            $pm_message = '[NOTIF:' . $comment_link . ']' . ($current_user_id ? get_the_author_meta('display_name', $current_user_id) : 'Utilizator') . ' te-a menționat: ' . wp_trim_words($comment_content, 20);
            $insert_ok = $wpdb->insert(
                $wpdb->prefix . 'private_messages',
                [
                    'sender_id'   => $sender_id_for_msg,
                    'receiver_id' => $mentioned_user_id,
                    'message'     => $pm_message,
                    'is_read'     => 0,
                    'created_at'  => current_time('mysql')
                ],
                ['%d', '%d', '%s', '%d', '%s']
            );

            if (defined('WP_DEBUG') && WP_DEBUG) {
                if ($insert_ok) {
                    mangayummy_debug_log("[mangayummy][mentions] inserted private_message (id={$wpdb->insert_id}) receiver={$mentioned_user_id}, comment={$comment_id}");
                } else {
                    mangayummy_debug_log("[mangayummy][mentions] FAILED to insert private_message for receiver={$mentioned_user_id}, comment={$comment_id} - db_error=" . $wpdb->last_error);
                }
            }
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                mangayummy_debug_log("[mangayummy][mentions] skipping private_message insert because existing_pm={$existing_pm}");
            }
        }
    }
}

/**
 * Single renderer returning server-side HTML for a comment (including replies)
 */
function mangayummy_render_comment($comment) {
    if (!is_object($comment)) return '';
    ob_start();
    $comment_id = intval($comment->comment_ID);
    $comment_user_id = intval($comment->user_id);
    $current_user_id = get_current_user_id();
    static $cached_ip_hash = null;
    if ($cached_ip_hash === null) {
        $client_ip = mangayummy_get_client_ip();
        $cached_ip_hash = $client_ip ? md5($client_ip) : '';
    }

    $comment_user_ctx = $comment_user_id > 0 ? mangayummy_get_comment_user_context($comment_user_id) : null;
    $likes = (int) get_comment_meta($comment_id, 'likes', true);
    $dislikes = (int) get_comment_meta($comment_id, 'dislikes', true);
    if ($likes < 0) $likes = 0;
    if ($dislikes < 0) $dislikes = 0;
    // Determine current caller reaction to apply active state
    $user_reaction = '';
    if ($current_user_id) {
        $user_reaction = get_user_meta($current_user_id, "reacted_{$comment_id}", true) ?: '';
    } elseif ($cached_ip_hash) {
        $user_reaction = get_comment_meta($comment_id, "reacted_{$comment_id}_{$cached_ip_hash}", true) ?: '';
    }
    // Check if this is a guest comment (user_id = 0 and has IP hash)
    $is_guest_comment = (!$comment->user_id && get_comment_meta($comment_id, '_guest_ip_hash', true));
    $comment_timestamp = strtotime($comment->comment_date);
    ?>
    <div class="comment" id="comment-<?php echo $comment_id; ?>" data-id="<?php echo $comment_id; ?>" data-comment-id="<?php echo $comment_id; ?>" data-parent-id="<?php echo intval($comment->comment_parent); ?>" data-date="<?php echo esc_attr($comment->comment_date); ?>" data-time="<?php echo $comment_timestamp; ?>" data-likes="<?php echo $likes; ?>" data-author-id="<?php echo $comment_user_id; ?>" data-current-user-id="<?php echo $current_user_id; ?>" data-chapter-id="<?php echo esc_attr(get_comment_meta($comment_id, '_chapter_id', true)); ?>" data-is-guest-comment="<?php echo $is_guest_comment ? 'true' : 'false'; ?>">
        <div class="comment-meta">
            <div class="comment-avatar-wrapper">
                <?php
                // Generate avatar HTML directly - bypass all filters
                if ($comment_user_id > 0) {
                    $avatar_url = $comment_user_ctx ? $comment_user_ctx['avatar_url'] : (get_template_directory_uri() . '/assets/img/default-avatar.png');
                    $profile_url = add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $comment_user_id), home_url('/'));
                    echo '<a href="' . esc_url($profile_url) . '" class="comment-avatar-link" title="Visit profile">';
                    echo '<img src="' . esc_url($avatar_url) . '" class="comment-avatar" width="48" height="48" alt="avatar" />';
                    echo '</a>';
                } else {
                    $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
                    echo '<img src="' . esc_url($avatar_url) . '" class="comment-avatar" width="48" height="48" alt="avatar" />';
                }
                ?>
            </div>
            <div class="comment-info">
                <div class="comment-header">
                    <?php
                    if ($comment_user_id > 0) {
                        $profile_url = add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $comment_user_id), home_url('/'));
                        $current_name = $comment_user_ctx ? $comment_user_ctx['display_name'] : $comment->comment_author;
                        echo '<a href="' . esc_url($profile_url) . '" class="comment-author-link" title="Visit profile"><strong>' . esc_html($current_name) . '</strong></a>';
                    } else {
                        echo '<strong>' . esc_html($comment->comment_author) . '</strong>';
                    }
                    ?>
                    <?php 
                    // Get user info (level and group)
                    if ($comment_user_id > 0 && $comment_user_ctx) {
                            $level_label = $comment_user_ctx['level_label'];
                            $level_tier_class = $comment_user_ctx['level_tier_class'];
                            $group_info = $comment_user_ctx['group_info'];

                            $level_class = 'comment-user-level';
                            if ($level_tier_class) {
                                $level_class .= ' ' . $level_tier_class;
                            }
                            
                            echo '<span class="' . esc_attr($level_class) . '">' . esc_html($level_label) . '</span>';
                    }
                    ?>
                </div>
                <div class="comment-meta-info">
                    <?php
                    // Use GMT date from DB then convert via WordPress timezone to avoid double offset
                    $comment_time_gmt = $comment->comment_date_gmt ?: $comment->comment_date;
                    ?>
                    <span class="comment-date"><?php echo mangayummy_get_date_ro($comment_time_gmt, 'd F Y H:i'); ?></span>
                    <?php 
                    // Show chapter info badge ONLY on manga reviews (not on single chapter)
                    if (is_singular('manga')) {
                        $chapter_number = get_comment_meta($comment_id, '_chapter_number', true);
                        $manga_id = get_comment_meta($comment_id, '_manga_id', true);
                        if ($chapter_number && $manga_id) {
                            $chapter_id = get_comment_meta($comment_id, '_chapter_id', true);
                            $chapter_post = get_post($chapter_id);
                            if ($chapter_post) {
                                $chapter_url = get_permalink($chapter_id);
                                ?>
                                <span class="comment-chapter-info">
                                    <i class="fa fa-book"></i>
                                    <a href="<?php echo esc_url($chapter_url); ?>" title="Go to chapter">Chapter <?php echo esc_html($chapter_number); ?></a>
                                </span>
                                <?php
                            }
                        }
                    }
                    ?>
                    <?php 
                    // Show reported badge if applicable
                    $reported = get_comment_meta($comment_id, '_reported', true);
                    if ($reported) {
                        ?>
                        <span class="comment-flag" title="Reported">??</span>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <div class="comment-menu">
                <button type="button" class="comment-menu-btn" title="Opțiuni">⋮</button>
                <div class="comment-menu-dropdown">
                    <?php 
                    $is_author = false;
                    
                    // Check if logged-in user is author
                    if ($current_user_id && intval($comment->user_id) === $current_user_id) {
                        $is_author = true;
                    }
                    // Check if guest is author (via IP)
                    elseif (!$current_user_id) {
                        $ip_hash = $cached_ip_hash;
                        $stored_ip = get_comment_meta($comment_id, '_guest_ip_hash', true);
                        if ($ip_hash && $stored_ip && $ip_hash === $stored_ip) {
                            $is_author = true;
                        }
                    }
                    
                    if ($is_author) {
                        // author can always edit or delete their comment
                        ?>
                        <button type="button" class="comment-edit" data-comment-id="<?php echo $comment_id; ?>" title="Editează comentariul">Editează</button>
                        <button type="button" class="comment-delete" data-comment-id="<?php echo $comment_id; ?>" title="Delete comment">Delete</button>
                        <?php
                    } else {
                        // Show report only for non-authors
                        ?>
                        <button type="button" class="comment-report" data-comment-id="<?php echo $comment_id; ?>" title="Report comment">Report</button>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>

        <?php
        $comment_post_type = get_post_type($comment->comment_post_ID);
        $is_chapter_comment = ($comment_post_type === 'chapter');
        ?>
        <div class="comment-body" data-original="<?php echo esc_attr($comment->comment_content); ?>">
            <div class="comment-text <?php echo $is_chapter_comment ? 'show-text' : 'hide-text'; ?>" data-comment-id="<?php echo $comment_id; ?>">
                <?php 
                $parsed_content = mangayummy_parse_comment_text($comment->comment_content);
                echo $parsed_content;
                ?>
            </div>
            <?php
            $edited_at = get_comment_meta($comment_id, '_edited_at', true);
            if (!empty($edited_at)) {
                echo '<span class="comment-edited">(editat)</span>';
            }
            ?>
            <?php if (!$is_chapter_comment) : ?>
              <a href="#" class="more-text bordered" data-comment-id="<?php echo $comment_id; ?>" style="display:none;">Afișează textul integral</a>
            <?php endif; ?>
            <textarea class="comment-edit-textarea" style="display:none" maxlength="1000"></textarea>
            <div class="comment-edit-actions" style="display:none">
                <button type="button" class="comment-save">Save</button>
                <button type="button" class="comment-cancel">Anulează</button>
            </div>
            
            <?php 
            // Show chapter reference ONLY on manga reviews
            if (is_singular('manga')) {
                $chapter_id = get_comment_meta($comment_id, '_chapter_id', true);
                $chapter_title = get_comment_meta($comment_id, '_chapter_title', true);
                
                if ($chapter_id && $chapter_title) {
                    $chapter_url = get_permalink($chapter_id);
                    ?>
                    <div class="comment-chapter-ref" style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid rgba(255,255,255,0.1); font-size: 0.85rem; color: #999;">
                        <i class="fa fa-book" style="margin-right: 0.5rem;"></i>
                        <span>Commented on: </span>
                        <a href="<?php echo esc_url($chapter_url); ?>" style="color: #13667a; text-decoration: none; font-weight: 500;">
                            <?php echo esc_html($chapter_title); ?>
                        </a>
                    </div>
                    <?php
                }
            }
            ?>
        </div>

            <div class="comment-actions">
                <button class="comment-like <?php echo (isset($user_reaction) && $user_reaction === 'like') ? 'active' : ''; ?>"
                        data-id="<?php echo $comment_id; ?>"
                        data-action="like"
                        title="Appreciate">
                    <i class="far fa-thumbs-up"></i>
                    <span class="count"><?php echo $likes; ?></span>
                </button>

                <button class="comment-dislike <?php echo (isset($user_reaction) && $user_reaction === 'dislike') ? 'active' : ''; ?>"
                        data-id="<?php echo $comment_id; ?>"
                        data-action="dislike"
                        title="Dislike">
                    <i class="far fa-thumbs-down"></i>
                    <span class="count"><?php echo $dislikes; ?></span>
                </button>

                <button class="reply-btn" data-comment="<?php echo $comment_id; ?>">Răspuns</button>
            </div>
    </div>
    <?php

    // ✅ REGULA DE AUR: DOAR root comment (no parent) are buton și container replies
    $is_root = empty($comment->comment_parent);
    
    if ($is_root) {
        // Găsește TOȚI descendenții (recursiv, nu doar direct children)
        $all_descendants = mangayummy_get_all_comment_descendants($comment_id);
        
        if ($all_descendants) {
            $total_replies = count($all_descendants);
            echo '<button class="toggle-replies" data-comment-id="' . $comment_id . '" data-count="' . $total_replies . '">Afișează răspunsurile (' . $total_replies . ')</button>';
            echo '<div class="comment-replies" data-parent-id="' . $comment_id . '">';
            foreach ($all_descendants as $reply) {
                echo mangayummy_render_comment($reply);
            }
            echo '</div>';
        }
    }
    // ❌ NU randa buton nici container la reply-uri

    return ob_get_clean();
}

// Comment reporting handler (edit/delete handlers consolidated to mangayummy_edit_comment and mangayummy_delete_comment)
add_action('wp_ajax_mangayummy_report_comment', function() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'mangayummy_comment_nonce')) {
        wp_send_json_error(['message' => 'Eroare verificare']);
    }
    
    $comment_id = intval($_POST['comment_id'] ?? 0);
    $reason = sanitize_text_field($_POST['reason'] ?? '');
    
    if (!$comment_id || !$reason) {
        wp_send_json_error(['message' => 'Date incomplete']);
    }
    
    // Check if already reported
    $reported = get_comment_meta($comment_id, '_reported', true);
    if ($reported) {
        wp_send_json_error(['message' => 'Comment already reported']);
    }
    
    // Mark as reported with reason + timestamp
    $report_data = [
        'reason' => $reason,
        'timestamp' => time(),
        'user_id' => get_current_user_id()
    ];
    add_comment_meta($comment_id, '_reported', $report_data, true);
    wp_send_json_success(['message' => 'Report submitted']);
});

add_action('wp_ajax_nopriv_mangayummy_report_comment', function() {
    wp_send_json_error(['message' => 'Trebuie să fii autentificat']);
});

// Reported Comments is now grouped under top-level Administration menu.

// NOTE: IndexNow and Cache settings are now consolidated into the main MangaYummy Settings page
// See mangayummy_settings_page() function for the unified settings interface with tabs

// Settings functions consolidated into mangayummy_settings_page() below

add_action('transition_post_status', 'mangayummy_cloudflare_purge_on_publish', 10, 3);
function mangayummy_cloudflare_purge_on_publish($new_status, $old_status, $post) {
    // Only trigger on new publishes (not updates / status changes)
    if ($new_status !== 'publish' || $old_status === 'publish') {
        return;
    }

    if (!in_array($post->post_type, ['manga', 'chapter'], true)) {
        return;
    }

    $zone_id = get_option('mangayummy_cf_zone_id', '');
    $api_token = get_option('mangayummy_cf_api_token', '');
    if (empty($zone_id) || empty($api_token)) {
        return;
    }

    $endpoint = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode($zone_id) . '/purge_cache';
    $body = wp_json_encode(['files' => ['https://mangayummy.com/']]);

    $response = wp_remote_post($endpoint, [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_token,
            'Content-Type' => 'application/json',
        ],
        'body' => $body,
        // Non-blocking: don’t wait for Cloudflare to respond so publishing is not delayed.
        'blocking' => false,
        // Use a minimal timeout so requests are fire-and-forget.
        'timeout' => 0.01,
    ]);

    if (defined('WP_DEBUG') && WP_DEBUG) {
        if (is_wp_error($response)) {
        } else {
        }
    }
}

function mangayummy_reported_comments_page() {
    ?>
    <div class="wrap">
        <h1>Reported Comments</h1>
        
        <?php
        // Get all comments with _reported meta
        $args = [
            'meta_key' => '_reported',
            'orderby' => 'comment_date',
            'order' => 'DESC',
            'number' => 100
        ];
        $comments = get_comments($args);
        
        if (empty($comments)) {
            echo '<p>No reported comments.</p>';
            return;
        }
        ?>
        
        <table class="wp-list-table widefat striped">
            <thead>
                <tr>
                    <th>Author</th>
                    <th>Manga</th>
                    <th>Comment</th>
                    <th>Reason</th>
                    <th>Reported At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($comments as $comment) : 
                    $post = get_post($comment->comment_post_ID);
                    $report_data = get_comment_meta($comment->comment_ID, '_reported', true);
                    $reported_reason = is_array($report_data) ? $report_data['reason'] : 'Necunoscut';
                    $reported_time = is_array($report_data) ? $report_data['timestamp'] : 0;
                    $reported_date = $reported_time ? date('d.m.Y H:i', $reported_time) : 'N/A';
                    
                    // Link la comentariu pe frontend
                    $comment_link = '';
                    if ($post) {
                        $comment_link = get_permalink($post->ID) . '#comment-' . $comment->comment_ID;
                    }
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html($comment->comment_author); ?></strong></td>
                        <td><?php echo $post ? '<a href="' . get_edit_post_link($post->ID) . '" target="_blank">' . esc_html($post->post_title) . '</a>' : 'Deleted'; ?></td>
                        <td>
                            <div style="max-width: 400px; max-height: 100px; overflow-y: auto; padding: 8px; background: #f5f5f5; border-radius: 4px; font-size: 13px;">
                                <?php echo wp_kses_post($comment->comment_content); ?>
                            </div>
                            <?php if ($comment_link) : ?>
                                <br><a href="<?php echo esc_url($comment_link); ?>" class="button button-small" target="_blank" style="margin-top: 5px;">Visit Comment →</a>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo esc_html($reported_reason); ?></strong></td>
                        <td><?php echo esc_html($reported_date); ?></td>
                        <td>
                            <a href="<?php echo get_edit_comment_link($comment->comment_ID); ?>" class="button" target="_blank">Edit</a>
                            <a href="<?php echo wp_nonce_url(admin_url('comment.php?action=deletecomment&c=' . $comment->comment_ID), 'delete-comment_' . $comment->comment_ID); ?>" class="button button-link-delete" onclick="return confirm('Are you sure?')">Delete</a>
                            <a href="<?php echo add_query_arg('clear', $comment->comment_ID); ?>" class="button" onclick="return confirm('Delete report?')">Clear Report</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php
        // Handle "clear report" action
        if (isset($_GET['clear']) && current_user_can('moderate_comments')) {
            $comment_id = intval($_GET['clear']);
            delete_comment_meta($comment_id, '_reported');
            echo '<div class="notice notice-success"><p>Report cleared.</p></div>';
        }
        ?>
    </div>
    <?php
}

/* ================================
   COMMENT NOTIFICATIONS SYSTEM
   ================================ */

/**
 * Get unread notification count for current user
 * Includes: comment_notifications + private_messages (system notifications with sender_id = 0)
 */
function mangayummy_get_notification_count() {
    if (!is_user_logged_in()) return 0;
    
    global $wpdb;
    $user_id = get_current_user_id();
    
    // Count from comment_notifications
    $comment_notifs = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}comment_notifications 
             WHERE user_id = %d AND is_read = 0",
            $user_id
        )
    );
    
    // Count from private_messages (system notifications only - sender_id = 0)
    $message_notifs = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}private_messages 
             WHERE receiver_id = %d AND sender_id = 0 AND is_read = 0",
            $user_id
        )
    );
    
    return $comment_notifs + $message_notifs;
}

/**
 * AJAX: Mark notification as read
 */
add_action('wp_ajax_mangayummy_mark_notif_read', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in']);
    }

    $notif_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$notif_id) {
        wp_send_json_error(['message' => 'Invalid notification ID']);
    }

    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'comment_notifications',
        ['is_read' => 1],
        ['id' => $notif_id, 'user_id' => get_current_user_id()],
        ['%d'],
        ['%d', '%d']
    );

    wp_send_json_success(['count' => mangayummy_get_notification_count()]);
});

/**
 * AJAX: Get all notifications for dropdown
 */
add_action('wp_ajax_mangayummy_get_notifications', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in']);
    }

    global $wpdb;
    $notifs = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}comment_notifications
             WHERE user_id = %d
             ORDER BY created_at DESC
             LIMIT 20",
            get_current_user_id()
        )
    );

    $html = '';
    if ($notifs) {
        foreach ($notifs as $n) {
            $reply_comment = get_comment($n->reply_id);
            $parent_comment = get_comment($n->comment_id);
            
            if (!$reply_comment || !$parent_comment) {
                continue;
            }
            
            $reply_author = get_comment_author($n->reply_id);
            $parent_link = get_comment_link($n->comment_id);
            $reply_link = $parent_link . '?reply_id=' . $n->reply_id . '#comment-' . $n->reply_id;
            
            $html .= '<li data-id="' . intval($n->id) . '" class="notif-item' . ($n->is_read ? '' : ' unread') . '">';
            $html .= '<a href="' . esc_url($reply_link) . '" class="notif-link">';
            
            // Check notification type
            if (isset($n->type) && $n->type === 'mention') {
                $html .= '<strong>' . esc_html($reply_author) . '</strong> te-a menționat într-un comentariu';
            } else {
                $html .= '<strong>' . esc_html($reply_author) . '</strong> ți-a răspuns';
            }
            
            $html .= '</a></li>';
        }
    }
    
    if (!$html) {
        $html = '<li class="notif-empty">Nu sunt notificări</li>';
    }

    wp_send_json_success(['html' => $html, 'count' => mangayummy_get_notification_count()]);
});

// System avatar helper (used for system/private messages)
function mangayummy_get_system_avatar() {
    $custom = get_option('mangayummy_system_avatar');
    if (!empty($custom)) {
        return esc_url($custom);
    }
    $template_dir = get_template_directory();
    $system_asset = $template_dir . '/assets/img/system-avatar.png';
    $logo = $template_dir . '/assets/img/logo.png';
    $fallback = $template_dir . '/assets/img/default-avatar.png';
    
    // Return first existing file
    if (file_exists($system_asset)) {
        return esc_url(get_template_directory_uri() . '/assets/img/system-avatar.png');
    }
    if (file_exists($logo)) {
        return esc_url(get_template_directory_uri() . '/assets/img/logo.png');
    }
    return esc_url(get_template_directory_uri() . '/assets/img/default-avatar.png');
}

// ===== WP ADMIN SETTINGS =====
add_action('admin_menu', 'mangayummy_register_settings_top_level_menu');
function mangayummy_register_settings_top_level_menu() {
    add_menu_page(
        'MangaYummy Settings',
        'MangaYummy Settings',
        'manage_options',
        'mangayummy_settings',
        'mangayummy_settings_theme_page',
        'dashicons-admin-generic',
        64
    );

    add_submenu_page(
        'mangayummy_settings',
        'Theme Settings',
        'Theme Settings',
        'manage_options',
        'mangayummy_settings',
        'mangayummy_settings_theme_page'
    );

    add_submenu_page(
        'mangayummy_settings',
        'IndexNow',
        'IndexNow',
        'manage_options',
        'mangayummy-settings-indexnow',
        'mangayummy_settings_indexnow_page'
    );

    add_submenu_page(
        'mangayummy_settings',
        'Cache / Cloudflare',
        'Cache / Cloudflare',
        'manage_options',
        'mangayummy-settings-cache',
        'mangayummy_settings_cache_page'
    );

    add_submenu_page(
        'mangayummy_settings',
        'GIPHY API',
        'GIPHY API',
        'manage_options',
        'mangayummy-settings-giphy',
        'mangayummy_settings_giphy_page'
    );
}

function mangayummy_settings_theme_page() {
    $_GET['tab'] = 'theme';
    mangayummy_settings_page();
}

function mangayummy_settings_indexnow_page() {
    $_GET['tab'] = 'indexnow';
    mangayummy_settings_page();
}

function mangayummy_settings_cache_page() {
    $_GET['tab'] = 'cache';
    mangayummy_settings_page();
}

function mangayummy_settings_giphy_page() {
    $_GET['tab'] = 'giphy';
    mangayummy_settings_page();
}

function mangayummy_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'theme';
    if (!in_array($tab, ['theme', 'indexnow', 'cache', 'giphy'], true)) {
        $tab = 'theme';
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('mangayummy_settings_nonce');

        if ($tab === 'indexnow' && isset($_POST['mangayummy_indexnow_key'])) {
            update_option('mangayummy_indexnow_key', sanitize_text_field($_POST['mangayummy_indexnow_key']));
            echo '<div class="notice notice-success"><p>IndexNow settings saved.</p></div>';
        }

        if ($tab === 'cache') {
            if (isset($_POST['mangayummy_cf_zone_id'])) {
                update_option('mangayummy_cf_zone_id', sanitize_text_field($_POST['mangayummy_cf_zone_id']));
            }
            if (isset($_POST['mangayummy_cf_api_token'])) {
                update_option('mangayummy_cf_api_token', sanitize_text_field($_POST['mangayummy_cf_api_token']));
            }
            echo '<div class="notice notice-success"><p>Cache / Cloudflare settings saved.</p></div>';
        }

        if ($tab === 'giphy' && isset($_POST['mangayummy_giphy_api_key'])) {
            update_option('mangayummy_giphy_api_key', sanitize_text_field($_POST['mangayummy_giphy_api_key']));
            echo '<div class="notice notice-success"><p>GIPHY API settings saved.</p></div>';
        }
    }

    $indexnow_key = get_option('mangayummy_indexnow_key', '');
    $cf_zone_id = get_option('mangayummy_cf_zone_id', '');
    $cf_api_token = get_option('mangayummy_cf_api_token', '');
    $giphy_api_key = get_option('mangayummy_giphy_api_key', '');

    ?>
    <div class="wrap">
        <h1>MangaYummy Settings</h1>

        <nav class="nav-tab-wrapper" style="margin-bottom: 18px;">
            <a href="<?php echo esc_url(admin_url('admin.php?page=mangayummy_settings')); ?>" class="nav-tab <?php echo $tab === 'theme' ? 'nav-tab-active' : ''; ?>">Theme Settings</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=mangayummy-settings-indexnow')); ?>" class="nav-tab <?php echo $tab === 'indexnow' ? 'nav-tab-active' : ''; ?>">IndexNow</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=mangayummy-settings-cache')); ?>" class="nav-tab <?php echo $tab === 'cache' ? 'nav-tab-active' : ''; ?>">Cache / Cloudflare</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=mangayummy-settings-giphy')); ?>" class="nav-tab <?php echo $tab === 'giphy' ? 'nav-tab-active' : ''; ?>">GIPHY API</a>
        </nav>

        <?php if ($tab === 'theme'): ?>
            <p class="description">No theme message settings available.</p>
        <?php elseif ($tab === 'indexnow'): ?>
            <form method="POST">
                <?php wp_nonce_field('mangayummy_settings_nonce'); ?>
                <h2>IndexNow</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="mangayummy_indexnow_key">IndexNow Key</label></th>
                        <td>
                            <input type="text" id="mangayummy_indexnow_key" name="mangayummy_indexnow_key" class="regular-text" value="<?php echo esc_attr($indexnow_key); ?>">
                            <p class="description">Used to ping IndexNow for new published chapters.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save IndexNow settings'); ?>
            </form>
        <?php elseif ($tab === 'cache'): ?>
            <form method="POST">
                <?php wp_nonce_field('mangayummy_settings_nonce'); ?>
                <h2>Cache / Cloudflare</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="mangayummy_cf_zone_id">Cloudflare Zone ID</label></th>
                        <td><input type="text" id="mangayummy_cf_zone_id" name="mangayummy_cf_zone_id" class="regular-text" value="<?php echo esc_attr($cf_zone_id); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="mangayummy_cf_api_token">Cloudflare API Token</label></th>
                        <td><input type="text" id="mangayummy_cf_api_token" name="mangayummy_cf_api_token" class="regular-text" value="<?php echo esc_attr($cf_api_token); ?>"></td>
                    </tr>
                </table>
                <?php submit_button('Save Cloudflare settings'); ?>
            </form>
        <?php else: ?>
            <form method="POST">
                <?php wp_nonce_field('mangayummy_settings_nonce'); ?>
                <h2>GIPHY API</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="mangayummy_giphy_api_key">GIPHY API Key</label></th>
                        <td>
                            <input type="text" id="mangayummy_giphy_api_key" name="mangayummy_giphy_api_key" class="regular-text" value="<?php echo esc_attr($giphy_api_key); ?>">
                            <p class="description">Used for GIF search/trending in comments and chat.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save GIPHY settings'); ?>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

/* ================================
   ADVANCED SEARCH FILTERING by Author/Artist
   ================================ */
function mangayummy_filter_by_author_artist( $query ) {
    if ( ! $query->is_main_query() || is_admin() ) {
        return;
    }

    $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field($_SERVER['REQUEST_URI']) : '';
    if ( ! is_page( 'browse' ) && ! is_page( 'cautare-avansata' ) && strpos($request_uri, '/browse') !== 0 && strpos($request_uri, '/cautare-avansata') !== 0 && ! isset( $_GET['author'] ) && ! isset( $_GET['artist'] ) && ! isset( $_GET['genre'] ) ) {
        return;
    }

    // Start tax_query array
    $tax_query = [];

    // Filter by author taxonomy
    if ( isset( $_GET['author'] ) && ! empty( $_GET['author'] ) ) {
        $tax_query[] = [
            'taxonomy' => 'author',
            'field'    => 'slug',
            'terms'    => sanitize_text_field( $_GET['author'] ),
        ];
    }

    // Filter by artist taxonomy
    if ( isset( $_GET['artist'] ) && ! empty( $_GET['artist'] ) ) {
        $tax_query[] = [
            'taxonomy' => 'artist',
            'field'    => 'slug',
            'terms'    => sanitize_text_field( $_GET['artist'] ),
        ];
    }

    // Apply tax_query if filters exist
    if ( ! empty( $tax_query ) ) {
        if ( count( $tax_query ) > 1 ) {
            $tax_query['relation'] = 'AND';
        }
        $query->set( 'tax_query', $tax_query );
        $query->set( 'post_type', 'manga' );
    }
}
add_action( 'pre_get_posts', 'mangayummy_filter_by_author_artist' );

// Modify search query to show 40 results per page and only manga posts
function mangayummy_modify_search_query($query) {
    if ($query->is_search && $query->is_main_query() && !is_admin()) {
        $query->set('post_type', array('manga'));
        $query->set('posts_per_page', 40);
    }
}
add_action('pre_get_posts', 'mangayummy_modify_search_query');

/* ================================
   MANGAYUMMY – SOCIAL USER SEARCH
   ================================ */

require get_template_directory() . '/inc/user-router.php';

/* ════════════════════════════════════════════════════════════════════════
   LOGIN AJAX HANDLER
   ════════════════════════════════════════════════════════════════════════ */

// Check if user is authenticated (AJAX endpoint)
function mangayummy_check_auth() {
    wp_send_json([
        'authenticated' => is_user_logged_in(),
        'user_id' => get_current_user_id()
    ]);
}
add_action('wp_ajax_mangayummy_check_auth', 'mangayummy_check_auth');
add_action('wp_ajax_nopriv_mangayummy_check_auth', 'mangayummy_check_auth');

// AJAX: Register User via Frontend Form - DISABLED (use ya_register from auth-register.php instead)
// This handler allowed registration without email verification - security risk
// add_action('wp_ajax_nopriv_mangayummy_register_user', function() { ... });

// Get unread messages count for current user (notifications + system messages, NOT friend chats)
function mangayummy_get_unread_messages_count() {
    if (!is_user_logged_in()) {
        return 0;
    }
    global $wpdb;
    $user_id = get_current_user_id();
    
    // Count unread notifications ([NOTIF] or [NOTIF:link] prefix) AND system messages (sender_id = 0)
    // Exclude friend request notification row to avoid double counting with friend_requests meta.
    $unread_notifs = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}private_messages
             WHERE receiver_id = %d
               AND is_read = 0
               AND (
                   sender_id = 0
                   OR (message LIKE '[NOTIF%%' AND message NOT LIKE '[NOTIF]ți-a trimis o cerere de prietenie')
               )",
            $user_id
        )
    );
    
    // Count pending friend requests
    $friend_requests = get_user_meta($user_id, 'friend_requests', true);
    $pending_requests = is_array($friend_requests) ? count($friend_requests) : 0;
    
    return $unread_notifs + $pending_requests;
}

// Get unread notifications count (manga_notifications table)
function mangayummy_unread_notifications_count($user_id) {
    if (!$user_id) {
        return 0;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'manga_notifications';

    return (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE user_id = %d AND is_read = 0",
            $user_id
        )
    );
}

// AJAX handler to get unread messages count (private messages + manga notifications + pending friend requests)
add_action('wp_ajax_mangayummy_get_unread_messages_count', function() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['count' => 0]);
    }

    global $wpdb;
    $user_id = get_current_user_id();

    // Count unread private messages ([NOTIF] or [NOTIF:link] prefix) AND system messages (sender_id = 0)
    // Exclude friend request notifications so they are not counted twice.
    $unread_notifs = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}private_messages
             WHERE receiver_id = %d
               AND is_read = 0
               AND (
                   sender_id = 0
                   OR (message LIKE '[NOTIF%%' AND message NOT LIKE '[NOTIF]ți-a trimis o cerere de prietenie')
               )",
            $user_id
        )
    );

    // Count unread manga notifications (follower notifications)
    $unread_manga_notifications = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}manga_notifications WHERE user_id = %d AND is_read = 0",
            $user_id
        )
    );

    // Count pending friend requests
    $friend_requests = get_user_meta($user_id, 'friend_requests', true);
    $pending_requests = is_array($friend_requests) ? count($friend_requests) : 0;

    wp_send_json_success(['count' => $unread_notifs + $unread_manga_notifications + $pending_requests]);
});

// ═════════════════════════════════════════════════════════════════════════════
// MANGA METABOX FOR FINAL CHAPTER
// ═════════════════════════════════════════════════════════════════════════════

add_action('add_meta_boxes', function() {
    add_meta_box(
        'manga_final_chapter',
        'Capitolul Final',
        'mangayummy_manga_final_chapter_callback',
        'manga',
        'normal',
        'default'
    );
});

function mangayummy_manga_final_chapter_callback($post) {
    wp_nonce_field('manga_final_chapter_nonce', 'manga_final_chapter_nonce');
    $final_chapter = get_post_meta($post->ID, '_final_chapter', true);
    ?>
    <div style="padding: 10px 0;">
        <label for="manga_final_chapter_field" style="display: block; margin-bottom: 8px;">
            <strong>Numărul Capitolului Final:</strong>
        </label>
        <input 
            type="text" 
            id="manga_final_chapter_field" 
            name="manga_final_chapter_field" 
            value="<?php echo esc_attr($final_chapter); ?>" 
            placeholder="ex: 500 sau 250.5"
            style="width: 100%; max-width: 300px; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"
        />
        <p style="margin-top: 8px; color: #666; font-size: 12px;">
            Introdu numărul capitolului final (de ex: 500, 250.5)
        </p>
    </div>
    <?php
}

add_action('save_post_manga', function($post_id) {
    // Check nonce
    if (!isset($_POST['manga_final_chapter_nonce']) || !wp_verify_nonce($_POST['manga_final_chapter_nonce'], 'manga_final_chapter_nonce')) {
        return;
    }
    
    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save the final chapter
    if (isset($_POST['manga_final_chapter_field'])) {
        $final_chapter = sanitize_text_field($_POST['manga_final_chapter_field']);
        if ($final_chapter) {
            update_post_meta($post_id, '_final_chapter', $final_chapter);
        } else {
            delete_post_meta($post_id, '_final_chapter');
        }
    }
});

add_action('add_meta_boxes', 'mangayummy_add_stire_youtube_metabox');
function mangayummy_add_stire_youtube_metabox() {
    add_meta_box(
        'mangayummy_stire_youtube',
        'YouTube Video',
        'mangayummy_render_stire_youtube_metabox',
        'stire',
        'normal',
        'default'
    );
}

function mangayummy_render_stire_youtube_metabox($post) {
    wp_nonce_field('mangayummy_stire_youtube_nonce', 'mangayummy_stire_youtube_nonce');
    $youtube_url = get_post_meta($post->ID, '_stire_youtube_url', true);
    ?>
    <div style="padding: 10px 0;">
        <label for="mangayummy_stire_youtube_field" style="display: block; margin-bottom: 8px; font-weight: 600;">
            URL YouTube
        </label>
        <input
            type="url"
            id="mangayummy_stire_youtube_field"
            name="mangayummy_stire_youtube_field"
            value="<?php echo esc_attr($youtube_url); ?>"
            placeholder="https://www.youtube.com/watch?v=..."
            style="width: 100%; max-width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"
        />
        <p style="margin-top: 8px; color: #666; font-size: 12px;">
            Introdu un link YouTube valid. Se va salva ca embed și va fi afișat pe pagina știrii.
        </p>
    </div>
    <?php
}

add_action('add_meta_boxes', 'mangayummy_add_stire_cover_metabox');
function mangayummy_add_stire_cover_metabox() {
    add_meta_box(
        'mangayummy_stire_cover',
        'Imagine Știre (URL extern)',
        'mangayummy_render_stire_cover_metabox',
        'stire',
        'normal',
        'default'
    );
}

function mangayummy_render_stire_cover_metabox($post) {
    wp_nonce_field('mangayummy_stire_cover_nonce', 'mangayummy_stire_cover_nonce');
    $cover_url = get_post_meta($post->ID, '_stire_cover_url', true);
    ?>
    <div style="padding: 10px 0;">
        <label for="mangayummy_stire_cover_field" style="display: block; margin-bottom: 8px; font-weight: 600;">
            URL imagine copertă
        </label>
        <input
            type="url"
            id="mangayummy_stire_cover_field"
            name="mangayummy_stire_cover_field"
            value="<?php echo esc_attr($cover_url); ?>"
            placeholder="https://..."
            style="width: 100%; max-width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"
        />
        <p style="margin-top: 8px; color: #666; font-size: 12px;">
            Introdu un URL valid pentru imaginea știrii. Se va folosi ca imagine copertă externă.
        </p>
    </div>
    <?php
}

add_action('save_post_stire', 'mangayummy_save_stire_cover_meta');
function mangayummy_save_stire_cover_meta($post_id) {
    if (!isset($_POST['mangayummy_stire_cover_nonce']) || !wp_verify_nonce($_POST['mangayummy_stire_cover_nonce'], 'mangayummy_stire_cover_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['mangayummy_stire_cover_field'])) {
        $cover_raw = esc_url_raw($_POST['mangayummy_stire_cover_field']);
        if ($cover_raw) {
            update_post_meta($post_id, '_stire_cover_url', $cover_raw);
        } else {
            delete_post_meta($post_id, '_stire_cover_url');
        }
    }
}

add_action('save_post_stire', 'mangayummy_save_stire_youtube_meta');
function mangayummy_save_stire_youtube_meta($post_id) {
    if (!isset($_POST['mangayummy_stire_youtube_nonce']) || !wp_verify_nonce($_POST['mangayummy_stire_youtube_nonce'], 'mangayummy_stire_youtube_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['mangayummy_stire_youtube_field'])) {
        $youtube_raw = esc_url_raw($_POST['mangayummy_stire_youtube_field']);
        if ($youtube_raw) {
            $embed_url = mangayummy_get_youtube_embed_url($youtube_raw);
            if ($embed_url) {
                update_post_meta($post_id, '_stire_youtube_url', $embed_url);
            } else {
                delete_post_meta($post_id, '_stire_youtube_url');
            }
        } else {
            delete_post_meta($post_id, '_stire_youtube_url');
        }
    }
}

// Funcție pentru normalizarea numerelor de capitol (păstrează zecimale în format slug-safe)
function mangayummy_normalize_chapter_number($number) {
    $number = str_replace(',', '.', $number); // siguranță
    
    // Only apply decimal cleanup if the number contains a decimal point
    if (strpos($number, '.') !== false) {
        $number = rtrim($number, '0');             // 0.10 -> 0.1
        $number = rtrim($number, '.');              // 1. -> 1
    }
    
    $number = str_replace('.', '-', $number);   // 0.01 -> 0-01
    return $number;
}

// Migrate translation groups from meta to taxonomy
function mangayummy_migrate_translation_groups_to_taxonomy() {
    if (get_option('translation_groups_migrated_2')) {
        return;
    }

    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_translation_group',
                'compare' => 'EXISTS'
            )
        )
    ));

    foreach ($chapters as $chapter) {
        $group_name = get_post_meta($chapter->ID, '_translation_group', true);
        if (!empty($group_name)) {
            file_put_contents(__DIR__ . '/migration_debug.log', 'Chapter ' . $chapter->ID . ': ' . $group_name . PHP_EOL, FILE_APPEND);
            $term = term_exists($group_name, 'translator_group');
            if (!$term) {
                $term = wp_insert_term($group_name, 'translator_group', array('slug' => $group_name));
            }
            if (!is_wp_error($term)) {
                wp_set_post_terms($chapter->ID, $term['term_id'], 'translator_group', false);
            }
        }
    }

    update_option('translation_groups_migrated_2', 1);
}
// Function to get manga rank in top 100 by rating
function mangayummy_get_manga_rank($manga_id) {
    $manga_id = intval($manga_id);
    if ($manga_id <= 0) {
        return false;
    }

    $transient_key = 'mangayummy_manga_rank_' . $manga_id;
    $cached = get_transient($transient_key);
    if ($cached !== false) {
        return $cached;
    }

    global $wpdb;

    // Get this manga's rating (only if > 0)
    $rating = $wpdb->get_var($wpdb->prepare(
        "SELECT CAST(meta_value AS DECIMAL(10,4)) FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s LIMIT 1",
        $manga_id,
        '_rating_avg'
    ));

    if (!$rating || floatval($rating) <= 0) {
        set_transient($transient_key, false, 30 * MINUTE_IN_SECONDS);
        return false;
    }

    // Rank is 1 + number of manga with a higher rating
    $rank = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) + 1
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s
         WHERE p.post_type = 'manga'
           AND p.post_status = 'publish'
           AND CAST(pm.meta_value AS DECIMAL(10,4)) > %f",
        '_rating_avg',
        floatval($rating)
    ));

    $rank = $rank ? intval($rank) : false;
    if (!$rank) {
        set_transient($transient_key, false, 30 * MINUTE_IN_SECONDS);
        return false;
    }

    // Keep full ranking for all mangas (not capped to top 100), as requested.
    set_transient($transient_key, $rank, 30 * MINUTE_IN_SECONDS);
    return $rank;
}

if (!function_exists('mangayummy_get_anilist_rating_from_url')) {
    /**
     * Fetch AniList average score for a manga URL and normalize it to 10-point scale.
     *
     * @param string $anilist_url
     * @return array{score:float, raw:int, id:int, url:string}|false
     */
    function mangayummy_get_anilist_rating_from_url($anilist_url) {
        $anilist_url = esc_url_raw((string) $anilist_url);
        if (!$anilist_url) {
            return false;
        }

        if (!preg_match('~anilist\.co\/(?:manga\/)?(\d+)~i', $anilist_url, $matches)) {
            return false;
        }

        $media_id = intval($matches[1]);
        if ($media_id <= 0) {
            return false;
        }

        $cache_key = 'mangayummy_anilist_rating_' . $media_id;
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $query = <<<'GRAPHQL'
query($id: Int) {
  Media(id: $id, type: MANGA) {
    averageScore
  }
}
GRAPHQL;

        $response = wp_remote_post('https://graphql.anilist.co', [
            'timeout' => 8,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => wp_json_encode([
                'query' => $query,
                'variables' => ['id' => $media_id],
            ]),
        ]);

        if (is_wp_error($response)) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $raw_score = intval($json['data']['Media']['averageScore'] ?? 0);
        if ($raw_score <= 0) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $normalized_score = round($raw_score / 10, 1);
        $result = [
            'score' => $normalized_score,
            'raw' => $raw_score,
            'id' => $media_id,
            'url' => $anilist_url,
        ];

        set_transient($cache_key, $result, 3 * HOUR_IN_SECONDS);
        return $result;
    }
}

if (!function_exists('mangayummy_get_mal_rating_from_url')) {
    /**
     * Fetch MyAnimeList score for a manga URL using Jikan API.
     *
     * @param string $mal_url
     * @return array{score:float, raw:float, id:int, url:string}|false
     */
    function mangayummy_get_mal_rating_from_url($mal_url) {
        $mal_url = esc_url_raw((string) $mal_url);
        if (!$mal_url) {
            return false;
        }

        if (!preg_match('~myanimelist\.net\/manga\/(\d+)~i', $mal_url, $matches)) {
            return false;
        }

        $mal_id = intval($matches[1]);
        if ($mal_id <= 0) {
            return false;
        }

        $cache_key = 'mangayummy_mal_rating_' . $mal_id;
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $response = wp_remote_get('https://api.jikan.moe/v4/manga/' . $mal_id, [
            'timeout' => 8,
            'headers' => [
                'Accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $raw_score = floatval($json['data']['score'] ?? 0);
        if ($raw_score <= 0) {
            set_transient($cache_key, false, 30 * MINUTE_IN_SECONDS);
            return false;
        }

        $result = [
            'score' => round($raw_score, 1),
            'raw' => $raw_score,
            'id' => $mal_id,
            'url' => $mal_url,
        ];

        set_transient($cache_key, $result, 3 * HOUR_IN_SECONDS);
        return $result;
    }
}

// Invalidate rank cache when manga rating changes
add_action('updated_postmeta', function($meta_id, $post_id, $meta_key, $meta_value) {
    if ($meta_key !== '_rating_avg') {
        return;
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'manga') {
        return;
    }

    delete_transient('mangayummy_manga_rank_' . $post_id);
}, 10, 4);
add_action('admin_init', 'mangayummy_migrate_translation_groups_to_taxonomy');

// Admin User Management Functions
function mangayummy_add_user_admin_section($user) {
    if (!current_user_can('manage_options')) return;
    $allow_gif = get_user_meta($user->ID, '_allow_gif_uploads', true);
    ?>
    <h3>Admin Actions</h3>
    <table class="form-table">
        <tr>
            <th><label for="allow_gif_uploads">GIF Uploads</label></th>
            <td>
                <label><input type="checkbox" name="allow_gif_uploads" id="allow_gif_uploads" value="1" <?php checked($allow_gif, 1); ?>> Permite încărcarea de GIF-uri la avatar și banner</label>
                <p class="description">Când e activat, userul poate încărca imagini animate GIF la profil.</p>
            </td>
        </tr>
        <tr>
            <th><label for="user_level">Set Level</label></th>
            <td>
                <input type="number" name="user_level" id="user_level" value="<?php echo intval(get_user_meta($user->ID, 'reader_level', true)); ?>" min="0">
                <p class="description">Set user level manually.</p>
            </td>
        </tr>
        <tr>
            <th><label for="user_xp">Set XP</label></th>
            <td>
                <input type="number" name="user_xp" id="user_xp" value="<?php echo intval(get_user_meta($user->ID, 'reader_xp', true)); ?>" min="0">
                <span id="xp_level_preview" style="margin-left: 10px; color: #13667a; font-weight: bold;"></span>
                <p class="description">Set user XP manually. Level will be calculated automatically (Level = XP / 150).</p>
                <script>
                document.getElementById('user_xp').addEventListener('input', function() {
                    var xp = parseInt(this.value) || 0;
                    var level = Math.floor(xp / 150);
                    if (level < 1) level = 1;
                    if (level > 999) level = 999;
                    document.getElementById('xp_level_preview').textContent = '→ Level ' + level;
                });
                // Trigger on page load
                document.getElementById('user_xp').dispatchEvent(new Event('input'));
                </script>
            </td>
        </tr>
        </tr>
        <tr>
            <th>Actions</th>
            <td>
                <?php
                $is_banned = get_user_meta($user->ID, '_banned', true);
                $muted_until = get_user_meta($user->ID, '_muted_until', true);
                $is_muted = $muted_until && time() < intval($muted_until);
                $is_invisible = get_user_meta($user->ID, '_invisible', true);
                ?>
                <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px;">
                    <?php if ($is_banned): ?>
                        <button type="submit" name="unban_user" value="1" class="button" style="background:#27ae60;color:#fff;border-color:#27ae60;">✓ Unban User</button>
                    <?php else: ?>
                        <button type="submit" name="ban_user" value="1" class="button" style="background:#e74c3c;color:#fff;border-color:#e74c3c;">🚫 Ban User</button>
                    <?php endif; ?>
                    
                    <?php if ($is_muted): ?>
                        <button type="submit" name="unmute_user" value="1" class="button" style="background:#27ae60;color:#fff;border-color:#27ae60;">🔊 Unmute</button>
                    <?php else: ?>
                        <button type="submit" name="mute_user" value="1" class="button" style="background:#f39c12;color:#fff;border-color:#f39c12;">🔇 Mute 1h</button>
                    <?php endif; ?>
                    
                    <?php if ($is_invisible): ?>
                        <button type="submit" name="make_visible" value="1" class="button" style="background:#27ae60;color:#fff;border-color:#27ae60;">👁 Make Visible</button>
                    <?php else: ?>
                        <button type="submit" name="make_invisible" value="1" class="button" style="background:#8e44ad;color:#fff;border-color:#8e44ad;">👻 Make Invisible</button>
                    <?php endif; ?>
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                    <button type="submit" name="reset_level" value="1" class="button" onclick="return confirm('Reset level și XP la 0?');">🔄 Reset Level</button>
                    <button type="submit" name="delete_ratings" value="1" class="button button-link-delete" onclick="return confirm('Șterge TOATE ratingurile acestui user?');">🗑 Delete Ratings</button>
                    <button type="button" onclick="mangayummy_loginAsUser(<?php echo $user->ID; ?>)" class="button button-primary">🔑 Login as User</button>
                </div>
            </td>
        </tr>
    </table>
    <script>
    function mangayummy_loginAsUser(userId) {
        if (confirm("Ești sigur că vrei să te loghezi ca acest utilizator? Vei fi redirectat la homepage.")) {
            var form = document.createElement("form");
            form.method = "POST";
            form.action = "<?php echo admin_url('admin-ajax.php'); ?>";
            
            var action = document.createElement("input");
            action.type = "hidden";
            action.name = "action";
            action.value = "mangayummy_login_as_user";
            form.appendChild(action);
            
            var userIdField = document.createElement("input");
            userIdField.type = "hidden";
            userIdField.name = "user_id";
            userIdField.value = userId;
            form.appendChild(userIdField);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    </script>
    <?php
}

function mangayummy_save_user_admin_section($user_id) {
    if (!current_user_can('manage_options')) return;
    
    // Allow GIF uploads
    if (isset($_POST['allow_gif_uploads'])) {
        update_user_meta($user_id, '_allow_gif_uploads', 1);
    } else {
        delete_user_meta($user_id, '_allow_gif_uploads');
    }
    
    // Set level (manual override)
    if (isset($_POST['user_level']) && !empty($_POST['user_level'])) {
        update_user_meta($user_id, 'reader_level', intval($_POST['user_level']));
    }
    
    // Set XP and auto-calculate level
    if (isset($_POST['user_xp'])) {
        $xp = intval($_POST['user_xp']);
        update_user_meta($user_id, 'reader_xp', $xp);
        
        // Auto-calculate level from XP (Level = XP / 150)
        $calculated_level = floor($xp / 150);
        if ($calculated_level < 1) $calculated_level = 1;
        if ($calculated_level > 999) $calculated_level = 999;
        update_user_meta($user_id, 'reader_level', $calculated_level);
    }
    
    // Reset level
    if (isset($_POST['reset_level'])) {
        update_user_meta($user_id, 'reader_level', 1);
        update_user_meta($user_id, 'reader_xp', 0);
    }
    
    // Ban/Unban
    if (isset($_POST['ban_user'])) {
        update_user_meta($user_id, '_banned', 1);
    }
    if (isset($_POST['unban_user'])) {
        delete_user_meta($user_id, '_banned');
    }
    
    // Mute/Unmute
    if (isset($_POST['mute_user'])) {
        update_user_meta($user_id, '_muted_until', time() + 3600); // Mute for 1 hour
    }
    if (isset($_POST['unmute_user'])) {
        delete_user_meta($user_id, '_muted_until');
    }
    
    // Invisible/Visible
    if (isset($_POST['make_invisible'])) {
        update_user_meta($user_id, '_invisible', 1);
    }
    if (isset($_POST['make_visible'])) {
        delete_user_meta($user_id, '_invisible');
    }
    
    // Delete ratings
    if (isset($_POST['delete_ratings'])) {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM $wpdb->usermeta WHERE user_id = %d AND meta_key LIKE 'manga_rated_%'", $user_id));
    }
}

add_action('show_user_profile', 'mangayummy_add_user_admin_section');
add_action('edit_user_profile', 'mangayummy_add_user_admin_section');
add_action('personal_options_update', 'mangayummy_save_user_admin_section');
add_action('edit_user_profile_update', 'mangayummy_save_user_admin_section');

// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN USERS LIST - CUSTOM COLUMNS (Banned, Email Verified)
// ═══════════════════════════════════════════════════════════════════════════════

// Add custom columns to users list
function mangayummy_add_user_columns($columns) {
    $columns['banned'] = 'Ban';
    $columns['email_verified'] = 'Email Verificat';
    return $columns;
}
add_filter('manage_users_columns', 'mangayummy_add_user_columns');

// Populate custom columns
function mangayummy_show_user_column_content($value, $column_name, $user_id) {
    if ($column_name === 'banned') {
        $is_banned = get_user_meta($user_id, '_banned', true);
        if ($is_banned) {
            return '<span style="color:#13667a;font-weight:bold;">🚫 BANAT</span>';
        }
        return '<span style="color:#52c41a;">✓</span>';
    }
    
    if ($column_name === 'email_verified') {
        $verified = get_user_meta($user_id, 'email_verified', true);
        // Legacy users (no meta) are considered verified
        if ($verified === '' || $verified === '1' || $verified === 1) {
            return '<span style="color:#52c41a;">✓ Verificat</span>';
        }
        return '<span style="color:#faad14;">⏳ Neverificat</span>';
    }
    
    return $value;
}
add_filter('manage_users_custom_column', 'mangayummy_show_user_column_content', 10, 3);

// Make columns sortable
function mangayummy_sortable_user_columns($columns) {
    $columns['banned'] = 'banned';
    $columns['email_verified'] = 'email_verified';
    return $columns;
}
add_filter('manage_users_sortable_columns', 'mangayummy_sortable_user_columns');

// Handle sorting by custom columns
function mangayummy_sort_users_by_custom_column($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    
    if ($orderby === 'banned') {
        $query->set('meta_key', '_banned');
        $query->set('orderby', 'meta_value');
    }
    
    if ($orderby === 'email_verified') {
        $query->set('meta_key', 'email_verified');
        $query->set('orderby', 'meta_value');
    }
}
add_action('pre_get_users', 'mangayummy_sort_users_by_custom_column');

// AJAX handler for login as user
function mangayummy_login_as_user() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    $user_id = intval($_POST['user_id']);
    $user = get_user_by('ID', $user_id);
    
    if (!$user) {
        wp_die('User not found');
    }
    
    // Store current admin user ID in session for logout
    if (!session_id()) session_start();
    $_SESSION['admin_impersonating'] = get_current_user_id();
    
    // Login as the user
    wp_set_auth_cookie($user_id, true);
    wp_set_current_user($user_id);
    
    wp_redirect(home_url());
    exit;
}
add_action('wp_ajax_mangayummy_login_as_user', 'mangayummy_login_as_user');

// Extract chapter images from source URL
function mangayummy_extract_chapter_images() {
    if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    
    $chapter_url = sanitize_url($_POST['chapter_url'] ?? '');
    if (empty($chapter_url)) {
        wp_send_json_error(['message' => 'URL-ul capitolului este necesar']);
    }
    
    // Make request to get HTML only
    $response = wp_remote_get($chapter_url, [
        'timeout' => 30,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'headers' => ['Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8']
    ]);
    
    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'Eroare la încărcarea paginii: ' . $response->get_error_message()]);
    }
    
    $html = wp_remote_retrieve_body($response);
    if (empty($html)) {
        wp_send_json_error(['message' => 'Pagină goală sau eroare']);
    }
    
    // Parse HTML
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML($html);
    libxml_clear_errors();
    
    $xpath = new DOMXPath($dom);
    
    // Find reader container
    $reader = $xpath->query("//*[@id='reader'] | //*[contains(@class, 'reader')]")->item(0);
    if (!$reader) {
        wp_send_json_error(['message' => 'Containerul reader nu a fost găsit']);
    }
    
    // Extract all img elements in order
    $imgs = $xpath->query('.//img', $reader);
    $image_urls = [];
    
    foreach ($imgs as $img) {
        $src = $img->getAttribute('data-src') ?: $img->getAttribute('src');
        if ($src) {
            // if src contains whitespace (e.g. page link + actual image) try to
            // pull out the real image URL only
            if (preg_match('/https?:\/\/[^\s"\']+\/wp-content\/uploads\/[^\s"\']+\.(?:png|jpe?g|webp)/i', $src, $m)) {
                $src = $m[0];
            }

            // Normalize URL and path
            if (!empty($src)) {
                $src = mangayummy_normalize_chapter_image_url($src);
            }

            // Normalize to absolute URL
            $absolute_url = mangayummy_normalize_url($src, $chapter_url);
            if ($absolute_url) {
                $absolute_url = mangayummy_normalize_chapter_image_url($absolute_url);
                $image_urls[] = $absolute_url;
            }
        }
    }
    
    // Filter images to keep only chapter pages
    $filtered_urls = array_filter($image_urls, function($url) {
        // ignore any URL with whitespace – prevents concatenated strings
        if (preg_match('/\s/', $url)) {
            return false;
        }

        // Must be from /wp-content/uploads/
        if (strpos($url, '/wp-content/uploads/') === false) {
            return false;
        }
        
        // Exclude URLs with ?resize=
        if (strpos($url, '?resize=') !== false) {
            return false;
        }
        
        // Exclude themes/
        if (strpos($url, '/themes/') !== false) {
            return false;
        }
        
        // Exclude assets/
        if (strpos($url, '/assets/') !== false) {
            return false;
        }
        
        // Exclude svg
        if (strpos(strtolower($url), '.svg') !== false) {
            return false;
        }
        
        // Exclude poster, logo, thumb, icon, avatar
        $exclude_keywords = ['poster', 'logo', 'thumb', 'icon', 'avatar'];
        foreach ($exclude_keywords as $keyword) {
            if (strpos(strtolower($url), $keyword) !== false) {
                return false;
            }
        }
        
        // Must have valid image extension
        $valid_extensions = ['.jpg', '.jpeg', '.png', '.webp'];
        $has_valid_ext = false;
        foreach ($valid_extensions as $ext) {
            if (strpos(strtolower($url), $ext) !== false) {
                $has_valid_ext = true;
                break;
            }
        }
        if (!$has_valid_ext) {
            return false;
        }
        
        // Additional: exclude if path contains resize or other non-full images
        // This covers images from other months/years that might not be chapter pages
        $path = parse_url($url, PHP_URL_PATH);
        if (preg_match('/\/\d{4}\/\d{2}\/.*-(\d+)x(\d+)\./', $path)) {
            // Looks like resized image (e.g., image-300x200.jpg)
            return false;
        }
        
        return true;
    });
    
    // Reset array keys to maintain order
    $filtered_urls = array_values($filtered_urls);
    
    if (empty($filtered_urls)) {
        wp_send_json_error(['message' => 'Nu s-au găsit imagini valide de capitol în containerul reader']);
    }
    
    wp_send_json_success(['images' => $filtered_urls]);
}

// Helper function to normalize URLs
function mangayummy_normalize_url($url, $base_url) {
    // If already absolute and https, return as is
    if (filter_var($url, FILTER_VALIDATE_URL) && strpos($url, 'https://') === 0) {
        return $url;
    }
    
    // Convert http to https
    if (strpos($url, 'http://') === 0) {
        $url = str_replace('http://', 'https://', $url);
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            return $url;
        }
    }
    
    // Handle protocol-relative
    if (strpos($url, '//') === 0) {
        return 'https:' . $url;
    }
    
    // Handle absolute paths
    if (strpos($url, '/') === 0) {
        $parsed = parse_url($base_url);
        return 'https://' . $parsed['host'] . $url;
    }
    
    // Handle relative URLs
    $parsed_base = parse_url($base_url);
    $base_path = isset($parsed_base['path']) ? dirname($parsed_base['path']) : '';
    if ($base_path === '/' || $base_path === '\\') $base_path = '';
    $absolute = $parsed_base['scheme'] . '://' . $parsed_base['host'] . '/' . ltrim($base_path . '/' . $url, '/');
    return str_replace('http://', 'https://', $absolute);
}

add_action('wp_ajax_mangayummy_extract_chapter_images', 'mangayummy_extract_chapter_images');

// Extract chapter images from Romanga.ro
function mangayummy_extract_chapter_images_romanga() {
    if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
        wp_send_json_error(['message' => 'Security error']);
    }
    
    $chapter_url = sanitize_url($_POST['chapter_url'] ?? '');
    if (empty($chapter_url)) {
        wp_send_json_error(['message' => 'URL-ul capitolului este necesar']);
    }
    
    // Validate it's from romanga.ro
    if (strpos($chapter_url, 'reader.romanga.ro') === false) {
        wp_send_json_error(['message' => 'URL-ul trebuie să fie de pe reader.romanga.ro']);
    }
    
    // Make request to get HTML
    $response = wp_remote_get($chapter_url, [
        'timeout' => 30,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'headers' => ['Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8']
    ]);
    
    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'Eroare la încărcarea paginii: ' . $response->get_error_message()]);
    }
    
    $html = wp_remote_retrieve_body($response);
    if (empty($html)) {
        wp_send_json_error(['message' => 'Pagină goală sau eroare']);
    }
    
    // Parse HTML
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML($html);
    libxml_clear_errors();
    
    $xpath = new DOMXPath($dom);
    
    $image_urls = [];
    
    // Method 1: Look for all img tags anywhere on the page that have WP-manga URLs
    $all_imgs = $xpath->query('//img');
    foreach ($all_imgs as $img) {
        $src = $img->getAttribute('data-src') ?: $img->getAttribute('data-lazy-src') ?: $img->getAttribute('src');

        // some Romanga pages have a space-separated list where the first part is
        // the manga/chapter link and the second part is the real image URL.  in
        // that case we only want the WP‑manga file, not the random page link.
        if ($src) {
            if (preg_match('/https?:\/\/[^\s"\']+\/wp-content\/uploads\/WP-manga\/data\/[^\s"\']+\.(?:png|jpe?g|webp)/i', $src, $m)) {
                $src = $m[0];
            }
        }

        if ($src && strpos($src, 'wp-content/uploads/WP-manga') !== false) {
            $absolute_url = mangayummy_normalize_url($src, $chapter_url);
            if ($absolute_url && !in_array($absolute_url, $image_urls)) {
                $image_urls[] = $absolute_url;
            }
        }
    }
    
    // Method 2: Look for WP-manga data in scripts
    if (empty($image_urls)) {
        $scripts = $xpath->query('//script');
        foreach ($scripts as $script) {
            $content = $script->textContent;
            if (strpos($content, 'wp_manga') !== false || strpos($content, 'chapter_preloaded_images') !== false) {
                // Try to extract chapter data
                if (preg_match('/chapter_preloaded_images[^}]*:\s*(\[[^\]]*\])/', $content, $matches)) {
                    $images_json = $matches[1];
                    $images = json_decode($images_json, true);
                    if (is_array($images)) {
                        foreach ($images as $img) {
                            if (is_string($img) && filter_var($img, FILTER_VALIDATE_URL)) {
                                $image_urls[] = $img;
                            }
                        }
                    }
                }
                
                // Also look for manga_id and chapter_hash
                if (preg_match('/manga_id[^:]*:\s*["\']([^"\']+)["\']/', $content, $matches)) {
                    $manga_id = $matches[1];
                }
                if (preg_match('/chapter_hash[^:]*:\s*["\']([^"\']+)["\']/', $content, $matches)) {
                    $chapter_hash = $matches[1];
                }
            }
        }
    }
    
    // Method 3: If we have manga_id and chapter_hash, try to generate URLs
    // NOTE: Disabled — generating URLs from saved chapter_hash can produce expired CDN links (causes 404).
    // To re-enable, remove the `false &&` condition and ensure upstream CDN URLs are valid.
    if (false && empty($image_urls) && isset($manga_id) && isset($chapter_hash)) {
        $base_url = 'https://reader.romanga.ro/wp-content/uploads/WP-manga/data/manga_' . $manga_id . '/' . $chapter_hash . '/';
        
        // Try to find the number of pages by parsing the HTML for patterns
        $page_count = 0;
        if (preg_match_all('/\/(\d+)\.png/', $html, $matches)) {
            $page_numbers = array_map('intval', $matches[1]);
            if (!empty($page_numbers)) {
                $page_count = max($page_numbers);
            }
        }
        
        // If no pattern found, try to find in scripts or other places
        if ($page_count == 0) {
            // Look for chapter_pages or similar in scripts
            $scripts = $xpath->query('//script');
            foreach ($scripts as $script) {
                $content = $script->textContent;
                if (preg_match('/chapter_pages[^:]*:\s*(\d+)/', $content, $matches)) {
                    $page_count = intval($matches[1]);
                    break;
                }
                if (preg_match('/total_pages[^:]*:\s*(\d+)/', $content, $matches)) {
                    $page_count = intval($matches[1]);
                    break;
                }
            }
        }
        
        if ($page_count == 0) {
            // Fallback: try up to 100 pages, but limit to avoid too many requests
            $page_count = 50;
        }
        
        // Generate URLs without checking existence (faster)
        for ($i = 1; $i <= $page_count; $i++) {
            $image_url = $base_url . str_pad($i, 3, '0', STR_PAD_LEFT) . '.png';
            $image_urls[] = $image_url;
        }
    }
    
    // Method 4: Last resort - look for any URLs in the HTML that match the pattern
    if (empty($image_urls)) {
        if (preg_match_all('/https:\/\/reader\.romanga\.ro\/wp-content\/uploads\/WP-manga\/data\/[^"\']*\.(png|jpg|jpeg|webp)/i', $html, $matches)) {
            $image_urls = array_unique($matches[0]);
        }
    }
    
    // Filter and validate images
    $filtered_urls = array_filter($image_urls, function($url) {
        // ignore any URL that contains whitespace – this catches the
        // "manga page + image" strings that were being pushed as a single row
        if (preg_match('/\s/', $url)) {
            return false;
        }

        // Must be from WP-manga data directory
        if (strpos($url, '/wp-content/uploads/WP-manga/data/') === false) {
            return false;
        }
        
        // Must have valid image extension
        $valid_extensions = ['.jpg', '.jpeg', '.png', '.webp'];
        $has_valid_ext = false;
        foreach ($valid_extensions as $ext) {
            if (strpos(strtolower($url), $ext) !== false) {
                $has_valid_ext = true;
                break;
            }
        }
        return $has_valid_ext;
    });
    
    $filtered_urls = array_values(array_unique($filtered_urls));
    
    if (empty($filtered_urls)) {
        // Debug info
        $debug_info = 'HTML length: ' . strlen($html) . '. ';
        $debug_info .= 'Found ' . $all_imgs->length . ' img tags total. ';
        if (isset($manga_id)) $debug_info .= 'Manga ID: ' . $manga_id . '. ';
        if (isset($chapter_hash)) $debug_info .= 'Chapter hash: ' . $chapter_hash . '. ';
        
        wp_send_json_error(['message' => 'Nu s-au găsit imagini valide de capitol pentru Romanga.ro. ' . $debug_info]);
    }
    
    wp_send_json_success(['images' => $filtered_urls]);
}


add_action('wp_ajax_mangayummy_extract_chapter_images_romanga', 'mangayummy_extract_chapter_images_romanga');

add_action('wp_enqueue_scripts', function () {
    // page slug might not be "settings" in Romanian; also load by template name
    if (!is_page('settings') && !is_page_template('page-settings.php')) return;

    // Load Cropper.js for image cropping
    wp_enqueue_style(
        'cropperjs-css',
        'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css',
        [],
        '1.6.1'
    );
    wp_enqueue_script(
        'cropperjs',
        'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js',
        [],
        '1.6.1',
        true
    );

    // Cache bust with filemtime
    $css_path = get_template_directory() . '/css/settings.css';
    $js_path = get_template_directory() . '/js/settings.js';
    $css_ver = file_exists($css_path) ? filemtime($css_path) : '1.0';
    $js_ver = file_exists($js_path) ? filemtime($js_path) : '1.0';

    wp_enqueue_style(
        'ya-settings-css',
        get_template_directory_uri() . '/css/settings.css?v=' . $css_ver,
        ['cropperjs-css'],
        null
    );

    wp_enqueue_script(
        'ya-settings-js',
        get_template_directory_uri() . '/js/settings.js?v=' . $js_ver,
        ['jquery', 'cropperjs'],
        null,
        true
    );

    // prepare reader preferences for inline script (helper returns defaults)
    // note: $reader_prefs['genres'] now lists *blocked* genres when checked
    $reader_prefs = mangayummy_get_reader_prefs();

    wp_add_inline_script('ya-settings-js', '
        window.YA_SETTINGS = {
            ajaxurl: "' . admin_url('admin-ajax.php') . '",
            nonce: "' . wp_create_nonce('ya_ajax_nonce') . '",
            readerPrefs: ' . json_encode($reader_prefs) . '
        };
    ', 'before');

}, 1000);

// ===== UPDATE ALTERNATIVE TITLES SEARCH META FOR ALL MANGAS (RUNS ONCE) =====
function mangayummy_update_alternative_titles_search_meta() {
    // Check if already updated
    if (get_option('mangayummy_alt_titles_search_updated')) {
        return;
    }
    
    $args = array(
        'post_type' => 'manga',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_alternative_titles',
                'compare' => 'EXISTS'
            )
        )
    );
    
    $mangas = get_posts($args);
    
    foreach ($mangas as $manga) {
        $alternative_titles = get_post_meta($manga->ID, '_alternative_titles', true);
        if (!empty($alternative_titles)) {
            if (!is_array($alternative_titles)) {
                $alternative_titles = [$alternative_titles];
            }
            update_post_meta($manga->ID, '_alternative_titles_search', implode(' ', $alternative_titles));
        }
    }
    
    // Also check for 'alternative_names' meta
    $args2 = array(
        'post_type' => 'manga',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => 'alternative_names',
                'compare' => 'EXISTS'
            )
        )
    );
    
    $mangas2 = get_posts($args2);
    
    foreach ($mangas2 as $manga) {
        $alt_names = get_post_meta($manga->ID, 'alternative_names', true);
        if (!empty($alt_names) && !get_post_meta($manga->ID, '_alternative_titles_search', true)) {
            // Only update if _alternative_titles_search doesn't exist
            update_post_meta($manga->ID, '_alternative_titles_search', $alt_names);
        }
    }
    
    // Mark as completed
    update_option('mangayummy_alt_titles_search_updated', true);
}

// ===== TEST AJAX HANDLERS FOR SEARCH TESTING =====

// Test authors AJAX
add_action('wp_ajax_mangayummy_test_authors', 'mangayummy_test_authors_ajax');
add_action('wp_ajax_nopriv_mangayummy_test_authors', 'mangayummy_test_authors_ajax');

function mangayummy_test_authors_ajax() {
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
            wp_send_json_error(['message' => 'Security error']);
        }

        global $wpdb;
        // Get meta values
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != '' ORDER BY meta_value ASC",
                '_author'
            )
        );

        // Also include taxonomy terms from 'author'
        $term_names = [];
        $terms = get_terms(['taxonomy' => 'author', 'hide_empty' => false]);
        if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $t) $term_names[] = $t->name;
        }

        $names = [];

        foreach ($term_names as $tn) {
            $tn = trim($tn);
            if ($tn === '') continue;
            if (strlen($tn) > 100) continue;
            $names[strtolower($tn)] = $tn;
        }

        foreach ($rows as $row) {
            $parts = preg_split('/\s*(?:,|;|\/|\\\\|&|\band\b|\bwith\b|\bfeat\b\.?|\bft\b\.?|\+)\s*/i', $row);
            foreach ($parts as $part) {
                $name = trim(preg_replace('/\s+/', ' ', $part));
                if ($name === '') continue;
                if (preg_match('/<[^>]*>/', $name)) continue;
                if (strlen($name) > 100) continue;
                $names[strtolower($name)] = $name;
            }
        }

        natcasesort($names);
        $authors = array_values($names);

        wp_send_json_success([
            'count' => count($authors),
            'authors' => array_slice($authors, 0, 500),
            'status' => 'success'
        ]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'Error: ' . $e->getMessage()]);
    }
}

// Test artists AJAX
add_action('wp_ajax_mangayummy_test_artists', 'mangayummy_test_artists_ajax');
add_action('wp_ajax_nopriv_mangayummy_test_artists', 'mangayummy_test_artists_ajax');

function mangayummy_test_artists_ajax() {
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
            wp_send_json_error(['message' => 'Security error']);
        }

        global $wpdb;
        // Get meta-based artist values
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != '' ORDER BY meta_value ASC",
                '_artist'
            )
        );

        // Also include taxonomy 'artist' terms (covers most series data)
        $terms = get_terms(['taxonomy' => 'artist', 'hide_empty' => false]);
        $term_names = [];
        if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $t) $term_names[] = $t->name;
        }

        $names = [];

        foreach ($term_names as $tn) {
            $tn = trim($tn);
            if ($tn === '') continue;
            if (strlen($tn) > 100) continue;
            $names[strtolower($tn)] = $tn;
        }

        foreach ($rows as $row) {
            $parts = preg_split('/\s*(?:,|;|\/|\\\\|&|\band\b|\bwith\b|\bfeat\b\.?|\bft\b\.?|\+)\s*/i', $row);
            foreach ($parts as $part) {
                $name = trim(preg_replace('/\s+/', ' ', $part));
                if ($name === '') continue;
                if (preg_match('/<[^>]*>/', $name)) continue;
                if (strlen($name) > 100) continue;
                $names[strtolower($name)] = $name;
            }
        }

        natcasesort($names);
        $artists = array_values($names);

        wp_send_json_success([
            'count' => count($artists),
            'artists' => array_slice($artists, 0, 500),
            'status' => 'success'
        ]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'Error: ' . $e->getMessage()]);
    }
}

/* -----------------------
   Admin tool: Clean Authors & Artists metadata
   Adds a Tools > "Curăță Autori/Artiști" page that can scan and fix `_author` / `_artist` postmeta.
   ----------------------- */
// Curățare autori/artiști: funcționalitate admin eliminată la cerere de către utilizator.
// Dacă ai nevoie din nou de acest tool, pot reintroduce codul sau pot rula curățarea manuală.

// Test genres AJAX
add_action('wp_ajax_mangayummy_test_genres', 'mangayummy_test_genres_ajax');
add_action('wp_ajax_nopriv_mangayummy_test_genres', 'mangayummy_test_genres_ajax');

function mangayummy_test_genres_ajax() {
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
            wp_send_json_error(['message' => 'Security error']);
        }

        $genres = get_terms([
            'taxonomy' => 'genre',
            'hide_empty' => false,
            'number' => 10
        ]);

        $genre_list = array_map(function($genre) {
            return [
                'id' => $genre->term_id,
                'name' => $genre->name,
                'slug' => $genre->slug,
                'count' => $genre->count
            ];
        }, $genres);

        wp_send_json_success([
            'count' => count($genres),
            'genres' => $genre_list,
            'status' => 'success'
        ]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'Error: ' . $e->getMessage()]);
    }
}

// Test manga AJAX
add_action('wp_ajax_mangayummy_test_manga', 'mangayummy_test_manga_ajax');
add_action('wp_ajax_nopriv_mangayummy_test_manga', 'mangayummy_test_manga_ajax');

function mangayummy_test_manga_ajax() {
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
            wp_send_json_error(['message' => 'Security error']);
        }

        // Get filter parameters
        $search = sanitize_text_field($_POST['search'] ?? '');
        $sort = sanitize_text_field($_POST['sort'] ?? '');
        $type = sanitize_text_field($_POST['type'] ?? '');
        $included_genres = sanitize_text_field($_POST['included_genres'] ?? '');
        $excluded_genres = sanitize_text_field($_POST['excluded_genres'] ?? '');
        $language = sanitize_text_field($_POST['language'] ?? '');
        $status = sanitize_text_field($_POST['status'] ?? '');
        // Sanitize + validate year range - ignore unrealistic values (prevents '200' broad matches)
        $min_year = 1900;
        $max_year = 2099;
        $year_from = intval($_POST['year_from'] ?? 0);
        $year_to = intval($_POST['year_to'] ?? 0);
        if ($year_from < $min_year || $year_from > $max_year) {
            $year_from = 0;
        }
        if ($year_to < $min_year || $year_to > $max_year) {
            $year_to = 0;
        }
        // If user swapped values, make it resilient by swapping server-side
        if ($year_from > 0 && $year_to > 0 && $year_from > $year_to) {
            $tmp = $year_from;
            $year_from = $year_to;
            $year_to = $tmp;
        }
        $author = sanitize_text_field($_POST['author'] ?? '');
        $artist = sanitize_text_field($_POST['artist'] ?? '');
        $page = intval($_POST['page'] ?? 1);
        $per_page = intval($_POST['per_page'] ?? 24);

        // Build query arguments
        $args = [
            'post_type' => 'manga',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'meta_query' => [],
            'tax_query' => []
        ];

        // Add search by title and advanced title-variants matching
        if (!empty($search)) {
            // Use the custom search query only and avoid WP core search syntax,
            // otherwise default core search can conflict with alternative-titles matching.
            $args['s'] = '';
            $args['ya_search_query'] = $search;
            add_filter('posts_where', 'mangayummy_ya_custom_search_where', 10, 2);
            add_filter('posts_join', 'mangayummy_ya_custom_search_join', 10, 2);

            // Prioritize titles starting with the search term (prefix priority)
            $GLOBALS['mangayummy_test_manga_search_prefix'] = $search;
            add_filter('posts_orderby', 'mangayummy_test_manga_orderby_prefix', 20, 2);
        }

        // Add sorting - improved from test_manga function
        switch ($sort) {
            case 'updated':
                $args['orderby'] = 'modified';
                $args['order'] = 'DESC';
                break;
            case 'created':
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
                break;
            case 'title_asc':
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
            case 'year_desc':
                $args['meta_key'] = '_release_year';
                $args['orderby'] = 'meta_value_num';
                $args['order'] = 'DESC';
                break;
            case 'rating':
                $args['meta_key'] = '_rating_avg';
                $args['orderby'] = 'meta_value_num';
                $args['order'] = 'DESC';
                break;
            case 'views':
                // Sort by views using custom orderby that checks multiple keys
                add_filter('posts_orderby', 'mangayummy_test_manga_orderby_views', 10, 2);
                break;
            case 'follows':
                // Sort by bookmark count using custom orderby
                add_filter('posts_orderby', 'mangayummy_test_manga_orderby_follows', 10, 2);
                break;
            default:
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
        }

        // Apply user reader preferences if logged in
        if (is_user_logged_in()) {
            $prefs = get_user_meta(get_current_user_id(), 'reader_prefs', true) ?: [];

            // explicit content preference: only hide adult manga when user has checked NSFW
            if (!empty($prefs['explicit']) && is_array($prefs['explicit'])) {
                $blockNsfw = in_array('nsfw', $prefs['explicit'], true);
                if ($blockNsfw) {
                    // exclude adult
                    $args['meta_query'][] = [
                        'relation' => 'OR',
                        [
                            'key' => '_manga_18',
                            'compare' => 'NOT EXISTS'
                        ],
                        [
                            'key' => '_manga_18',
                            'value' => '1',
                            'compare' => '!='
                        ]
                    ];
                }
            }
        }

        // Add genre filters
        if (!empty($included_genres)) {
            $included_genre_array = array_map('trim', explode(',', $included_genres));
            $args['tax_query'][] = [
                'taxonomy' => 'genre',
                'field' => 'slug',
                'terms' => $included_genre_array,
                'operator' => 'IN'
            ];
        }

        if (!empty($excluded_genres)) {
            $excluded_genre_array = array_map('trim', explode(',', $excluded_genres));
            $args['tax_query'][] = [
                'taxonomy' => 'genre',
                'field' => 'slug',
                'terms' => $excluded_genre_array,
                'operator' => 'NOT IN'
            ];
        }

        // Add status filter with mapping from test_manga function
        if (!empty($status) && $status !== 'oricare') {
            $status_map = array(
                'releasing' => 'ongoing',
                'finished' => 'completed',
                'cancelled' => 'cancelled',
                'hiatus' => 'hiatus'
            );
            $mapped_status = isset($status_map[$status]) ? $status_map[$status] : $status;
            $args['meta_query'][] = [
                'key' => '_status',
                'value' => $mapped_status,
                'compare' => '='
            ];
        }

        // Add type filter (manga/manhua/manhwa) – was missing previously, so frontend selection had no effect
        if (!empty($type) && $type !== 'oricare') {
            $args['meta_query'][] = [
                'key' => '_manga_type',
                'value' => $type,
                'compare' => '='
            ];
        }

        // Add year range filter
        // Improved behavior:
        // - If both from+to provided: match manga with start year in range OR whose [start,end] overlaps the range
        // - If only from provided: match exact year, spans that include the year, posts with only _release_year_end, or fallback to the previous >= behavior
        // - If only to provided: match posts with start/end <= year_to
        if ($year_from > 0 || $year_to > 0) {
            if ($year_from > 0 && $year_to > 0) {
                // match either posts with _release_year in [from,to] OR posts whose span [_release_year, _release_year_end] overlaps [from,to]
                $args['meta_query'][] = [
                    'relation' => 'OR',
                    [
                        'relation' => 'AND',
                        [
                            'key' => '_release_year',
                            'value' => $year_from,
                            'compare' => '>=',
                            'type' => 'NUMERIC'
                        ],
                        [
                            'key' => '_release_year',
                            'value' => $year_to,
                            'compare' => '<=',
                            'type' => 'NUMERIC'
                        ]
                    ],
                    [
                        'relation' => 'AND',
                        [
                            'key' => '_release_year',
                            'value' => $year_from,
                            'compare' => '<=',
                            'type' => 'NUMERIC'
                        ],
                        [
                            'key' => '_release_year_end',
                            'value' => $year_to,
                            'compare' => '>=',
                            'type' => 'NUMERIC'
                        ]
                    ]
                ];
            } elseif ($year_from > 0 && $year_to === 0) {
                // Single year_from: match exact start/end or spans that include the year
                // (do NOT fallback to start >= year_from to avoid overly-broad results)
                $args['meta_query'][] = [
                    'relation' => 'OR',
                    [
                        'key' => '_release_year',
                        'value' => $year_from,
                        'compare' => '=',
                        'type' => 'NUMERIC'
                    ],
                    [
                        'key' => '_release_year_end',
                        'value' => $year_from,
                        'compare' => '=',
                        'type' => 'NUMERIC'
                    ],
                    [
                        'relation' => 'AND',
                        [
                            'key' => '_release_year',
                            'value' => $year_from,
                            'compare' => '<=',
                            'type' => 'NUMERIC'
                        ],
                        [
                            'key' => '_release_year_end',
                            'value' => $year_from,
                            'compare' => '>=',
                            'type' => 'NUMERIC'
                        ]
                    ]
                ];
            } elseif ($year_from === 0 && $year_to > 0) {
                // Only year_to provided: return manga that finished on or before year_to.
                // Require that a _release_year_end exists and is <= year_to (exclude ongoing without end-year).
                $args['meta_query'][] = [
                    'relation' => 'AND',
                    [
                        'key' => '_release_year_end',
                        'compare' => 'EXISTS'
                    ],
                    [
                        'key' => '_release_year_end',
                        'value' => $year_to,
                        'compare' => '<=',
                        'type' => 'NUMERIC'
                    ]
                ];
            }
        }

        // Add author filter
        if (!empty($author) && $author !== 'oricare') {
            // If an author term exists with this slug, filter by taxonomy (AJAX path)
            if (term_exists($author, 'author')) {
                $args['tax_query'][] = [
                    'taxonomy' => 'author',
                    'field' => 'slug',
                    'terms' => sanitize_text_field($author),
                ];
            } else {
                $args['meta_query'][] = [
                    'key' => '_author',
                    'value' => $author,
                    'compare' => 'LIKE'
                ];
            }
        }

        // Add artist filter
        if (!empty($artist) && $artist !== 'oricare') {
            // If an artist term exists with this slug, filter by taxonomy (AJAX path)
            if (term_exists($artist, 'artist')) {
                $args['tax_query'][] = [
                    'taxonomy' => 'artist',
                    'field' => 'slug',
                    'terms' => sanitize_text_field($artist),
                ];
            } else {
                $args['meta_query'][] = [
                    'key' => '_artist',
                    'value' => $artist,
                    'compare' => 'LIKE'
                ];
            }
        }

        // Add language filtering - manga must have chapters in the specified language
        // This is from the test_manga function
        if (!empty($language) && $language !== 'oricare') {
            $GLOBALS['mangayummy_test_manga_language_filter'] = $language;
            add_filter('posts_where', 'mangayummy_test_manga_language_filter', 10, 2);
        }

        $manga_query = new WP_Query($args);
        $total_count = $manga_query->found_posts;

        $manga_list = [];
        if ($manga_query->have_posts()) {
            while ($manga_query->have_posts()) {
                $manga_query->the_post();
                $post_id = get_the_ID();

                // Enforce that only manga posts are returned (filter out any chapter posts accidentally present)
                if (get_post_type($post_id) !== 'manga') {
                    mangayummy_debug_log('cautare-avansata: skipped non-manga post in results id=' . $post_id . ' type=' . get_post_type($post_id));
                    continue;
                }

                // Get manga data - improved from test_manga function
                $thumbnail = get_the_post_thumbnail_url($post_id, 'manga-card');
                if (!$thumbnail) {
                    $thumbnail = get_template_directory_uri() . '/assets/img/default-manga.jpg';
                }

                $year = get_post_meta($post_id, '_release_year', true);
                $rating = get_post_meta($post_id, '_rating_avg', true);

                // Improved views handling from test_manga function
                $views = get_post_meta($post_id, 'monthly_views', true);
                if (!$views) {
                    $views = get_post_meta($post_id, 'manga_views_total', true);
                }
                if (!$views) {
                    $views = get_post_meta($post_id, '_manga_views_total', true);
                }
                if (!$views) {
                    $views = get_post_meta($post_id, '_manga_views', true);
                }
                if (!$views) {
                    $views = get_post_meta($post_id, '_views', true);
                }

                // Corect: dacă nu există views, setează la 0 (nu reseta în baza de date aici)
                if (!$views) {
                    $views = 0;
                    // NU apela update_post_meta pentru a evita resetarea accidentală pe manga cu valori provenite din chei legacy
                    // update_post_meta($post_id, 'manga_views_total', $views);
                }

                $status_meta = get_post_meta($post_id, '_status', true);
                $type_meta = get_post_meta($post_id, '_manga_type', true);
                $chapters_meta = get_post_meta($post_id, '_chapter_number', true);

                // Use explicit chapter count meta if available, otherwise calculate from actual chapter posts.
                $chapters = 0;
                if ($chapters_meta !== '' && $chapters_meta !== null && is_numeric($chapters_meta) && floatval($chapters_meta) > 0) {
                    $chapters = intval($chapters_meta);
                } else {
                    $chapters = mangayummy_get_total_chapters($post_id);
                }

                // Format rating
                $rating_display = $rating ? number_format($rating, 1) : 'N/A';

                // Format views - improved formatting from test_manga
                $views_display = '0';
                if ($views && is_numeric($views)) {
                    if ($views >= 1000000) {
                        $views_display = number_format($views / 1000000, 1) . 'M';
                    } elseif ($views >= 1000) {
                        $views_display = number_format($views / 1000, 0) . 'k';
                    } else {
                        $views_display = number_format($views);
                    }
                }

                // Format status - improved from test_manga function
                $status_display = 'NECUNOSCUT';
                switch ($status_meta) {
                    case 'ongoing':
                        $status_display = 'ÎN CURS';
                        break;
                    case 'completed':
                        $status_display = 'FINALIZAT';
                        break;
                    case 'hiatus':
                        $status_display = 'ÎN PAUZĂ';
                        break;
                    case 'cancelled':
                        $status_display = 'ANULAT';
                        break;
                }

                // Get description
                $description = get_the_excerpt();
                if (empty($description)) {
                    $description = wp_trim_words(get_the_content(), 20);
                }

                $manga_list[] = [
                    'id' => $post_id,
                    'title' => get_the_title(),
                    'permalink' => get_permalink(),
                    'thumbnail' => $thumbnail,
                    'year' => $year ?: 'N/A',
                    'rating' => $rating_display,
                    'views' => $views_display,
                    'status' => $status_meta,
                    'type' => $type_meta ?: 'manga',
                    'chapters' => $chapters ?: 0,
                    'description' => $description,
                    'updated' => get_post_modified_time('U', true, $post_id),
                ];
            }
            wp_reset_postdata();
        }

        // Remove the language filter if it was added
        if (!empty($language) && $language !== 'oricare') {
            remove_filter('posts_where', 'mangayummy_test_manga_language_filter', 10);
            unset($GLOBALS['mangayummy_test_manga_language_filter']);
        }

        // Remove custom advanced search filters if we applied them
        if (!empty($search)) {
            remove_filter('posts_where', 'mangayummy_ya_custom_search_where', 10);
            remove_filter('posts_join', 'mangayummy_ya_custom_search_join', 10);
            remove_filter('posts_orderby', 'mangayummy_test_manga_orderby_prefix', 20);
            unset($GLOBALS['mangayummy_test_manga_search_prefix']);
        }

        // Remove the follows orderby filter if it was added
        if ($sort === 'follows') {
            remove_filter('posts_orderby', 'mangayummy_test_manga_orderby_follows', 10);
        }

        // Remove the views orderby filter if it was added
        if ($sort === 'views') {
            remove_filter('posts_orderby', 'mangayummy_test_manga_orderby_views', 10);
        }

        // Developer debug log: for all advanced search queries, show exact manga links in WP debug log.
        $permalinks = array_column($manga_list, 'permalink');
        if (trim($search) !== '') {
            mangayummy_debug_log(sprintf('cautare-avansata search=%s -> %d results: %s', $search, count($permalinks), implode(', ', $permalinks)));
        } else {
            mangayummy_debug_log(sprintf('cautare-avansata search=(empty) -> %d results', count($permalinks)));
        }

        $returned_count = count($manga_list);
        if ($returned_count !== $total_count) {
            mangayummy_debug_log(sprintf('cautare-avansata: adjusted count from %d to %d (filtered out non-manga results) for search=%s', $total_count, $returned_count, $search));
        }

        wp_send_json_success([
            'count' => $total_count,
            'found_posts' => $total_count,
            'current_page_count' => $returned_count,
            'manga' => $manga_list,
            'page' => $page,
            'total_pages' => $manga_query->max_num_pages ?: 1,
            'status' => 'success'
        ]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'Error: ' . $e->getMessage()]);
    }
}

add_action('wp_ajax_mangayummy_get_random_manga', 'mangayummy_get_random_manga_ajax');
add_action('wp_ajax_nopriv_mangayummy_get_random_manga', 'mangayummy_get_random_manga_ajax');

function mangayummy_get_random_manga_ajax() {
    try {
        if (!wp_verify_nonce($_POST['nonce'], 'ya_ajax_nonce')) {
            wp_send_json_error(['message' => 'Security error']);
        }

        // Get all published manga posts
        $args = [
            'post_type' => 'manga',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'rand', // Random order
            'meta_query' => [],
            'tax_query' => []
        ];

        $manga_query = new WP_Query($args);

        if ($manga_query->have_posts()) {
            $manga_query->the_post();
            $post_id = get_the_ID();

            wp_send_json_success([
                'permalink' => get_permalink(),
                'title' => get_the_title()
            ]);
        } else {
            wp_send_json_error(['message' => 'No manga found']);
        }

        wp_reset_postdata();
    } catch (Exception $e) {
        wp_send_json_error(['message' => 'Error: ' . $e->getMessage()]);
    }
}

// Add custom search filters for manga searches
add_action('pre_get_posts', function($query) {
    if (!is_admin() && $query->is_search() && in_array($query->get('post_type'), ['manga', 'anime', 'any'])) {
        add_filter('posts_where', 'mangayummy_ya_custom_search_where', 10, 2);
        add_filter('posts_join', 'mangayummy_ya_custom_search_join', 10, 2);
    }
});

// Apply reader preferences globally to any front-end manga query
// helper returns normalized preferences with defaults if nothing meaningful present
function mangayummy_get_reader_prefs($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    $prefs = get_user_meta($user_id, 'reader_prefs', true);
    if (!is_array($prefs)) {
        $prefs = [];
    }

    // if no prefs stored at all, default to nothing blocked and nsfw allowed
    if (!metadata_exists('user', $user_id, 'reader_prefs')) {
        $prefs['genres'] = [];    // blocked genres list
        $prefs['explicit'] = []; // no explicit blocking by default
        return $prefs;
    }

    // metadata exists: respect whatever arrays are saved (including empty ones)

    // if genres/explicit keys missing or not arrays, default them too
    if (!isset($prefs['genres']) || !is_array($prefs['genres'])) {
        $prefs['genres'] = [];
    }
    if (!isset($prefs['explicit']) || !is_array($prefs['explicit'])) {
        $prefs['explicit'] = [];
    }

    return $prefs;
}

add_action('pre_get_posts', 'mangayummy_apply_reader_prefs_globally');
function mangayummy_apply_reader_prefs_globally($query) {
    if (is_admin()) {
        return;
    }

    // If query specifically targets manga posts (including arrays)
    $post_type = $query->get('post_type');
    $is_manga_query = false;

    if (empty($post_type)) {
        // no post_type set means default 'post' - skip unless this is home and homepage shows manga via custom loop.
        // We'll not attempt to modify generic 'post' queries.
        $is_manga_query = false;
    } elseif (is_array($post_type)) {
        if (in_array('manga', $post_type)) {
            $is_manga_query = true;
        }
    } else {
        if ($post_type === 'manga') {
            $is_manga_query = true;
        }
    }

    if (!$is_manga_query) {
        return;
    }

    // now apply preferences (same logic as ajax handler)
    if (is_user_logged_in()) {
        $prefs = mangayummy_get_reader_prefs();


        if (isset($prefs['genres']) && !empty($prefs['genres'])) {
            // prefs.genres now stores blocked genre slugs directly
            $tax = $query->get('tax_query');
            if (!is_array($tax)) $tax = [];
            $tax[] = [
                'taxonomy' => 'genre',
                'field' => 'slug',
                'terms' => $prefs['genres'],
                'operator' => 'NOT IN'
            ];
            $query->set('tax_query', $tax);
        }

        // explicit preference now acts as a block list: checking NSFW hides adult manga
        if (isset($prefs['explicit'])) {
            $blockNsfw = in_array('nsfw', $prefs['explicit'], true);
            if ($blockNsfw) {
                // exclude all adult manga
                $meta = $query->get('meta_query');
                if (!is_array($meta)) $meta = [];
                $meta[] = [
                    'relation' => 'OR',
                    [
                        'key' => '_manga_18',
                        'compare' => 'NOT EXISTS'
                    ],
                    [
                        'key' => '_manga_18',
                        'value' => '1',
                        'compare' => '!='
                    ]
                ];
                $query->set('meta_query', $meta);
            }
        }
    }
}

// ===== reader prefs cleanup tool =====
add_action('admin_menu', function() {
    add_menu_page(
        'Manga Manager',
        'Manga Manager',
        'manage_options',
        'mangayummy-manga-manager',
        'mangayummy_render_manga_manager_page',
        'dashicons-book',
        61
    );
    
    // Reader Management items are now registered in mangayummy_add_admin_menu()
});

function mangayummy_render_manga_manager_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    echo '<div class="wrap">';
    echo '<h1>Manga Manager</h1>';
    echo '<p>Bine ai venit în panoul MangaYummy Manager. Alege un instrument:</p>';
    echo '<ul>';
    echo '<li><a href="' . esc_url(admin_url('admin.php?page=ya-reset-reader-prefs')) . '">Reset Reader Prefs</a></li>';
    echo '<li><a href="' . esc_url(admin_url('admin.php?page=ya-adjust-manga-views')) . '">Adjust Manga Views</a></li>';
    echo '</ul>';
    echo '</div>';
}


function mangayummy_ya_render_reset_prefs_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }
    // handle form submission
    if (isset($_POST['ya_reset_reader_prefs']) && check_admin_referer('ya_reset_reader_prefs_action')) {
        $users = get_users(['fields' => 'ID']);
        foreach ($users as $uid) {
            update_user_meta($uid, 'reader_prefs', ['genres' => [], 'explicit' => []]);
        }
        echo '<div class="updated"><p>All reader preferences cleared.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Reset Reader Preferences</h1>
        <p>This tool clears the <code>reader_prefs</code> user meta for every account.</p>
        <form method="post">
            <?php wp_nonce_field('ya_reset_reader_prefs_action'); ?>
            <input type="hidden" name="ya_reset_reader_prefs" value="1">
            <?php submit_button('Reset Now', 'secondary'); ?>
        </form>
    </div>
    <?php
}

function mangayummy_get_manga_id_from_identifier($identifier) {
    $identifier = trim($identifier);

    if (is_numeric($identifier) && intval($identifier) > 0) {
        return intval($identifier);
    }

    // If full URL is provided, try extracting path/slug
    if (strpos($identifier, 'http://') === 0 || strpos($identifier, 'https://') === 0) {
        $url_parts = wp_parse_url($identifier);
        if (!empty($url_parts['path'])) {
            $path = trim($url_parts['path'], '/');
            if (strpos($path, 'manga/') === 0) {
                $path = substr($path, strlen('manga/'));
            }
            $path = trim($path, '/');
            $identifier = $path;
        }
    }

    // If path includes additional levels (like /manga/slug/chapter/...), take first segment
    $parts = explode('/', trim($identifier, '/'));
    if (count($parts) > 1) {
        // prefer the manga slug segment
        if ($parts[0] === 'manga') {
            $identifier = $parts[1] ?? $parts[0];
        } else {
            $identifier = $parts[0];
        }
    }

    $manga = get_page_by_path($identifier, OBJECT, 'manga');
    if ($manga) {
        return $manga->ID;
    }

    $query = new WP_Query([
        'post_type' => 'manga',
        'name' => $identifier,
        'posts_per_page' => 1,
        'fields' => 'ids'
    ]);

    if ($query->have_posts()) {
        return intval($query->posts[0]);
    }

    return 0;
}

function mangayummy_ya_render_adjust_manga_views_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    $message = '';
    if (isset($_POST['ya_adjust_manga_views']) && check_admin_referer('ya_adjust_manga_views_action')) {
        $identifier = sanitize_text_field($_POST['manga_identifier'] ?? '');
        $operation = sanitize_text_field($_POST['operation'] ?? 'add');
        $value = intval($_POST['value'] ?? 0);

        if ($identifier === '') {
            $message = '<div class="notice notice-error"><p>Please provide Manga ID or slug.</p></div>';
        } else {
            $manga_id = mangayummy_get_manga_id_from_identifier($identifier);

            if (!$manga_id || get_post_type($manga_id) !== 'manga') {
                $message = '<div class="notice notice-error"><p>Invalid manga identifier. Ensure it is a valid manga post.</p></div>';
            } else {
                $current = (int) get_post_meta($manga_id, 'manga_views_total', true);
                $legacy = (int) get_post_meta($manga_id, '_manga_views', true);

                if ($operation === 'set') {
                    $new = max(0, $value);
                } else {
                    $new = max(0, $current + $value);
                }

                update_post_meta($manga_id, 'manga_views_total', $new);
                update_post_meta($manga_id, '_manga_views', $new);

                $message = '<div class="notice notice-success"><p>Updated manga views for ID ' . esc_html($manga_id) . ': from ' . esc_html($current) . ' (legacy ' . esc_html($legacy) . ') to ' . esc_html($new) . '.</p></div>';
            }
        }
    }

    ?>
    <div class="wrap">
        <h1>Adjust Manga Views</h1>
        <?php echo $message; ?>
        <p>Manually adjust the read counter for a manga. Use <strong>post ID</strong> or <strong>slug</strong> in the first field.</p>
        <form method="post">
            <?php wp_nonce_field('ya_adjust_manga_views_action'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="manga_identifier">Manga ID/Slug</label></th>
                    <td><input type="text" name="manga_identifier" id="manga_identifier" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="operation">Operation</label></th>
                    <td>
                        <select name="operation" id="operation">
                            <option value="add">Add to current</option>
                            <option value="set">Set exact value</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="value">Value</label></th>
                    <td><input type="number" name="value" id="value" class="regular-text" value="0" required></td>
                </tr>
            </table>
            <input type="hidden" name="ya_adjust_manga_views" value="1">
            <?php submit_button('Apply'); ?>
        </form>
    </div>
    <?php
}

// helper: determine whether a manga post respects the current reader preferences
function mangayummy_manga_matches_prefs($post_id) {
    if (!is_user_logged_in()) {
        return true; // guests see everything
    }
    $prefs = mangayummy_get_reader_prefs();

    // genres: prefs['genres'] is a **block list** of adult genre slugs.
    // if the array is empty or not set, nothing is excluded.
    if (!empty($prefs['genres']) && is_array($prefs['genres'])) {
        $terms = wp_get_post_terms($post_id, 'genre', ['fields'=>'slugs']);
        if (array_intersect($terms, $prefs['genres'])) {
            return false;
        }
    }

    // explicit preference: treat 'nsfw' as a **block list** entry.
    // only hide adult manga when user has explicitly chosen to block NSFW.
    if (!empty($prefs['explicit']) && is_array($prefs['explicit'])) {
        if (in_array('nsfw', $prefs['explicit'], true)) {
            $has18 = get_post_meta($post_id, '_manga_18', true);
            if ($has18) {
                return false;
            }
        }
    }
    return true;
}

// ===== NOINDEX for sensitive genres =====
add_filter('wpseo_robots', function($robots) {
    // only apply on genre archive pages
    if (is_tax('genre')) {
        $noindex_terms = [
            'adult',
            'matur',
            'smut',
            'sex-in-grup',
            'masturbare',
            'milf',
            'loli',
            'incest',
            'ntr',
            'prostitutie',
            'sadism',
            'masochism',
            'violenta-sexuala',
            'viol',
            'hentai',
            'sani-mari',
            'ahegao',
            'succubus',
            'sclavie',
            'anal',
            'droguri',
            'tortura',
        ];

        $term = get_queried_object();
        if ($term && isset($term->slug)) {
            $current = $term->slug;
            if (in_array($current, $noindex_terms, true)) {
                return 'noindex, follow';
            }
        }
    }

    return $robots;
});

// ===== CHAPTER ADMIN DATE FILTERING =====
/**
 * Add date filter dropdown to chapter admin list
 */
function mangayummy_add_chapter_date_filter() {
    global $typenow;
    
    if ($typenow !== 'chapter') {
        return;
    }
    
    $selected_date = isset($_GET['chapter_date_filter']) ? sanitize_text_field($_GET['chapter_date_filter']) : '';
    
    echo '<select name="chapter_date_filter" id="chapter_date_filter">';
    echo '<option value="">— Toate datele —</option>';
    
    // Add "Today" option
    $today = date('Y-m-d');
    echo '<option value="' . $today . '" ' . selected($selected_date, $today, false) . '>Astăzi (' . date('d M Y') . ')</option>';
    
    // Add "Yesterday" option
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    echo '<option value="' . $yesterday . '" ' . selected($selected_date, $yesterday, false) . '>Ieri (' . date('d M Y', strtotime('-1 day')) . ')</option>';
    
    // Add last 7 days
    for ($i = 2; $i <= 7; $i++) {
        $date = date('Y-m-d', strtotime("-{$i} days"));
        $display_date = date('d M Y', strtotime("-{$i} days"));
        echo '<option value="' . $date . '" ' . selected($selected_date, $date, false) . '>' . $display_date . '</option>';
    }
    
    // Add current month
    $current_month = date('Y-m');
    echo '<option value="' . $current_month . '-month" ' . selected($selected_date, $current_month . '-month', false) . '>Luna curentă (' . date('M Y') . ')</option>';
    
    // Add last month
    $last_month = date('Y-m', strtotime('-1 month'));
    echo '<option value="' . $last_month . '-month" ' . selected($selected_date, $last_month . '-month', false) . '>Luna trecută (' . date('M Y', strtotime('-1 month')) . ')</option>';
    
    echo '</select>';
}
add_action('restrict_manage_posts', 'mangayummy_add_chapter_date_filter');

/**
 * Modify chapter query based on date filter
 */
function mangayummy_filter_chapter_by_date($query) {
    global $pagenow, $typenow;
    
    if ($pagenow !== 'edit.php' || $typenow !== 'chapter' || !is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $selected_date = isset($_GET['chapter_date_filter']) ? sanitize_text_field($_GET['chapter_date_filter']) : '';
    
    if (empty($selected_date)) {
        return;
    }
    
    // Handle month filtering
    if (strpos($selected_date, '-month') !== false) {
        $month_year = str_replace('-month', '', $selected_date);
        list($year, $month) = explode('-', $month_year);
        
        $query->set('year', $year);
        $query->set('monthnum', $month);
    } else {
        // Handle specific date filtering
        $query->set('date_query', array(
            array(
                'year'  => date('Y', strtotime($selected_date)),
                'month' => date('m', strtotime($selected_date)),
                'day'   => date('d', strtotime($selected_date)),
            ),
        ));
    }
}
add_action('pre_get_posts', 'mangayummy_filter_chapter_by_date');

/**
 * Add custom columns to chapter admin list
 */
function mangayummy_chapter_admin_columns($columns) {
    $new_columns = array();
    
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        
        // Add date column after title
        if ($key === 'title') {
            $new_columns['chapter_date'] = 'Dată creare';
            $new_columns['chapter_manga'] = 'Manga';
        }
    }
    
    return $new_columns;
}
add_filter('manage_chapter_posts_columns', 'mangayummy_chapter_admin_columns');

/**
 * Display custom column content for chapters
 */
function mangayummy_chapter_admin_column_content($column, $post_id) {
    switch ($column) {
        case 'chapter_date':
            $post = get_post($post_id);
            echo '<span style="font-size: 12px; color: #666;">';
            echo get_the_date('d M Y H:i', $post_id);
            echo '</span>';
            break;
            
        case 'chapter_manga':
            $manga_id = get_post_meta($post_id, '_manga_id', true);
            if ($manga_id) {
                $manga = get_post($manga_id);
                if ($manga) {
                    echo '<a href="' . get_edit_post_link($manga_id) . '" target="_blank">';
                    echo esc_html($manga->post_title);
                    echo '</a>';
                } else {
                    echo '<span style="color: #999;">Manga șters</span>';
                }
            } else {
                echo '<span style="color: #999;">Fără manga</span>';
            }
            break;
    }
}
add_action('manage_chapter_posts_custom_column', 'mangayummy_chapter_admin_column_content', 10, 2);

/**
 * Make chapter date column sortable
 */
function mangayummy_chapter_sortable_columns($columns) {
    $columns['chapter_date'] = 'date';
    $columns['chapter_manga'] = 'manga';
    return $columns;
}
add_filter('manage_edit-chapter_sortable_columns', 'mangayummy_chapter_sortable_columns');

/**
 * Handle custom sorting for chapter columns
 */
function mangayummy_chapter_orderby($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    
    switch ($orderby) {
        case 'manga':
            $query->set('meta_key', '_manga_id');
            $query->set('orderby', 'meta_value_num');
            break;
    }
}
add_action('pre_get_posts', 'mangayummy_chapter_orderby');

// ===== ZIP UPLOAD PROCESSING =====
/**
 * Process ZIP file upload and extract images
 */
function mangayummy_process_zip_upload() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(array('message' => 'No permission'));
    }
    
    $post_id = intval($_POST['post_id']);
    
    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'Invalid post ID'));
    }
    
    if (!isset($_FILES['zip_file']) || $_FILES['zip_file']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(array('message' => 'No file uploaded or upload error'));
    }
    
    $file = $_FILES['zip_file'];
    
    // Validate file type
    $allowed_mimes = array('application/zip', 'application/x-zip-compressed');
    $file_type = wp_check_filetype($file['name'], $allowed_mimes);
    
    if (!$file_type['type'] && !preg_match('/\.zip$/i', $file['name'])) {
        wp_send_json_error(array('message' => 'Invalid file type. Only ZIP files are allowed.'));
    }
    
    // Check file size (200MB limit)
    if ($file['size'] > 200 * 1024 * 1024) {
        wp_send_json_error(array('message' => 'File too large. Maximum size is 200MB.'));
    }
    
    // Create temporary directory for extraction
    $temp_dir = wp_tempnam('zip_extract_');
    if (!unlink($temp_dir) || !mkdir($temp_dir, 0755, true)) {
        wp_send_json_error(array('message' => 'Could not create temporary directory'));
    }
    
    try {
        // Move uploaded file to temp location
        $zip_path = $temp_dir . '/uploaded.zip';
        if (!move_uploaded_file($file['tmp_name'], $zip_path)) {
            throw new Exception('Could not save uploaded file');
        }
        
        // Check if ZipArchive is available
        if (!class_exists('ZipArchive')) {
            throw new Exception('ZIP extraction not supported on this server');
        }
        
        $zip = new ZipArchive();
        if ($zip->open($zip_path) !== true) {
            throw new Exception('Could not open ZIP file');
        }
        
        // Extract ZIP
        $extract_path = $temp_dir . '/extracted/';
        if (!mkdir($extract_path, 0755, true)) {
            throw new Exception('Could not create extraction directory');
        }
        
        $zip->extractTo($extract_path);
        $zip->close();
        
        // Find all image files
        $image_extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp');
        $image_files = array();
        
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($extract_path));
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $extension = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
                if (in_array($extension, $image_extensions)) {
                    $image_files[] = $file->getPathname();
                }
            }
        }
        
        if (empty($image_files)) {
            throw new Exception('No image files found in ZIP');
        }
        
        // Sort images using natural (human) order so "2.jpg" comes before "10.jpg".
        usort($image_files, function($a, $b) {
            return strnatcasecmp(basename($a), basename($b));
        });
        
        // Convert to URLs (store in uploads directory)
        $upload_dir = wp_upload_dir();
        $chapter_dir = $upload_dir['basedir'] . '/chapters/' . $post_id . '/';
        
        if (!file_exists($chapter_dir)) {
            wp_mkdir_p($chapter_dir);
        }
        
        $image_urls = array();
        $image_count = 0;
        
        foreach ($image_files as $image_path) {
            $filename = basename($image_path);

            // Sanitize filename to avoid spaces/special char issues
            $filename = sanitize_file_name($filename);
            $filename = preg_replace('/[^a-zA-Z0-9._-]/', '-', $filename);
            $filename = preg_replace('/-+/', '-', $filename);
            $filename = trim($filename, '-');

            $new_path = $chapter_dir . $filename;

            // Avoid duplicates by appending index if needed
            $base_name = pathinfo($filename, PATHINFO_FILENAME);
            $extension = pathinfo($filename, PATHINFO_EXTENSION);
            $index = 1;
            while (file_exists($new_path)) {
                $new_path = $chapter_dir . $base_name . '-' . $index . '.' . $extension;
                $index++;
            }

            // Copy file to uploads directory
            if (copy($image_path, $new_path)) {
                // If the copied file actually is webp, keep extension as webp
                $real_mime = @mime_content_type($new_path);
                if ($real_mime === 'image/webp' && strtolower($extension) !== 'webp') {
                    $new_webp = $chapter_dir . $base_name . '.' . 'webp';
                    if (!file_exists($new_webp)) {
                        @rename($new_path, $new_webp);
                        $new_path = $new_webp;
                        $filename = basename($new_webp);
                    }
                }

                $image_urls[] = $upload_dir['baseurl'] . '/chapters/' . $post_id . '/' . basename($new_path);
                $image_count++;
            }
        }
        
        if (empty($image_urls)) {
            throw new Exception('Could not process any images');
        }
        
        // Save images to chapter meta
        update_post_meta($post_id, '_chapter_images', $image_urls);
        
        // If post is auto-draft, save it as draft so it becomes visible
        $post = get_post($post_id);
        if ($post && $post->post_status === 'auto-draft') {
            wp_update_post(array(
                'ID' => $post_id,
                'post_status' => 'draft'
            ));
        }
        
        // Set translation group to MangaYummy if not set
        $existing_group = get_post_meta($post_id, '_translation_group', true);
        if (empty($existing_group)) {
            update_post_meta($post_id, '_translation_group', 'MangaYummy');
        }
        
        // Clear any caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        wp_send_json_success(array(
            'message' => 'S-au extras și încărcat ' . $image_count . ' imagini din ZIP!'
        ));
        
    } catch (Exception $e) {
        wp_send_json_error(array('message' => 'Error processing ZIP: ' . $e->getMessage()));
    } finally {
        // Clean up temporary files
        if (function_exists('mangayummy_recursive_rmdir')) {
            mangayummy_recursive_rmdir($temp_dir);
        } else {
            // Fallback cleanup
            array_map('unlink', glob("$temp_dir/*.*"));
            rmdir($temp_dir);
        }
    }
}
add_action('wp_ajax_mangayummy_process_zip_upload', 'mangayummy_process_zip_upload');

/**
 * Delete all chapter images
 */

// helper that removes stale/nonpublished manga ids from a user's status/bookmark arrays
function mangayummy_sanitize_user_manga_meta($user_id) {
    $valid_statuses = array('reading', 'planned', 'completed', 'paused', 'abandoned');
    $keys = [];
    foreach ($valid_statuses as $s) {
        $keys[] = 'manga_status_' . $s;
    }
    $bookmark_keys = array('mangayummy_bookmarks', 'bookmarked_manga', 'bookmarked_mangas');
    $keys = array_merge($keys, $bookmark_keys);

    $total_removed = 0;
    foreach ($keys as $meta_key) {
        $list = get_user_meta($user_id, $meta_key, true);
        if (!is_array($list)) continue;
        $clean = [];
        foreach ($list as $manga_id) {
            $manga_id = intval($manga_id);
            if ($manga_id && get_post_status($manga_id) === 'publish') {
                $clean[] = $manga_id;
            } else {
                $total_removed++;
            }
        }
        $clean = array_values(array_unique($clean));
        if ($clean !== $list) {
            update_user_meta($user_id, $meta_key, $clean);
        }
    }
    if ($total_removed) {
        // sanitized entries removed
    }
}

function mangayummy_delete_chapter_images() {
    check_ajax_referer('ya_ajax_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(array('message' => 'No permission'));
    }
    
    $post_id = intval($_POST['post_id']);
    
    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'Invalid post ID'));
    }
    
    try {
        // Get existing images
        $existing_images = get_post_meta($post_id, '_chapter_images', true);
        if (empty($existing_images) || !is_array($existing_images)) {
            wp_send_json_success(array('message' => 'No images to delete'));
            return;
        }
        
        // Delete physical files
        $upload_dir = wp_upload_dir();
        $chapter_dir = $upload_dir['basedir'] . '/chapters/' . $post_id . '/';
        
        if (is_dir($chapter_dir)) {
            $files = glob($chapter_dir . '*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
            rmdir($chapter_dir);
        }
        
        // Clear chapter meta
        delete_post_meta($post_id, '_chapter_images');
        
        // Clear any caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        wp_send_json_success(array('message' => 'Toate imaginile au fost șterse cu succes!'));
        
    } catch (Exception $e) {
        wp_send_json_error(array('message' => 'Error deleting images: ' . $e->getMessage()));
    }
}
add_action('wp_ajax_mangayummy_delete_chapter_images', 'mangayummy_delete_chapter_images');

/**
 * Recursively remove directory
 */
function mangayummy_recursive_rmdir($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    mangayummy_recursive_rmdir($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

// ===== Admin: metabox pentru capitole șterse asociate unui `manga` =====
add_action('add_meta_boxes', 'mangayummy_add_trashed_chapters_metabox');
function mangayummy_add_trashed_chapters_metabox() {
    add_meta_box(
        'mangayummy_trashed_chapters',
        'Capitole șterse',
        'mangayummy_render_trashed_chapters_metabox',
        'manga',
        'side',
        'default'
    );
}

function mangayummy_render_trashed_chapters_metabox($post) {
    $manga_id = $post->ID;
    $args = [
        'post_type' => 'chapter',
        'post_status' => 'trash',
        'posts_per_page' => -1,
        'meta_query' => [[
            'key' => '_manga_id',
            'value' => $manga_id,
            'compare' => '=',
        ]],
    ];
    $trashed = get_posts($args);
    if (empty($trashed)) {
        echo '<p>Niciun capitol șters.</p>';
        return;
    }
    $count = count($trashed);
    $nonce_all = wp_create_nonce('mangayummy_restore_all_chapters_' . $manga_id);
    $restore_all_url = add_query_arg([
        'action' => 'mangayummy_restore_all_chapters',
        'manga_id' => $manga_id,
        '_wpnonce' => $nonce_all,
    ], admin_url('admin-post.php'));

    echo '<p style="margin-bottom:8px;">Există <strong>' . intval($count) . '</strong> capitole în coș.</p>';
    echo '<p><a class="button" href="' . esc_url($restore_all_url) . '">Restabilește toate</a></p>';

    // admin trash-all button (only administrators would see this meta box anyway)
    $nonce_trash = wp_create_nonce('ya_ajax_nonce');
    echo '<p><button id="manga-trash-all-btn" class="button button-secondary" data-manga-id="' . intval($manga_id) . '" data-nonce="' . $nonce_trash . '">Mută toate capitolele în coș</button></p>';
    echo "<script>
    jQuery(function($){
        $('#manga-trash-all-btn').on('click', function(e){
            e.preventDefault();
            if(!confirm('Sigur vrei să muți toate capitolele acestui manga în coș?')) return;
            var btn = $(this), mid = btn.data('manga-id'), nonce = btn.data('nonce');
            btn.prop('disabled',true).text('Se mută...');
            $.post(ajaxurl,{action:'mangayummy_trash_all_chapters',manga_id:mid,nonce:nonce},function(resp){
                if(resp.success){
                    alert('Au fost mutate în coș ' + (resp.data.trashed||0) + ' capitole.');
                    location.reload();
                } else {
                    alert('Eroare: ' + (resp.data && resp.data.message ? resp.data.message : 'Operatiune esuata'));
                    btn.prop('disabled',false).text('Mută toate capitolele în coș');
                }
            }).fail(function(){
                alert('Eroare de rețea. Încearcă din nou.');
                btn.prop('disabled',false).text('Mută toate capitolele în coș');
            });
        });
    });
    </script>";

    echo '<ul style="margin:8px 0 0;padding-left:16px;">';
    foreach ($trashed as $ch) {
        $title = esc_html(get_the_title($ch));
        $nonce = wp_create_nonce('mangayummy_restore_chapter_' . $ch->ID);
        $url = add_query_arg([
            'action' => 'mangayummy_restore_chapter',
            'chapter_id' => $ch->ID,
            'manga_id' => $manga_id,
            '_wpnonce' => $nonce,
        ], admin_url('admin-post.php'));
        echo '<li style="margin-bottom:6px;">' . $title . ' — <a href="' . esc_url($url) . '">Restabilește</a></li>';
    }
    echo '</ul>';
}

add_action('admin_post_mangayummy_restore_chapter', 'mangayummy_handle_restore_chapter');
function mangayummy_handle_restore_chapter() {
    $chapter_id = isset($_GET['chapter_id']) ? intval($_GET['chapter_id']) : 0;
    $manga_id = isset($_GET['manga_id']) ? intval($_GET['manga_id']) : 0;
    if (!$chapter_id) {
        wp_safe_redirect(wp_get_referer() ?: admin_url());
        exit;
    }
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'mangayummy_restore_chapter_' . $chapter_id)) {
        wp_die('Nonce invalid');
    }
    if (!current_user_can('edit_post', $manga_id) && !current_user_can('edit_post', $chapter_id)) {
        wp_die('Nu ai permisiunea necesară.');
    }

    $result = wp_untrash_post($chapter_id);

    $redirect = admin_url('post.php?post=' . $manga_id . '&action=edit');
    $redirect = add_query_arg('mangayummy_restored', $result ? '1' : '0', $redirect);
    wp_safe_redirect($redirect);
    exit;
}

add_action('admin_post_mangayummy_restore_all_chapters', 'mangayummy_handle_restore_all_chapters');
function mangayummy_handle_restore_all_chapters() {
    $manga_id = isset($_GET['manga_id']) ? intval($_GET['manga_id']) : 0;
    if (!$manga_id) {
        wp_safe_redirect(wp_get_referer() ?: admin_url());
        exit;
    }
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'mangayummy_restore_all_chapters_' . $manga_id)) {
        wp_die('Nonce invalid');
    }
    if (!current_user_can('edit_post', $manga_id)) {
        wp_die('Nu ai permisiunea necesară.');
    }

    $args = [
        'post_type' => 'chapter',
        'post_status' => 'trash',
        'posts_per_page' => -1,
        'meta_query' => [[
            'key' => '_manga_id',
            'value' => $manga_id,
            'compare' => '=',
        ]],
        'fields' => 'ids',
    ];
    $trashed_ids = get_posts($args);
    $restored = 0;
    if (!empty($trashed_ids)) {
        foreach ($trashed_ids as $cid) {
            if (wp_untrash_post($cid)) $restored++;
        }
    }

    $redirect = admin_url('post.php?post=' . $manga_id . '&action=edit');
    $redirect = add_query_arg('mangayummy_restored_count', intval($restored), $redirect);
    wp_safe_redirect($redirect);
    exit;
}

// Quick admin bar link for faster access
add_action('admin_bar_menu', 'mangayummy_admin_bar_manga_manager_link', 100);
function mangayummy_admin_bar_manga_manager_link($wp_admin_bar) {
    if (!current_user_can('manage_options')) {
        return;
    }
    $args = array(
        'id'    => 'mangayummy-manga-manager',
        'title' => 'Manga Manager',
        'href'  => admin_url('admin.php?page=mangayummy-manga-manager'),
        'meta'  => array('class' => 'mangayummy-manga-manager'),
    );
    $wp_admin_bar->add_node($args);
}

// Rezolvare dublare imagine Discord: blocheaza Yoast OG/Twitter pe manga/chapter
add_action('template_redirect', function() {
    if (is_singular('manga') || is_singular('chapter')) {
        // wpseo_opengraph este deprecate in Yoast >=14; folosim wpseo_frontend_presenters
        add_filter('wpseo_frontend_presenters', 'mangayummy_disable_yoast_og_twitter_presenters', 99);
        remove_action('wpseo_head', 'wpseo_frontend_head', 1);
    }
}, 1);

// ── Creare știre de către utilizatori ──────────────────────────────────────
add_action('wp_ajax_mangayummy_submit_stire', 'mangayummy_submit_stire');

function mangayummy_submit_stire() {
    if (!wp_verify_nonce($_POST['nonce'] ?? '', 'mangayummy_submit_stire_nonce')) {
        wp_send_json_error('Eroare de securitate.');
    }

    if (!is_user_logged_in()) {
        wp_send_json_error('Trebuie să fii logat.');
    }

    $titlu   = sanitize_text_field($_POST['titlu'] ?? '');
    $rezumat = sanitize_textarea_field($_POST['rezumat'] ?? '');
    $category = sanitize_key($_POST['category'] ?? '');
    $cover_url = esc_url_raw($_POST['cover_url'] ?? '');
    $video_url = esc_url_raw($_POST['video_url'] ?? '');

    // Permite tag-uri HTML sigure în conținut
    $allowed = array_merge(
        wp_kses_allowed_html('post'),
        ['img' => ['src' => true, 'alt' => true, 'style' => true, 'class' => true]]
    );
    $continut = wp_kses($_POST['continut'] ?? '', $allowed);

    if (empty($titlu)) {
        wp_send_json_error('Titlul este obligatoriu.');
    }

    if (mb_strlen(wp_strip_all_tags($continut)) < 10) {
        wp_send_json_error('Conținutul trebuie să aibă cel puțin 10 caractere.');
    }

    $edit_post_id = intval($_POST['post_id'] ?? 0);
    $is_edit = false;
    $response_message = 'Știrea a fost trimisă spre verificare. Mulțumim!';

    if ($edit_post_id > 0) {
        $existing_post = get_post($edit_post_id);
        if (!$existing_post || $existing_post->post_type !== 'stire' || !mangayummy_user_can_edit_stire($edit_post_id)) {
            wp_send_json_error('Nu ai permisiunea de a edita această știre.');
        }

        $is_edit = true;
        $response_message = 'Știrea a fost actualizată.';
        $post_data = [
            'ID'           => $edit_post_id,
            'post_title'   => $titlu,
            'post_excerpt' => $rezumat,
            'post_content' => $continut,
            'post_status'  => get_post_status($edit_post_id),
        ];

        $post_id = wp_update_post($post_data, true);
        if (is_wp_error($post_id)) {
            wp_send_json_error('Eroare la actualizare: ' . $post_id->get_error_message());
        }
    } else {
        $current_user_id = get_current_user_id();
        $auto_publish = mangayummy_stire_author_can_auto_publish($current_user_id);

        $post_data = [
            'post_title'   => $titlu,
            'post_excerpt' => $rezumat,
            'post_content' => $continut,
            'post_type'    => 'stire',
            'post_status'  => $auto_publish ? 'publish' : 'pending',
            'post_author'  => $current_user_id,
        ];

        $post_id = wp_insert_post($post_data, true);
        if (is_wp_error($post_id)) {
            wp_send_json_error('Eroare la salvare: ' . $post_id->get_error_message());
        }

        update_post_meta($post_id, '_stire_author_id', $current_user_id);

        if ($auto_publish) {
            $response_message = 'News article has been auto-published.';
        }

        // Notify admin by email whenever a new stire is submitted or auto-published.
        $admin_email = get_bloginfo('admin_email');
        if (is_email($admin_email)) {
            $post_status = $auto_publish ? 'published' : 'pending approval';
            $subject = sprintf('MangaYummy: new news %s', $post_status);
            $body = sprintf(
                "A new news article was created on MangaYummy by %s (%s).\n\nTitle: %s\nStatus: %s\n\nLink: %s\n",
                get_the_author_meta('display_name', $current_user_id),
                get_the_author_meta('user_email', $current_user_id),
                $titlu,
                $post_status,
                get_permalink($post_id)
            );
            $headers = ['Content-Type: text/plain; charset=UTF-8', 'From: MangaYummy <' . sanitize_email($admin_email) . '>'];
            wp_mail($admin_email, $subject, $body, $headers);
        }
    }

    // Set category taxonomy
    if (!empty($category)) {
        $term = get_term_by('slug', $category, 'stiri_category');
        if ($term) {
            wp_set_post_terms($post_id, [$term->term_id], 'stiri_category');
        }
    } else {
        wp_set_post_terms($post_id, [], 'stiri_category');
    }

    // Set cover image from URL
    if (!empty($cover_url)) {
        update_post_meta($post_id, '_stire_cover_url', $cover_url);
    } elseif ($is_edit) {
        delete_post_meta($post_id, '_stire_cover_url');
    }

    // Set YouTube embed URL from submitted video URL
    if (!empty($video_url)) {
        $embed_url = mangayummy_get_youtube_embed_url($video_url);
        if ($embed_url) {
            update_post_meta($post_id, '_stire_youtube_url', $embed_url);
        } else {
            wp_send_json_error('URL YouTube invalid. Folosește un link valid către YouTube.');
        }
    } elseif ($is_edit) {
        delete_post_meta($post_id, '_stire_youtube_url');
    }

    wp_send_json_success([
        'message' => $response_message,
        'post_id' => $post_id,
    ]);
}

function mangayummy_get_youtube_embed_url($url) {
    $url = trim($url);
    if (empty($url)) {
        return '';
    }

    $parsed = wp_parse_url($url);
    if (!$parsed || empty($parsed['host'])) {
        return '';
    }

    $host = str_replace('www.', '', strtolower($parsed['host']));
    $path = trim($parsed['path'] ?? '', '/');

    if ($host === 'youtu.be') {
        if ($path) {
            return 'https://www.youtube.com/embed/' . esc_attr($path);
        }
        return '';
    }

    if (in_array($host, ['youtube.com', 'youtube-nocookie.com'], true)) {
        if (!empty($parsed['query'])) {
            parse_str($parsed['query'], $query_vars);
            if (!empty($query_vars['v'])) {
                return 'https://www.youtube.com/embed/' . esc_attr($query_vars['v']);
            }
        }

        if ($path) {
            if (strpos($path, 'embed/') === 0) {
                return 'https://www.youtube.com/embed/' . esc_attr(substr($path, 6));
            }
            if (strpos($path, 'v/') === 0) {
                return 'https://www.youtube.com/embed/' . esc_attr(substr($path, 2));
            }
            if (strpos($path, 'shorts/') === 0) {
                return 'https://www.youtube.com/embed/' . esc_attr(substr($path, 7));
            }
        }
    }

    return '';
}

function mangayummy_stire_author_can_auto_publish($user_id) {
    if (!$user_id) {
        return false;
    }
    return (bool) get_user_meta($user_id, 'trusted_stire_poster', true);
}

function mangayummy_mark_stire_author_trusted($new_status, $old_status, $post) {
    if ($post->post_type !== 'stire') {
        return;
    }

    if ($old_status !== 'pending' || $new_status !== 'publish') {
        return;
    }

    $author_id = intval(get_post_meta($post->ID, '_stire_author_id', true));
    if (!$author_id) {
        $author_id = intval($post->post_author);
    }
    if (!$author_id) {
        return;
    }

    update_user_meta($author_id, 'trusted_stire_poster', 1);
}
add_action('transition_post_status', 'mangayummy_mark_stire_author_trusted', 10, 3);

    // ===== OVERRIDE WORDPRESS TINYMC EDITOR TEXT COLOR IN ADMIN =====
    add_action('admin_head', function() {
        echo '<style>
            .js .tmce-active .wp-editor-area {
                color: #000000 !important;
                background-color: #ffffff !important;
            }
        </style>';
    });


