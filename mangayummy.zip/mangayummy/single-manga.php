<?php 
// Disable page caching for dynamic content
if (!defined('DONOTCACHEPAGE')) {
    define('DONOTCACHEPAGE', true);
}

// SEO: Send Last-Modified header for better crawl efficiency
$post_modified = get_the_modified_time('U');
if ($post_modified) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $post_modified) . ' GMT');
}

// Short browser cache - allows back button to work but ensures fresh content
// Disable cache for logged-in users during development
if (is_user_logged_in()) {
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
} else {
    header('Cache-Control: private, max-age=60');
}

get_header(); 

$has_giphy_api = function_exists('mangayummy_has_giphy_api_key') ? mangayummy_has_giphy_api_key() : (trim((string) get_option('mangayummy_giphy_api_key', '')) !== '');

// Load all post meta once to avoid repeated get_post_meta calls
$manga_id = get_the_ID();
$manga_meta = get_post_meta($manga_id);
?>

<div id="main-page" class="manga-page">

<?php
// 18+ age warning banner
$manga_id = get_the_ID();
$is_18_content = $manga_meta['_manga_18'][0] ?? '';
if ($is_18_content) {
    // display simple informative message instead of a modal
    echo '<div class="nsfw-alert">' . esc_html(
    'This manga may not be suitable for all ages or for viewing in public places (NSFW).'
    ) . '</div>';
}
?>
<section class="manga-overview">
<div class="profile-manga">
  <div class="summary_content_wrap">
    <div class="summary_image">
      <div class="manga-cover shadow-md shadow-black/50" data-manga-id="<?php echo get_the_ID(); ?>" data-current-status="<?php echo esc_attr(is_user_logged_in() ? (function_exists('mangayummy_get_manga_status') ? mangayummy_get_manga_status(get_current_user_id(), get_the_ID()) : '') : ''); ?>">
        <span id="mangaLiveStatus" class="manga-status status-<?php echo esc_attr(strtolower($manga_meta['_status'][0] ?? '')); ?>" data-status="<?php echo esc_attr(strtolower($manga_meta['_status'][0] ?? '')); ?>"><?php
          $status = strtolower($manga_meta['_status'][0] ?? '');
          if ($status === 'ongoing') {
            _e('În desfășurare', 'mangayummy');
          } elseif ($status === 'completed') {
            _e('Finalizat', 'mangayummy');
          } elseif ($status === 'hiatus') {
            _e('În Pauză', 'mangayummy');
          } elseif ($status === 'cancelled') {
            _e('Anulat', 'mangayummy');
          } else {
            echo esc_html($status);
          }
        ?></span>
        <?php $sm_status = is_user_logged_in() ? (function_exists('mangayummy_get_manga_status') ? mangayummy_get_manga_status(get_current_user_id(), get_the_ID()) : '') : ''; ?>
        <span class="status-badge <?php echo $sm_status ? 'status-' . esc_attr($sm_status) : ''; ?>">
          <?php
          $badge_labels = [
            'reading' => 'Reading',
            'planned' => 'Planned',
            'completed' => 'Completed',
            'paused' => 'Paused',
            'abandoned' => 'Dropped'
          ];
          if ($sm_status && isset($badge_labels[$sm_status])) echo esc_html($badge_labels[$sm_status]);
          ?>
        </span>
        <div class="manga-actions">
          <button class="manga-actions-toggle" aria-haspopup="true" aria-expanded="false">⋯</button>
          <ul class="manga-actions-menu" role="menu">
            <li class="manga-action" data-status="reading">Reading</li>
            <li class="manga-action" data-status="planned">Planned</li>
            <li class="manga-action" data-status="completed">Completed</li>
            <li class="manga-action" data-status="paused">Paused</li>
            <li class="manga-action" data-status="abandoned">Dropped</li>
          </ul>
        </div>
        <?php
          $cover_image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
          if (!$cover_image_url) {
              // Try meta cover image URL
              $cover_image_url = $manga_meta['_cover_image_url'][0] ?? '';
          }
          if (!$cover_image_url) {
              // Try legacy cover image meta
              $cover_image_url = $manga_meta['_cover_image'][0] ?? '';
          }
          if (!$cover_image_url) {
              $cover_image_url = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22400%22 viewBox=%220 0 300 400%22%3E%3Crect fill=%22%231a1a1a%22 width=%22300%22 height=%22400%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 font-family=%22Arial%22 font-size=%2224%22 fill=%22%23666%22%3ENo Cover%3C/text%3E%3C/svg%3E';
          }
        ?>
        <img class="shadow-md shadow-black/50" src="<?php echo esc_url($cover_image_url); ?>" data-full-url="<?php echo esc_url($cover_image_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" loading="lazy" fetchpriority="high" decoding="async">
        <?php $rank = mangayummy_get_manga_rank(get_the_ID()); echo '<span class="rank-pill" aria-hidden="true"><i class="fa fa-hashtag"></i> <span class="rank">' . ($rank ?: 'N/A') . '</span></span>'; ?>

        <!-- MangaYummy-style lightbox -->
        <div id="mangayummy-lightbox" class="mangayummy-lightbox" aria-hidden="true" role="dialog" aria-label="Cover preview">
          <img id="mangayummy-lightbox-img" class="mangayummy-lightbox-img" src="" alt="<?php echo esc_attr(get_the_title() . ' cover'); ?>">
        </div>

      </div>

      <?php
        // Compact action buttons placed directly under the cover image.
        $current_progress = is_user_logged_in() ? mangayummy_get_manga_progress(get_current_user_id(), get_the_ID()) : 0;
        $total_chapters = $manga_meta['_final_chapter'][0] ?? '';
        $total_chapters = $total_chapters ? floatval($total_chapters) : 0;
        $has_progress = intval($current_progress) > 0;
        $is_following = is_user_logged_in() ? mangayummy_is_following(get_current_user_id(), get_the_ID()) : false;
      ?>
      <div class="manga-summary-actions compact-tooltip-actions">
        <div class="meta-icon-row">
          <div class="meta-icon-box bookmark-box"
               data-post="<?php echo get_the_ID(); ?>"
               data-nonce="<?php echo wp_create_nonce('mangayummy_bookmark_nonce'); ?>"
               data-logged-in="<?php echo is_user_logged_in() ? '1' : '0'; ?>"
               data-tooltip-content="Favorite"
               aria-label="Favorite"
               title="Favorite">
              <svg class="meta-svg-icon <?php echo (is_user_logged_in() && mangayummy_is_bookmarked(get_the_ID())) ? 'active' : ''; ?>" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              <span class="meta-count"><?php echo mangayummy_bookmark_count(get_the_ID()); ?></span>
              <span class="meta-label">Favorite</span>
          </div>

          <div class="meta-icon-box follow-box"
               data-manga="<?php echo get_the_ID(); ?>"
               data-nonce="<?php echo wp_create_nonce('mangayummy_follow_nonce'); ?>"
               data-following="<?php echo $is_following ? '1' : '0'; ?>"
               data-logged-in="<?php echo is_user_logged_in() ? '1' : '0'; ?>"
               data-tooltip-content="<?php echo esc_attr($is_following ? 'You are following' : 'Follow'); ?>"
               aria-label="<?php echo esc_attr($is_following ? 'You are following' : 'Follow'); ?>"
               title="<?php echo esc_attr($is_following ? 'You are following' : 'Follow'); ?>">
              <svg class="meta-svg-icon <?php echo $is_following ? 'active' : ''; ?>" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span class="meta-count"><?php echo intval( mangayummy_get_manga_follow_count(get_the_ID()) ); ?></span>
              <span class="meta-label"><?php echo $is_following ? 'You are following' : 'Follow'; ?></span>
          </div>

          <div class="meta-icon-box progress-box"
               data-manga-id="<?php echo get_the_ID(); ?>"
               data-logged-in="<?php echo is_user_logged_in() ? '1' : '0'; ?>"
               data-tooltip-content="Chapters read"
               aria-label="Chapters read"
               title="Chapters read">
              <?php if ($has_progress): ?>
              <svg class="meta-svg-icon book-open" viewBox="0 0 24 24" fill="currentColor"><path d="M21 4H3a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1zM4 18V6h7v12H4zm16 0h-7V6h7v12z"/><path d="M6 8h3v2H6zm0 4h3v2H6zm9-4h3v2h-3zm0 4h3v2h-3z"/></svg>
              <?php else: ?>
              <svg class="meta-svg-icon book-closed" viewBox="0 0 24 24" fill="currentColor"><path d="M6 22h15v-2H6.012C5.55 19.988 5 19.805 5 19s.55-.988 1.012-1H21V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2zM5 8V4a1 1 0 0 1 1-1h13v12H6c-.364 0-.706.085-1 .236V8z"/></svg>
              <?php endif; ?>
              <span class="meta-count">
                <?php echo intval($current_progress); ?>
                <?php if ($total_chapters > 0): ?>
                  / <?php echo intval($total_chapters); ?>
                <?php endif; ?>
              </span>
              <span class="meta-label">Capitole</span>
          </div>

          <div class="meta-icon-box report-action-box"
               id="mangaReportTrigger"
               role="button"
               tabindex="0"
               aria-expanded="false"
               aria-controls="mangaEditActionBar"
               data-tooltip-content="Report"
               aria-label="Report"
               title="Report">
              <i class="far fa-pencil" aria-hidden="true"></i>
          </div>
        </div>

        <div id="mangaEditActionBar" class="manga-edit-action-bar" hidden>
          <form id="mangaReportForm" class="manga-edit-action-form">
            <input type="hidden" name="manga_id" value="<?php echo get_the_ID(); ?>">
            <input type="hidden" name="action" value="mangayummy_submit_report">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('mangayummy_report_nonce'); ?>">

            <div class="report-form-footer">
              <button type="button" class="btn btn-secondary" id="mangaInlineEditorCancel">Anulează</button>
              <button type="submit" class="btn btn-primary">Trimite pentru verificare</button>
            </div>

            <div id="reportSuccess" class="alert alert-success" style="display:none;">✓ Propunerea a fost trimisă cu succes.</div>
            <div id="reportError" class="alert alert-danger" style="display:none;"></div>
          </form>
        </div>
        <div id="mangaEditToast" class="manga-edit-toast" role="status" aria-live="polite"></div>
      </div>
    </div>

    <style>
      #mangayummy-lightbox {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.85);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        opacity: 0;
        visibility: hidden;
        transition: opacity 250ms ease, visibility 250ms ease;
      }
      #mangayummy-lightbox.open {
        opacity: 1;
        visibility: visible;
      }
      #mangayummy-lightbox-img {
        max-height: 80vh;
        max-width: 90vw;
        width: auto;
        height: auto;
        border: 0;
        border-radius: 0;
        box-shadow: none;
        animation: mangayummyLightboxFadeIn 200ms ease-in;
      }
      @keyframes mangayummyLightboxFadeIn {
        from { opacity: 0; transform: scale(0.98); }
        to { opacity: 1; transform: scale(1); }
      }
    </style>

    <script>
      (function() {
        function initCoverLightbox() {
          var wrapper = document.querySelector('.summary_image .manga-cover');
          var cover = wrapper ? wrapper.querySelector('img[data-full-url]') : null;
          var lightbox = document.getElementById('mangayummy-lightbox');
          var lightboxImg = document.getElementById('mangayummy-lightbox-img');
          if (!cover || !lightbox || !lightboxImg) return;

          var fullSrc = cover.dataset.fullUrl || cover.src;
          cover.style.cursor = 'zoom-in';
          cover.addEventListener('click', function(e) {
            e.preventDefault();
            lightboxImg.src = fullSrc;
            lightbox.classList.add('open');
            lightbox.setAttribute('aria-hidden', 'false');
          });

          var closeLightbox = function () {
            lightbox.classList.remove('open');
            lightbox.setAttribute('aria-hidden', 'true');
            lightboxImg.src = '';
          };

          lightbox.addEventListener('click', closeLightbox);

          document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && lightbox.classList.contains('open')) {
              closeLightbox();
            }
          });
        }

        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', initCoverLightbox);
        } else {
          initCoverLightbox();
        }
      })();
    </script>

    <div class="summary_content">
      <?php
      // Always display the primary (Romanian) title on the manga page.
      // English title is used only for SEO/Yoast, not shown to users.
      $manga_title = get_the_title();
      echo '<h1 class="manga-title" id="mangaLiveTitle">' . esc_html( $manga_title ) . '</h1>';
      ?>
      <?php
      $alt_titles = maybe_unserialize($manga_meta['_alternative_titles'][0] ?? '');
      if (!is_array($alt_titles)) {
          $alt_titles = $alt_titles ? [$alt_titles] : []; // Backward compatibility
      }
      // If metadata was stored as a single string with slashes, split it so each title gets its own span
      if (count($alt_titles) === 1 && strpos($alt_titles[0], ' / ') !== false) {
          $alt_titles = array_map('trim', explode(' / ', $alt_titles[0]));
      }
      if (!empty($alt_titles)) {
        // list of alternate titles without label text
        echo '<h2 class="alt-titles manga-subtitle" id="mangaLiveAltTitlesRow">';
        echo '<span class="alt-titles-list" id="mangaLiveAltTitles">';
        $first = true;
        foreach ($alt_titles as $t) {
            if (! $first) {
                echo ' / ';
            }
            echo '<span itemprop="alternateName">' . esc_html($t) . '</span>';
            $first = false;
        }
        echo '</span>';
        echo '</h2>';
      }
      ?>

<?php
$post_id = get_the_ID();

$avg   = floatval($manga_meta['_rating_avg'][0] ?? 0);
$count = intval($manga_meta['_rating_count'][0] ?? 0);
$user_rating = 0;

if (is_user_logged_in()) {
  $uid = get_current_user_id();
  $user_rating = floatval(get_user_meta($uid, 'rating_' . $post_id, true));

  // Legacy fallback used in other parts of the theme.
  if ($user_rating <= 0) {
    $user_rating = floatval(get_user_meta($uid, 'manga_rated_' . $post_id, true));
  }
}

// total views for display in rating area
$total_views = function_exists('mangayummy_get_total_manga_views') ? mangayummy_get_total_manga_views($post_id) : 0;
$anilist_url = $manga_meta['_anilist_url'][0] ?? '';
$mal_url = $manga_meta['_myanimelist_url'][0] ?? '';
$anilist_rating_data = function_exists('mangayummy_get_anilist_rating_from_url') ? mangayummy_get_anilist_rating_from_url($anilist_url) : false;
$mal_rating_data = function_exists('mangayummy_get_mal_rating_from_url') ? mangayummy_get_mal_rating_from_url($mal_url) : false;

if ($avg <= 0) {
  $avg = 0;
  $count = 0;
}

?>

<div class="mangayummy-rating-wrap collapsible-rating"
     data-post="<?php echo $post_id; ?>"
     data-rating="<?php echo $avg; ?>"
  data-user-rating="<?php echo $user_rating; ?>"
  data-collapsible-rating="1"
     data-logged="<?php echo is_user_logged_in() ? '1' : '0'; ?>"
     data-debug-user="<?php echo is_user_logged_in() ? 'logged_in' : 'not_logged'; ?>"
     data-debug-user-id="<?php echo get_current_user_id(); ?>">

  <div class="mangayummy-rating-stars">
      <?php
      // For logged users with an existing vote, show their own stars.
      $display_rating = ($user_rating > 0) ? $user_rating : $avg;
      $filled = round($display_rating);
      for ($i = 1; $i <= 10; $i++): ?>
        <span class="star<?php echo $i <= $filled ? ' filled' : ''; ?>"
              data-value="<?php echo $i; ?>"></span>
      <?php endfor; ?>
      <span class="rating-meta-inline">
        <span class="rating-number"><?php echo number_format($avg, 1); ?></span>
        <span class="rating-views" aria-label="Vizualizari manga">
          <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false">
            <path d="M10 14.23c1.17 0 2.17-.41 2.99-1.24A4.08 4.08 0 0014.22 10c0-1.17-.41-2.17-1.23-3A4.07 4.07 0 0010 5.78c-1.17 0-2.17.41-2.99 1.24A4.08 4.08 0 005.78 10c0 1.17.41 2.17 1.23 3A4.07 4.07 0 0010 14.22Zm0-2.07c-.6 0-1.11-.21-1.53-.63A2.09 2.09 0 017.85 10c0-.6.2-1.11.63-1.53.41-.42.92-.63 1.52-.63s1.11.21 1.53.63.62.93.62 1.53-.2 1.11-.63 1.53c-.41.42-.92.63-1.52.63ZM10 17c-2.05 0-3.95-.54-5.7-1.63A11.29 11.29 0 01.24 11.01c-.09-.14-.15-.3-.19-.47a2.52 2.52 0 010-1.07c.04-.17.1-.34.2-.48A11.29 11.29 0 014.3 4.63 10.56 10.56 0 0110 3c2.05 0 3.95.54 5.7 1.63a11.28 11.28 0 014.06 4.36c.09.14.15.3.19.47a2.53 2.53 0 010 1.07c-.04.17-.1.34-.2.48a11.29 11.29 0 01-4.06 4.36A10.56 10.56 0 0110 17Z" transform="translate(0, 0)"></path>
          </svg>
          <span class="rating-views-count"><?php echo number_format((int) $total_views); ?></span>
        </span>
        <?php if ($count > 0): ?>
          <span class="rating-raters" aria-label="Număr de ratinguri">
            <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false">
              <path d="M0 15.19c0-.5.1-.95.33-1.35.22-.4.52-.7.91-.94a11.13 11.13 0 015.96-1.64 11.48 11.48 0 015.94 1.64c.39.23.7.54.91.94.22.4.33.85.33 1.35v.57A2.19 2.19 0 0112.17 18H2.2A2.19 2.19 0 010 15.76v-.57ZM15.33 18a3.93 3.93 0 00.67-2.24v-.39c0-.6-.14-1.3-.44-2.09a3.8 3.8 0 00-1.45-1.86c.86.1 1.67.28 2.43.52.76.25 1.47.57 2.13.96.43.25.77.57 1 .97.22.4.33.82.33 1.23v.66A2.19 2.19 0 0117.79 18h-2.46ZM7.18 9.86c-1.09 0-2-.38-2.76-1.14A3.82 3.82 0 013.3 5.93c0-1.1.37-2.03 1.12-2.79A3.72 3.72 0 017.18 2c1.08 0 2 .38 2.75 1.14s1.13 1.7 1.13 2.8c0 1.09-.38 2.02-1.13 2.78A3.72 3.72 0 017.18 9.86Zm9.5-3.93c0 1.1-.37 2.03-1.13 2.79A3.72 3.72 0 0112.8 9.86c-.18 0-.4 0-.63-.03a2.82 2.82 0 01-.63-.13 6.21 6.21 0 000-7.54c.2-.06.42-.1.63-.13.2-.02.42-.03.63-.03 1.08 0 2 .38 2.75 1.14.76.76 1.13 1.7 1.13 2.8Z" transform="translate(0, 0)"></path>
            </svg>
            <span class="rating-raters-count"><?php echo number_format($count); ?></span>
          </span>
        <?php endif; ?>
        <?php if (!empty($anilist_rating_data['score']) || !empty($mal_rating_data['score'])): ?>
          <span class="content-ref-ids">
            <?php if (!empty($anilist_rating_data['score'])): ?>
              <a class="anilist-color link" data-balloon="AniList" data-balloon-pos="down" href="<?php echo esc_url($anilist_rating_data['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="Rating AniList">
                <div class="anilist logo-ref"></div>
                <span><?php echo esc_html(number_format((float) $anilist_rating_data['score'], 1)); ?></span>
              </a>
            <?php endif; ?>
            <?php if (!empty($mal_rating_data['score'])): ?>
              <a class="mal-color link" data-balloon="MyAnimeList" data-balloon-pos="down" href="<?php echo esc_url($mal_rating_data['url']); ?>" target="_blank" rel="noopener noreferrer" aria-label="Rating MyAnimeList">
                <div class="mal logo-ref"></div>
                <span><?php echo esc_html(number_format((float) $mal_rating_data['score'], 1)); ?></span>
              </a>
            <?php endif; ?>
          </span>
        <?php endif; ?>
      </span>

  </div>
</div>

    <div class="manga-meta-grid">

  <div class="meta-left">
    <!-- Rating display removed (duplicate of stars) -->


    <!-- Titluri alternative mutate sus, sub H1, pentru SEO și structură semantică -->
    <?php
    $authors = get_the_terms(get_the_ID(), 'author');
    $artists = get_the_terms(get_the_ID(), 'artist');
    $search_url = home_url('/browse/');

    $author_links = array();
    if ($authors) {
      foreach ($authors as $author_term) {
        // use a custom param to avoid conflicting with WP's "author" query var
        $author_link = add_query_arg('filter_author', $author_term->slug, $search_url);
        $author_links[] = '<a href="' . esc_url($author_link) . '" style="color:rgba(177,197,206,1) !important;">' . esc_html($author_term->name) . '</a>';
      }
    }
    $authors_str = implode(', ', $author_links);

    $artist_links = array();
    if ($artists) {
      foreach ($artists as $artist_term) {
        $artist_link = add_query_arg('filter_artist', $artist_term->slug, $search_url);
        $artist_links[] = '<a href="' . esc_url($artist_link) . '" style="color:rgba(177,197,206,1) !important;">' . esc_html($artist_term->name) . '</a>';
      }
    }
    $artists_str = implode(', ', $artist_links);

    // If author and artist are the same, show a combined label rather than duplicating the name.
    $author_names = array_map(function($t) { return strtolower(trim($t->name)); }, $authors ?: []);
    $artist_names = array_map(function($t) { return strtolower(trim($t->name)); }, $artists ?: []);
    sort($author_names);
    sort($artist_names);
    $same_author_artist = !empty($author_names) && $author_names === $artist_names;
    ?>

    <?php if ($same_author_artist): ?>
      <div class="meta-item" id="mangaLiveAuthorArtistRow"><strong>Autor și Artist</strong> <span id="mangaLiveAuthorArtist"><?php echo $authors_str; ?></span></div>
    <?php else: ?>
      <?php if ($authors_str): ?>
        <div class="meta-item" id="mangaLiveAuthorRow"><strong>Autor</strong> <span id="mangaLiveAuthor"><?php echo $authors_str; ?></span></div>
      <?php endif; ?>
      <?php if ($artists_str): ?>
        <div class="meta-item" id="mangaLiveArtistRow"><strong>Artist</strong> <span id="mangaLiveArtist"><?php echo $artists_str; ?></span></div>
      <?php endif; ?>
    <?php endif; ?>

    <?php
    $genres = get_the_terms(get_the_ID(), 'genre');
    if ($genres):
      $search_url = home_url('/browse/');
      $red_genres = array('sângeros', 'violența sexuală', 'viol', 'matur', 'nuditate', 'tragedie', 'sinucidere', 'masturbare', 'sex în grup', 'adult', 'ecchi', 'hentai', 'canibalism', 'prostituţie', 'tragedie', 'smut', 'yandere', 'sclavie', 'anal', 'droguri');
      $gray_genres = array(
        'ticăloasă', 'harem', 'gyaru', 'viața școlară',
        'alpinism', 'adopţie', 'activități în aer liber', 'adaptare', 'amnezie', 'animale', 'anti-erou', 'arte marțiale', 'asasini', 'basm', 'biografic', 'bisexual', 'blesteme',
        'călătorie', 'căsătorie', 'clonă', 'club școlar', 'crimă', 'cult', 'cultivare', 'delincvent', 'demoni', 'desen', 'dizabilitate', 'dragoni', 'educațional', 'elf', 'extratereștri', 'fantome', 'filosofic', 'filozofie', 'fugar', 'gemenii', 'groază', 'harem feminin', 'horror', 'incest', 'îngeri', 'intimidare', 'isekai', 'istoric', 'jocuri de noroc', 'jocuri video', 'josei', 'literatură clasică', 'loli', 'magie', 'majordom', 'manipularea timpului', 'masochism', 'medical', 'medieval', 'militar', 'monștri', 'ntr', 'politică', 'poliţie', 'post-apocaliptic', 'protagonist masculin', 'protagonistă feminină', 'psihologie', 'pustie', 'război', 'răzbunare', 'reîncarnare', 'religie', 'sadism', 'salt în timp', 'samurai', 'şantaj', 'schimb de gen', 'şcoală', 'sf', 'solitudine', 'sport', 'superputeri', 'supranatural', 'supravieţuire', 'temniță', 'terorism', 'thriller', 'tranvestit', 'triunghi amoros', 'tsundere', 'vampiri', 'viața de apoi', 'viața de zi cu zi', 'zei', 'zombi', 'vikingi'
        , 'milf', 'actorie', 'hărțuire', 'cosplay', 'colegiu', 'angajați de birou', 'detectiv', 'Orfan', 'tortură', 'orfan', 'idol', 'realitate virtuală', 'ninja', 'kuudere', 'tomboy', 'mafia'
      );
      
      // First sort alphabetically by name
      usort($genres, function($a, $b) {
        return strcmp($a->name, $b->name);
      });
      
      // Separate genres into five groups: oneshot, doujinshi, normal, red, gray
      $oneshot_genres = array();
      $doujinshi_genres = array();
      $normal_genres = array();
      $red_genres_list = array();
      $gray_genres_list = array();
      
      foreach ($genres as $genre) {
        $genre_name_lower = strtolower($genre->name);
        if (stripos($genre->slug, 'oneshot') !== false || stripos($genre->name, 'oneshot') !== false) {
          $oneshot_genres[] = $genre;
        } elseif (stripos($genre->slug, 'doujinshi') !== false || stripos($genre->name, 'doujinshi') !== false) {
          $doujinshi_genres[] = $genre;
        } elseif (in_array($genre_name_lower, $gray_genres)) {
          $gray_genres_list[] = $genre;
        } elseif (in_array($genre_name_lower, $red_genres)) {
          $red_genres_list[] = $genre;
        } else {
          $normal_genres[] = $genre;
        }
      }
      
      // Combine: oneshot first, then doujinshi, then red, then normal, then gray
      $genres = array_merge($oneshot_genres, $doujinshi_genres, $red_genres_list, $normal_genres, $gray_genres_list);
      
      $genre_links = array();
      foreach ($genres as $genre) {
        $genre_link = add_query_arg('genre', $genre->slug, $search_url);
        $classes = array();
        if (in_array(strtolower($genre->name), $red_genres)) {
          $classes[] = 'genre-red';
        }
        // Add gray color for specified genres
        if (in_array(strtolower($genre->name), $gray_genres)) {
          $classes[] = 'genre-gray';
        }
        // Add explicit class for doujinshi so CSS can target it reliably
        // Mark as doujinshi if slug or name contains the term (handles variants)
        if (stripos($genre->slug, 'doujinshi') !== false || stripos($genre->name, 'doujinshi') !== false) {
          $classes[] = 'genre-doujinshi';
        }
        $class_attr = $classes ? 'class="' . esc_attr(implode(' ', $classes)) . '"' : '';
        // Inline style fallback for doujinshi to ensure color appears immediately
        $style_attr = '';
        // remove inline color styles; colors should be handled by CSS classes instead
        // (doujinshi/gray colors can be defined in stylesheet if needed)
        // previously we used inline styles here, but they are no longer desired.
        $genre_links[] = '<a href="' . esc_url($genre_link) . '" ' . $class_attr . ' ' . $style_attr . '>' . esc_html($genre->name) . '</a>';
      }
      // join without comma, just a space between items
      $genres_str = implode(' ', $genre_links);
    ?>
      <div class="meta-item meta-genres" id="mangaLiveGenresRow"><strong>Genuri</strong> <span id="mangaLiveGenres"><?php echo $genres_str; ?></span></div>
    <?php endif; ?>

    <?php
      // translator server user field – saved for later output
      $translator_user = $manga_meta['_translator_user'][0] ?? '';
      // release year metadata
      $year = $manga_meta['_release_year'][0] ?? '';
      $year_end = $manga_meta['_release_year_end'][0] ?? '';

      // Use get_post_meta() with $single = true so WordPress will unserialize the array for us.
      $official_raw_urls = get_post_meta($manga_id, '_official_raw_urls', true);

      // Normalize different storage formats (serialized array, plain URL string, newline-separated list)
      if (is_string($official_raw_urls)) {
          $trimmed = trim($official_raw_urls);
          if (strpos($trimmed, "\n") !== false || strpos($trimmed, "\r") !== false) {
              $official_raw_urls = array_filter(array_map('trim', preg_split('/[\r\n]+/', $trimmed)));
          } elseif (filter_var($trimmed, FILTER_VALIDATE_URL)) {
              $official_raw_urls = [$trimmed];
          } else {
              $official_raw_urls = [];
          }
      }

      if (is_array($official_raw_urls)) {
          $official_raw_urls = array_filter($official_raw_urls, function($url) {
              return filter_var(trim($url), FILTER_VALIDATE_URL);
          });
      } else {
          $official_raw_urls = [];
      }

      // Backward compatibility: check for old single URL field
      if (empty($official_raw_urls)) {
        $old_url = get_post_meta($manga_id, '_official_raw_url', true) ?? '';
        $official_raw_urls = $old_url ? [$old_url] : [];
      }
      if (!empty($official_raw_urls) && is_array($official_raw_urls)):
        ?>
        <div class="meta-item desktop-hide" style="display: flex; align-items: center;">
          <strong style="margin: 0;">Citește sau cumpără</strong>
          <span class="external-links">
            <?php foreach ($official_raw_urls as $official_raw_url):
              // Detect domain and get appropriate logo
              $parsed_url = parse_url($official_raw_url);
              $domain = strtolower($parsed_url['host'] ?? '');
              $logo_url = '';
              $alt_text = 'Oficial Raw';

              // Map domains to logos
              if (strpos($domain, 'bilibili.com') !== false) {
                $logo_url = 'https://www.bilibili.com/favicon.ico';
                $alt_text = 'Bilibili Manga';
              } elseif (strpos($domain, 'naver.com') !== false) {
                $logo_url = 'https://ssl.pstatic.net/static/nstore/series_favicon_152.ico';
                $alt_text = 'Naver Webtoon';
              } elseif (strpos($domain, 'webtoons.com') !== false) {
                $logo_url = 'https://webtoons-static.pstatic.net/image/favicon/favicon.ico?dt=2017082301';
                $alt_text = 'Webtoons';
              } elseif (strpos($domain, 'webtoon') !== false) {
                $logo_url = 'https://webtoon-phinf.pstatic.net/20210118_123/1610966827518qPWq8_JPEG/favicon.ico';
                $alt_text = 'Webtoon';
              } elseif (strpos($domain, 'tappytoon') !== false) {
                $logo_url = 'https://www.tappytoon.com/favicon.ico';
                $alt_text = 'Tappytoon';
              } elseif (strpos($domain, 'tapas') !== false) {
                $logo_url = 'https://tapas.io/favicon.ico';
                $alt_text = 'Tapas';
              } elseif (strpos($domain, 'kodansha') !== false) {
                $logo_url = 'https://kodansha.us/kodansha-favicon.png';
                $alt_text = 'Kodansha US';
              } elseif (strpos($domain, 'lezhin') !== false) {
                $logo_url = 'https://ccdn.lezhin.com/files/assets/img/favicon.ico';
                $alt_text = 'Lezhin';
              } elseif (strpos($domain, 'tencent') !== false) {
                $logo_url = 'https://www.tencent.com/favicon.ico';
                $alt_text = 'Tencent';
              } elseif (strpos($domain, 'page.kakao.com') !== false) {
                $logo_url = 'https://page.kakaocdn.net/pageweb/resources/favicon/favicon.ico';
                $alt_text = 'Kakao Page';
              } elseif (strpos($domain, 'webtoon.kakao.com') !== false) {
                $logo_url = 'https://page.kakaocdn.net/pageweb/resources/favicon/favicon.ico';
                $alt_text = 'Kakao Webtoon';
              } elseif (strpos($domain, 'kakao') !== false) {
                $logo_url = 'https://page.kakao.com/favicon.ico';
                $alt_text = 'Kakao';
              } elseif (strpos($domain, 'sfacg.com') !== false) {
                $logo_url = 'https://mm.sfacg.com/favicon.ico';
                $alt_text = 'SFACG';
              } elseif (strpos($domain, 'shonenmagazine.com') !== false) {
                $logo_url = 'https://pocket.shonenmagazine.com/favicon.ico';
                $alt_text = 'Shonen Magazine';
              } elseif (strpos($domain, 'shonenjump.com') !== false) {
                $logo_url = 'https://www.shonenjump.com/favicon.ico';
                $alt_text = 'Shonen Jump';
              } elseif (strpos($domain, 'shonenjumpplus.com') !== false) {
                $logo_url = 'https://cdn-ak.shonenjumpplus.com/images/favicon.ico?1770340471';
                $alt_text = 'Shonen Jump Plus';
              } elseif (strpos($domain, 'mangaplus.shueisha.co.jp') !== false) {
                $logo_url = 'https://mangaplus.shueisha.co.jp/favicon.ico';
                $alt_text = 'Manga Plus';
              } elseif (strpos($domain, 'jumpsq.shueisha.co.jp') !== false) {
                $logo_url = 'https://jumpsq.shueisha.co.jp/favicon.ico';
                $alt_text = 'Jump SQ';
              } elseif (strpos($domain, 'bookwalker.jp') !== false) {
                $logo_url = 'https://bookwalker.jp/favicon.ico';
                $alt_text = 'BookWalker';
              } elseif (strpos($domain, 'toonboom') !== false) {
                $logo_url = 'https://toonboom.com/favicon.ico';
                $alt_text = 'Toon Boom';
              } elseif (strpos($domain, 'comixology') !== false || strpos($domain, 'amazon') !== false) {
                $logo_url = 'https://www.amazon.com/favicon.ico';
                $alt_text = 'Amazon/Comixology';
              } elseif (strpos($domain, 'drive.google.com') !== false) {
                $logo_url = 'https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png';
                $alt_text = 'Google Drive';
              } elseif (strpos($domain, 'pixiv.net') !== false || strpos($domain, 'pixiv') !== false) {
                $logo_url = 'https://www.pixiv.net/favicon.ico';
                $alt_text = 'Pixiv';
              } elseif (strpos($domain, 'webcomicgamma.takeshobo.co.jp') !== false) {
                $logo_url = 'https://webcomicgamma.takeshobo.co.jp/favicon.ico';
                $alt_text = 'Webcomic Gamma';
              } elseif (strpos($domain, 'takecomic.jp') !== false) {
                $logo_url = 'https://takecomic.jp/favicon.ico';
                $alt_text = 'Take Comic';
              // removed explicit mangadex favicon mapping
              } elseif (strpos($domain, 'mangakakalot') !== false) {
                $logo_url = 'https://mangakakalot.com/favicon.ico';
                $alt_text = 'MangaKakalot';
              } elseif (strpos($domain, 'manganelo') !== false) {
                $logo_url = 'https://manganelo.com/favicon.ico';
                $alt_text = 'MangaNelo';
              } elseif (strpos($domain, 'kuaikanmanhua.com') !== false) {
                $logo_url = 'https://www.kuaikanmanhua.com/favicon.ico';
                $alt_text = 'Kuaikan Manhua';
              } elseif (strpos($domain, 'global.toptoon.com') !== false) {
                $logo_url = 'https://global.toptoon.com/favicon.ico';
                $alt_text = 'Toptoon';
              } elseif (strpos($domain, 'comic-days.com') !== false) {
                $logo_url = 'https://cdn.comic-days.com/images/favicon.ico?1770272153';
                $alt_text = 'Comic Days';
              } elseif (strpos($domain, 'comic-medu.com') !== false) {
                $logo_url = '//cdn-public.comici.jp/content/12/favicon/202309281918424786AA97CB8DC5D9CD1AA28337BEDCECECC.png';
                $alt_text = 'Comic MeDu';
              } elseif (strpos($domain, 'postype.com') !== false) {
                $logo_url = 'https://postype.com/favicon.ico';
                $alt_text = 'Postype';
              } elseif (strpos($domain, 'twitter') !== false) {
                $logo_url = 'https://abs.twimg.com/favicons/twitter.3.ico';
                $alt_text = 'Twitter';
              } elseif (strpos($domain, 'yanmaga.jp') !== false) {
                $logo_url = 'https://yanmaga.jp/favicon.ico';
                $alt_text = 'Yanmaga Web';
              } elseif (strpos($domain, 'tonarinoyj.jp') !== false) {
                $logo_url = 'https://cdn.tonarinoyj.jp/images/favicon.ico?1771307842';
                $alt_text = 'Tonari no Young Jump';
              } elseif (strpos($domain, 'comic-walker.com') !== false) {
                $logo_url = 'https://comic-walker.com/favicons/favicon.ico';
                $alt_text = 'Comic Walker';
              } elseif (strpos($domain, 'seiga.nicovideo.jp') !== false || strpos($domain, 'nicovideo.jp') !== false) {
                $logo_url = 'https://www.nicovideo.jp/favicon.ico';
                $alt_text = 'Nico Seiga';
              } elseif (strpos($domain, 'comics.manga-bang.com') !== false) {
                $logo_url = '//cdn-public.comici.jp/content/11/favicon/2023080310161913412C928E7D8CF82971057C36281C8BD99.png';
                $alt_text = 'Manga Bang';
              } elseif (strpos($domain, 'comic-gardo.com') !== false) {
                $logo_url = 'https://cdn.comic-gardo.com/images/favicon.ico?1770616285';
                $alt_text = 'Comic Gardo';
              } elseif (strpos($domain, 'toptoon.com') !== false) {
                $logo_url = 'https://toptoon.com/favicon.ico';
                $alt_text = 'Toptoon';
              } elseif (strpos($domain, 'ac.qq.com') !== false) {
                $logo_url = 'https://ac.qq.com/favicon.ico';
                $alt_text = 'Tencent AC QQ';
              } elseif (strpos($domain, 'jp.square-enix.com') !== false) {
                $logo_url = 'https://www.jp.square-enix.com/favicon.ico';
                $alt_text = 'Square Enix';
              } elseif (strpos($domain, 'novelpia.com') !== false) {
                $logo_url = 'https://novelpia.com/favicon.ico';
                $alt_text = 'Novelpia';
              } elseif (strpos($domain, 'viz.com') !== false) {
                $logo_url = 'https://www.viz.com/favicon.ico';
                $alt_text = 'VIZ Official';
              } elseif (strpos($domain, 'yenpress.com') !== false) {
                $logo_url = 'https://yenpress.com/favicon.ico';
                $alt_text = 'Yen Press';
              } elseif (strpos($domain, 'fanfox.net') !== false) {
                $logo_url = 'https://fanfox.net/favicon.ico';
                $alt_text = 'Fanfox';
              }
              
              ?>
              <a href="<?php echo esc_url($official_raw_url); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo esc_attr($alt_text); ?>" style="display: inline-flex; align-items: center; gap: 5px; opacity: 1 !important;">
                <?php if ($logo_url): ?>
                  <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($alt_text); ?>" width="20" height="20" loading="lazy" decoding="async" style="vertical-align: middle;" onerror="this.outerHTML='<span class=&quot;raw-fallback-badge&quot;>RAW</span>'">
                <?php else: ?>
                  <span class="raw-fallback-badge">RAW</span>
                <?php endif; ?>
              </a>
            <?php endforeach; ?>
          </span>
        </div>
      <?php endif; ?>


    <?php
      $final_chapter = $manga_meta['_final_chapter'][0] ?? '';
      if ($final_chapter): ?>
        <div class="meta-item meta-item-final-chapter desktop-hide" id="mangaLiveFinalChapterMobileRow">
          <strong>Final chapter</strong> 
          <span class="final-chapter-badge">
            <span class="chapter-number" id="mangaLiveFinalChapterMobile"><?php echo esc_html($final_chapter); ?></span>
          </span>
        </div>
      <?php endif; ?>
  </div>

  <div class="meta-right">
    <div class="desktop-only">
      <?php
      // Inline meta items moved to right column (desktop)
      $manga_type = $manga_meta['_manga_type'][0] ?? '';
      $type_label = $manga_type ? ucfirst($manga_type) : 'Manga';
      $type_url = home_url('/manga/?type=' . strtolower($manga_type ? $manga_type : 'manga'));
      $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
      ?>
      <div class="meta-item" id="mangaLiveTypeRow"><strong>Tip</strong> <span id="mangaLiveTypeWrap"><a href="<?php echo esc_url($type_url); ?>" class="manga-type-link <?php echo esc_attr($type_class); ?>" id="mangaLiveType"><?php echo esc_html($type_label); ?></a></span></div>

      <?php
      $year = $manga_meta['_release_year'][0] ?? '';
      $year_end = $manga_meta['_release_year_end'][0] ?? '';
      if ($year):
        $search_url = home_url('/browse/');
        $year_url = add_query_arg('year', $year, $search_url);
        $display_year = $year_end ? $year . '-' . $year_end : $year;
      ?>
        <div class="meta-item" id="mangaLiveYearRow">
          <strong>Release year</strong>
          <span id="mangaLiveYearWrap"><a href="<?php echo esc_url($year_url); ?>" style="color:rgba(177,197,206,1) !important;" id="mangaLiveYear"><?php echo esc_html($display_year); ?></a></span>
        </div>
      <?php endif; ?>

      <?php
      $translator_user_meta = $manga_meta['_translator_user'][0] ?? '';
      $translator_user_id = 0;
      $translator_user_display = $translator_user_meta;

      if (!empty($translator_user_meta)) {
          if (is_numeric($translator_user_meta)) {
              // Stored as user ID (preferred)
              $translator_user_id = intval($translator_user_meta);
              $user_obj = get_user_by('ID', $translator_user_id);
              if ($user_obj) {
                  $translator_user_display = $user_obj->display_name ?: $user_obj->user_login;
              }
          } else {
              // Stored as username/display_name (legacy). Try to resolve to a user ID and cache it.
              $translator_cache_key = 'mangayummy_translator_user_' . sanitize_key($translator_user_meta);
              $translator_user_id = get_transient($translator_cache_key);

              if ($translator_user_id === false) {
                  $user_obj = null;

                  // search display_name exactly (may not be unique but usually is)
                  $user_query = new WP_User_Query(array(
                      'search'         => esc_attr($translator_user_meta),
                      'search_columns' => array('display_name'),
                      'number'         => 1,
                  ));
                  $users_found = $user_query->get_results();
                  if (!empty($users_found)) {
                      $user_obj = $users_found[0];
                  }

                  // fallback to login if display_name lookup failed
                  if (!$user_obj) {
                      $user_obj = get_user_by('login', $translator_user_meta);
                  }

                  $translator_user_id = $user_obj ? $user_obj->ID : 0;
                  set_transient($translator_cache_key, $translator_user_id, 60 * MINUTE_IN_SECONDS);
              }

              if ($translator_user_id) {
                  $user_obj = get_user_by('ID', intval($translator_user_id));
                  if ($user_obj) {
                      $translator_user_display = $user_obj->display_name ?: $user_obj->user_login;
                  }
              }
          }
      }

      if (!empty($translator_user_display)):
          $translator_link = '';
          if ($translator_user_id) {
              $translator_link = home_url('/profile/?view_user=' . intval($translator_user_id));
          }
      ?>
        <div class="meta-item" id="mangaLiveTranslatorRow">
          <strong>Romanian translation</strong>
          <span id="mangaLiveTranslator"><?php if ($translator_link): ?>
                  <a href="<?php echo esc_url($translator_link); ?>" class="translator-user-link" data-user-id="<?php echo intval($translator_user_id); ?>"><?php echo esc_html($translator_user_display); ?></a>
                <?php else: ?>
                  <?php echo esc_html($translator_user_display); ?>
                <?php endif; ?></span>
        </div>
      <?php endif; ?>

      

      <?php
      // Use get_post_meta() so WordPress unserializes the array for us.
      $official_raw_urls = get_post_meta($manga_id, '_official_raw_urls', true);
      if (empty($official_raw_urls)) {
        $old_url = get_post_meta($manga_id, '_official_raw_url', true) ?? '';
        $official_raw_urls = $old_url ? [$old_url] : [];
      }
      if (!empty($official_raw_urls) && is_array($official_raw_urls)):
        ?>
        <div class="meta-item" style="display: flex; align-items: center;">
          <strong style="margin: 0;">Read or buy</strong>
          <span class="external-links">
            <?php foreach ($official_raw_urls as $official_raw_url):
              // Detect domain and get appropriate logo
              $parsed_url = parse_url($official_raw_url);
              $domain = strtolower($parsed_url['host'] ?? '');
              $logo_url = '';
              $alt_text = 'Oficial Raw';

              // Map domains to logos
              if (strpos($domain, 'bilibili.com') !== false) {
                $logo_url = 'https://www.bilibili.com/favicon.ico';
                $alt_text = 'Bilibili Manga';
              } elseif (strpos($domain, 'naver.com') !== false) {
                $logo_url = 'https://ssl.pstatic.net/static/nstore/series_favicon_152.ico';
                $alt_text = 'Naver Webtoon';
              } elseif (strpos($domain, 'webtoons.com') !== false) {
                $logo_url = 'https://webtoons-static.pstatic.net/image/favicon/favicon.ico?dt=2017082301';
                $alt_text = 'Webtoons';
              } elseif (strpos($domain, 'webtoon') !== false) {
                $logo_url = 'https://webtoon-phinf.pstatic.net/20210118_123/1610966827518qPWq8_JPEG/favicon.ico';
                $alt_text = 'Webtoon';
              } elseif (strpos($domain, 'tappytoon') !== false) {
                $logo_url = 'https://www.tappytoon.com/favicon.ico';
                $alt_text = 'Tappytoon';
              } elseif (strpos($domain, 'tapas') !== false) {
                $logo_url = 'https://tapas.io/favicon.ico';
                $alt_text = 'Tapas';
              } elseif (strpos($domain, 'kodansha') !== false) {
                $logo_url = 'https://kodansha.us/kodansha-favicon.png';
                $alt_text = 'Kodansha US';
              } elseif (strpos($domain, 'lezhin') !== false) {
                $logo_url = 'https://ccdn.lezhin.com/files/assets/img/favicon.ico';
                $alt_text = 'Lezhin';
              } elseif (strpos($domain, 'tencent') !== false) {
                $logo_url = 'https://www.tencent.com/favicon.ico';
                $alt_text = 'Tencent';
              } elseif (strpos($domain, 'page.kakao.com') !== false) {
                $logo_url = 'https://page.kakaocdn.net/pageweb/resources/favicon/favicon.ico';
                $alt_text = 'Kakao Page';
              } elseif (strpos($domain, 'webtoon.kakao.com') !== false) {
                $logo_url = 'https://page.kakaocdn.net/pageweb/resources/favicon/favicon.ico';
                $alt_text = 'Kakao Webtoon';
              } elseif (strpos($domain, 'kakao') !== false) {
                $logo_url = 'https://page.kakao.com/favicon.ico';
                $alt_text = 'Kakao';
              } elseif (strpos($domain, 'sfacg.com') !== false) {
                $logo_url = 'https://mm.sfacg.com/favicon.ico';
                $alt_text = 'SFACG';
              } elseif (strpos($domain, 'shonenmagazine.com') !== false) {
                $logo_url = 'https://pocket.shonenmagazine.com/favicon.ico';
                $alt_text = 'Shonen Magazine';
              } elseif (strpos($domain, 'shonenjump.com') !== false) {
                $logo_url = 'https://www.shonenjump.com/favicon.ico';
                $alt_text = 'Shonen Jump';
              } elseif (strpos($domain, 'shonenjumpplus.com') !== false) {
                $logo_url = 'https://cdn-ak.shonenjumpplus.com/images/favicon.ico?1770340471';
                $alt_text = 'Shonen Jump Plus';
              } elseif (strpos($domain, 'mangaplus.shueisha.co.jp') !== false) {
                $logo_url = 'https://mangaplus.shueisha.co.jp/favicon.ico';
                $alt_text = 'Manga Plus';
              } elseif (strpos($domain, 'jumpsq.shueisha.co.jp') !== false) {
                $logo_url = 'https://jumpsq.shueisha.co.jp/favicon.ico';
                $alt_text = 'Jump SQ';
              } elseif (strpos($domain, 'bookwalker.jp') !== false) {
                $logo_url = 'https://bookwalker.jp/favicon.ico';
                $alt_text = 'BookWalker';
              } elseif (strpos($domain, 'toonboom') !== false) {
                $logo_url = 'https://toonboom.com/favicon.ico';
                $alt_text = 'Toon Boom';
              } elseif (strpos($domain, 'comixology') !== false || strpos($domain, 'amazon') !== false) {
                $logo_url = 'https://www.amazon.com/favicon.ico';
                $alt_text = 'Amazon/Comixology';
              } elseif (strpos($domain, 'drive.google.com') !== false) {
                $logo_url = 'https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png';
                $alt_text = 'Google Drive';
              } elseif (strpos($domain, 'pixiv.net') !== false || strpos($domain, 'pixiv') !== false) {
                $logo_url = 'https://www.pixiv.net/favicon.ico';
                $alt_text = 'Pixiv';
              } elseif (strpos($domain, 'webcomicgamma.takeshobo.co.jp') !== false) {
                $logo_url = 'https://webcomicgamma.takeshobo.co.jp/favicon.ico';
                $alt_text = 'Webcomic Gamma';
              } elseif (strpos($domain, 'takecomic.jp') !== false) {
                $logo_url = 'https://takecomic.jp/favicon.ico';
                $alt_text = 'Take Comic';
              // removed explicit mangadex favicon mapping
              } elseif (strpos($domain, 'mangakakalot') !== false) {
                $logo_url = 'https://mangakakalot.com/favicon.ico';
                $alt_text = 'MangaKakalot';
              } elseif (strpos($domain, 'manganelo') !== false) {
                $logo_url = 'https://manganelo.com/favicon.ico';
                $alt_text = 'MangaNelo';
              } elseif (strpos($domain, 'kuaikanmanhua.com') !== false) {
                $logo_url = 'https://www.kuaikanmanhua.com/favicon.ico';
                $alt_text = 'Kuaikan Manhua';
              } elseif (strpos($domain, 'global.toptoon.com') !== false) {
                $logo_url = 'https://global.toptoon.com/favicon.ico';
                $alt_text = 'Toptoon';
              } elseif (strpos($domain, 'comic-days.com') !== false) {
                $logo_url = 'https://cdn.comic-days.com/images/favicon.ico?1770272153';
                $alt_text = 'Comic Days';
              } elseif (strpos($domain, 'comic-medu.com') !== false) {
                $logo_url = '//cdn-public.comici.jp/content/12/favicon/202309281918424786AA97CB8DC5D9CD1AA28337BEDCECECC.png';
                $alt_text = 'Comic MeDu';
              } elseif (strpos($domain, 'postype.com') !== false) {
                $logo_url = 'https://postype.com/favicon.ico';
                $alt_text = 'Postype';
              } elseif (strpos($domain, 'twitter') !== false) {
                $logo_url = 'https://abs.twimg.com/favicons/twitter.3.ico';
                $alt_text = 'Twitter';
              } elseif (strpos($domain, 'yanmaga.jp') !== false) {
                $logo_url = 'https://yanmaga.jp/favicon.ico';
                $alt_text = 'Yanmaga Web';
              } elseif (strpos($domain, 'tonarinoyj.jp') !== false) {
                $logo_url = 'https://cdn.tonarinoyj.jp/images/favicon.ico?1771307842';
                $alt_text = 'Tonari no Young Jump';
              } elseif (strpos($domain, 'comic-walker.com') !== false) {
                $logo_url = 'https://comic-walker.com/favicons/favicon.ico';
                $alt_text = 'Comic Walker';
              } elseif (strpos($domain, 'seiga.nicovideo.jp') !== false || strpos($domain, 'nicovideo.jp') !== false) {
                $logo_url = 'https://www.nicovideo.jp/favicon.ico';
                $alt_text = 'Nico Seiga';
              } elseif (strpos($domain, 'comics.manga-bang.com') !== false) {
                $logo_url = '//cdn-public.comici.jp/content/11/favicon/2023080310161913412C928E7D8CF82971057C36281C8BD99.png';
                $alt_text = 'Manga Bang';
              } elseif (strpos($domain, 'comic-gardo.com') !== false) {
                $logo_url = 'https://cdn.comic-gardo.com/images/favicon.ico?1770616285';
                $alt_text = 'Comic Gardo';
              } elseif (strpos($domain, 'toptoon.com') !== false) {
                $logo_url = 'https://toptoon.com/favicon.ico';
                $alt_text = 'Toptoon';
              } elseif (strpos($domain, 'ac.qq.com') !== false) {
                $logo_url = 'https://ac.qq.com/favicon.ico';
                $alt_text = 'Tencent AC QQ';
              } elseif (strpos($domain, 'jp.square-enix.com') !== false) {
                $logo_url = 'https://www.jp.square-enix.com/favicon.ico';
                $alt_text = 'Square Enix';
              } elseif (strpos($domain, 'novelpia.com') !== false) {
                $logo_url = 'https://novelpia.com/favicon.ico';
                $alt_text = 'Novelpia';
              } elseif (strpos($domain, 'viz.com') !== false) {
                $logo_url = 'https://www.viz.com/favicon.ico';
                $alt_text = 'VIZ Official';
              } elseif (strpos($domain, 'yenpress.com') !== false) {
                $logo_url = 'https://yenpress.com/favicon.ico';
                $alt_text = 'Yen Press';
              } elseif (strpos($domain, 'fanfox.net') !== false) {
                $logo_url = 'https://fanfox.net/favicon.ico';
                $alt_text = 'Fanfox';
              }
               
              ?>
              <a href="<?php echo esc_url($official_raw_url); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo esc_attr($alt_text); ?>" style="display: inline-flex; align-items: center; gap: 5px; opacity: 1 !important;">
                <?php if ($logo_url): ?>
                  <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($alt_text); ?>" width="20" height="20" loading="lazy" decoding="async" style="vertical-align: middle;" onerror="this.outerHTML='<span class=&quot;raw-fallback-badge&quot;>RAW</span>'">
                <?php else: ?>
                  <span class="raw-fallback-badge">RAW</span>
                <?php endif; ?>
              </a>
            <?php endforeach; ?>
          </span>
        </div>
    <?php endif; ?>

      <?php
      $final_chapter = $manga_meta['_final_chapter'][0] ?? '';
      if ($final_chapter): ?>
        <div class="meta-item meta-item-final-chapter" id="mangaLiveFinalChapterRow">
          <strong>Final chapter</strong>
          <span class="final-chapter-badge">
            <span class="chapter-number" id="mangaLiveFinalChapter"><?php echo esc_html($final_chapter); ?></span>
          </span>
        </div>
    <?php endif; ?>

    </div>

  </div>

</div>

    <div class="manga-actions">
      <?php
      // Only Romanian chapters are supported now, so just pick the first one
      $manga_id_for_chapters = get_the_ID();
      $cache_key = 'manga_first_chapters_' . $manga_id_for_chapters;
      $cached_first_chapters = get_transient($cache_key);
      if ($cached_first_chapters === false) {
          $all_chapters = get_posts(array(
              'post_type' => 'chapter',
              'meta_query' => array(
                  array('key' => '_manga_id', 'value' => $manga_id_for_chapters)
              ),
              'posts_per_page' => -1,
              'fields' => 'ids',
              'no_found_rows' => true,
          ));
          $ro_chapters = [];
          foreach ($all_chapters as $chapter_id) {
              // ignore language meta entirely, assume ro
              $ro_chapters[] = $chapter_id;
          }
          usort($ro_chapters, function($a, $b) {
              $num_a = mangayummy_get_chapter_number($a);
              if ($num_a === null) $num_a = 999999;
              $num_b = mangayummy_get_chapter_number($b);
              if ($num_b === null) $num_b = 999999;
              return $num_a <=> $num_b;
          });
          $cached_first_chapters = array('ro' => !empty($ro_chapters) ? $ro_chapters[0] : 0);
          set_transient($cache_key, $cached_first_chapters, 15 * MINUTE_IN_SECONDS);
      }
      $manga_id = get_the_ID();
      ?>
      <?php
      $redirect_chapters_enabled = isset($manga_meta['_redirect_chapters_enabled'][0]) && $manga_meta['_redirect_chapters_enabled'][0] === '1';
      $redirect_chapters_url     = trim($manga_meta['_redirect_chapters_url'][0] ?? '');
      ?>

      <div class="manga-action-buttons">
          <?php
          $first_link = $cached_first_chapters['ro'] ? get_permalink($cached_first_chapters['ro']) : '#';
          $first_num = $cached_first_chapters['ro'] ? mangayummy_get_chapter_number($cached_first_chapters['ro']) : '';
          if ($redirect_chapters_enabled && !empty($redirect_chapters_url)) {
              if (strpos($redirect_chapters_url, '%chapter%') !== false) {
                  $first_link = str_replace('%chapter%', $first_num ?: '', $redirect_chapters_url);
              } elseif (strpos($redirect_chapters_url, '{chapter}') !== false) {
                  $first_link = str_replace('{chapter}', $first_num ?: '', $redirect_chapters_url);
              } else {
                  $first_link = $redirect_chapters_url;
              }
          }
            // Button label with chapter number
          if ($first_num) {
              $button_label = sprintf('Start reading: Chapter %s', esc_html($first_num));
          } else {
              $button_label = 'Start reading';
          }
          ?>
          <?php
          $first_target = ($redirect_chapters_enabled && !empty($redirect_chapters_url)) ? '_blank' : '_self';
          $first_rel = ($first_target === '_blank') ? 'noopener noreferrer' : '';
          ?>
          <a href="<?php echo esc_url($first_link); ?>" target="<?php echo esc_attr($first_target); ?>"<?php echo $first_rel ? ' rel="' . esc_attr($first_rel) . '"' : ''; ?> class="btn-read-first"><?php echo $button_label; ?></a>
          <?php if (current_user_can('manage_options')): ?>

          <?php endif; ?>
      </div>
    </div>

    <!-- Language modal removed entirely -->

    <!-- Reading status moved to the 3-dot actions menu above the cover -->


    <?php if (have_posts()) : while (have_posts()) : the_post(); endwhile; endif; ?>

    <section class="manga-summary">
<?php
// determine if the manga has a long description (more than ~4 lines worth of text)
$raw_desc = wp_strip_all_tags(get_the_content());
$has_long_desc = strlen(trim($raw_desc)) > 300; // adjust threshold as needed
?>
      <div class="summary-wrapper<?php echo $has_long_desc ? ' long-desc' : ''; ?>">
        <div class="summary-text" id="summaryText">
          <div id="mangaLiveDescription"><?php echo wpautop(get_the_content()); ?></div>
          <button id="bug-btn" class="bug-button" type="button" aria-label="Bug Hunter" title="🐛">
            <i class="far fa-bug" aria-hidden="true"></i>
          </button>
        </div>
      </div>

      <!-- replace arrow span with a generic "more" div for long descriptions -->
    <div class="summary-toggle more" id="summaryToggle" aria-expanded="false" style="cursor: pointer; display: none;">
      <!-- text or icon will be added by JS -->
    </div>

    </section>

  </section> <!-- .manga-overview -->

    <section class="manga-latest">
      <?php
      $manga_id = get_the_ID();
      $cache_key = 'manga_chapters_list_' . $manga_id;
      $chapters_data = get_transient($cache_key);

      if ($chapters_data === false) {
        $chapters = new WP_Query([
          'post_type' => 'chapter',
          'posts_per_page' => 500,
          'meta_query' => [
            [
              'key' => '_manga_id',
              'value' => $manga_id,
              'compare' => '='
            ]
          ],
          'meta_key' => '_chapter_number',
          'orderby' => 'meta_value_num',
          // Default ordering: newest chapters first (largest chapter number on top)
          'order' => 'DESC',
          'no_found_rows' => true,
          'update_post_term_cache' => false
        ]);

        // Pre-fetch all translation groups in one query
        $all_groups = array();
        $chapters_data = array();

        if ($chapters->have_posts()) {
          while ($chapters->have_posts()) {
            $chapters->the_post();
            $chapter_id = get_the_ID();
            $translation_group = get_post_meta($chapter_id, '_translation_group', true);

            if ($translation_group && !isset($all_groups[$translation_group])) {
              $term = get_term_by('name', $translation_group, 'translator_group');
              if ($term) {
                $link = get_term_link($term);
                $all_groups[$translation_group] = !is_wp_error($link) ? $link : '';
              } else {
                $all_groups[$translation_group] = '';
              }
            }

            $chapters_data[] = array(
              'id' => $chapter_id,
              'chapter_number' => mangayummy_get_chapter_number($chapter_id),
              'title' => get_the_title(),
              'permalink' => get_permalink(),
              'date' => get_the_date('U'),
              'author' => get_the_author(),
              'translation_group' => $translation_group,
              'translation_group_link' => $translation_group ? ($all_groups[$translation_group] ?? '') : '',
              'comment_count' => get_comments_number($chapter_id),
              'view_count' => mangayummy_get_chapter_views($chapter_id),
              'posted_date' => mangayummy_time_ago(get_the_date('U')),
              // language meta ignored - only Romanian supported
            );

          }
          wp_reset_postdata();
        }

        set_transient($cache_key, $chapters_data, 5 * MINUTE_IN_SECONDS);
      }

      $chapters_count = is_array($chapters_data) ? count($chapters_data) : 0;
      ?>

      <div class="section-title-container">
        <h3 class="section-title latest-chapters-title">
          Chapters<span id="chapters-count" class="chapters-count-label"></span>
        </h3>
        <!-- count label removed; will be injected into H3 itself -->

        <?php if ($chapters_count > 8): ?>
          <div class="chapter-controls">
            <span id="chapter-order-label" class="chapters-order-label">Descending</span>
            <button id="toggle-chapter-order" class="chapter-toggle-btn" data-order="desc" aria-label="Toggle order">
                <span class="icon-desc icon-active">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="sort-icon-down">
                        <path d="M12 5v14M19 12l-7 7-7-7"></path>
                    </svg>
                </span>
                <span class="icon-asc icon-hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="sort-icon-up">
                        <path d="M12 19V5M19 12l-7-7-7 7"></path>
                    </svg>
                </span>
            </button>
          </div>
        <?php endif; ?>
      </div>

      <?php if ($chapters_count > 8): ?>
        <div class="chapter-search">
          <input id="searchchapter" type="text" placeholder="Find a chapter (e.g. 15 or 117)" autocomplete="off">
        </div>
      <?php endif; ?>

      <div class="listing-chapters_wrap">
        <div class="wp-manga-chapter">
          <?php

          // Language counts not needed; site only serves Romanian chapters
          ?>

          <?php 
            // site only serves Romanian chapters; define counts to prevent notices
            $ro_chapters_count = count($chapters_data);
            $en_chapters_count = 0;
          ?>
          <?php if (!empty($chapters_data)): ?>
            <?php $shouldCollapse = false; ?>
            <div class="chapters-box">
              <ul class="chapters-list">
                <?php
                $totalChaps = count($chapters_data);
                $i = 0;
                $final_chapter_number = trim($manga_meta['_final_chapter'][0] ?? '');
                foreach ($chapters_data as $chapter_item):
                  $chapter_number_display = $chapter_item['chapter_number'] !== null ? $chapter_item['chapter_number'] : '';
                  $display_num = $chapter_number_display;
                ?>
                  <li class="latest-chapter-item" data-date="<?php echo esc_attr($chapter_item['date']); ?>" data-posted="<?php echo esc_attr($chapter_item['posted_date']); ?>" data-id="<?php echo esc_attr($chapter_item['id']); ?>" data-chapter="<?php echo esc_attr($chapter_number_display); ?>" data-title="<?php echo esc_attr($chapter_item['title']); ?>" data-display="<?php echo esc_attr($display_num); ?>">
                    <?php
                      // Redirect chapter links to external URL if enabled in manga settings
                      $chapter_link = $chapter_item['permalink'];
                      if (!empty($redirect_chapters_url) && $redirect_chapters_enabled) {
                          if (strpos($redirect_chapters_url, '%chapter%') !== false) {
                              $chapter_link = str_replace('%chapter%', $chapter_number_display ?: '', $redirect_chapters_url);
                          } elseif (strpos($redirect_chapters_url, '{chapter}') !== false) {
                              $chapter_link = str_replace('{chapter}', $chapter_number_display ?: '', $redirect_chapters_url);
                          } else {
                              $chapter_link = $redirect_chapters_url;
                          }
                      }
                    ?>
                    <?php
                      $chapter_target = ($redirect_chapters_enabled && !empty($redirect_chapters_url)) ? '_blank' : '_self';
                      $chapter_rel = ($chapter_target === '_blank') ? 'noopener noreferrer' : '';
                    ?>
                    <a href="<?php echo esc_url($chapter_link); ?>" target="<?php echo esc_attr($chapter_target); ?>"<?php echo $chapter_rel ? ' rel="' . esc_attr($chapter_rel) . '"' : ''; ?>>
                      <span class="chapter-main">
                      <?php
                        $chap_num = $display_num;
                        $chap_title = trim($chapter_item['title']);
                        if ($chap_num !== '') {
                          $chapter_number_class = 'chapter-number';
                          if ($redirect_chapters_enabled && !empty($redirect_chapters_url)) {
                              $chapter_number_class .= ' chapter-number-redirect';
                          }
                          echo '<span class="' . esc_attr($chapter_number_class) . '">Cap. ' . esc_html($chap_num) . '</span>';
                          if ($chap_title !== '') {
                            echo ' <span class="chapter-sep"> - </span> <span class="chapter-title">' . esc_html($chap_title) . '</span>';
                          }
                          if ($final_chapter_number !== '' && (string)$chap_num === (string)$final_chapter_number) {
                            echo ' <span class="chapter-final">SFÂRȘIT</span>';
                          }
                        } else {
                          // no chapter number available, show title only
                          echo '<span class="chapter-title">' . esc_html($chap_title) . '</span>';
                        }
                      ?>
                      </span>
                      <span class="chapter-meta">
                        <?php if ( ! empty( $chapter_item['translation_group'] ) ) :
                            $tg_name = $chapter_item['translation_group'];
                            $tg_link = $chapter_item['translation_group_link'] ?? '';
                        ?>
                            <span class="chapter-credit" data-url="<?php echo esc_url( $tg_link ); ?>">
                                <?php echo esc_html( $tg_name ); ?>
                            </span>
                        <?php endif; ?>

                        <?php if ($redirect_chapters_enabled && !empty($redirect_chapters_url)) : ?>
                            <span class="chapter-redirect-label" style="color:#ffb300;font-weight:700;margin-left:8px;"></span>
                        <?php endif; ?>

                        <span class="chapter-age"><?php echo esc_html($chapter_item['posted_date']); ?></span>
                      </span>
                    </a>
                  </li>
                <?php
                  $i++;
                endforeach;
                ?>
              </ul>
            </div>
            <script>
              // Mark chapter as read when opened
              document.addEventListener('DOMContentLoaded', function () {
                try {
                  const chapId = <?php echo (int) get_the_ID(); ?>;
                  const key = 'mangayummy_read_chapters';
                  const stored = localStorage.getItem(key);
                  const seen = stored ? JSON.parse(stored) : [];
                  if (!Array.isArray(seen)) return;
                  if (!seen.includes(chapId)) {
                    seen.push(chapId);
                    localStorage.setItem(key, JSON.stringify(seen));
                  }
                } catch (e) {
                  // ignore localStorage failures
                }
              });
            </script>
            <?php if ($ro_chapters_count === 0 && $en_chapters_count > 0): ?>
              <div class="no-ro-chapters-message" style="display: none;">
                <p>La moment nu există traducere în română.</p>
              </div>
            <?php endif; ?>
          <?php else: ?>
            <div class="no-chapters-message-all">
              <p>La moment nu sunt capitole disponibile.</p>
            </div>
            <div class="no-chapters-message-filtered" style="display: none;">
              <h3>Niciun capitol încă</h3>
              <p>Poate într-un viitor acest peak o să fie tradus în română!</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </section>

<?php
// OPTIMIZED: Single query for both count and display
$comments_cache_key = 'mangayummy_manga_comments_' . $manga_id;
$all_comments = get_transient($comments_cache_key);
if ($all_comments === false) {
  $all_comments = get_comments([
    'post_id' => $manga_id,
    'parent'  => 0,
    'status'  => 'approve',
    'orderby' => 'date',
    'order'   => 'DESC'
  ]);
  set_transient($comments_cache_key, $all_comments, 5); // cache for 5 seconds
}
$comments_count = get_comments_number(); // Count all comments including replies

// Get reviews count (comments from chapters)
$reviews_cache_key = 'mangayummy_reviews_count_' . $manga_id;
$reviews_count = get_transient($reviews_cache_key);
if ($reviews_count === false) {
    $reviews_count = get_comments([
        'status'     => 'approve',
        'parent'     => 0,
        'count'      => true,
        'meta_query' => [
            [
                'key'   => '_manga_id',
                'value' => $manga_id,
            ]
        ],
    ]);
    set_transient($reviews_cache_key, $reviews_count, 2 * MINUTE_IN_SECONDS);
}
?>

<section class="manga-comments-section">
  <div class="tabs-block content-page offset-top no-padding">
    <div class="tabs-header" style="overflow: visible;">
      <ul class="tabs bordered-top">
        <li class="active tabs-li bordered-top-left materiable" data-id="#comments-tab" id="comments">
          <span class="title" style="display: initial"><i class="fa fa-comment"></i> Comments</span>
          <span class="count"><?php echo $comments_count; ?></span>
        </li>
        <li class="tabs-li materiable" data-id="#reviews-tab" id="reviews">
          <span class="title" style="display: initial"><i class="fa fa-file-text"></i> Reviews</span>
          <span class="count"><?php echo $reviews_count; ?></span>
        </li>
      </ul>
    </div>
    
    <div class="tabs-content" style="min-height: 130px; padding: 10px;">
      <div id="comments-tab" class="tab-content active">
        
        <!-- Comment form (visible to all users) -->
        <div class="comment-form-wrapper">
          <div class="comment-form-header">
            <span class="comment-form-title"><i class="fa fa-pencil"></i> Add a comment</span>
          </div>
          
          <div id="manga-comment-form" class="manga-comment-form" data-post-id="<?php echo get_the_ID(); ?>">
            <!-- Text formatting toolbar -->
            <div class="comment-toolbar">
                <div class="toolbar-left">
                  <button type="button" class="format-btn text-format-btn" data-format="bold" title="Bold (Ctrl+B)">
                    <i class="fa fa-bold"></i>
                  </button>
                  <button type="button" class="format-btn text-format-btn" data-format="italic" title="Italic (Ctrl+I)">
                    <i class="fa fa-italic"></i>
                  </button>
                  <button type="button" class="format-btn text-format-btn" data-format="underline" title="Underline">
                    <i class="fa fa-underline"></i>
                  </button>
                  <button type="button" class="format-btn text-format-btn" data-format="spoiler" title="Spoiler">
                    <i class="fa fa-eye-slash"></i>
                  </button>
                  <button type="button" class="format-btn text-format-btn" data-format="code" title="Code">
                    <i class="fa fa-code"></i>
                  </button>
                </div>
                <div class="toolbar-right">
                  <button type="button" class="format-btn emoji-picker-btn" title="Add emoji">
                    <i class="fa fa-smile-o"></i>
                  </button>
                  <?php if ($has_giphy_api): ?><button type="button" class="format-btn gif-picker-btn" title="Add GIF" style="font-weight:700; font-size:12px;">GIF</button><?php endif; ?>
                  <!-- Emoji picker popup -->
                  <div class="emoji-picker-popup" style="display: none;">
                    <div class="emoji-categories">
                      <button type="button" class="emoji-category active" data-category="smileys">😊</button>
                      <button type="button" class="emoji-category" data-category="hand">👋</button>
                      <button type="button" class="emoji-category" data-category="heart">❤️</button>
                      <button type="button" class="emoji-category" data-category="fire">🔥</button>
                      <button type="button" class="emoji-category" data-category="star">⭐</button>
                    </div>
                    <div class="emoji-grid" id="emoji-grid">
                      <!-- Will be populated by JavaScript -->
                    </div>
                  </div>
                  <!-- GIF picker popup -->
                  <?php if ($has_giphy_api): ?>
                  <div class="gif-picker-popup" style="display: none;">
                    <div class="gif-search-wrapper">
                      <input type="text" id="gif-search-input" class="gif-search-input" placeholder="Search GIFs...">
                      <button type="button" id="gif-search-btn" class="gif-search-btn">🔍</button>
                    </div>
                    <div class="gif-grid" id="gif-grid">
                      <div class="gif-loading">Loading GIFs...</div>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
              </div>
              
              <div class="form-group">
                <div id="gif-preview" class="gif-preview" style="display:none; margin-bottom:8px;"></div>
                <textarea 
                  id="manga-comment-text" 
                  class="comment-textarea" 
                  placeholder="Share your opinion about this manga..." 
                  rows="4" 
                  minlength="1"
                  maxlength="1000"
                  required></textarea>
                <small class="comment-help">0/1000 characters</small>
              </div>
              <div class="form-actions">
                <button type="button" class="btn-submit-comment" id="submit-manga-comment">
                  <i class="fa fa-send"></i> Post comment
                </button>
              </div>
              <?php wp_nonce_field( 'mangayummy_comment_nonce', 'nonce' ); ?>
            </div>
            <div id="comment-message" class="comment-message" style="display:none;"></div>
          </div>
        
        <!-- Comments sorting -->
        <div class="comments-sort-block"<?php echo empty($all_comments) ? ' style="display:none"' : ''; ?>>
          <div class="sort-label">Sort:</div>
          <div class="sort-buttons">
            <button type="button" class="sort-btn active" data-sort="newest" title="Newest comments">
              <i class="fa fa-clock-o"></i> Newest
            </button>
            <button type="button" class="sort-btn" data-sort="oldest" title="Oldest comments">
              <i class="fa fa-history"></i> Oldest
            </button>
            <button type="button" class="sort-btn" data-sort="liked" title="Most liked comments">
              <i class="fa fa-heart"></i> Most liked
            </button>
          </div>
        </div>

        <!-- Comments list -->
        <div class="comments-list-wrapper">
          <?php
          // Reuse $all_comments from above - no need to re-query
          if ( !empty($all_comments) ) :
            echo '<div class="comments-list" data-sort-type="newest">';
            foreach ( $all_comments as $comment ) :
              // Set global comment for WordPress functions
              $GLOBALS['comment'] = $comment;
              manga_comment_callback($comment);
            endforeach;
            echo '</div>';
          endif;
          ?>
        </div>
      </div>
      
      <div id="reviews-tab" class="tab-content">
        <?php
        $manga_id = get_the_ID();

        // Get comments linked to this manga via _manga_id meta
        $reviews_list_cache_key = 'mangayummy_reviews_list_' . $manga_id;
        $comments = get_transient($reviews_list_cache_key);
        if ($comments === false) {
            $comments = get_comments([
                'status'     => 'approve',
                'parent'     => 0,
                'order'      => 'DESC',
                'number'     => 100,
                'meta_query' => [
                    [
                        'key'   => '_manga_id',
                        'value' => $manga_id,
                    ]
                ],
            ]);
            set_transient($reviews_list_cache_key, $comments, 5); // cache for 5 seconds
        }

        if (!$comments) {
            echo '<p class="no-comments"><i class="fa fa-file-text"></i> No chapter reviews yet.</p>';
        } else {
            echo '<div class="comments-list" data-sort-type="newest">';
            foreach ($comments as $comment) {
                $GLOBALS['comment'] = $comment;
                manga_comment_callback($comment);
            }
            echo '</div>';
        }
        ?>
      </div>
    </div>
  </div>
</section>

<!-- ✅ Delete confirm modal -->
<div id="deleteModal" class="modal">
  <div class="modal-box">
    <p>Are you sure you want to delete this comment?</p>
    <button type="button" id="confirmDelete">Yes</button>
    <button type="button" id="cancelDelete">No</button>
  </div>
</div>

<!-- ✅ Report comment modal (like YummyAnime) -->
<div id="reportModal" class="report-modal">
  <div class="report-box">
    <button type="button" class="report-close">×</button>
    <h3>Report a comment</h3>
    
    <ul class="report-list">
      <li><button type="button" data-reason="spoiler">spoiler</button></li>
      <li><button type="button" data-reason="limbaj_obscen">obscene language</button></li>
      <li><button type="button" data-reason="insulte">insulting other participants</button></li>
      <li><button type="button" data-reason="offtopic">off-topic or meaningless comment</button></li>
      <li><button type="button" data-reason="link">link to a third-party website</button></li>
    </ul>
  </div>
</div>

<!-- ✅ Toast notification -->
<div id="toast" class="toast"></div>

    </div>
  </div>
</div>
  </div>
</div>
</body>

<script>
// Summary expand/collapse is now handled by main.js
</script>



<script>
document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('toggle-chapter-order');
    const list = document.querySelector('.listing-chapters_wrap .chapters-list');
    const countLabel = document.getElementById('chapters-count');
    const orderLabel = document.getElementById('chapter-order-label');

    if (countLabel && list) {
        const total = list.querySelectorAll('.latest-chapter-item').length;
        countLabel.textContent = ' (' + total + ')'; // leading space joins with title
    }

    if (!btn || !list) {
        console.error('[ERROR] Button or list not found!');
        return;
    }

    const iconDesc = btn.querySelector('.icon-desc');
    const iconAsc  = btn.querySelector('.icon-asc');

    // Default to desc (newest chapters first)
    const savedOrder = 'desc';
    btn.dataset.order = savedOrder;
    updateIcon(savedOrder);
    if (orderLabel) orderLabel.textContent = savedOrder === 'desc' ? 'Descending' : 'Ascending';

    btn.addEventListener('click', function () {
        const newOrder = btn.dataset.order === 'desc' ? 'asc' : 'desc';
        btn.dataset.order = newOrder;
        if (orderLabel) orderLabel.textContent = newOrder === 'desc' ? 'Descending' : 'Ascending';
        // Removed localStorage persistence - always reset to asc on page reload
        updateIcon(newOrder);

        // simply sort without any animation or height locking
        sortChapters(newOrder, false);
    });

    function sortChapters(order, animate) {
        // Select ALL chapters, including filtered/hidden ones
        const items = Array.from(list.querySelectorAll('.latest-chapter-item'));


        // animation disabled, nothing to do here

        items.sort((a, b) => {
            const chA = parseFloat(a.dataset.chapter || 0);
            const chB = parseFloat(b.dataset.chapter || 0);
            return order === 'desc' ? chB - chA : chA - chB;
        });

        setTimeout(() => {
            items.forEach(i => list.appendChild(i));
            items.forEach(i => {
                i.style.opacity = '1';
                i.style.transform = 'translateY(0)';
            });

            // unlock the height and reapply visibility once animation is done
            list.style.minHeight = '';
            reapplyChapterVisibility();

            // fire a custom event so collapsed boxes can recompute marker
            list.dispatchEvent(new Event('sorted'));
        }, animate ? 120 : 0);
    }

    function updateIcon(order) {
        if (order === 'desc') {
            iconDesc.classList.remove('icon-hidden');
            iconDesc.classList.add('icon-active');
            iconAsc.classList.add('icon-hidden');
            iconAsc.classList.remove('icon-active');
        } else {
            iconDesc.classList.add('icon-hidden');
            iconDesc.classList.remove('icon-active');
            iconAsc.classList.remove('icon-hidden');
            iconAsc.classList.add('icon-active');
        }
    }
    
    function reapplyChapterVisibility() {
        const chaptersBoxes = document.querySelectorAll('.chapters-box');
        chaptersBoxes.forEach(box => {
            const allVisibleChapters = box.querySelectorAll('.latest-chapter-item:not(.filtered-out)');
            
            // Always show all chapters; scrolling will allow users to access the full list.
      allVisibleChapters.forEach(chapter => {
        chapter.style.display = 'list-item';
      });
        });
    }
});
</script>

<script>
// YummyAnime Comments Tabs - Tab Switching
document.querySelectorAll('.tabs-li.materiable').forEach(tab => {
  tab.addEventListener('click', () => {
    const tabId = tab.getAttribute('data-id');
    
    // Remove active from all tabs
    document.querySelectorAll('.tabs-li').forEach(t => t.classList.remove('active'));
    
    // Remove active from all content
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    
    // Add active to clicked tab
    tab.classList.add('active');
    
    // Add active to content
    const contentElement = document.querySelector(tabId);
    if (contentElement) {
      contentElement.classList.add('active');
      
      // Check comment heights when reviews tab becomes visible
      if (tabId === '#reviews-tab' && window.checkCommentTextHeights) {
        // Small delay to ensure the tab is fully visible
        setTimeout(() => window.checkCommentTextHeights(), 50);
      }
    }
  });
});
</script>

<script>
// Text Formatting & Emoji Manager
class CommentFormatter {
  constructor(textareaSelectorOrElement) {
    this.textarea = (typeof textareaSelectorOrElement === 'string') ? document.querySelector(textareaSelectorOrElement) : textareaSelectorOrElement;
    this.emojiMap = {
      smileys: ['😊', '😂', '😍', '😭', '😠', '😴', '😴', '🤔', '😎', '🥳', '😘', '🤗'],
      hand: ['👋', '🙌', '👏', '🤝', '👍', '👎', '✌️', '🤟', '💪', '👊', '✊', '🖐️'],
      heart: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '💕', '💞'],
      fire: ['🔥', '⭐', '✨', '💫', '🌟', '💥', '🎉', '🎊', '⚡', '🔆', '🌈', '👑'],
      star: ['⭐', '🌟', '✨', '💫', '🌠', '🎆', '🎇', '💥', '🔆', '🌠', '⭐', '✨']
    };
    
    // Mention autocomplete properties
    this.mentionDropdown = null;
    this.currentMentionStart = -1;
    this.currentMentionQuery = '';
    this.selectedIndex = -1;
    this.mentionResults = [];
    
    this.init();
  }

  init() {
    // Text format buttons
    document.querySelectorAll('.text-format-btn').forEach(btn => {
      // Prevent the button from stealing focus (preserve textarea selection)
      btn.addEventListener('mousedown', (e) => e.preventDefault());
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const format = btn.dataset.format;
        this.applyFormat(format);
      });
    });

    // Emoji picker button
    const emojiBtn = document.querySelector('.emoji-picker-btn');
    const emojiPopup = document.querySelector('.emoji-picker-popup');
    const gifBtn = document.querySelector('.gif-picker-btn');
    const gifPopup = document.querySelector('.gif-picker-popup');
    const gifSearchInput = document.getElementById('gif-search-input');
    const gifSearchBtn = document.getElementById('gif-search-btn');
    const toolbarRight = document.querySelector('.toolbar-right');
    
    if (emojiBtn && emojiPopup) {
      emojiBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        emojiPopup.style.display = emojiPopup.style.display === 'none' ? 'block' : 'none';
        if (emojiPopup.style.display === 'block') {
          this.populateEmojiGrid('smileys');
          if (gifPopup) gifPopup.style.display = 'none';
        }
      });
    }

    const showGifLoginError = () => {
      const message = document.getElementById('comment-message');
      if (message) {
        message.style.display = 'block';
        message.textContent = 'You must be logged in to use GIFs.';
        message.style.color = '#ff4d4d';
        setTimeout(() => {
          message.style.display = 'none';
          message.textContent = '';
        }, 3500);
      }
    };

    if (gifBtn && gifPopup) {
      gifBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
          showGifLoginError();
          return;
        }

        gifPopup.style.display = gifPopup.style.display === 'none' ? 'block' : 'none';
        if (gifPopup.style.display === 'block') {
          this.loadTrendingGIFs();
          if (emojiPopup) emojiPopup.style.display = 'none';
          if (gifSearchInput) gifSearchInput.focus();
        }
      });

      if (gifSearchInput) {
        gifSearchInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            this.searchGIFs(gifSearchInput.value.trim());
          }
        });
      }

      if (gifSearchBtn) {
        gifSearchBtn.addEventListener('click', (e) => {
          e.preventDefault();
          this.searchGIFs(gifSearchInput?.value.trim() || '');
        });
      }
    }

    // Close pickers when clicking outside
    document.addEventListener('click', (e) => {
      if (toolbarRight && !toolbarRight.contains(e.target)) {
        if (emojiPopup) emojiPopup.style.display = 'none';
        if (gifPopup) gifPopup.style.display = 'none';
      }
    });

    // Category buttons for emoji
    document.querySelectorAll('.emoji-category').forEach(btn => {
      btn.addEventListener('mousedown', (e) => e.preventDefault());
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        document.querySelectorAll('.emoji-category').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.populateEmojiGrid(btn.dataset.category);
      });
    });

    // Initialize mention autocomplete
    this.initMentionAutocomplete();

    // Keyboard shortcuts
    if (this.textarea) {
      this.textarea.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
          e.preventDefault();
          this.applyFormat('bold');
        } else if ((e.ctrlKey || e.metaKey) && e.key === 'i') {
          e.preventDefault();
          this.applyFormat('italic');
        }
      });
    }
  }

  applyFormat(format) {
    const start = this.textarea.selectionStart;
    const end = this.textarea.selectionEnd;
    const text = this.textarea.value;
    const selectedText = text.substring(start, end) || 'text';

    let formattedText = '';
    
    switch(format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `__${selectedText}__`;
        break;
      case 'spoiler':
        formattedText = `||${selectedText}||`;
        break;
      case 'code':
        formattedText = `\`${selectedText}\``;
        break;
      default:
        return;
    }

    const newText = text.substring(0, start) + formattedText + text.substring(end);
    this.textarea.value = newText;
    this.textarea.focus();
    this.textarea.selectionStart = start + formattedText.length;
  }

  populateEmojiGrid(category) {
    const grid = document.getElementById('emoji-grid');
    const emojis = this.emojiMap[category] || [];
    
    grid.innerHTML = '';
    emojis.forEach(emoji => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'emoji-btn';
      btn.textContent = emoji;
      // prevent focus steal on mousedown
      btn.addEventListener('mousedown', (e) => e.preventDefault());
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.insertEmoji(emoji);
        document.querySelector('.emoji-picker-popup').style.display = 'none';
      });
      grid.appendChild(btn);
    });
  }

  insertEmoji(emoji) {
    const start = this.textarea.selectionStart;
    const end = this.textarea.selectionEnd;
    const text = this.textarea.value;
    
    const newText = text.substring(0, start) + emoji + text.substring(end);
    this.textarea.value = newText;
    this.textarea.focus();
    this.textarea.selectionStart = this.textarea.selectionEnd = start + emoji.length;
  }

  loadTrendingGIFs() {
    const gifGrid = document.getElementById('gif-grid');
    if (!gifGrid) return;

    gifGrid.innerHTML = '<div class="gif-loading">Loading GIFs...</div>';

    fetch((typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : ya_ajax.ajax_url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=mangayummy_get_gifs&type=featured'
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.data && data.data.gifs) {
        this.displayGIFs(data.data.gifs);
      } else {
        gifGrid.innerHTML = '<div class="gif-error">Error loading GIFs</div>';
      }
    })
    .catch(() => {
      gifGrid.innerHTML = '<div class="gif-error">Error loading GIFs</div>';
    });
  }

  searchGIFs(query) {
    const gifGrid = document.getElementById('gif-grid');
    if (!gifGrid) return;

    if (!query) {
      this.loadTrendingGIFs();
      return;
    }

    gifGrid.innerHTML = '<div class="gif-loading">Searching GIFs...</div>';

    fetch((typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : ya_ajax.ajax_url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=mangayummy_get_gifs&type=search&query=' + encodeURIComponent(query)
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.data && data.data.gifs) {
        this.displayGIFs(data.data.gifs);
      } else {
        gifGrid.innerHTML = '<div class="gif-error">No GIFs found</div>';
      }
    })
    .catch(() => {
      gifGrid.innerHTML = '<div class="gif-error">Error searching GIFs</div>';
    });
  }

  displayGIFs(gifs) {
    const gifGrid = document.getElementById('gif-grid');
    if (!gifGrid) return;

    if (!Array.isArray(gifs) || gifs.length === 0) {
      gifGrid.innerHTML = '<div class="gif-no-results">Niciun GIF găsit</div>';
      return;
    }

    gifGrid.innerHTML = gifs.map(gif => `
      <div class="gif-item" data-url="${gif.url}">
        <img src="${gif.preview}" alt="${gif.title}" loading="lazy" />
      </div>
    `).join('');

    gifGrid.querySelectorAll('.gif-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const gifUrl = item.dataset.url;

        // Add URL to comment text for fallback/search transparency
        const start = this.textarea.selectionStart;
        const end = this.textarea.selectionEnd;
        const value = this.textarea.value;
        const insertText = gifUrl;

        this.textarea.value = value.substring(0, start) + insertText + value.substring(end);
        this.textarea.focus();
        this.textarea.selectionStart = this.textarea.selectionEnd = start + insertText.length;

        // Show preview in the form
        const preview = document.getElementById('gif-preview');
        if (preview) {
          preview.style.display = 'block';
          preview.innerHTML = `
            <div style="position: relative; display: flex; align-items: center; gap: 8px; justify-content: flex-end;">
              <button type="button" id="gif-preview-clear" style="background:#ff4d4d;color:#fff;border:none;border-radius:999px;padding:2px 8px;cursor:pointer;font-size:11px;">X</button>
            </div>
            <img src="${gifUrl}" alt="GIF preview" style="max-width:100%;border-radius:8px;margin-top:8px;display:block;" loading="lazy" />
          `;
          const clear = document.getElementById('gif-preview-clear');
          if (clear) {
            clear.addEventListener('click', () => {
              preview.style.display = 'none';
              preview.innerHTML = '';
              // Optional: remove GIF URL from comment input
              if (this.textarea.value.includes(gifUrl)) {
                this.textarea.value = this.textarea.value.replace(gifUrl, '').trim();
              }
            });
          }
        }

        const gifPopup = document.querySelector('.gif-picker-popup');
        if (gifPopup) gifPopup.style.display = 'none';
      });
    });
  }

  // Initialize mention autocomplete
  initMentionAutocomplete() {
    if (!this.textarea) {
      console.error('Textarea not found, cannot initialize mention autocomplete');
      return;
    }

    // Create dropdown element
    this.mentionDropdown = document.createElement('div');
    this.mentionDropdown.className = 'mention-autocomplete';
    document.body.appendChild(this.mentionDropdown);

    // Handle input events
    this.textarea.addEventListener('input', (e) => this.handleMentionInput(e));
    this.textarea.addEventListener('keydown', (e) => this.handleMentionKeydown(e));
    this.textarea.addEventListener('blur', () => setTimeout(() => this.hideMentionDropdown(), 150));

    // Handle clicks on dropdown items
    this.mentionDropdown.addEventListener('click', (e) => {
      const item = e.target.closest('.mention-item');
      if (item) {
        e.preventDefault();
        const index = parseInt(item.dataset.index);
        this.selectMention(index);
      }
    });
  }

  // Handle textarea input for mentions
  handleMentionInput(e) {
    const cursorPos = this.textarea.selectionStart;
    const text = this.textarea.value;

    // Find the current word being typed
    const beforeCursor = text.substring(0, cursorPos);
    const words = beforeCursor.split(/\s+/);
    const currentWord = words[words.length - 1];

    // Check if current word starts with @
    if (currentWord.startsWith('@') && currentWord.length > 1) {
      const query = currentWord.substring(1); // Remove @
      this.currentMentionQuery = query;
      // Use the actual '@' position so we don't duplicate the '@' when inserting
      const atPos = beforeCursor.lastIndexOf('@');
      this.currentMentionStart = atPos >= 0 ? atPos : (cursorPos - query.length - 1);
      this.searchUsers(query);
    } else {
      this.hideMentionDropdown();
    }
  }

  // Handle keyboard navigation in mention dropdown
  handleMentionKeydown(e) {
    if (!this.mentionDropdown.classList.contains('show')) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        this.selectedIndex = Math.min(this.selectedIndex + 1, this.mentionResults.length - 1);
        this.updateDropdownSelection();
        break;
      case 'ArrowUp':
        e.preventDefault();
        this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
        this.updateDropdownSelection();
        break;
      case 'Enter':
      case 'Tab':
        if (this.selectedIndex >= 0) {
          e.preventDefault();
          this.selectMention(this.selectedIndex);
        }
        break;
      case 'Escape':
        this.hideMentionDropdown();
        break;
    }
  }

  // Search users via AJAX
  async searchUsers(query) {
    if (typeof mangayummy_comments === 'undefined') {
      console.error('mangayummy_comments object not available');
      this.hideMentionDropdown();
      return;
    }

    try {
      const response = await fetch(`${mangayummy_comments.ajax_url}?action=mangayummy_search_users&q=${encodeURIComponent(query)}`);

      const results = await response.json();

      if (results.length > 0) {
        this.showMentionDropdown(results);
      } else {
        this.hideMentionDropdown();
      }
    } catch (error) {
      console.error('Error searching users:', error);
      this.hideMentionDropdown();
    }
  }

  // Show mention dropdown with results
  showMentionDropdown(results) {
    this.mentionDropdown.innerHTML = '';
    this.selectedIndex = 0;

    results.forEach((user, index) => {
      const item = document.createElement('div');
      item.className = `mention-item ${index === 0 ? 'active' : ''} ${user.is_friend ? 'friend' : ''}`;
      item.dataset.index = index;

      item.innerHTML = `
        <img src="${user.avatar}" alt="${user.display_name}" class="mention-avatar" loading="lazy" decoding="async">
        <div class="mention-info">
          <div class="mention-username">
            @${user.display_name}
            ${user.is_friend ? '<span class="mention-friend-badge">Friend</span>' : ''}
          </div>
          <div class="mention-display-name">${user.display_name}</div>
        </div>
      `;

      this.mentionDropdown.appendChild(item);
    });

    // Position dropdown - simple approach: below the textarea
    const textareaRect = this.textarea.getBoundingClientRect();

    this.mentionDropdown.style.left = `${textareaRect.left + window.scrollX}px`;
    this.mentionDropdown.style.top = `${textareaRect.bottom + window.scrollY + 5}px`;

    this.mentionDropdown.classList.add('show');
  }

  // Hide mention dropdown
  hideMentionDropdown() {
    this.mentionDropdown.classList.remove('show');
    this.currentMentionStart = -1;
    this.currentMentionQuery = '';
    this.selectedIndex = -1;
    this.mentionResults = [];
  }

  // Update visual selection in dropdown
  updateDropdownSelection() {
    const items = this.mentionDropdown.querySelectorAll('.mention-item');
    items.forEach((item, index) => {
      item.classList.toggle('active', index === this.selectedIndex);
    });
  }

  // Select a mention from dropdown
  selectMention(index) {
    const user = this.mentionResults[index];
    if (!user) return;
    
    const text = this.textarea.value;
    const beforeMention = text.substring(0, this.currentMentionStart);
    const afterMention = text.substring(this.textarea.selectionStart);
    
    // Insert the selected username
    const newText = beforeMention + '@' + user.display_name + ' ' + afterMention;
    this.textarea.value = newText;
    
    // Set cursor position after the mention
    const newCursorPos = this.currentMentionStart + user.display_name.length + 2; // +2 for @ and space
    this.textarea.selectionStart = this.textarea.selectionEnd = newCursorPos;
    
    this.hideMentionDropdown();
    this.textarea.focus();
  }

  // Get cursor position for dropdown placement
  getCursorPosition() {
    const textareaRect = this.textarea.getBoundingClientRect();
    const style = window.getComputedStyle(this.textarea);
    
    // Create a temporary div to measure text
    const div = document.createElement('div');
    div.style.position = 'absolute';
    div.style.visibility = 'hidden';
    div.style.whiteSpace = 'pre-wrap';
    div.style.font = style.font;
    div.style.fontSize = style.fontSize;
    div.style.fontFamily = style.fontFamily;
    div.style.padding = style.padding;
    div.style.border = style.border;
    div.style.width = style.width;
    div.style.wordWrap = 'break-word';
    
    const text = this.textarea.value.substring(0, this.textarea.selectionStart);
    div.textContent = text;
    
    document.body.appendChild(div);
    const rect = div.getBoundingClientRect();
    document.body.removeChild(div);
    
    return {
      left: textareaRect.left + rect.width + window.scrollX,
      top: textareaRect.top + rect.height + window.scrollY
    };
  }
}

// Comment Sorting Manager
class CommentSorter {
  constructor() {
    this.commentsList = document.querySelector('.comments-list');
    this.sortButtons = document.querySelectorAll('.sort-btn');
    this.currentSort = 'newest';
    
    this.init();
  }

  init() {
    this.sortButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Update active button
        this.sortButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const sortType = btn.dataset.sort;
        this.sortComments(sortType);
      });
    });
  }

  sortComments(sortType) {
    if (!this.commentsList) return;

    // CRITICAL: Select ONLY top-level comments (not replies)
    const comments = Array.from(this.commentsList.querySelectorAll(':scope > .comment'));
    this.commentsList.dataset.sortType = sortType;

    comments.sort((a, b) => {
      const timeA = parseInt(a.dataset.time || 0);
      const timeB = parseInt(b.dataset.time || 0);
      const likesA = parseInt(a.dataset.likes || 0);
      const likesB = parseInt(b.dataset.likes || 0);

      switch(sortType) {
        case 'newest':
          return timeB - timeA;
        case 'oldest':
          return timeA - timeB;
        case 'liked':
          return likesB - likesA;
        default:
          return 0;
      }
    });

    // Helper: Get comment block (comment + button + replies as one unit)
    const getCommentBlock = (comment) => {
      const commentId = comment.dataset.commentId || comment.id.replace('comment-', '');
      
      // Găsește butonul și replies-urile pe baza data attributes, nu pe poziție
      const btn = document.querySelector(
        `.toggle-replies[data-comment-id="${commentId}"]`
      );
      const replies = document.querySelector(
        `.comment-replies[data-parent-id="${commentId}"]`
      );
      
      return [comment, btn, replies].filter(Boolean);
    };

    // Animate sorting
    comments.forEach(comment => {
      comment.style.opacity = '0.7';
      comment.style.transform = 'translateY(5px)';
    });

    setTimeout(() => {
      // Reattach comments with their full blocks (comment + button + replies)
      comments.forEach(comment => {
        getCommentBlock(comment).forEach(el => {
          this.commentsList.appendChild(el);
        });
      });

      comments.forEach(comment => {
        comment.style.opacity = '1';
        comment.style.transform = 'translateY(0)';
      });
      
      // Reset all replies to hidden after sort (using classList instead of inline style)
      document.querySelectorAll('.comment-replies').forEach(replies => {
        replies.classList.remove('open');
        replies.style.display = 'none'; // Explicit inline style
      });
    }, 100);
  }
}

// ✅ Toast helper function
function showToast(text) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2500);
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  new CommentFormatter('#manga-comment-text');
  new CommentSorter();
  
  // Initialize spoiler reveal on all existing comments
  initSpoilerHandlers();
  
  // ✅ Character counter live (max 1000)
  const textarea = document.querySelector('#manga-comment-text');
  const counter = document.querySelector('.comment-help');
  if (textarea && counter) {
    const updateCounter = () => {
      counter.textContent = `${textarea.value.length}/1000 characters`;
    };
    textarea.addEventListener('input', updateCounter);
    updateCounter();
  }
  
  // ✅ Comment menu (3 dots - edit/delete/report)
  document.addEventListener('click', e => {
    // Toggle menu
    const menuBtn = e.target.closest('.comment-menu-btn');
    if (menuBtn) {
      const menu = menuBtn.nextElementSibling;
      if (menu && menu.classList.contains('comment-menu-dropdown')) {
        // if menu empty, show placeholder
        if (menu.children.length === 0) {
          menu.textContent = 'No options';
          menu.style.display = 'block';
        } else {
          menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }
      }
      return;
    }
    
    // Close all menus when clicking outside
    document.querySelectorAll('.comment-menu-dropdown').forEach(m => m.style.display = 'none');
  });
  
  // Show/hide options based on user role
  document.querySelectorAll('.comment').forEach(comment => {
    const authorId = comment.dataset.authorId;
    const currentId = comment.dataset.currentUserId;
    const isGuestComment = comment.dataset.isGuestComment === 'true';
    const isCurrentUserGuest = currentId === '0' || !currentId;
    
    // If both are guests, don't remove buttons (server will handle showing correct ones)
    if (isGuestComment && isCurrentUserGuest) {
      return; // Don't modify - server already rendered correct buttons
    }
    
    // If current user is logged in, check normal ownership
    if (authorId && currentId) {
      if (authorId !== currentId) {
        // Not author → remove edit/delete, keep report
        comment.querySelector('.comment-edit')?.remove();
        comment.querySelector('.comment-delete')?.remove();
      } else {
        // Author → remove report, keep edit/delete
        comment.querySelector('.comment-report')?.remove();
      }
    }
  });
  
  // ✅ EDIT INLINE
  document.addEventListener('click', e => {
    // EDIT button clicked
    if (e.target.classList.contains('comment-edit')) {
      const body = e.target.closest('.comment').querySelector('.comment-body');
      const text = body.querySelector('.comment-text');
      const textarea = body.querySelector('.comment-edit-textarea');
      const actions = body.querySelector('.comment-edit-actions');
      
      textarea.value = text.textContent.trim();
      text.style.display = 'none';
      textarea.style.display = 'block';
      actions.style.display = 'flex';
      textarea.focus();
    }
    
    // CANCEL button clicked
    if (e.target.classList.contains('comment-cancel')) {
      const body = e.target.closest('.comment-body');
      body.querySelector('.comment-text').style.display = 'block';
      body.querySelector('.comment-edit-textarea').style.display = 'none';
      body.querySelector('.comment-edit-actions').style.display = 'none';
    }
    
    // SAVE button clicked
    if (e.target.classList.contains('comment-save')) {
      const comment = e.target.closest('.comment');
      const body = comment.querySelector('.comment-body');
      const textarea = body.querySelector('.comment-edit-textarea');
      const commentId = comment.dataset.commentId;
      
      const formData = new FormData();
      formData.append('action', 'mangayummy_edit_comment');
      formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
      formData.append('comment_id', commentId);
      formData.append('content', textarea.value);
      
      fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          // Update displayed text
          const textDiv = body.querySelector('.comment-text');
          textDiv.innerHTML = res.data.rendered;

          // Show edited label in comment body
          const commentEl = e.target.closest('.comment');
          if (commentEl) {
            const bodyEl = commentEl.querySelector('.comment-body');
            if (bodyEl && !bodyEl.querySelector('.comment-edited')) {
              const editedSpan = document.createElement('span');
              editedSpan.className = 'comment-edited';
              editedSpan.textContent = '(edited)';
              bodyEl.insertBefore(editedSpan, bodyEl.querySelector('.more-text'));
            }
          }

          // Hide edit mode
          textDiv.style.display = 'block';
          textarea.style.display = 'none';
          body.querySelector('.comment-edit-actions').style.display = 'none';
        } else {
          alert('Editing error: ' + (res.data?.message || 'Unknown'));
        }
      })
      .catch(err => {
        console.error('Edit error:', err);
        alert('Editing error');
      });
    }
  });
  
  // ✅ DELETE with confirm modal
  let deleteTarget = null;
  
  document.addEventListener('click', e => {
    if (e.target.classList.contains('comment-delete')) {
      deleteTarget = e.target.closest('.comment');
      document.getElementById('deleteModal').style.display = 'block';
    }
  });
  
  document.getElementById('cancelDelete').onclick = () => {
    document.getElementById('deleteModal').style.display = 'none';
  };
  
  document.getElementById('confirmDelete').onclick = () => {
    if (!deleteTarget) return;
    
    const formData = new FormData();
    formData.append('action', 'mangayummy_delete_comment');
    formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
    formData.append('comment_id', deleteTarget.dataset.commentId);
    
    const deletedCommentId = deleteTarget.dataset.commentId;
    const deletedParentId = deleteTarget.dataset.parentId;
    
    fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
      method: 'POST',
      body: formData
    })
    .then(r => r.json())
    .then(res => {
      if (res.success || res === '') {
        const deletedCommentId = deleteTarget.dataset.commentId;
        let deletedParentId = deleteTarget.dataset.parentId;
        
        // If this comment is a reply, traverse UP to find the root parent comment
        if (deletedParentId) {
          // This reply's parent - but we might need to go UP further if parent is also a reply
          let container = deleteTarget.closest('.comment-replies');
          if (container) {
            const firstLevelParentId = container.dataset.parentId;
            
            // Check if we need to go UP further (nested replies)
            let currentContainer = container;
            let rootParentId = firstLevelParentId;
            while (currentContainer) {
              const parentComment = currentContainer.previousElementSibling;
              if (parentComment && parentComment.classList.contains('comment')) {
                const parentId = parentComment.dataset.commentId;
                // Check if this comment also has a parent (it's a reply)
                const parentParentId = parentComment.dataset.parentId;
                if (parentParentId && parentParentId !== '0') {
                  // This is also a reply, keep going up
                  currentContainer = parentComment.closest('.comment-replies');
                  if (currentContainer) {
                    rootParentId = currentContainer.dataset.parentId;
                  }
                } else {
                  // This is a root comment
                  rootParentId = parentId;
                  break;
                }
              } else {
                break;
              }
            }
            deletedParentId = rootParentId;
          }
        }
        
        // fade out before removing
        const targetComment = deleteTarget; // capture reference
        if (targetComment) {
            targetComment.classList.add('fade-out');
        }
        setTimeout(() => {
            if (targetComment) {
                targetComment.remove();
            }
            document.getElementById('deleteModal').style.display = 'none';
            showMessage(res.data?.message || 'Comment deleted', 'error');
            
            // Update comment count
            const countSpan = document.querySelector('#comments .count');
            if (countSpan) {
              const currentCount = parseInt(countSpan.textContent) || 0;
              countSpan.textContent = Math.max(0, currentCount - 1);
            }
            updateSortVisibility();
        }, 300);
        const countSpan = document.querySelector('#comments .count');
        if (countSpan) {
          const currentCount = parseInt(countSpan.textContent) || 0;
          countSpan.textContent = Math.max(0, currentCount - 1);
        }
        updateSortVisibility();
        
        // ========== UPDATE TOGGLE BUTTON IF THIS WAS A REPLY ==========
        if (deletedParentId) {
          // Wait for DOM to fully update - 100ms should be safe
          setTimeout(() => {
            const toggleBtn = document.querySelector(`.toggle-replies[data-comment-id="${deletedParentId}"]`);
            const repliesContainer = document.querySelector(`.comment-replies[data-parent-id="${deletedParentId}"]`);
            
            if (toggleBtn && repliesContainer) {
              // Count remaining replies AFTER DOM update - re-query to be sure
              const remainingReplies = repliesContainer.querySelectorAll(':scope > .comment').length;
              
              if (remainingReplies === 0) {
                // No more replies - DELETE container completely, not just hide
                repliesContainer.remove();
                toggleBtn.remove();
              } else {
                // Replies still exist - keep button visible and container open
                toggleBtn.style.display = 'inline-block';
                toggleBtn.textContent = 'Hide replies (' + remainingReplies + ')';
                repliesContainer.style.display = 'block';
                repliesContainer.classList.add('open');
                toggleBtn.dataset.expanded = 'true';
              }
            }
          }, 100);
        }
        
        deleteTarget = null;
      } else {
        alert(res.data?.message || 'Delete error');
      }
    })
    .catch(err => console.error('Delete error:', err));
  };
  
  // ✅ REPORT comment - open modal with reasons
  let reportCommentId = null;
  
  document.addEventListener('click', e => {
    if (e.target.classList.contains('comment-report')) {
      reportCommentId = e.target.closest('.comment').dataset.commentId;
      document.getElementById('reportModal').classList.add('show');
    }
  });
  
  // Close report modal
  document.querySelector('.report-close').addEventListener('click', () => {
    document.getElementById('reportModal').classList.remove('show');
  });
  
  // Submit report with reason
  document.querySelectorAll('.report-list button').forEach(btn => {
    btn.addEventListener('click', () => {
      const reason = btn.dataset.reason;
      const nonceField = document.querySelector('input[name="nonce"]');
      const nonce = nonceField ? nonceField.value : '';
      
      const formData = new FormData();
      formData.append('action', 'report_comment');
      formData.append('nonce', nonce);
      formData.append('comment_id', reportCommentId);
      formData.append('reason', reason);
      
      fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          showToast('Report submitted ✔');
          // Remove report button from comment
          const comment = document.querySelector('[data-comment-id="' + reportCommentId + '"]');
          if (comment) {
            const reportBtn = comment.querySelector('.comment-report');
            if (reportBtn) reportBtn.remove();
          }
        } else {
          showToast(res.data?.message || 'Reporting error');
        }
        document.getElementById('reportModal').classList.remove('show');
      })
      .catch(err => {
        console.error('Report error:', err);
        showToast('Reporting error');
        document.getElementById('reportModal').classList.remove('show');
      });
    });
  });
});

// Handle spoiler reveal on click and touch (mobile support)
function initSpoilerHandlers() {
  function toggleSpoiler(el) {
    el.classList.toggle('revealed');
  }

  // Click handler (desktop)
  document.addEventListener('click', function(e) {
    const spoiler = e.target.closest('.spoiler');
    if (spoiler) {
      toggleSpoiler(spoiler);
    }
  });

  // Touch handler (mobile) - CRITICAL for iOS/Android
  document.addEventListener('touchstart', function(e) {
    const spoiler = e.target.closest('.spoiler');
    if (spoiler) {
      e.preventDefault();
      toggleSpoiler(spoiler);
    }
  }, { passive: false });
}
</script>

<script>
// Manga Comment Form AJAX Handler
function updateSortVisibility() {
  const block = document.querySelector('.comments-sort-block');
  const list = document.querySelector('.comments-list');
  if (!block) return;
  if (list && list.querySelector(':scope > .comment')) {
    block.style.display = '';
  } else {
    block.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  updateSortVisibility();
  const commentForm = document.getElementById('manga-comment-form');
  const submitBtn = document.getElementById('submit-manga-comment');
  const commentText = document.getElementById('manga-comment-text');
  const messageDiv = document.getElementById('comment-message');

  // Prevent duplicate execution
  if (window.mangaCommentHandlerInitialized) {
    console.warn('⚠️ Manga comment handler already initialized');
    return;
  }
  window.mangaCommentHandlerInitialized = true;

  const MIN_COMMENT_DELAY = 5000; // 5 seconds anti-spam
  const initialSubmitLabel = submitBtn ? submitBtn.innerHTML : '';

  if (commentForm && submitBtn) {
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();

      // ensure user is logged in
      if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
        showMessage('You must be logged in to comment.', 'error');
        return;
      }

      // Rate limit: 1 comment every 5 seconds
      const now = Date.now();
      const lastSubmit = window._lastMangaCommentSubmit || 0;
      if (now - lastSubmit < MIN_COMMENT_DELAY) {
        const waitSeconds = Math.ceil((MIN_COMMENT_DELAY - (now - lastSubmit)) / 1000);
        showMessage('Please wait ' + waitSeconds + ' seconds before posting again.', 'error');
        return;
      }

      // Disable button during submission
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Posting...';

      // Prepare data
      const formData = new FormData();
      formData.append('action', 'mangayummy_add_manga_comment');
      formData.append('post_id', commentForm.dataset.postId);
      formData.append('comment', commentText.value);
      
      // Get nonce from the nonce field inside the form
      const nonceField = commentForm.querySelector('input[name="nonce"]');
      if (nonceField) {
        formData.append('nonce', nonceField.value);
      }

      // Send AJAX request
      fetch(ya_ajax.ajax_url, {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Save submit time only on success
          window._lastMangaCommentSubmit = Date.now();
          showMessage(data.data.message, 'success');
          commentText.value = '';

          // Clear GIF preview after successful submit
          const gifPreview = document.getElementById('gif-preview');
          if (gifPreview) {
            gifPreview.style.display = 'none';
            gifPreview.innerHTML = '';
          }

          // Insert server-rendered HTML (single source of truth)
          if (data.data && data.data.html) {
            // CRITICAL: Get comments-list from the ACTIVE comments tab, not reviews tab
            const commentsTab = document.querySelector('#comments-tab.active');
            if (!commentsTab) {
              console.error('❌ Comments tab not found or not active!');
              return;
            }
            
            let list = commentsTab.querySelector('.comments-list');
            const listWasCreated = !list;
            
            // If no comments exist, create the list container and remove "no comments" message
            if (!list) {
              const wrapper = commentsTab.querySelector('.comments-list-wrapper');
              if (wrapper) {
                const noComments = wrapper.querySelector('.no-comments');
                if (noComments) noComments.remove();
                
                list = document.createElement('div');
                list.className = 'comments-list';
                list.setAttribute('data-sort-type', 'newest');
                wrapper.appendChild(list);
              }
            }
            
            if (list) {
              // Remove "no comments" message if it still exists
              const noComments = document.querySelector('.no-comments');
              if (noComments) {
                noComments.remove();
              }
              
              // If list was just created, wait for next frame to ensure DOM is ready
              const insertComment = () => {
                // Insert the HTML returned by server
                list.insertAdjacentHTML('afterbegin', data.data.html);
                
                // Reinitialize behaviours on next frame
                requestAnimationFrame(() => {
                  if (typeof window.attachMangaCommentEventListeners === 'function') {
                    window.attachMangaCommentEventListeners();
                  }
                  if (typeof window.updateCommentCounter === 'function') {
                    window.updateCommentCounter();
                  }
                  // Reinitialize sorter to apply sorting to new comment
                  if (typeof CommentSorter === 'function') {
                    new CommentSorter();
                  }
                  updateSortVisibility();
                });
              };
              
              // If list was just created, wait one frame for DOM to be ready
              if (listWasCreated) {
                requestAnimationFrame(insertComment);
              } else {
                insertComment();
              }
            }
          }
          
          // Clear browser history to prevent form resubmission alert
          window.history.replaceState(null, '', window.location.href);
        } else {
          showMessage(data.data || 'Posting error', 'error');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showMessage('Connection error', 'error');
        // Reset timer on error to allow immediate retry
        window._lastMangaCommentSubmit = 0;
      })
      .finally(() => {
        // Re-enable button
        submitBtn.disabled = false;
        submitBtn.innerHTML = initialSubmitLabel || '<i class="fa fa-send"></i> Post comment';
      });
    });
  }

  // Note: client MUST NOT construct comment markup. Server returns HTML.

  function expandGifComments() {
    document.querySelectorAll('.comment-text').forEach(el => {
      if (el.querySelector('img.comment-gif')) {
        el.classList.remove('hide-text');
        el.classList.add('show-text');
        el.classList.add('comment-has-gif');

        const moreTextBtn = el.parentNode.querySelector('.more-text');
        if (moreTextBtn) {
          moreTextBtn.style.display = 'none';
        }
      }
    });
  }

  window.attachMangaCommentEventListeners = function() {
    expandGifComments();

    // Attach like/dislike handlers to newly added comments
    const likes = document.querySelectorAll('.comment-like:not([data-bound])');
    const dislikes = document.querySelectorAll('.comment-dislike:not([data-bound])');
    
    const handleReaction = (btn) => {
      btn.setAttribute('data-bound', '1');
      
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Prevent double-click
        if (btn.dataset.processing === '1') return;
        btn.dataset.processing = '1';
        
        const commentId = btn.dataset.id;
        const action = btn.dataset.action;
        
        if (!commentId || !action) {
          btn.dataset.processing = '0';
          return;
        }
        
        const formData = new FormData();
        formData.append('action', 'mangayummy_react_comment');
        // Use mangayummy_comments.nonce (the correct nonce for comments)
        const nonce = typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.nonce : ya_ajax.nonce;
        formData.append('nonce', nonce);
        formData.append('comment_id', commentId);
        formData.append('reaction', action);
        
        fetch(ya_ajax.ajax_url, {
          method: 'POST',
          body: formData
        })
        .then(r => r.json())
        .then(res => {
          if (res.success) {
            const box = btn.closest('.comment-actions');
            if (box) {
              // Update counts
              const likeBtn = box.querySelector('.comment-like');
              const dislikeBtn = box.querySelector('.comment-dislike');
              
              if (likeBtn) likeBtn.querySelector('.count').textContent = res.data.likes;
              if (dislikeBtn) dislikeBtn.querySelector('.count').textContent = res.data.dislikes;
              
              // Update active state - remove from both buttons first
              if (likeBtn) likeBtn.classList.remove('active');
              if (dislikeBtn) dislikeBtn.classList.remove('active');
              
              // Add active to correct button
              if (res.data.current) {
                const activeBtn = box.querySelector('.comment-' + res.data.current);
                if (activeBtn) activeBtn.classList.add('active');
              }
            }
          } else {
            console.error('React error:', res);
          }
        })
        .catch(err => console.error('React error:', err))
        .finally(() => {
          btn.dataset.processing = '0';
        });
      });
    };
    
    likes.forEach(handleReaction);
    dislikes.forEach(handleReaction);
  };

  window.updateCommentCounter = function() {
    // Get current count from the counter
    const countElement = document.querySelector('.tabs-li[data-id="#comments-tab"] .count');
    if (countElement) {
      const currentCount = parseInt(countElement.textContent) || 0;
      countElement.textContent = currentCount + 1;
    }
  };

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function showMessage(message, type) {
    messageDiv.style.display = 'block';
    messageDiv.className = 'comment-message ' + type;
    messageDiv.innerHTML = '<i class="fa ' + (type === 'success' ? 'fa-check' : 'fa-exclamation') + '"></i> ' + message;
    
    // Auto hide after 5 seconds
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 5000);
  }
  window.showMessage = showMessage;
  
  // Initialize event listeners for existing comments
  if (typeof window.attachMangaCommentEventListeners === 'function') {
    window.attachMangaCommentEventListeners();
  }
  
  // CommentFormatter is already initialized above in the first DOMContentLoaded
  // const commentFormatter = new CommentFormatter('#manga-comment-text');
});

// Update reviews counter based on actual DOM (not PHP calculation)
document.addEventListener('DOMContentLoaded', () => {
  const reviewsTab = document.querySelector('#reviews-tab');
  const reviewsCounter = document.querySelector('[data-id="#reviews-tab"] .count');

  if (!reviewsTab || !reviewsCounter) return;

  const getChapterComments = () => {
    return [...reviewsTab.querySelectorAll('.comment')]
      .filter(c => c.dataset.chapterId); // ONLY chapter comments
  };

  const updateReviewsCount = () => {
    const total = getChapterComments().length;
    reviewsCounter.textContent = total;
  };

  // Hide non-chapter comments from reviews
  reviewsTab.querySelectorAll('.comment').forEach(c => {
    if (!c.dataset.chapterId) {
      c.style.display = 'none';
    }
  });

  updateReviewsCount();

  // Update if comments are added dynamically (AJAX)
  const observer = new MutationObserver(() => {
    reviewsTab.querySelectorAll('.comment').forEach(c => {
      if (!c.dataset.chapterId) {
        c.style.display = 'none';
      }
    });
    updateReviewsCount();
  });

  observer.observe(reviewsTab, { childList: true, subtree: true });
});

// viewed-chapter script removed per request

</script>

<style>
/* viewed chapter CSS removed */

/* Language Selection Modal */
.language-modal .modal-body {
  padding: 20px;
}

.language-modal .chapters-box {
  margin: 0;
}

.language-modal .chapters-list {
  margin: 0;
  padding: 0;
  list-style: none;
}

.language-modal .modal-chapter-item {
  margin-bottom: 10px;
  border-radius: 8px;
  transition: background-color 0.3s ease;
}

.language-modal .modal-chapter-item:hover {
  background-color: #f8f9fa;
}

.language-modal .modal-chapter-item a {
  padding: 15px;
  display: block;
  color: inherit;
  text-decoration: none;
}
</style>

<!-- ========== COMMENT TEXT EXPAND/COLLAPSE TOGGLE ========== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Initialize toggle functionality for all comment texts
  function initCommentToggle() {
    document.querySelectorAll('.comment-text.hide-text').forEach(function(textDiv) {
      const commentId = textDiv.getAttribute('data-comment-id');
      const moreBtn = document.querySelector('.more-text[data-comment-id="' + commentId + '"]');
      
      if (!moreBtn) return;
      
      // Check if text overflows
      setTimeout(function() {
        const maxHeight = window.innerWidth <= 768 ? 150 : 72;
        const isOverflowing = textDiv.scrollHeight > maxHeight;
        
        if (isOverflowing) {
          moreBtn.style.display = 'inline-block';
        } else {
          moreBtn.style.display = 'none';
        }
      }, 100);
      
      // Toggle handler
      moreBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        const isExpanded = textDiv.classList.contains('show-text');
        
        if (isExpanded) {
          // Collapse
          textDiv.classList.remove('show-text');
          textDiv.classList.add('hide-text');
          moreBtn.textContent = 'Show full text';
        } else {
          // Expand
          textDiv.classList.remove('hide-text');
          textDiv.classList.add('show-text');
          moreBtn.textContent = 'Hide text';
        }
      });
    });
  }
  
  // Initialize on page load
  initCommentToggle();
  
  // Re-initialize when new comments are added via AJAX
  document.addEventListener('comment-added', function() {
    initCommentToggle();
  });
});
</script>

<!-- Chapters list scroll & sort logic -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const chaptersBoxes = document.querySelectorAll('.chapters-box');
  chaptersBoxes.forEach(box => {
    const chaptersList = box.querySelector('.chapters-list');
    if (!chaptersList) return;
    // list of items will be recalculated inside render() so it stays in sync after sorting

    const onLastClick = (e) => {
      if (box.classList.contains('collapsed')) {
        e.preventDefault();
        expand();
      }
    };

    function render() {
      // Get current visible chapters each time (accounts for reordering)
      const allChapters = Array.from(chaptersList.querySelectorAll('.latest-chapter-item:not(.filtered-out)'));

      // Only show the first 8 chapters when collapsed
      // Show all chapters (scroll container handles overflow)
      allChapters.forEach(ch => {
        ch.style.display = 'list-item';
        ch.style.cursor = '';
      });
    }

    function expand() {
      box.classList.remove('collapsed');
      box.classList.add('expanded');
      render();
    }

    // when sort order changes, re-run render
    chaptersList.addEventListener('sorted', render);

    // render once to apply visibility
    render();
  });
});

// Handle translator link clicks
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.latest-chapter-item > a').forEach(function(link) {
    link.addEventListener('click', function(e) {
      var translator = e.target.closest('.translator-name');
      if (translator && translator.hasAttribute('data-link')) {
        e.preventDefault();
        var groupLink = translator.getAttribute('data-link');
        if (groupLink) {
          window.location.href = groupLink;
        }
        return false;
      }
      // Otherwise, proceed with normal chapter link
    });
  });
});

</script>

<style>
.is-page-editing .manga-title,
.is-page-editing .alt-titles-list,
.is-page-editing #mangaLiveAuthor,
.is-page-editing #mangaLiveArtist,
.is-page-editing #mangaLiveAuthorArtist,
.is-page-editing #mangaLiveGenres,
.is-page-editing #mangaLiveType,
.is-page-editing #mangaLiveYear,
.is-page-editing #mangaLiveStatus,
.is-page-editing #mangaLiveFinalChapter,
.is-page-editing #mangaLiveFinalChapterMobile,
.is-page-editing #mangaLiveTranslator,
.is-page-editing #mangaLiveDescription {
  outline: 1px dashed rgba(255,255,255,0.35);
  background: rgba(255,255,255,0.04);
  border-radius: 6px;
  box-shadow: inset 0 0 0 1px rgba(255,255,255,0.03);
}

.is-page-editing .manga-title,
.is-page-editing .alt-titles-list,
.is-page-editing #mangaLiveAuthor,
.is-page-editing #mangaLiveArtist,
.is-page-editing #mangaLiveAuthorArtist,
.is-page-editing #mangaLiveGenres,
.is-page-editing #mangaLiveType,
.is-page-editing #mangaLiveYear,
.is-page-editing #mangaLiveStatus,
.is-page-editing #mangaLiveTranslator {
  padding: 4px 6px;
}

.is-page-editing #mangaLiveDescription {
  padding: 10px 12px;
  min-height: 120px;
}

.is-page-editing #mangaLiveGenres a,
.is-page-editing #mangaLiveYear {
  pointer-events: none;
}

.is-page-editing #mangaLiveTranslator a {
  pointer-events: none;
}

.is-page-editing .manga-live-editable.manga-live-changed,
.is-page-editing .manga-live-editable.manga-live-changed a {
  color: #13667a !important;
}

.manga-select-menu {
  position: fixed;
  min-width: 180px;
  max-width: 240px;
  background: #151515;
  border: 1px solid rgba(255,255,255,0.14);
  border-radius: 10px;
  box-shadow: 0 16px 36px rgba(0,0,0,0.45);
  padding: 6px;
  z-index: 10060;
}

.manga-select-menu button {
  width: 100%;
  display: block;
  text-align: left;
  border: none;
  background: transparent;
  color: #f3f3f3;
  padding: 8px 10px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
}

.manga-select-menu button:hover,
.manga-select-menu button.is-active {
  background: rgba(255,255,255,0.08);
}

.manga-edit-action-bar {
  position: relative;
  width: 100%;
  max-width: 100%;
  margin-top: 10px;
  z-index: 2;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0,0,0,0.25);
  padding: 14px;
}

.manga-edit-action-form {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
}

.manga-edit-toast {
  position: fixed;
  bottom: 20px;
  right: 20px;
  max-width: min(420px, calc(100vw - 24px));
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.16);
  background: rgba(14,14,14,0.96);
  color: #f3f3f3;
  box-shadow: 0 12px 34px rgba(0,0,0,0.42);
  opacity: 0;
  transform: translateY(-10px);
  pointer-events: none;
  transition: opacity 0.2s ease, transform 0.2s ease;
  z-index: 10040;
}

.manga-edit-toast.show {
  opacity: 1;
  transform: translateY(0);
}

.manga-edit-toast.is-warning {
  border-color: rgba(255, 181, 71, 0.52);
}

.manga-edit-action-note label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #f5f5f5;
}

.form-group {
  margin-bottom: 15px;
}

.form-control {
  width: 100%;
  padding: 12px;
  background: #0f0f0f;
  border: 1px solid #333;
  color: #fff;
  border-radius: 4px;
  font-size: 14px;
  box-sizing: border-box;
}

.form-control:focus {
  outline: none;
  border-color: #7a7a7a;
  box-shadow: 0 0 0 3px rgba(255,255,255,0.06);
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}

.btn-primary {
  background-color: #f3f3f3;
  color: #111;
}

.btn-primary:hover {
  background-color: #fff;
}

.btn-secondary {
  background-color: #252525;
  color: #fff;
}

.btn-secondary:hover {
  background-color: #303030;
}

.alert {
  padding: 12px 15px;
  border-radius: 4px;
  margin-bottom: 15px;
  font-size: 14px;
}

.alert-success {
  background-color: #2e7d32;
  color: #fff;
  border: 1px solid #1b5e20;
}

.alert-danger {
  background-color: #c62828;
  color: #fff;
  border: 1px solid #6a0000;
}

small {
  color: #999;
  font-size: 12px;
}

.report-form-footer {
  gap: 10px;
  align-items: center;
  justify-content: flex-end;
}

@media (max-width: 640px) {
  .manga-edit-action-bar {
    padding: 12px;
  }

  .manga-edit-toast {
    bottom: 10px;
    right: 8px;
  }

  .manga-edit-action-form {
    grid-template-columns: 1fr;
  }

  .report-form-footer {
    flex-direction: column-reverse;
  }

  .report-form-footer .btn {
    width: 100%;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const reportTrigger = document.getElementById('mangaReportTrigger');
  const actionBar = document.getElementById('mangaEditActionBar');
  const inlineCancel = document.getElementById('mangaInlineEditorCancel');
  const reportForm = document.getElementById('mangaReportForm');
  const editToast = document.getElementById('mangaEditToast');
  const summaryContent = document.querySelector('.summary_content');
  const metaLeft = document.querySelector('.meta-left');
  const metaRight = document.querySelector('.meta-right .desktop-only') || document.querySelector('.meta-right');

  const liveTitle = document.getElementById('mangaLiveTitle');
  const liveStatus = document.getElementById('mangaLiveStatus');
  let liveAltTitles = document.getElementById('mangaLiveAltTitles');
  let liveAltTitlesRow = document.getElementById('mangaLiveAltTitlesRow');
  let liveAuthor = document.getElementById('mangaLiveAuthor');
  let liveAuthorRow = document.getElementById('mangaLiveAuthorRow');
  let liveArtist = document.getElementById('mangaLiveArtist');
  let liveArtistRow = document.getElementById('mangaLiveArtistRow');
  let liveAuthorArtist = document.getElementById('mangaLiveAuthorArtist');
  let liveAuthorArtistRow = document.getElementById('mangaLiveAuthorArtistRow');
  let liveGenres = document.getElementById('mangaLiveGenres');
  let liveGenresRow = document.getElementById('mangaLiveGenresRow');
  let liveType = document.getElementById('mangaLiveType');
  let liveTypeRow = document.getElementById('mangaLiveTypeRow');
  let liveYear = document.getElementById('mangaLiveYear');
  let liveYearRow = document.getElementById('mangaLiveYearRow');
  let liveFinalChapter = document.getElementById('mangaLiveFinalChapter') || document.getElementById('mangaLiveFinalChapterMobile');
  let liveFinalChapterRow = document.getElementById('mangaLiveFinalChapterRow') || document.getElementById('mangaLiveFinalChapterMobileRow');
  let liveTranslator = document.getElementById('mangaLiveTranslator');
  let liveTranslatorRow = document.getElementById('mangaLiveTranslatorRow');
  let liveDescription = document.getElementById('mangaLiveDescription');

  const editingState = {
    active: false,
    snapshots: new Map(),
    createdIds: [],
    originalValues: null
  };
  let activeSelectionMenu = null;
  let selectionMenuCleanup = null;

  function snapshotElement(key, element, row) {
    if (!element || editingState.snapshots.has(key)) return;
    editingState.snapshots.set(key, {
      element,
      row,
      html: element.innerHTML,
      rowDisplay: row ? row.style.display : '',
      originalText: normalizeComparableText(element.textContent || '')
    });
  }

  function normalizeComparableText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function updateChangedState(key, element) {
    if (!element) return;
    const snapshot = editingState.snapshots.get(key);
    if (!snapshot) return;
    const currentText = normalizeComparableText(element.textContent || '');
    if (currentText !== snapshot.originalText) {
      element.classList.add('manga-live-changed');
    } else {
      element.classList.remove('manga-live-changed');
    }
  }

  function makeEditable(element, key, row, plainText) {
    if (!element) return;
    snapshotElement(key, element, row);
    if (plainText) {
      element.textContent = element.textContent.trim();
    }
    element.contentEditable = 'true';
    element.classList.add('manga-live-editable');
    element.spellcheck = false;
    element.oninput = function() {
      updateChangedState(key, element);
    };
    updateChangedState(key, element);
  }

  function closeSelectionMenu() {
    if (typeof selectionMenuCleanup === 'function') {
      selectionMenuCleanup();
      selectionMenuCleanup = null;
    }
    if (activeSelectionMenu && activeSelectionMenu.parentNode) {
      activeSelectionMenu.parentNode.removeChild(activeSelectionMenu);
    }
    activeSelectionMenu = null;
  }

  function showSelectionMenu(anchorEl, options, currentText, onSelect) {
    closeSelectionMenu();
    if (!anchorEl || !Array.isArray(options) || options.length === 0) return;

    const rect = anchorEl.getBoundingClientRect();
    const menu = document.createElement('div');
    menu.className = 'manga-select-menu';

    options.forEach(function(option) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = option;
      if (normalizeComparableText(option).toLowerCase() === normalizeComparableText(currentText).toLowerCase()) {
        btn.classList.add('is-active');
      }
      btn.addEventListener('click', function() {
        onSelect(option);
        closeSelectionMenu();
      });
      menu.appendChild(btn);
    });

    document.body.appendChild(menu);

    const menuRect = menu.getBoundingClientRect();
    const viewportW = window.innerWidth;
    const viewportH = window.innerHeight;
    let left = rect.left;
    let top = rect.bottom + 8;

    if (left + menuRect.width > viewportW - 8) {
      left = viewportW - menuRect.width - 8;
    }
    if (left < 8) left = 8;
    if (top + menuRect.height > viewportH - 8) {
      top = rect.top - menuRect.height - 8;
    }
    if (top < 8) top = 8;

    menu.style.left = left + 'px';
    menu.style.top = top + 'px';
    activeSelectionMenu = menu;

    function removeMenuListeners() {
      document.removeEventListener('mousedown', onDocMouseDown, true);
      window.removeEventListener('resize', onWindowClose);
      window.removeEventListener('scroll', onWindowClose, true);
    }

    function onWindowClose() {
      closeSelectionMenu();
    }

    function onDocMouseDown(event) {
      if (!menu.contains(event.target) && event.target !== anchorEl) {
        closeSelectionMenu();
      }
    }

    selectionMenuCleanup = removeMenuListeners;

    window.setTimeout(function() {
      document.addEventListener('mousedown', onDocMouseDown, true);
      window.addEventListener('resize', onWindowClose);
      window.addEventListener('scroll', onWindowClose, true);
    }, 0);
  }

  function makeSelectable(element, key, row, options, fieldLabel) {
    if (!element) return;
    snapshotElement(key, element, row);
    element.contentEditable = 'false';
    element.classList.add('manga-live-editable', 'manga-live-selectable');
    element.spellcheck = false;
    element.setAttribute('tabindex', '0');
    element.setAttribute('role', 'button');
    element.style.cursor = 'pointer';

    element.onclick = function(e) {
      e.preventDefault();
      e.stopPropagation();
      showSelectionMenu(element, options, element.textContent || '', function(selected) {
        element.textContent = selected;
        updateChangedState(key, element);
      });
    };

    element.onkeydown = function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        element.click();
      }
    };

    updateChangedState(key, element);
  }

  function ensureAltTitlesRow() {
    if (liveAltTitles && liveAltTitlesRow) return;
    if (!summaryContent || !liveTitle) return;
    const row = document.createElement('h2');
    row.className = 'alt-titles manga-subtitle';
    row.id = 'mangaLiveAltTitlesRow';
    const span = document.createElement('span');
    span.className = 'alt-titles-list';
    span.id = 'mangaLiveAltTitles';
    row.appendChild(span);
    liveTitle.insertAdjacentElement('afterend', row);
    editingState.createdIds.push('mangaLiveAltTitlesRow');
    liveAltTitlesRow = row;
    liveAltTitles = span;
  }

  function openInlineEditor() {
    if (editingState.active) return;
    const initialScrollX = window.scrollX || window.pageXOffset || 0;
    const initialScrollY = window.scrollY || window.pageYOffset || 0;

    editingState.active = true;
    document.body.classList.add('is-page-editing');
    if (actionBar) actionBar.hidden = false;
    if (reportTrigger) reportTrigger.setAttribute('aria-expanded', 'true');

    ensureAltTitlesRow();
    makeEditable(liveTitle, 'title', null, true);
    makeEditable(liveAltTitles, 'altTitles', liveAltTitlesRow, true);
    makeEditable(liveAuthor, 'author', liveAuthorRow, true);
    makeEditable(liveArtist, 'artist', liveArtistRow, true);
    makeEditable(liveAuthorArtist, 'authorArtist', liveAuthorArtistRow, true);
    makeEditable(liveGenres, 'genres', liveGenresRow, true);
    makeSelectable(liveType, 'type', liveTypeRow, ['Manga', 'Manhwa', 'Manhua'], 'Tip');
    makeEditable(liveYear, 'year', liveYearRow, true);
    makeEditable(liveFinalChapter, 'finalChapter', liveFinalChapterRow, true);
    makeEditable(liveTranslator, 'translator', liveTranslatorRow, true);
    makeSelectable(liveStatus, 'status', null, ['În desfășurare', 'Finalizat', 'În Pauză', 'Anulat', 'Abandonat'], 'Status');
    makeEditable(liveDescription, 'description', null, false);
    editingState.originalValues = collectSuggestedValues();

    // Keep user at the same viewport position when entering edit mode.
    if ((window.scrollY || window.pageYOffset || 0) !== initialScrollY || (window.scrollX || window.pageXOffset || 0) !== initialScrollX) {
      window.scrollTo({ top: initialScrollY, left: initialScrollX, behavior: 'auto' });
    }
  }

  function closeInlineEditor(restoreOriginal) {
    if (!editingState.active) return;

    if (restoreOriginal) {
      editingState.snapshots.forEach(function(snapshot) {
        if (snapshot.element) {
          snapshot.element.innerHTML = snapshot.html;
        }
        if (snapshot.row) {
          snapshot.row.style.display = snapshot.rowDisplay;
        }
      });

      editingState.createdIds.forEach(function(id) {
        const element = document.getElementById(id);
        if (element) element.remove();
      });

      liveAltTitles = document.getElementById('mangaLiveAltTitles');
      liveAltTitlesRow = document.getElementById('mangaLiveAltTitlesRow');
      liveAuthor = document.getElementById('mangaLiveAuthor');
      liveAuthorRow = document.getElementById('mangaLiveAuthorRow');
      liveArtist = document.getElementById('mangaLiveArtist');
      liveArtistRow = document.getElementById('mangaLiveArtistRow');
      liveAuthorArtist = document.getElementById('mangaLiveAuthorArtist');
      liveAuthorArtistRow = document.getElementById('mangaLiveAuthorArtistRow');
      liveGenres = document.getElementById('mangaLiveGenres');
      liveGenresRow = document.getElementById('mangaLiveGenresRow');
      liveType = document.getElementById('mangaLiveType');
      liveTypeRow = document.getElementById('mangaLiveTypeRow');
      liveYear = document.getElementById('mangaLiveYear');
      liveYearRow = document.getElementById('mangaLiveYearRow');
      liveFinalChapter = document.getElementById('mangaLiveFinalChapter') || document.getElementById('mangaLiveFinalChapterMobile');
      liveFinalChapterRow = document.getElementById('mangaLiveFinalChapterRow') || document.getElementById('mangaLiveFinalChapterMobileRow');
      liveTranslator = document.getElementById('mangaLiveTranslator');
      liveTranslatorRow = document.getElementById('mangaLiveTranslatorRow');
      liveDescription = document.getElementById('mangaLiveDescription');
    }

    editingState.snapshots.forEach(function(snapshot) {
      if (snapshot.element) {
        snapshot.element.contentEditable = 'false';
        snapshot.element.classList.remove('manga-live-editable');
        snapshot.element.classList.remove('manga-live-selectable');
        snapshot.element.classList.remove('manga-live-changed');
        snapshot.element.onclick = null;
        snapshot.element.onkeydown = null;
        snapshot.element.oninput = null;
      }
    });

    closeSelectionMenu();

    editingState.snapshots.clear();
    editingState.createdIds = [];
    editingState.originalValues = null;
    editingState.active = false;
    document.body.classList.remove('is-page-editing');
    if (actionBar) actionBar.hidden = true;
    if (reportTrigger) reportTrigger.setAttribute('aria-expanded', 'false');
  }

  function getText(element) {
    return element ? String(element.textContent || '').trim() : '';
  }

  function getDescriptionText() {
    return liveDescription ? String(liveDescription.innerText || '').trim() : '';
  }

  function normalizeStatus(value) {
    const normalized = value.toLowerCase().trim();
    const map = {
      'în desfășurare': 'ongoing',
      'în desfasurare': 'ongoing',
      'ongoing': 'ongoing',
      'finalizat': 'completed',
      'completed': 'completed',
      'în pauză': 'hiatus',
      'în pauza': 'hiatus',
      'hiatus': 'hiatus',
      'anulat': 'cancelled',
      'cancelled': 'cancelled',
      'abandonat': 'dropped',
      'dropped': 'dropped'
    };
    return map[normalized] || normalized;
  }

  function normalizeType(value) {
    const normalized = value.toLowerCase().trim();
    if (normalized === 'manga' || normalized === 'manhwa' || normalized === 'manhua') {
      return normalized;
    }
    return normalized;
  }

  function collectSuggestedValues() {
    return {
      title: getText(liveTitle),
      alternative_titles: getText(liveAltTitles),
      genres: getText(liveGenres),
      author: getText(liveAuthor) || getText(liveAuthorArtist),
      artist: getText(liveArtist) || getText(liveAuthorArtist),
      type: normalizeType(getText(liveType)),
      status: normalizeStatus(getText(liveStatus)),
      year: getText(liveYear).replace(/[^0-9]/g, ''),
      final_chapter: getText(liveFinalChapter),
      translator_ro: getText(liveTranslator),
      description: getDescriptionText()
    };
  }

  function hasAnyChange(currentValues) {
    const originalValues = editingState.originalValues || {};
    return Object.keys(currentValues).some(function(key) {
      return String(currentValues[key] || '') !== String(originalValues[key] || '');
    });
  }

  function getChangedFieldKeys(currentValues) {
    const originalValues = editingState.originalValues || {};
    return Object.keys(currentValues).filter(function(key) {
      return String(currentValues[key] || '') !== String(originalValues[key] || '');
    });
  }

  let toastTimer = null;

  function showEditToast(message) {
    if (!editToast) return;
    editToast.textContent = message;
    editToast.classList.add('is-warning', 'show');
    if (toastTimer) {
      window.clearTimeout(toastTimer);
    }
    toastTimer = window.setTimeout(function() {
      editToast.classList.remove('show');
    }, 2600);
  }

  if (reportTrigger) {
    reportTrigger.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      if (editingState.active) {
        closeInlineEditor(true);
      } else {
        openInlineEditor();
      }
    });

    reportTrigger.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        if (editingState.active) {
          closeInlineEditor(true);
        } else {
          openInlineEditor();
        }
      }
    });
  }

  if (inlineCancel) inlineCancel.addEventListener('click', function() {
    closeInlineEditor(true);
  });

  reportForm.addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData();
    const submitBtn = reportForm.querySelector('button[type="submit"]');
    const successAlert = document.getElementById('reportSuccess');
    const errorAlert = document.getElementById('reportError');
    const currentValues = collectSuggestedValues();
    const changedFieldKeys = getChangedFieldKeys(currentValues);

    if (changedFieldKeys.length === 0) {
      showEditToast('Nu poti trimite daca nu ai modificat nimic.');
      return;
    }

    formData.append('manga_id', reportForm.querySelector('input[name="manga_id"]').value);
    formData.append('action', 'mangayummy_submit_report');
    formData.append('nonce', reportForm.querySelector('input[name="nonce"]').value);
    formData.append('title', currentValues.title);
    formData.append('alternative_titles', currentValues.alternative_titles);
    formData.append('genres', currentValues.genres);
    formData.append('author', currentValues.author);
    formData.append('artist', currentValues.artist);
    formData.append('type', currentValues.type);
    formData.append('status', currentValues.status);
    formData.append('year', currentValues.year);
    formData.append('final_chapter', currentValues.final_chapter);
    formData.append('translator_ro', currentValues.translator_ro);
    formData.append('description', currentValues.description);
    formData.append('changed_fields', JSON.stringify(changedFieldKeys));
    formData.append('message', '');

    submitBtn.disabled = true;
    submitBtn.textContent = 'Se trimite...';

    fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
      method: 'POST',
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        successAlert.style.display = 'block';
        errorAlert.style.display = 'none';
        setTimeout(() => {
          successAlert.style.display = 'none';
          closeInlineEditor(true);
        }, 1800);
      } else {
        errorAlert.textContent = '❌ ' + (data.data || 'Eroare la trimitere');
        errorAlert.style.display = 'block';
        successAlert.style.display = 'none';
      }
      submitBtn.disabled = false;
      submitBtn.textContent = 'Trimite pentru verificare';
    })
    .catch(err => {
      errorAlert.textContent = '❌ Eroare de rețea';
      errorAlert.style.display = 'block';
      successAlert.style.display = 'none';
      submitBtn.disabled = false;
      submitBtn.textContent = 'Trimite pentru verificare';
    });
  });
});
</script>

<?php get_footer(); ?>