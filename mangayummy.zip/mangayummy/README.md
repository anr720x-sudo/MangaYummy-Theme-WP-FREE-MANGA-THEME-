# MangaYummy - Free & Open Source WordPress Theme

## What is MangaYummy
MangaYummy is a free, open-source WordPress theme built for manga and webtoon reading websites. It combines a modern dark UI, fast browsing, chapter-based reading flows, and community features (profiles, comments, bookmarks, ratings, and progress tracking) to help you launch a complete reading platform at no cost.

## Features list
- Purpose-built manga and chapter architecture for organized libraries and reading flows.
- Fast homepage sections (recent releases, popular titles, recommended titles, latest chapters).
- Reader profile system with levels, XP, bookmarks, and reading progress.
- AJAX-powered interactions for smooth UX (login, register, comments, ratings, status updates).
- Manga status management (ongoing, completed, hiatus, dropped).
- Chapter-first experience with progress updates and chapter navigation.
- News module integration for announcements and community updates.
- Legacy-safe migration layer for AJAX endpoint upgrades.
- Translation-ready structure using WordPress i18n functions and text domain `mangayummy`.
- Mobile-first responsive layout for phone, tablet, and desktop readers.

## Requirements
- WordPress: 6.4 or newer
- PHP: 8.1 or newer
- MySQL: 5.7+ or MariaDB 10.4+
- HTTPS enabled (recommended for production)

### Recommended plugins (optional)
- Yoast SEO or Rank Math (SEO fields integration)
- LiteSpeed Cache / WP Rocket (performance)
- UpdraftPlus (backup)
- Wordfence (security hardening)

## Installation
1. Upload the theme folder (`mangayummy`) to `wp-content/themes/`.
2. Go to WordPress Admin -> Appearance -> Themes.
3. Activate **MangaYummy**.
4. Go to Settings -> Permalinks and click **Save Changes** once.
5. Verify that required custom post types (`manga`, `chapter`, `stire`) are available.
6. Open the homepage and confirm sections load correctly.

## Demo Import
1. Open WordPress Admin -> Tools -> Import.
2. Install and run the **WordPress Importer** plugin.
3. Import `demo/demo-content.xml` from this package.
4. Assign imported content to an existing admin user.
5. Enable attachment download if prompted.
6. After import, go to Settings -> Permalinks and click **Save Changes**.
7. Check imported manga, chapters, and news posts.

## Theme Options & Customization
- Main behavior is configured from theme templates and `functions.php`.
- Homepage sections are managed by content and theme query logic.
- Reader/profile behavior is powered by user meta and AJAX handlers.
- Colors and presentation can be adjusted in theme CSS files:
  - `style.css`
  - `css/front-page.css`
  - `css/single-manga.css`
  - `css/single-chapter.css`
- JavaScript interactions are in `js/` and use vanilla ES6.

## Translation / i18n
- Text Domain: `mangayummy`
- Theme is prepared for WordPress translation workflows.
- For localization:
  1. Generate a POT file from theme sources.
  2. Create `.po/.mo` files for your language.
  3. Place compiled translation files under `languages/`.

## Changelog
### v1.0.0 - Initial Release
- Initial commercial release of MangaYummy.
- Added manga/chapter/news structures.
- Added user profiles, bookmarks, ratings, and reading progress.
- Added AJAX-driven UX flows.
- Added homepage modules for popular, recent, and recommended content.
- Added translation-ready text domain setup.

## Support & Credits
### Support the Developer ☕
MangaYummy is completely free and open source. If you find this theme useful and would like to support its continued development and maintenance, consider making a donation:

- **[Buy me a coffee](https://buymeacoffee.com/mangayummy9)** - Support via Buy Me a Coffee
- **[PayPal](https://buymeacoffee.com/mangayummy9)** - Support via PayPal
- **[GitHub Sponsors](https://buymeacoffee.com/mangayummy9)** - Sponsor the project on GitHub

Your donation helps:
- Keep MangaYummy free for everyone
- Fund ongoing maintenance and bug fixes
- Support new features and improvements
- Cover server and development costs

### Support
- Issue tracker: GitHub Issues or your marketplace support
- Community: Discord server for discussions
- Documentation: README and inline code comments
- Include your WordPress version, PHP version, and issue steps when reporting bugs

### Credits
- WordPress core
- Font Awesome (icons)
- Swiper (sliders, if enabled in your build)

### License
MangaYummy is licensed under **GPL-2.0-or-later** (GNU General Public License v2 or later).
This means:
- ✅ You can use it commercially
- ✅ You can modify it
- ✅ You must keep the GPL license
- ✅ You must share modifications under GPL
- ✅ You must provide a copy of the license

Third-party assets and libraries retain their own licenses.
