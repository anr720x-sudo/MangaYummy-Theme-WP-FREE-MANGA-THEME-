<?php
/**
 * Template Name: Site-uri de manga
 */
get_header();
?>

<style>
/* make body flex so footer sticks bottom */
html, body { height: 100%; margin: 0; padding: 0; background: #000; }
body { display: flex; flex-direction: column; }
.collab-container { flex: 1; padding: 30px 0; border: 8px solid rgba(255,77,79,0.3); margin: 20px; border-radius: 12px; background: #1a1a1a; }
/* collaboration page */
.collab-container h1 { font-size: 2.5rem; margin-bottom: 16px; text-align: center; color: #fff; }
.collab-grid { display: flex; flex-wrap: wrap; gap: 24px 32px; justify-content: center; }
.collab-item { max-width: 220px; text-align: center; border: 1px solid #333; padding: 12px; border-radius: 8px; background: #111; transition: border-color .3s, background .3s; }
.collab-item:hover { border-color: #13667a; background: #222; } 
.collab-logo { max-width: 100%; height: auto; border-radius: 8px; margin-bottom: 12px; background: #1a1a1a; padding: 8px; }
.collab-name { font-size: 1.2rem; font-weight: 600; color: #fff; margin-top: 8px; text-decoration: none; display: inline-block; }
/* no special hover decoration on name anymore */
.collab-item a:hover .collab-name { color: #13667a; }
.collab-desc { font-size: 1rem; color: #ccc; line-height: 1.4; padding: 8px; border: 1px solid #333; border-radius: 6px; background: rgba(0,0,0,0.1); }
</style>

<div class="collab-container">
    <h1>Site-uri de manga în limba română</h1>

    <div class="collab-grid">
        <?php
        // Build list from customizer settings; fall back to hard‑coded one if none provided.
        $sites = array();
        for ($i = 1; $i <= 5; $i++) {
            $name = get_theme_mod("siteuri_{$i}_name");
            if (empty($name)) {
                continue; // skip unused slots
            }
            $logo = get_theme_mod("siteuri_{$i}_logo");
            $desc = get_theme_mod("siteuri_{$i}_desc");
            $url  = get_theme_mod("siteuri_{$i}_url");
            $sites[] = array(
                'name' => $name,
                'logo' => $logo,
                'desc' => $desc,
                'url'  => $url,
            );
        }

        if (empty($sites)) {
            // fallback sample entry if customizer is empty
            $sites[] = array(
                'name' => 'MangaYummy',
                'logo' => get_template_directory_uri() . '/assets/img/logo.png',
                'desc' => 'Platforma noastră principală unde poți citi mii de manga în limba română.',
            );
        }

        foreach ($sites as $site) : ?>
            <div class="collab-item">
                <?php if (!empty($site['url'])): ?>
                    <a href="<?php echo esc_url($site['url']); ?>" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo esc_url($site['logo']); ?>" 
                             alt="<?php echo esc_attr($site['name']); ?>" 
                             class="collab-logo">
                        <h3 class="collab-name"><?php echo esc_html($site['name']); ?></h3>
                    </a>
                <?php else: ?>
                    <img src="<?php echo esc_url($site['logo']); ?>" 
                         alt="<?php echo esc_attr($site['name']); ?>" 
                         class="collab-logo">
                    <h3 class="collab-name"><?php echo esc_html($site['name']); ?></h3>
                <?php endif; ?>
                <p class="collab-desc"><?php echo esc_html($site['desc']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
get_footer();
