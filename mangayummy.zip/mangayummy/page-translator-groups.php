<?php
/**
 * Template Name: Translator Groups
 * Description: Page template for displaying translator groups and their manga
 */

get_header();
?>

<main class="translator-group-page">
    <div class="translator-container">
        <?php
        $translator_group = get_query_var('translator_group');
        
        // If no translator group specified, show list of all translator groups
        if (empty($translator_group)) {
            echo '<div class="translator-list-page">';
            echo '<h2>Grupuri de traducători manga în limba română</h2>';
            
            echo '<div class="translator-seo-content">';
            echo '<p>MangaYummy centralizează echipe de traducere active care oferă manga-uri în limba română, facilitând accesul cititorilor la proiecte actualizate constant.</p>';
            echo '</div>';
            
            echo '<h1>Grupuri de Traducere</h1>';
            echo '<p>Selectați un grup pentru a vedea mangaurile traduse.</p>';
            
            // Get all unique translator groups
            global $wpdb;
            $translator_groups = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT meta_value 
                     FROM {$wpdb->postmeta} 
                     WHERE meta_key = %s 
                     AND meta_value != '' 
                     ORDER BY meta_value ASC",
                    '_translation_group'
                )
            );
            
            // Pagination
            $groups_per_page = 27;
            $total_groups = count($translator_groups);
            $total_pages = ceil($total_groups / $groups_per_page);
            $current_page = max(1, get_query_var('paged', 1));
            $offset = ($current_page - 1) * $groups_per_page;
            $paginated_groups = array_slice($translator_groups, $offset, $groups_per_page);
            
            if (!empty($paginated_groups)) {
                echo '<div class="translator-groups-grid">';
                foreach ($paginated_groups as $group) {
                    // Count manga for this group
                    $group_chapters = $wpdb->get_col(
                        $wpdb->prepare(
                            "SELECT DISTINCT pm2.meta_value 
                             FROM {$wpdb->postmeta} pm1 
                             INNER JOIN {$wpdb->postmeta} pm2 ON pm1.post_id = pm2.post_id 
                             WHERE pm1.meta_key = '_translation_group' 
                             AND pm1.meta_value = %s 
                             AND pm2.meta_key = '_manga_id'",
                            $group
                        )
                    );
                    $manga_count = count(array_unique($group_chapters));
                    
                    echo '<div class="translator-group-card">';
                    echo '<div class="translator-group-header">';
                    echo '<h3 class="translator-group-name">';
                    echo '<a href="' . esc_url(add_query_arg('translator_group', urlencode($group))) . '">';
                    echo esc_html($group);
                    echo '</a>';
                    echo '</h3>';
                    echo '<div class="translator-group-stats">';
                    $manga_word = $manga_count === 1 ? 'manga' : 'manga-uri';
                    echo '<span class="manga-count">' . $manga_count . ' ' . $manga_word . '</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="translator-group-description">';
                    echo '<p>Grup de traducători</p>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '</div>';
                
                // Pagination
                if ($total_pages > 1) {
                    echo '<div class="translator-pagination">';
                    echo paginate_links(array(
                        'total' => $total_pages,
                        'current' => $current_page,
                        'prev_text' => '« Anterior',
                        'next_text' => 'Următor »',
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '?paged=%#%'
                    ));
                    echo '</div>';
                }
            } else {
                echo '<div class="no-translator-groups">';
                echo '<p>Nu există grupuri de traducători disponibile momentan.</p>';
                echo '</div>';
            }
            
            echo '</div>';
            get_footer();
            return;
        }
        
        $translator_group = sanitize_text_field(urldecode($translator_group));
        
        // Get all chapters by this translator group
        $chapters = new WP_Query([
            'post_type' => 'chapter',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => '_translation_group',
                    'value' => $translator_group,
                    'compare' => '='
                ]
            ],
            'orderby' => 'meta_value_num',
            'meta_key' => '_chapter_number',
            'order' => 'DESC'
        ]);
        
        // Get unique manga IDs
        $manga_ids = [];
        if ($chapters->have_posts()) {
            while ($chapters->have_posts()) {
                $chapters->the_post();
                $manga_id = get_post_meta(get_the_ID(), '_manga_id', true);
                if (!in_array($manga_id, $manga_ids)) {
                    $manga_ids[] = $manga_id;
                }
            }
        }
        wp_reset_postdata();
        ?>
        
        <div class="translator-header">
            <h1 class="translator-title">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="none" viewBox="0 0 24 24" class="translator-header-icon">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2m8-10a4 4 0 1 0 0-8 4 4 0 0 0 0 8"></path>
                </svg>
                <?php echo esc_html($translator_group); ?>
            </h1>
            <p class="translator-subtitle">
                <?php echo count($manga_ids); ?> manga traduse
            </p>
        </div>
        
        <?php if (!empty($manga_ids)): ?>
            <div class="manga-grid">
                <?php foreach ($manga_ids as $manga_id): ?>
                    <?php 
                    $manga = get_post($manga_id);
                    if (!$manga) continue;
                    ?>
                    <div class="manga-card">
                        <div class="manga-cover-wrapper">
                            <a href="<?php echo get_permalink($manga_id); ?>">
                                  <img src="<?php echo esc_url(get_the_post_thumbnail_url($manga_id, 'full')); ?>" 
                                     alt="<?php echo esc_attr($manga->post_title); ?>"
                                     class="manga-cover-image"
                                     loading="lazy" decoding="async">
                            </a>
                        </div>
                        <h3 class="manga-card-title">
                            <a href="<?php echo get_permalink($manga_id); ?>">
                                <?php echo esc_html($manga->post_title); ?>
                            </a>
                        </h3>
                        
                        <div class="manga-card-chapters">
                            <strong>Capitole traduse:</strong>
                            <?php
                            // Get chapters for this manga by this translator
                            $manga_chapters = new WP_Query([
                                'post_type' => 'chapter',
                                'posts_per_page' => -1,
                                'meta_query' => [
                                    [
                                        'key' => '_manga_id',
                                        'value' => $manga_id,
                                        'compare' => '='
                                    ],
                                    [
                                        'key' => '_translation_group',
                                        'value' => $translator_group,
                                        'compare' => '='
                                    ]
                                ],
                                'orderby' => 'meta_value_num',
                                'meta_key' => '_chapter_number',
                                'order' => 'ASC'
                            ]);
                            
                            $chapter_numbers = [];
                            if ($manga_chapters->have_posts()) {
                                while ($manga_chapters->have_posts()) {
                                    $manga_chapters->the_post();
                                    $chapter_num = mangayummy_get_chapter_number(get_the_ID());
                                    if ($chapter_num) {
                                        $chapter_numbers[] = $chapter_num;
                                    }
                                }
                            }
                            wp_reset_postdata();
                            
                            echo esc_html(implode(', ', $chapter_numbers));
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-manga-found">
                <p>Nu s-au găsit manga traduse de <?php echo esc_html($translator_group); ?>.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
.translator-group-page {
    background-color: #1a1a1a;
    padding: 40px 20px;
    min-height: calc(100vh - 200px);
}

.translator-container {
    max-width: 1200px;
    margin: 0 auto;
}

.translator-header {
    margin-bottom: 40px;
    text-align: center;
}

.translator-title {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    font-size: 32px;
    font-weight: 700;
    color: #fff;
    margin-bottom: 8px;
}

.translator-header-icon {
    color: #4a9eff;
    stroke: currentColor;
}

.translator-subtitle {
    font-size: 16px;
    color: #999;
    margin: 0;
}

.manga-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 24px;
    margin-bottom: 40px;
}

.manga-card {
    background: #2a2a2a;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #444;
    transition: all 0.3s;
}

.manga-card:hover {
    background: #333;
    border-color: #4a9eff;
    transform: translateY(-4px);
    box-shadow: 0 8px 16px rgba(74, 158, 255, 0.2);
}

.manga-cover-wrapper {
    position: relative;
    padding-bottom: 150%;
    overflow: hidden;
}

.manga-cover-wrapper a {
    position: absolute;
    inset: 0;
    display: block;
}

.manga-cover-image {
    width: 100%;
    height: 100%;
    
    transition: transform 0.3s;
}

.manga-card:hover .manga-cover-image {
    transform: scale(1.05);
}

.manga-card-title {
    padding: 12px;
    margin: 0;
    font-size: 14px;
    font-weight: 600;
    color: #fff;
    min-height: 40px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #3a3a3a;
}

.manga-card-title a {
    color: #fff;
    text-decoration: none;
}

.manga-card-title a:hover {
    color: #4a9eff;
}

.manga-card-chapters {
    padding: 12px;
    font-size: 12px;
    color: #ddd;
    line-height: 1.6;
}

.manga-card-chapters strong {
    color: #4a9eff;
    display: block;
    margin-bottom: 4px;
}

.translator-seo-content {
    margin: 30px 0;
    padding: 20px;
    background: #1a1a1a;
    border-radius: 8px;
    border-left: 4px solid #13667a;
}

.translator-seo-content p {
    margin: 0 0 15px 0;
    line-height: 1.6;
    color: #ddd;
    font-size: 16px;
}

.translator-seo-content p:last-child {
    margin-bottom: 0;
}

.translator-seo-content h2 {
    margin: 0 0 20px 0;
    color: #13667a;
    font-size: 24px;
    font-weight: 600;
}

.no-manga-found {
    text-align: center;
    padding: 60px 20px;
    color: #999;
}

.no-manga-found p {
    font-size: 16px;
    margin: 0;
}

    .manga-grid {
        grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
        gap: 16px;
    }
}

/* Translator Groups List Styles */
.translator-groups-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.translator-list-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background: #0f0f0f;
    color: #fff;
}

.translator-list-page h2 {
    color: #13667a;
    font-size: 2em;
    margin-bottom: 20px;
    text-align: center;
}

.translator-seo-content {
    background: #1a1a1a;
    padding: 20px;
    border-radius: 8px;
    margin: 20px 0;
    border-left: 4px solid #13667a;
}

.translator-seo-content p {
    margin: 10px 0;
    line-height: 1.6;
    color: #ccc;
}

.translator-list-page h1 {
    color: #13667a;
    text-align: center;
    margin: 30px 0 10px 0;
}

.translator-list-page > p {
    text-align: center;
    color: #ccc;
    margin-bottom: 30px;
}

.translator-group-card {
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 8px;
    padding: 20px;
    transition: all 0.3s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.translator-group-card:hover {
    border-color: #13667a;
    box-shadow: 0 4px 16px rgba(3, 199, 90, 0.2);
    transform: translateY(-2px);
}

.translator-group-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.translator-group-name {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
}

.translator-group-name a {
    color: #13667a;
    text-decoration: none;
    transition: color 0.3s ease;
}

.translator-group-name a:hover {
    color: #02a84a;
    text-decoration: underline;
}

.translator-group-stats {
    text-align: right;
}

.manga-count {
    background: #13667a;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

.translator-group-description {
    color: #ccc;
    font-size: 14px;
    line-height: 1.4;
}

.no-translator-groups {
    text-align: center;
    padding: 40px;
    color: #666;
}

@media (max-width: 768px) {
    .translator-groups-grid {
        grid-template-columns: 1fr;
        gap: 16px;
    }
    
    .translator-group-card {
        padding: 16px;
    }
    
    .translator-group-header {
        flex-direction: column;
        gap: 8px;
    }
    
</main>

<?php get_footer(); ?>

