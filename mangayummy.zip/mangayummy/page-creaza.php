<?php
/**
 * Template Name: Creează Știre
 */
get_header();

if (!is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

$edit_post_id = intval($_GET['post_id'] ?? 0);
$edit_post = null;
$selected_category = '';
$cover_url = '';
$video_url = '';
$rezumat = '';
$titlu = '';
$continut = '';
$submit_button_text = 'Trimite spre verificare';
$page_title = 'Adaugă știre (Încă în testare)';
$edit_mode = false;

if ($edit_post_id > 0) {
    $edit_post = get_post($edit_post_id);
    if ($edit_post && $edit_post->post_type === 'stire' && mangayummy_user_can_edit_stire($edit_post_id)) {
        $edit_mode = true;
        $submit_button_text = 'Salvează modificările';
        $page_title = 'Editează știre';
        $titlu = get_the_title($edit_post_id);
        $rezumat = get_post_field('post_excerpt', $edit_post_id);
        $continut = get_post_field('post_content', $edit_post_id);
        $cover_url = get_post_meta($edit_post_id, '_stire_cover_url', true);
        $video_url = get_post_meta($edit_post_id, '_stire_youtube_url', true);
        $terms = get_the_terms($edit_post_id, 'stiri_category');
        if ($terms && !is_wp_error($terms) && !empty($terms)) {
            $selected_category = $terms[0]->slug;
        }
    } else {
        $edit_post_id = 0;
    }
}
?>

<main class="creaza-page" id="main-page">
    <div class="creaza-container">
        <div class="creaza-header">
            <a href="<?php echo esc_url(home_url('/news')); ?>" class="creaza-back-btn">
                <i class="fa fa-arrow-left"></i> Înapoi la știri
            </a>
            <h1 class="creaza-title"><i class="fa fa-plus-circle"></i> <?php echo esc_html($page_title); ?></h1>
        </div>

        <form id="creaza-stire-form" class="creaza-form">
            <?php wp_nonce_field('mangayummy_submit_stire_nonce', 'stire_nonce'); ?>
            <input type="hidden" id="stire-post-id" name="stire_post_id" value="<?php echo esc_attr($edit_post_id); ?>">

            <div class="creaza-field">
                <label for="stire-titlu" class="creaza-label">Titlu <span class="required">*</span></label>
                <input type="text" id="stire-titlu" name="stire_titlu" class="creaza-input" placeholder="Titlul știrii..." maxlength="200" required value="<?php echo esc_attr($titlu); ?>">
                <small class="creaza-char-count" id="titlu-count"><?php echo mb_strlen($titlu); ?>/200</small>
            </div>

            <div class="creaza-field">
                <label for="stire-continut" class="creaza-label">Conținut <span class="required">*</span></label>
                <div class="creaza-editor-toolbar">
                    <button type="button" class="editor-btn" data-cmd="bold" title="Bold"><i class="fa fa-bold"></i></button>
                    <button type="button" class="editor-btn" data-cmd="italic" title="Italic"><i class="fa fa-italic"></i></button>
                    <button type="button" class="editor-btn" data-cmd="underline" title="Underline"><i class="fa fa-underline"></i></button>
                    <button type="button" class="editor-btn" data-cmd="strikeThrough" title="Strikethrough"><i class="fa fa-strikethrough"></i></button>
                    <span class="toolbar-sep"></span>
                    <button type="button" class="editor-btn" data-cmd="insertUnorderedList" title="Listă"><i class="fa fa-list-ul"></i></button>
                    <button type="button" class="editor-btn" data-cmd="insertOrderedList" title="Listă numerotată"><i class="fa fa-list-ol"></i></button>
                    <span class="toolbar-sep"></span>
                    <button type="button" class="editor-btn" data-cmd="formatBlock" data-val="H2" title="Titlu"><i class="fa fa-header"></i></button>
                    <button type="button" class="editor-btn" data-cmd="formatBlock" data-val="BLOCKQUOTE" title="Citat"><i class="fa fa-quote-left"></i></button>
                    <span class="toolbar-sep"></span>
                    <button type="button" class="editor-btn" id="link-btn" title="Link"><i class="fa fa-link"></i></button>
                    <button type="button" class="editor-btn" id="img-btn" title="Imagine URL"><i class="fa fa-image"></i></button>
                </div>
                <div id="stire-editor" class="creaza-editor" contenteditable="true" data-placeholder="Scrie conținutul știrii..."><?php echo wp_kses_post($continut); ?></div>
                <small class="creaza-char-count" id="editor-count"><?php echo mb_strlen(wp_strip_all_tags($continut)); ?> caractere</small>
            </div>

            <div class="creaza-field">
                <label for="stire-video-url" class="creaza-label">Video YouTube <span class="sub">(URL, opțional)</span></label>
                <input type="url" id="stire-video-url" name="stire_video_url" class="creaza-input" placeholder="https://www.youtube.com/watch?v=..." value="<?php echo esc_url($video_url); ?>">
                <small class="creaza-char-count">Va fi afișat ca embed pe pagina știrii.</small>
            </div>

            <div class="creaza-field">
                <label for="stire-cover-url" class="creaza-label">Imagine copertă <span class="sub">(URL, opțional)</span></label>
                <input type="url" id="stire-cover-url" name="stire_cover_url" class="creaza-input" placeholder="https://..." value="<?php echo esc_url($cover_url); ?>">
                <div id="cover-preview" class="cover-preview" style="display:<?php echo $cover_url ? 'block' : 'none'; ?>;">
                    <img id="cover-preview-img" src="<?php echo esc_url($cover_url); ?>" alt="Preview" />
                </div>
            </div>

            <div class="creaza-field">
                <label for="stire-rezumat" class="creaza-label">Rezumat <span class="sub">(opțional — max 300 caractere)</span></label>
                <textarea id="stire-rezumat" name="stire_rezumat" class="creaza-textarea" placeholder="Un scurt rezumat al știrii..." rows="3" maxlength="300"><?php echo esc_textarea($rezumat); ?></textarea>
                <small class="creaza-char-count" id="rezumat-count"><?php echo mb_strlen($rezumat); ?>/300</small>
            </div>

            <div class="creaza-field">
                <label class="creaza-label">Categorie</label>
                <div class="creaza-category-btns">
                    <button type="button" class="cat-btn<?php echo $selected_category === '' ? ' active' : ''; ?>" data-cat="">All</button>
                    <button type="button" class="cat-btn<?php echo $selected_category === 'site' ? ' active' : ''; ?>" data-cat="site">Site</button>
                    <button type="button" class="cat-btn<?php echo $selected_category === 'anime' ? ' active' : ''; ?>" data-cat="anime">Anime</button>
                    <button type="button" class="cat-btn<?php echo $selected_category === 'manga' ? ' active' : ''; ?>" data-cat="manga">Manga</button>
                </div>
                <input type="hidden" id="stire-category" name="stire_category" value="<?php echo esc_attr($selected_category); ?>">
            </div>

            <div id="stire-message" class="stire-message" style="display:none;"></div>

            <div class="creaza-actions">
                <button type="submit" class="btn-submit-stire" id="submit-stire-btn" data-default-label="<?php echo esc_attr($submit_button_text); ?>">
                    <i class="fa fa-paper-plane"></i> <?php echo esc_html($submit_button_text); ?>
                </button>
            </div>
        </form>
    </div>
</main>

<style>
.creaza-page {
    max-width: 820px;
    margin: 30px auto 60px;
    padding: 0 16px;
}
.creaza-container {
    background: var(--head, #1a1a1a);
    border-radius: 20px;
    padding: 32px;
}
.creaza-header {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 28px;
    flex-wrap: wrap;
}
.creaza-back-btn {
    color: #aaa;
    font-size: 13px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: color 0.2s;
}
.creaza-back-btn:hover { color: #fff; }
.creaza-title {
    margin: 0;
    font-size: 1.4rem;
    font-weight: 800;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 10px;
}
.creaza-title i { color: #13667a; }
.creaza-form { display: flex; flex-direction: column; gap: 22px; }
.creaza-field { display: flex; flex-direction: column; gap: 8px; }
.creaza-label {
    color: #ccc;
    font-size: 14px;
    font-weight: 600;
}
.creaza-label .required { color: #13667a; }
.creaza-label .sub { color: #777; font-weight: 400; font-size: 12px; }
.creaza-input, .creaza-textarea {
    background: #0f0f0f;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    font-size: 14px;
    font-family: inherit;
    padding: 12px 14px;
    transition: border-color 0.2s;
    outline: none;
}
.creaza-input:focus, .creaza-textarea:focus { border-color: #13667a; }
.creaza-textarea { resize: vertical; min-height: 80px; }
.creaza-char-count { color: #666; font-size: 11px; align-self: flex-end; }

/* Editor */
.creaza-editor-toolbar {
    background: #111;
    border: 1px solid #333;
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    padding: 8px 10px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 4px;
}
.editor-btn {
    background: none;
    border: none;
    color: #ccc;
    cursor: pointer;
    padding: 5px 8px;
    border-radius: 5px;
    font-size: 13px;
    transition: background 0.15s, color 0.15s;
}
.editor-btn:hover { background: #222; color: #fff; }
.editor-btn.active { background: #13667a22; color: #13667a; }
.toolbar-sep { width: 1px; height: 18px; background: #333; margin: 0 4px; }
.creaza-editor {
    background: #0f0f0f;
    border: 1px solid #333;
    border-radius: 0 0 8px 8px;
    color: #f2f2f2;
    font-size: 15px;
    font-family: inherit;
    line-height: 1.8;
    min-height: 260px;
    padding: 14px;
    outline: none;
    transition: border-color 0.2s;
    word-break: break-word;
}
.creaza-editor:focus { border-color: #13667a; }
.creaza-editor:empty:before {
    content: attr(data-placeholder);
    color: #555;
    pointer-events: none;
}
.creaza-editor blockquote {
    border-left: 3px solid #13667a;
    margin: 10px 0;
    padding-left: 14px;
    color: #bbb;
}
.creaza-editor h2 { font-size: 1.2rem; margin: 12px 0 6px; color: #fff; }
.creaza-editor a { color: #13667a; }
.creaza-editor img { max-width: 100%; border-radius: 8px; margin: 8px 0; display: block; }

/* Category buttons */
.creaza-category-btns { display: flex; gap: 8px; flex-wrap: wrap; }
.cat-btn {
    background: #0f0f0f;
    border: 1px solid #333;
    color: #ccc;
    padding: 7px 18px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s;
}
.cat-btn:hover { border-color: #13667a; color: #13667a; }
.cat-btn.active { background: #13667a22; border-color: #13667a; color: #13667a; }

/* Cover preview */
.cover-preview {
    margin-top: 8px;
    border-radius: 10px;
    overflow: hidden;
    max-height: 220px;
}
.cover-preview img {
    width: 100%;
    height: 220px;
    object-fit: cover;
    display: block;
}

/* Message */
.stire-message {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.stire-message.success { background: #13667a22; border: 1px solid #13667a55; color: #13667a; }
.stire-message.error { background: #13667a22; border: 1px solid #13667a55; color: #ff6b6b; }

/* Submit */
.creaza-actions { display: flex; justify-content: flex-end; }
.btn-submit-stire {
    background: #13667a;
    color: #fff;
    border: none;
    padding: 12px 28px;
    border-radius: 999px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background 0.2s;
}
.btn-submit-stire:hover:not(:disabled) { background: #fa8e90; }
.btn-submit-stire:disabled { opacity: 0.6; cursor: not-allowed; }

@media (max-width: 600px) {
    .creaza-container { padding: 20px 16px; }
    .creaza-header { flex-direction: column; align-items: flex-start; gap: 10px; }
}
</style>

<script>
(function() {
document.addEventListener('DOMContentLoaded', function() {

    const form       = document.getElementById('creaza-stire-form');
    const submitBtn  = document.getElementById('submit-stire-btn');
    const msgDiv     = document.getElementById('stire-message');
    const editor     = document.getElementById('stire-editor');
    const titluInput = document.getElementById('stire-titlu');
    const rezumatInput = document.getElementById('stire-rezumat');
    const coverInput = document.getElementById('stire-cover-url');
    const videoInput = document.getElementById('stire-video-url');
    const catInput   = document.getElementById('stire-category');
    const postIdInput = document.getElementById('stire-post-id');
    const defaultButtonLabel = submitBtn.dataset.defaultLabel || submitBtn.textContent.trim();
    const editMode = <?php echo $edit_mode ? 'true' : 'false'; ?>;

    const coverPreview = document.getElementById('cover-preview');
    const coverPreviewImg = document.getElementById('cover-preview-img');

    if (coverInput.value.trim()) {
        coverPreview.style.display = 'block';
        coverPreviewImg.src = coverInput.value.trim();
    }

    // -- Character counters --
    titluInput.addEventListener('input', function() {
        document.getElementById('titlu-count').textContent = this.value.length + '/200';
    });
    rezumatInput.addEventListener('input', function() {
        document.getElementById('rezumat-count').textContent = this.value.length + '/300';
    });
    editor.addEventListener('input', function() {
        document.getElementById('editor-count').textContent = (this.innerText.trim().length) + ' caractere';
    });

    // -- Toolbar buttons --
    document.querySelectorAll('.editor-btn[data-cmd]').forEach(function(btn) {
        btn.addEventListener('mousedown', function(e) {
            e.preventDefault();
            const cmd = this.dataset.cmd;
            const val = this.dataset.val || null;
            document.execCommand(cmd, false, val);
            editor.focus();
        });
    });

    document.getElementById('link-btn').addEventListener('mousedown', function(e) {
        e.preventDefault();
        const url = prompt('Introdu URL-ul link-ului:');
        if (url) {
            document.execCommand('createLink', false, url);
        }
        editor.focus();
    });

    document.getElementById('img-btn').addEventListener('mousedown', function(e) {
        e.preventDefault();
        const url = prompt('Introdu URL-ul imaginii:');
        if (url) {
            document.execCommand('insertImage', false, url);
        }
        editor.focus();
    });

    // -- Category buttons --
    document.querySelectorAll('.cat-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            catInput.value = this.dataset.cat;
        });
    });

    // -- Cover image preview --
    coverInput.addEventListener('input', function() {
        const url = this.value.trim();
        const preview = document.getElementById('cover-preview');
        const img = document.getElementById('cover-preview-img');
        if (url) {
            img.src = url;
            img.onload = function() { preview.style.display = 'block'; };
            img.onerror = function() { preview.style.display = 'none'; };
        } else {
            preview.style.display = 'none';
        }
    });

    // -- Submit --
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const titlu = titluInput.value.trim();
        const continut = editor.innerHTML.trim();
        const rezumat = rezumatInput.value.trim();
        const category = catInput.value;
        const coverUrl = coverInput.value.trim();
        const videoUrl = videoInput.value.trim();

        if (!titlu) {
            showMsg('Titlul este obligatoriu.', 'error');
            return;
        }
        if (!continut || editor.innerText.trim().length < 10) {
            showMsg('Conținutul trebuie să aibă cel puțin 10 caractere.', 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Se trimite...';

        const nonce = document.querySelector('input[name="stire_nonce"]').value;
        const fd = new FormData();
        fd.append('action', 'mangayummy_submit_stire');
        fd.append('nonce', nonce);
        fd.append('titlu', titlu);
        fd.append('continut', continut);
        fd.append('rezumat', rezumat);
        fd.append('category', category);
        fd.append('cover_url', coverUrl);
        fd.append('video_url', videoUrl);
        if (postIdInput && postIdInput.value) {
            fd.append('post_id', postIdInput.value);
        }

        fetch(ya_ajax.ajax_url, { method: 'POST', credentials: 'same-origin', body: fd })
            .then(r => r.json())
            .then(function(data) {
                if (data.success) {
                    showMsg('<i class="fa fa-check"></i> ' + (data.data.message || 'Știrea a fost trimisă spre verificare!'), 'success');
                    if (!editMode) {
                        form.reset();
                        editor.innerHTML = '';
                        coverPreview.style.display = 'none';
                        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
                        document.querySelector('.cat-btn[data-cat=""]').classList.add('active');
                        videoInput.value = '';
                    }
                } else {
                    showMsg(data.data || 'Eroare la trimitere.', 'error');
                }
            })
            .catch(function() {
                showMsg('Eroare la conexiune.', 'error');
            })
            .finally(function() {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fa fa-paper-plane"></i> ' + defaultButtonLabel;
            });
    });

    function showMsg(text, type) {
        msgDiv.style.display = 'flex';
        msgDiv.className = 'stire-message ' + type;
        msgDiv.innerHTML = text;
        msgDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
});
})();
</script>

<?php get_footer(); ?>
