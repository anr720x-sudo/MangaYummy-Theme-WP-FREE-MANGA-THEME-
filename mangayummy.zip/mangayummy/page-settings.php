<?php
/**
 * Settings Page Template
 * URL: /settings
 * Access: Logged-in users only
 */

// Disable caching for settings pages
if (!defined('DONOTCACHEPAGE')) {
    define('DONOTCACHEPAGE', true);
}
nocache_headers();

$is_embed_settings = (isset($_GET['ya_embed']) && $_GET['ya_embed'] === '1');

// Fallback: if request is loaded in an iframe, treat it as embed mode too.
// Some caches/CDN rules may strip query args and would otherwise trigger redirects.
if (!$is_embed_settings) {
    $fetch_dest = isset($_SERVER['HTTP_SEC_FETCH_DEST']) ? strtolower((string) $_SERVER['HTTP_SEC_FETCH_DEST']) : '';
    if ($fetch_dest === 'iframe') {
        $is_embed_settings = true;
    }
}

// Redirect to login if not logged in
if (!is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

// Keep settings available only as embedded modal content.
if (!$is_embed_settings) {
    wp_redirect(home_url('/#settings'));
    exit;
}

// In embed mode, we still need wp_head/wp_footer so settings CSS/JS are printed.
if ($is_embed_settings) {
    wp_head();
}



$user_id = get_current_user_id();
$user = get_user_by('ID', $user_id);
$current_avatar = get_user_meta($user_id, 'profile_avatar', true);
$current_avatar = !empty($current_avatar) ? $current_avatar : false;
$current_banner = get_user_meta($user_id, 'profile_banner', true);
$current_banner = !empty($current_banner) ? $current_banner : false;

?>

<main class="settings-page<?php echo $is_embed_settings ? ' settings-page--embed' : ''; ?>">
    <div class="settings-wrapper" data-user-id="<?php echo $user_id; ?>">
        <?php if (!$is_embed_settings): ?>
        <!-- Header -->
        <div class="settings-header">
            <h1>Settings</h1>
            <p class="settings-subtitle">Manage your account and preferences</p>
        </div>
        <?php endif; ?>

        <!-- Settings Container -->
        <div class="settings-container">
            <!-- Settings Tabs Navigation -->
            <div class="settings-tabs">
                <button type="button" class="tab-button active" data-tab="general">
                    <span class="tab-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg></span>
                    <span>General</span>
                </button>
                <button type="button" class="tab-button" data-tab="security">
                    <span class="tab-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="16" r="1" fill="currentColor"/><path d="M7 11V7a5 5 0 0110 0v4" stroke="currentColor" stroke-width="2"/></svg></span>
                    <span>Security</span>
                </button>
                <button type="button" class="tab-button" data-tab="appearance">
                    <span class="tab-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.828 14.828a4 4 0 01-5.656 0l-4-4A4 4 0 116.343 3.172l4 4a4 4 0 015.656 5.656z" stroke="currentColor" stroke-width="2"/><path d="M9 9l6 6" stroke="currentColor" stroke-width="2"/><circle cx="9" cy="9" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/></svg></span>
                    <span>Appearance</span>
                </button>
                <button type="button" class="tab-button" data-tab="preferences">
                    <span class="tab-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 5h16v2H4z" stroke="currentColor" stroke-width="2"/><path d="M4 11h16v2H4z" stroke="currentColor" stroke-width="2"/><path d="M4 17h16v2H4z" stroke="currentColor" stroke-width="2"/></svg></span>
                    <span>Preferences</span>
                </button>
            </div>

            <!-- Settings Content -->
            <div class="settings-content">
                <!-- General Settings -->
                <div class="profile-tab active" id="general-tab">
                    <h3>General Settings</h3>
                    
                     <!-- Username -->
                    <div class="setting-group">
                        <label for="username-input" class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span>Username</label>
                        <div class="username-validator">
                            <div class="username-input-wrapper">
                                <input type="text" id="username-input" value="<?php echo esc_attr($user->display_name); ?>" class="setting-input username-input" placeholder="Enter a unique name (3-20 characters)" maxlength="20" autocomplete="off" spellcheck="false">
                                <div id="username-status" class="username-status">
                                    <span class="status-icon"></span>
                                </div>
                            </div>
                            <div id="username-message" class="username-message">
                                <span class="message-text"></span>
                            </div>
                            <div class="username-requirements">
                                <div class="requirement">
                                    <span class="req-icon" id="req-length">○</span>
                                    <span class="req-text">Minimum 3 characters</span>
                                </div>
                                <div class="requirement">
                                    <span class="req-icon" id="req-unique">○</span>
                                    <span class="req-text">Unique name on the server</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Birthday -->
                    <div class="setting-group">
                        <label for="birthday-input" class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg></span>Date of Birth</label>
                        <?php 
                        $birthday_value = get_user_meta($user_id, 'birthday', true);
                        if (empty($birthday_value)) {
                            $birthday_value = get_user_meta($user_id, 'user_birthday', true);
                        }
                        if (empty($birthday_value)) {
                            $birthday_value = get_user_meta($user_id, 'profile_birthday', true);
                        }
                        if (empty($birthday_value)) {
                            $birthday_value = get_user_meta($user_id, 'birthdate', true);
                        }
                        ?>
                        <input type="date" id="birthday-input" value="<?php echo esc_attr($birthday_value); ?>" class="setting-input" autocomplete="off">
                    </div>

                    <!-- Gender -->
                    <div class="setting-group">
                        <label for="gender-select" class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"/><path d="M12 7V3m0 18v-4M7 12H3m18 0h-4M16.24 7.76l2.83-2.83M4.93 19.07l2.83-2.83M16.24 16.24l2.83 2.83M4.93 4.93l2.83 2.83"/></svg></span>Gender</label>
                        <?php 
                        $gender_value = mangayummy_get_user_gender($user_id);
                        ?>
                        <div class="segmented-control" role="group" aria-label="Select gender">
                            <button type="button" class="segmented-option<?php echo $gender_value === 'masculin' ? ' active' : ''; ?>" data-value="masculin">Male</button>
                            <button type="button" class="segmented-option<?php echo $gender_value === 'feminin' ? ' active' : ''; ?>" data-value="feminin">Female</button>
                            <button type="button" class="segmented-option<?php echo empty($gender_value) ? ' active' : ''; ?>" data-value="">Not defined</button>
                        </div>
                        <select id="gender-select" class="setting-input visually-hidden">
                            <option value="" <?php selected($gender_value, ''); ?>>Not defined</option>
                            <option value="masculin" <?php selected($gender_value, 'masculin'); ?>>Male</option>
                            <option value="feminin" <?php selected($gender_value, 'feminin'); ?>>Female</option>
                        </select>
                    </div>

                    <!-- Avatar Upload -->
                    <div class="setting-group">
                        <label class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></span>Profile Picture</label>
                        <div class="profile-image-upload">
                            <input type="file" id="avatar-file-input" accept="image/jpeg,image/png,image/webp<?php if (get_user_meta($user_id, 'user_group', true)): ?>,image/gif<?php endif; ?>" style="display: none;">
                            <div class="upload-controls">
                                <button type="button" id="avatar-upload-btn" class="btn-secondary"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg> Choose file</button>
                                <button type="button" id="avatar-remove-btn" class="btn-danger-outline" aria-label="Remove profile picture" <?php echo !$current_avatar ? 'style="display:none;"' : ''; ?>><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><path d="M16.3 2.34h-3.12l-.34-1.14c-.1-.35-.3-.65-.57-.87-.26-.21-.59-.33-.93-.33H8.66c-.33 0-.66.12-.93.33-.26.22-.46.52-.57.87l-.34 1.14H3.7c-.87 0-1.58.8-1.58 1.76v1.17c0 .66.53.59 1.1.59h14.13c.3 0 .53-.26.53-.59V4.1c0-.97-.7-1.76-1.58-1.76Zm-8.37 0 .23-.77c.03-.11.1-.22.2-.29a.5.5 0 01.3-.1h2.7c.21 0 .41.15.5.4l.21.76H7.93ZM3.3 7.11l.84 11.3c.03.43.21.84.5 1.13.3.3.67.46 1.07.46h8.58c.4 0 .78-.16 1.07-.46.3-.3.47-.7.5-1.14l.84-11.3H3.3v.01Zm4.07 9.96a.53.53 0 01-1.05 0v-8.2a.53.53 0 011.05 0v8.2Zm3.16 0a.53.53 0 11-1.06 0v-8.2a.53.53 0 011.06 0v8.2Zm3.15 0a.53.53 0 01-1.05 0v-8.2c0-.16.05-.3.15-.42a.5.5 0 01.37-.17.5.5 0 0 1 .37.17c.1.11.16.26.16.42v8.2Z" transform="translate(0, 0)"></path></svg></button>
                            </div>
                        </div>
                    </div>

                    <!-- Banner Upload -->
                    <div class="setting-group">
                        <label class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2" ry="2"/><path d="M3 9h18"/></svg></span>Profile Banner</label>
                        <div class="profile-image-upload banner-upload">
                            <input type="file" id="banner-file-input" accept="image/jpeg,image/png,image/webp<?php if (get_user_meta($user_id, 'user_group', true)): ?>,image/gif<?php endif; ?>" style="display: none;">
                            <div class="upload-controls">
                                <button type="button" id="banner-upload-btn" class="btn-secondary"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg> Choose file</button>
                                <button type="button" id="banner-remove-btn" class="btn-danger-outline" aria-label="Remove banner" <?php echo !$current_banner ? 'style="display:none;"' : ''; ?>><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><path d="M16.3 2.34h-3.12l-.34-1.14c-.1-.35-.3-.65-.57-.87-.26-.21-.59-.33-.93-.33H8.66c-.33 0-.66.12-.93.33-.26.22-.46.52-.57.87l-.34 1.14H3.7c-.87 0-1.58.8-1.58 1.76v1.17c0 .66.53.59 1.1.59h14.13c.3 0 .53-.26.53-.59V4.1c0-.97-.7-1.76-1.58-1.76Zm-8.37 0 .23-.77c.03-.11.1-.22.2-.29a.5.5 0 01.3-.1h2.7c.21 0 .41.15.5.4l.21.76H7.93ZM3.3 7.11l.84 11.3c.03.43.21.84.5 1.13.3.3.67.46 1.07.46h8.58c.4 0 .78-.16 1.07-.46.3-.3.47-.7.5-1.14l.84-11.3H3.3v.01Zm4.07 9.96a.53.53 0 01-1.05 0v-8.2a.53.53 0 011.05 0v8.2Zm3.16 0a.53.53 0 11-1.06 0v-8.2a.53.53 0 011.06 0v8.2Zm3.15 0a.53.53 0 01-1.05 0v-8.2c0-.16.05-.3.15-.42a.5.5 0 01.37-.17.5.5 0 0 1 .37.17c.1.11.16.26.16.42v8.2Z" transform="translate(0, 0)"></path></svg></button>
                            </div>
                        </div>
                    </div>

                    <!-- Bio -->
                    <div class="setting-group">
                        <label for="bio-textarea" class="setting-label"><span class="setting-label-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v10z"/></svg></span>Bio / About</label>
                        <textarea id="bio-textarea" class="setting-textarea" rows="4" placeholder="Tell us something about yourself..." autocomplete="off" spellcheck="false" maxlength="2000"><?php echo esc_textarea(get_user_meta($user_id, 'bio', true)); ?></textarea>
                    </div>

                    <!-- Discord Connection -->
                    <div class="setting-group">
                        <?php
                        $discord_id = get_user_meta($user_id, 'discord_id', true);
                        if (!empty($discord_id)):
                        ?>
                        <div class="discord-connected-box">
                            <span class="discord-connected-status">
                                <svg width="18" height="14" viewBox="0 0 127.14 96.36" fill="#5865F2"><path d="M107.7 8.07A105.15 105.15 0 0 0 81.47 0a72.06 72.06 0 0 0-3.36 6.83 97.68 97.68 0 0 0-29.11 0A72.37 72.37 0 0 0 45.64 0a105.89 105.89 0 0 0-26.25 8.09C2.79 32.65-1.71 56.6.54 80.21a105.73 105.73 0 0 0 32.17 16.15 77.7 77.7 0 0 0 6.89-11.11 68.42 68.42 0 0 1-10.85-5.18c.91-.66 1.8-1.34 2.66-2a75.57 75.57 0 0 0 64.32 0c.87.71 1.76 1.39 2.66 2a68.68 68.68 0 0 1-10.87 5.19 77 77 0 0 0 6.89 11.1 105.25 105.25 0 0 0 32.19-16.14c2.64-27.38-4.51-51.11-18.9-72.15zM42.45 65.69C36.18 65.69 31 60 31 53s5-12.74 11.43-12.74S54 46 53.89 53s-5.05 12.69-11.44 12.69zm42.24 0C78.41 65.69 73.25 60 73.25 53s5-12.74 11.44-12.74S96.23 46 96.12 53s-5.04 12.69-11.43 12.69z"/></svg>
                                Discord account connected
                            </span>
                            <button type="button" id="discord-disconnect-btn" class="btn-danger-outline"
                                data-nonce="<?php echo esc_attr(wp_create_nonce('ya_ajax_nonce')); ?>">
                                Disconnect
                            </button>
                        </div>
                        <?php elseif (!empty(DISCORD_CLIENT_ID)): ?>
                        <?php
                            $dc_state = wp_generate_password(32, false);
                            set_transient('discord_oauth_state_' . $dc_state, 1, 10 * MINUTE_IN_SECONDS);
                            $dc_connect_url = 'https://discord.com/oauth2/authorize?' . http_build_query([
                                'client_id'     => DISCORD_CLIENT_ID,
                                'redirect_uri'  => home_url('/?discord_oauth=1'),
                                'response_type' => 'code',
                                'scope'         => 'identify email',
                                'state'         => $dc_state,
                                'prompt'        => 'none',
                            ]);
                        ?>
                        <a href="<?php echo esc_url($dc_connect_url); ?>" class="btn-discord-connect">
                            <svg width="18" height="14" viewBox="0 0 127.14 96.36" fill="currentColor"><path d="M107.7 8.07A105.15 105.15 0 0 0 81.47 0a72.06 72.06 0 0 0-3.36 6.83 97.68 97.68 0 0 0-29.11 0A72.37 72.37 0 0 0 45.64 0a105.89 105.89 0 0 0-26.25 8.09C2.79 32.65-1.71 56.6.54 80.21a105.73 105.73 0 0 0 32.17 16.15 77.7 77.7 0 0 0 6.89-11.11 68.42 68.42 0 0 1-10.85-5.18c.91-.66 1.8-1.34 2.66-2a75.57 75.57 0 0 0 64.32 0c.87.71 1.76 1.39 2.66 2a68.68 68.68 0 0 1-10.87 5.19 77 77 0 0 0 6.89 11.1 105.25 105.25 0 0 0 32.19-16.14c2.64-27.38-4.51-51.11-18.9-72.15zM42.45 65.69C36.18 65.69 31 60 31 53s5-12.74 11.43-12.74S54 46 53.89 53s-5.05 12.69-11.44 12.69zm42.24 0C78.41 65.69 73.25 60 73.25 53s5-12.74 11.44-12.74S96.23 46 96.12 53s-5.04 12.69-11.43 12.69z"/></svg>
                            Connect Discord
                        </a>
                        <?php else: ?>
                        <p class="setting-help">Discord OAuth is not configured (constants are missing in wp-config.php).</p>
                        <?php endif; ?>
                        <?php if (isset($_GET['discord_linked']) && $_GET['discord_linked'] === '1'): ?>
                        <p class="discord-linked-success">✅ Discord account connected successfully!</p>
                        <?php endif; ?>
                        <?php if (isset($_GET['discord_error']) && $_GET['discord_error'] === 'already_linked'): ?>
                        <p class="discord-linked-error">⚠️ This Discord account is already connected to another user.</p>
                        <?php endif; ?>
                        <?php if (isset($_GET['discord_error']) && $_GET['discord_error'] === 'discord_email_required_link_existing'): ?>
                        <p class="discord-linked-error">⚠️ Log in normally and connect Discord from settings.</p>
                        <?php endif; ?>

                        <div class="setting-group" id="discord-verification-group">
                            <button type="button" id="generate-discord-verification-link" class="btn-secondary">Generate verification link</button>
                            <div class="discord-verification-link-row" id="discord-verification-row" style="display:none; margin-top:12px; gap:10px; align-items:center;">
                                <input id="discord-verification-link" type="text" readonly class="setting-input" value="" style="flex:1;">
                                <button type="button" id="copy-discord-verification-link" class="btn-secondary">Copy link</button>
                            </div>
                            <p class="setting-help">Press the button to generate a unique Discord verification link. Send it in your Discord ticket for confirmation.</p>
                        </div>
                    </div>

                    <!-- SINGLE SAVE BUTTON AT END -->
                    <div class="setting-group" style="margin-top: 30px; display: flex; gap: 12px;">
                        <button type="button" id="save-all-general-btn" class="btn-primary">Save all</button>
                    </div>
                </div>

                <!-- Security Settings -->
                <div class="profile-tab" id="security-tab">
                    <h3>Security Settings</h3>

                    <!-- Email Change -->
                    <div class="setting-group">
                        <label class="setting-label">Change Email</label>
                        <p class="setting-help">Current email: <strong><?php echo esc_html($user->user_email); ?></strong></p>
                        <div class="security-form">
                            <input type="email" id="new-email-input" placeholder="New email" class="setting-input">
                            <input type="password" id="email-password-confirm" placeholder="Confirm with current password" class="setting-input">
                            <button type="button" id="save-email-btn" class="btn-primary">Change Email</button>
                        </div>
                    </div>

                    <!-- Password Change -->
                    <div class="setting-group">
                        <label class="setting-label">Change Password</label>
                        <div class="security-form">
                            <input type="password" id="current-password-input" placeholder="Current password" class="setting-input">
                            <input type="password" id="new-password-input" placeholder="New password (min. 6 characters)" class="setting-input">
                            <input type="password" id="confirm-password-input" placeholder="Confirm new password" class="setting-input">
                            <button type="button" id="save-password-btn" class="btn-primary">Change Password</button>
                        </div>
                    </div>
                </div>

                <!-- Appearance Settings -->
                <div class="profile-tab" id="appearance-tab">
                    <h3>Appearance Settings</h3>

                    <!-- Level Effect Selector -->
                    <div class="setting-group">
                        <label class="setting-label">Efect Badge Level</label>
                        <p class="setting-help" style="margin-bottom: 15px;">Select the effect for your level badge. You unlock new effects every 50 levels!</p>
                        
                        <?php
                        $user_level = intval(get_user_meta($user_id, 'reader_level', true) ?: 1);
                        $active_effect = mangayummy_get_active_level_effect_key($user_id);
                        $all_effects = mangayummy_get_all_level_effects();
                        ?>
                        
                        <div class="level-effects-grid">
                            <?php foreach ($all_effects as $key => $effect): 
                                $is_unlocked = $user_level >= $effect['unlock'];
                                $is_selected = ($active_effect === $key);
                            ?>
                            <div class="level-effect-option <?php echo $is_unlocked ? 'unlocked' : 'locked'; ?> <?php echo $is_selected ? 'selected' : ''; ?>" 
                                 data-effect="<?php echo esc_attr($key); ?>"
                                 data-unlock="<?php echo esc_attr($effect['unlock']); ?>">
                                <div class="effect-preview">
                                    <span class="effect-badge <?php echo esc_attr($effect['class']); ?>">Level <?php echo $user_level; ?></span>
                                </div>
                                <div class="effect-info">
                                    <span class="effect-name"><?php echo esc_html($effect['name']); ?></span>
                                    <?php if (!$is_unlocked): ?>
                                        <span class="effect-unlock">🔒 Level <?php echo $effect['unlock']; ?>+</span>
                                    <?php else: ?>
                                        <span class="effect-unlocked">✓ Unlocked</span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($is_selected && $is_unlocked): ?>
                                    <div class="effect-selected-badge">✓</div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div id="effect-save-status" class="effect-save-status"></div>
                    </div>

                    <!-- Avatar Frame Effect Selector -->
                    <div class="setting-group">
                        <label class="setting-label">Avatar Frame Effect</label>
                        <p class="setting-help" style="margin-bottom: 15px;">Select the effect for your avatar frame. You unlock new effects every 100 levels!</p>
                        
                        <?php
                        $active_avatar_effect = mangayummy_get_active_avatar_effect_key($user_id);
                        $all_avatar_effects = mangayummy_get_all_avatar_effects();
                        ?>
                        
                        <div class="avatar-effects-grid">
                            <?php foreach ($all_avatar_effects as $key => $effect): 
                                $is_unlocked = $user_level >= $effect['unlock'];
                                $is_selected = ($active_avatar_effect === $key);
                            ?>
                            <div class="avatar-effect-option <?php echo $is_unlocked ? 'unlocked' : 'locked'; ?> <?php echo $is_selected ? 'selected' : ''; ?>" 
                                 data-effect="<?php echo esc_attr($key); ?>"
                                 data-unlock="<?php echo esc_attr($effect['unlock']); ?>">
                                <div class="avatar-effect-preview <?php echo esc_attr($effect['class']); ?>">
                                    <img src="<?php echo esc_url(get_user_meta($user_id, 'profile_avatar', true) ?: get_template_directory_uri() . '/assets/img/default-avatar.png'); ?>" alt="Preview">
                                </div>
                                <div class="effect-info">
                                    <span class="effect-name"><?php echo esc_html($effect['name']); ?></span>
                                    <?php if (!$is_unlocked): ?>
                                        <span class="effect-unlock">🔒 Level <?php echo $effect['unlock']; ?>+</span>
                                    <?php else: ?>
                                        <span class="effect-unlocked">✓ Unlocked</span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($is_selected && $is_unlocked): ?>
                                    <div class="effect-selected-badge">✓</div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div id="avatar-effect-save-status" class="effect-save-status"></div>
                    </div>
                </div>

                <!-- Preferences Settings -->
                <div class="profile-tab" id="preferences-tab">
                    <h3>Content Preferences</h3>
                    <p class="prefs-note" style="margin-bottom:15px;">Check a genre to hide it from search results and general listings.</p>
                    <?php
                    // prepare data using centralized helper (applies defaults even if stored array is empty)
                    $prefs = mangayummy_get_reader_prefs($user_id);
                    // build red genre list same as on single-manga (will compare slugs)
                    $red_genres = array('sângeros','violența sexuală','viol','matur','nuditate','tragedie','sinucidere','masturbare','sex în grup','adult','ecchi','hentai','canibalism','prostituţie','tragedie','smut','yandere','sclavie','anal','droguri');
                    $red_slugs = array_map('sanitize_title', $red_genres);
                    // load all genres ordered by popularity (term count)
                    $genres = get_terms([
                        'taxonomy'   => 'genre',
                        'hide_empty' => false,
                        'orderby'    => 'count',
                        'order'      => 'DESC'
                    ]);
                    ?>
                    <p class="prefs-warning" style="margin-bottom:15px; color:#ffc107;">Warning: this preferences page is under development and bugs may appear.</p>
                    <form id="prefs-form">
                        <fieldset>
                            <legend>Explicit Content</legend>
                            <label><input type="checkbox" name="explicit[]" value="nsfw" <?php checked(in_array('nsfw',$prefs['explicit'] ?? [])); ?>> NSFW (hide when checked)</label><br>
                        </fieldset>
                        <fieldset class="genres-include" style="margin-top:20px;">
                            <legend>Genuri</legend>
                            <?php foreach($genres as $g): ?>
                                <?php
                                    $label_classes = '';
                                    if (in_array($g->slug, $red_slugs, true)) {
                                        $label_classes = 'genre-red';
                                    }
                                ?>
                                <label<?php if($label_classes) echo ' class="'.esc_attr($label_classes).'"'; ?>><input type="checkbox" name="genres[]" value="<?php echo esc_attr($g->slug); ?>" <?php checked(in_array($g->slug, $prefs['genres'] ?? [])); ?>> <span class="genre-name"><?php echo esc_html($g->name); ?></span></label><br>
                            <?php endforeach; ?>
                        </fieldset>
                        <div class="setting-group" style="margin-top:20px;">
                            <button type="submit" class="btn-primary">Save preferences</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</main>

<!-- Image Crop Modal -->
<div id="cropModal" class="crop-modal">
    <div class="crop-modal-content">
        <div class="crop-modal-header">
            <span class="crop-modal-title">Crop image</span>
            <button type="button" class="crop-modal-close">&times;</button>
        </div>
        <div class="crop-container">
            <img id="cropImage" src="" alt="Crop preview">
        </div>
        <div class="crop-modal-actions">
            <button type="button" class="crop-btn crop-btn-cancel">Cancel</button>
            <button type="button" class="crop-btn crop-btn-save">Save</button>
        </div>
    </div>
</div>

<?php
if ($is_embed_settings) {
    wp_footer();
}
