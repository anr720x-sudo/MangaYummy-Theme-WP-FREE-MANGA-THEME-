﻿<?php
// Disable page caching for dynamic content but allow search engine caching
if (!defined('DONOTCACHEPAGE')) {
    define('DONOTCACHEPAGE', true);
}

// SEO: Send Last-Modified header for better crawl efficiency
$post_modified = get_the_modified_time('U');
if ($post_modified) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $post_modified) . ' GMT');
}

// Allow browser caching for short periods (helps with back button)
// Disable cache for logged-in users during development
if (is_user_logged_in()) {
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
} else {
    header('Cache-Control: private, max-age=60');
}

get_header();

$has_giphy_api = function_exists('mangayummy_has_giphy_api_key') ? mangayummy_has_giphy_api_key() : (trim((string) get_option('mangayummy_giphy_api_key', '')) !== '');

// Set cookie when viewing chapter
$chapter_id = get_the_ID();

// Load all meta for this chapter once (avoids repeated get_post_meta calls)
$chapter_meta = get_post_meta($chapter_id);
?>

<script>
// Mark chapter as viewed (for local UI tracking)
(function() {
    const chapterId = <?php echo json_encode($chapter_id); ?>;

    // Set cookie for backwards compatibility (existing logic)
    const cookieName = 'viewed_chapter_' + chapterId;
    const d = new Date();
    d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000)); // 1 year
    const expires = "expires=" + d.toUTCString();
    document.cookie = cookieName + "=1; " + expires + "; path=/";

    // Also store in localStorage so the manga chapter list can mark it as read
    try {
        const key = 'mangayummy_read_chapters';
        const stored = localStorage.getItem(key);
        const list = stored ? JSON.parse(stored) : [];
        if (Array.isArray(list) && !list.includes(chapterId)) {
            list.push(chapterId);
            localStorage.setItem(key, JSON.stringify(list));
        }
    } catch (e) {
        // ignore localStorage errors (private mode, etc.)
    }
})();
</script>

<div class="single-chapter">
    <?php
    $manga_id = intval($chapter_meta['_manga_id'][0] ?? 0);
    $chapter_number_raw = mangayummy_get_chapter_number($chapter_id);
    $chapter_number = $chapter_number_raw !== null ? floatval($chapter_number_raw) : 0;
    $chapter_number_display = $chapter_number_raw !== null ? $chapter_number_raw : '';
    $manga_title = get_the_title($manga_id);
    // Get translator group for this chapter
    $translator_group_name = $chapter_meta['_translation_group'][0] ?? '';
    
    // Track manga reading activity
    mangayummy_track_manga_reading($manga_id, $chapter_id);
    
    // Simple alt text for images
    $alt_text = esc_attr($manga_title . ' - Chapter ' . $chapter_number_display);
    ?>
    
    <!-- CHAPTER HEADER -->
    <div class="chapter-header">
        <?php $current_chapter_title = trim(get_the_title()); ?>
        <?php if ($current_chapter_title === ''): ?>
            <h1>
                <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" class="manga-title-link"><?php echo esc_html($manga_title); ?></a>
            </h1>
            <div class="chapter-info-row">
                <div class="chapter-label">Chapter <?php echo esc_html($chapter_number_display); ?></div>
            </div>
        <?php else: ?>
            <h1>
                <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" class="manga-title-link"><?php echo esc_html($manga_title); ?></a>
            </h1>
            <div class="chapter-info-row">
                <h2 class="chapter-title"><?php echo esc_html($current_chapter_title); ?></h2>
                <span class="chapter-separator">-</span>
                <div class="chapter-label">Chapter <?php echo esc_html($chapter_number_display); ?></div>
            </div>
        <?php endif; ?>
    </div>
    
    <?php
      // OPTIMIZED: Transient cache for chapter navigation (persistent)
      // Store both chapter number and chapter language to avoid repeated meta lookups.
      $nav_cache_key = 'chapter_nav_' . $manga_id;
      $chapter_nav = get_transient($nav_cache_key);
      
      if ($chapter_nav === false) {
          // Fetch all chapter IDs for this manga
          $all_chapter_ids = get_posts(array(
            'post_type' => 'chapter',
            'meta_query' => array(
              array('key' => '_manga_id', 'value' => $manga_id)
            ),
            'posts_per_page' => -1,
            'fields' => 'ids',
            'no_found_rows' => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false
          ));

          // Build array: chapter_id => ['number'=>..., 'language'=>...]
          // Batch query languages for all chapters in one go
          global $wpdb;
          $lang_map = [];
          if (!empty($all_chapter_ids)) {
              $placeholders = implode(',', array_fill(0, count($all_chapter_ids), '%d'));
              $sql = "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ($placeholders)";
              $prepare_args = array_merge([$sql, '_chapter_language'], $all_chapter_ids);
              $rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], $prepare_args));
              foreach ($rows as $row) {
                  $lang_map[intval($row->post_id)] = $row->meta_value;
              }
          }

          $chapter_nav = array();
          foreach ($all_chapter_ids as $cid) {
            $num_raw = mangayummy_get_chapter_number($cid);
            $num = $num_raw !== null ? floatval($num_raw) : 0;
            $lang = isset($lang_map[$cid]) && $lang_map[$cid] !== '' ? $lang_map[$cid] : 'ro';
            $chapter_nav[$cid] = [
                'number' => $num,
                'language' => $lang,
            ];
          }
          
          // Cache for 15 minutes (persistent transient)
          set_transient($nav_cache_key, $chapter_nav, 15 * MINUTE_IN_SECONDS);
      }

      // Sort by chapter number ASC
      uasort($chapter_nav, function($a, $b) {
          return $a['number'] <=> $b['number'];
      });
      $chapter_ids_sorted = array_keys($chapter_nav);
      $chapters_count = count($chapter_ids_sorted);

      // Find current index
      $current_index = array_search($chapter_id, $chapter_ids_sorted);

      // Display chapter count by highest chapter number, not by raw post count.
      $chapter_max_number = 0;
      foreach ($chapter_nav as $item) {
          if ($item['number'] > $chapter_max_number) {
              $chapter_max_number = $item['number'];
          }
      }
      $chapter_total_display = ($chapter_max_number === floor($chapter_max_number))
          ? intval($chapter_max_number)
          : rtrim(rtrim((string)$chapter_max_number, '0'), '.');

      // Previous chapter: first lower index
      $prev_chapter_post = null;
      if ($current_index !== false && $current_index > 0) {
        $prev_id = $chapter_ids_sorted[$current_index - 1];
        $prev_chapter_post = get_post($prev_id);
      }

      // Next chapter: first higher index
      $next_chapter_post = null;
      if ($current_index !== false && $current_index < count($chapter_ids_sorted) - 1) {
        $next_id = $chapter_ids_sorted[$current_index + 1];
        $next_chapter_post = get_post($next_id);
      }

      $chapter_like_count = (int) get_post_meta($chapter_id, '_chapter_likes', true);
      if ($chapter_like_count < 0) {
          $chapter_like_count = 0;
      }
      $user_has_liked_chapter = false;
      if (is_user_logged_in()) {
          $user_has_liked_chapter = get_user_meta(get_current_user_id(), 'chapter_liked_' . $chapter_id, true) ? true : false;
      }

      $home_url = get_permalink($manga_id);
      $chapter_header_count = 'Chapter ' . esc_html($chapter_number_display) . ' / ' . esc_html($chapter_total_display);
      $is_last_chapter_top = ($current_index === false || $current_index >= count($chapter_ids_sorted) - 1);
    ?>

    <div class="chapter-controls">
      <button class="mobile-nav-btn" type="button" aria-expanded="false" aria-label="Chapters menu">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </button>

      <div class="controls-left">
        <div class="chapter-dropdown">
          <button class="chapter-current">Chapter <?php echo esc_html($chapter_number); ?></button>
          <ul class="chapter-list">
            <?php
            $filtered_chapter_numbers = is_array($chapter_nav) ? $chapter_nav : [];
            uasort($filtered_chapter_numbers, function($a, $b) {
                return $b['number'] <=> $a['number'];
            });
            $chapter_ids_desc = array_keys($filtered_chapter_numbers);
            foreach ($chapter_ids_desc as $cid) {
              $ch_num_display = isset($filtered_chapter_numbers[$cid]['number']) ? $filtered_chapter_numbers[$cid]['number'] : '';
              $is_current = ($cid === $chapter_id) ? 'active' : '';
              echo '<li class="' . esc_attr($is_current) . '" data-url="' . esc_url(get_permalink($cid)) . '">Chapter ' . esc_html($ch_num_display) . '</li>';
            }
            ?>
          </ul>
        </div>

        <div class="page-load-toggle">
            <label for="loadMode" style="color:#fff;">&nbsp;</label>
            <select id="loadMode">
                <optgroup label="Load Options">
                    <option value="o">One page</option>
                    <option value="a" selected>All pages</option>
                </optgroup>
            </select>
        </div>

      </div>

      <div class="zoom-fab-wrapper" aria-expanded="false" aria-label="Zoom popup">
        <button type="button" class="zoom-fab" aria-label="Open zoom settings"></button>
        <div class="zoom-popup hidden" role="group" aria-label="Control zoom">
          <button type="button" class="zoom-btn zoom-out" aria-label="Zoom out">-</button>
            <span class="zoom-level" aria-live="polite">100%</span>
          <button type="button" class="zoom-btn zoom-in" aria-label="Zoom in">+</button>
        </div>
      </div>

      <div class="chapter-nav">
        <?php
        if ($prev_chapter_post) {
          echo '<a href="' . esc_url(get_permalink($prev_chapter_post->ID)) . '" class="nav-btn prev"><span class="arrow left"></span> Previous</a>';
        } else {
          echo '<span class="nav-btn prev disabled"><span class="arrow left"></span> Previous</span>';
        }

        if ($is_last_chapter_top) {
          echo '<a href="' . esc_url($home_url) . '" class="nav-btn next back-to-manga">Back to Manga <svg class="icon-info" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.5"></circle><circle cx="12" cy="8" r="1" fill="currentColor"></circle><line x1="12" y1="11" x2="12" y2="17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line></svg></a>';
        } elseif ($next_chapter_post) {
          echo '<a href="' . esc_url(get_permalink($next_chapter_post->ID)) . '" class="nav-btn next">Next <span class="arrow"></span></a>';
        } else {
          echo '<span class="nav-btn next disabled">Next <span class="arrow"></span></span>';
        }
        ?>
      </div>

      <?php
      // Check if user should be suggested to continue in English
      // (site currently serves only Romanian chapters)
      $current_language = 'ro';
      $show_english_suggestion = false;
      $english_next_chapter_url = '';

      if ($current_language === 'ro' && !$next_chapter_post) {
        // User is reading in Romanian and reached the last chapter
        // Check if there are higher numbered chapters in English
        $english_chapters = array();
        foreach ($chapter_nav as $cid => $item) {
          $lang = $item['language'] ?? 'ro';
          $num = $item['number'] ?? 0;
          if ($lang === 'en' && $num > $chapter_number) {
            $english_chapters[$cid] = $num;
          }
        }

        if (!empty($english_chapters)) {
          // Sort by chapter number ASC and get the next one
          asort($english_chapters, SORT_NUMERIC);
          $next_english_id = key($english_chapters);
          $english_next_chapter_url = get_permalink($next_english_id);
          $show_english_suggestion = true;
        }
      }
      ?>
    </div>

    <!-- CHAPTER PAGES (External API with Fallback) -->
    <!-- load mode selector: one page / all pages / manual -->
    <!-- no counter text server-side; JS will add if necessary -->
    <div class="chapter-pages"
         data-prev-chapter="<?php echo isset($prev_chapter_post) && $prev_chapter_post ? esc_url(get_permalink($prev_chapter_post->ID)) : ''; ?>"
         data-next-chapter="<?php echo isset($next_chapter_post) && $next_chapter_post ? esc_url(get_permalink($next_chapter_post->ID)) : ''; ?>">
        <?php
        // Disable all MangaDex integration: we serve only local images from our server.
        // Clear any Mangadex chapter id to avoid external API calls or CDN URLs.
        // NOTE: do NOT overwrite $chapter_id (current chapter ID) as it is used for comment caching.
        $mangadex_chapter_id = '';
        $mangadex_chapter_id_fallback = '';
        $images_rendered = false;
        
        // External image integration removed â€” site serves only local images from storage
        
        // ===== ATTEMPT 2: Fallback to saved image URLs =====
        if (!$images_rendered) {
          $saved_images = maybe_unserialize($chapter_meta['_chapter_images'][0] ?? '');

          // If this chapter is a Mangadex chapter, do NOT use saved CDN URLs
          // because they often expire; instead try the At-Home API again.
          if (!empty($mangadex_chapter_id)) {
            // Remove legacy saved URLs to avoid future fallbacks
            if (!empty($saved_images)) {
              delete_post_meta(get_the_ID(), '_chapter_images');
            }

            // Try a forced retry against the At-Home API by clearing the API cache key
            $retry_url = 'https://api.mangadex.org/at-home/server/' . rawurlencode($mangadex_chapter_id);
            if (function_exists('mangadex_cache_key_for_url')) {
              $cache_key = mangadex_cache_key_for_url($retry_url);
              if ($cache_key) delete_transient($cache_key);
            }

            // Forced retry: fetch direct from At-Home API (bypass cached client)
            $retry_data = function_exists('mangadex_get_chapter_at_home_server_direct') ? mangadex_get_chapter_at_home_server_direct($mangadex_chapter_id) : mangadex_get_chapter_at_home_server($mangadex_chapter_id);
            if (!is_wp_error($retry_data) && !empty($retry_data['baseUrl']) && !empty($retry_data['chapter']['data'])) {
              $data = $retry_data;
              $base_url = $data['baseUrl'];
              $hash = $data['chapter']['hash'];
              $pages = $data['chapter']['data'];

              if (!empty($pages)) {
                foreach ($pages as $page_number => $page) {
                  $img_url = $base_url . '/data/' . $hash . '/' . $page;
                  $img_url = isset($filter_mangadex_url) ? $filter_mangadex_url($img_url) : $img_url;
                  $img_url = mangayummy_normalize_chapter_image_url($img_url);
                  // Try to obtain real dimensions for local uploads to avoid visual distortion
                  $img_width = '';
                  $img_height = '';
                  $upload = wp_get_upload_dir();
                  if (strpos($img_url, $upload['baseurl']) === 0) {
                    $local_path = str_replace($upload['baseurl'], $upload['basedir'], $img_url);
                    if (file_exists($local_path)) {
                      $size = @getimagesize($local_path);
                      if (!empty($size[0]) && !empty($size[1])) {
                        $img_width = intval($size[0]);
                        $img_height = intval($size[1]);
                      }
                    }
                  }

                  $size_attrs = '';
                  if ($img_width && $img_height) {
                    $size_attrs = ' width="' . $img_width . '" height="' . $img_height . '"';
                  }

                  $proxied_url = esc_url(mangayummy_proxy_image_url($img_url));
                  $is_critical = ($page_number < 2);
                  $src_attr = $is_critical ? ' src="' . $proxied_url . '"' : '';
                  $data_src_attr = $is_critical ? '' : ' data-src="' . $proxied_url . '"';
                  $fetchpriority = ($page_number === 0) ? 'high' : 'auto';
                  $loading = $is_critical ? 'eager' : 'lazy';

                  echo '<img' .
                    $src_attr .
                    $data_src_attr . '
                    alt="' . esc_attr($alt_text) . '"
                    class="chapter-page"' . $size_attrs . '
                    decoding="async"
                    fetchpriority="' . esc_attr($fetchpriority) . '"
                    referrerpolicy="no-referrer"
                    loading="' . esc_attr($loading) . '"
                  >';

                }
              }
            }

            // If retry failed, do not fall back to saved CDN URLs for Mangadex chapters.
          } else {
            // No external chapter id â€” safe to use saved image URLs if present
            if (!empty($saved_images)) {
              // Handle both formats: comma-separated URLs or array
              if (is_string($saved_images)) {
                $image_urls = array_filter(array_map('trim', explode(',', $saved_images)));
              } else {
                $image_urls = is_array($saved_images) ? $saved_images : [];
              }

              if (!empty($image_urls)) {
                foreach ($image_urls as $index => $url) {
                  if (!empty($url)) {
                    // Normalize URL encoding (spaces => %20 etc.) and path segments
                    $url = mangayummy_normalize_chapter_image_url($url);
                  }
                  if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                    // First 5 images: high+eager, 6-15: auto+eager, 16+: low+lazy
                    // Try to obtain real dimensions for local uploads
                    $img_width = '';
                    $img_height = '';
                    $upload = wp_get_upload_dir();
                    if (strpos($url, $upload['baseurl']) === 0) {
                      $local_path = str_replace($upload['baseurl'], $upload['basedir'], $url);
                      if (file_exists($local_path)) {
                        $size = @getimagesize($local_path);
                        if (!empty($size[0]) && !empty($size[1])) {
                          $img_width = intval($size[0]);
                          $img_height = intval($size[1]);
                        }
                      }
                    }

                    $size_attrs = '';
                    if ($img_width && $img_height) {
                      $size_attrs = ' width="' . $img_width . '" height="' . $img_height . '"';
                    }

                    $proxied_url = esc_url(mangayummy_proxy_image_url($url));
                    $is_critical = ($index < 2);
                    $src_attr = $is_critical ? ' src="' . $proxied_url . '"' : '';
                    $data_src_attr = $is_critical ? '' : ' data-src="' . $proxied_url . '"';
                    $fetchpriority = ($index === 0) ? 'high' : 'auto';
                    $loading = $is_critical ? 'eager' : 'lazy';

                    echo '<img' .
                        $src_attr .
                        $data_src_attr . '
                        alt="' . esc_attr($alt_text) . '" 
                        class="chapter-page"' . $size_attrs . '
                        decoding="async"
                        fetchpriority="' . esc_attr($fetchpriority) . '"
                        referrerpolicy="no-referrer"
                        loading="' . esc_attr($loading) . '"
                      >';
                    $images_rendered = true;
                  }
                }
              }
            }
          }
        }
        
        // ===== NO IMAGES AVAILABLE =====
        if (!$images_rendered) {
            // Log basic error for debugging (no sensitive data)

            echo '<div class="no-images">
                <div class="no-images-icon"><svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
                <p>Images are missing. Please contact staff or a team member to restore them.</p>
                
            </div>';
        }
        ?>
    </div>

    <?php
    $translator_donation_enabled = get_post_meta($manga_id, '_translator_donation_enabled', true);
    $translator_donation_url = get_post_meta($manga_id, '_translator_donation_url', true);
    if ($translator_donation_enabled && !empty($translator_donation_url)) :
        $donation_url = esc_url($translator_donation_url);
    ?>
    <div class="translator-donation-notice" style="border: 1px solid #13667a; border-radius: 12px; color: #ffffff; text-align: center;">
        <p style="margin:0;font-size:15px;line-height:1.6;color:#ffffff; text-align: center;">
            If you want to support the translator:
            <a href="<?php echo $donation_url; ?>" target="_blank" rel="noopener noreferrer" style="color:#ffffff; text-decoration:underline;"><?php echo $donation_url; ?></a>
        </p>
    </div>
    <?php endif; ?>

    <script>
    // load-mode script: switch between one/all/manual page display
    document.addEventListener('DOMContentLoaded', function() {
        const select = document.getElementById('loadMode');
        const pagesContainer = document.querySelector('.chapter-pages');
      const topChapterControls = document.querySelector('.chapter-controls:not(.bottom-controls)');
        if (!select || !pagesContainer) return;
        const pageLoadToggle = document.querySelector('.page-load-toggle');
        const pages = Array.from(pagesContainer.querySelectorAll('img.chapter-page'));
        let current = 0;

        // restore preference from localStorage (applies to all mangas)
        const stored = localStorage.getItem('mangayummy_load_mode');
        if (stored) {
            select.value = stored;
        } else {
            select.value = 'a'; // default all pages
        }
        // if we were redirected from previous chapter and hash indicates last page
        if (location.hash === '#last') {
            // will apply after images array is populated
            current = pages.length - 1;
        }

        let imageZoom = 1.0;
        const minZoom = 0.5;
        const maxZoom = 2.5;
        const zoomStep = 0.1;

        const zoomFab = document.querySelector('.zoom-fab');
        const zoomFabWrapper = document.querySelector('.zoom-fab-wrapper');
        const zoomPopup = document.querySelector('.zoom-popup');
        const zoomOutBtn = document.querySelector('.zoom-popup .zoom-out');
        const zoomInBtn = document.querySelector('.zoom-popup .zoom-in');
        const zoomLevelLabel = document.querySelector('.zoom-popup .zoom-level');
        const yaBottomNav = document.querySelector('.ya-bottom-nav');

        function isMobileViewport() {
            return window.matchMedia('(max-width: 768px)').matches;
        }

        function updateZoomFabLabel() {
            if (zoomFab) {
                zoomFab.textContent = Math.round(imageZoom * 100) + '%';
            }
        }

        function updateZoomFabVisibility() {
            if (!zoomFabWrapper) return;

            if (!isMobileViewport()) {
                // Desktop can show always
                zoomFabWrapper.classList.add('mobile-visible');
            } else {
                if (!yaBottomNav || yaBottomNav.classList.contains('is-hidden')) {
                    zoomFabWrapper.classList.remove('mobile-visible');
                } else {
                    zoomFabWrapper.classList.add('mobile-visible');
                }
            }
        }

        function applyZoom() {
            const zoomFactor = imageZoom;

            // Apply zoom to the whole strip/container so all pages scale together
            pagesContainer.style.transform = `scale(${zoomFactor})`;
            pagesContainer.style.transformOrigin = 'top center';
            pagesContainer.style.width = '100%';

            if (zoomLevelLabel) {
                zoomLevelLabel.textContent = Math.round(zoomFactor * 100) + '%';
            }
            updateZoomFabLabel();

            // Adjust bottom controls spacing proportional with transformed container
            const renderedHeight = pagesContainer.getBoundingClientRect().height;
            const naturalHeight = pagesContainer.offsetHeight;
            const diff = renderedHeight - naturalHeight;

            const bottomControls = document.querySelector('.chapter-controls.bottom-controls');
            const bottomControlsVisible = bottomControls && window.getComputedStyle(bottomControls).display !== 'none';

            if (bottomControls) {
                const baseBottomMargin = 20; // defined in CSS (.chapter-controls.bottom-controls)
                const computedMargin = Math.max(0, baseBottomMargin + diff);
                bottomControls.style.marginTop = `${computedMargin}px`;
            }

            const commentSection = document.querySelector('.manga-comments-section');
            if (commentSection) {
                if (bottomControlsVisible) {
                    commentSection.style.marginTop = '';
                } else {
                    const baseCommentMargin = 30; // defined in CSS (.manga-comments-section)
                    const computedCommentMargin = Math.max(0, baseCommentMargin + diff);
                    commentSection.style.marginTop = `${computedCommentMargin}px`;
                }
            }

            // Allow negative margin-bottom on zoom-out so downstream content rises with scaled-down pages
            pagesContainer.style.marginBottom = `${diff}px`;

            // For one-page mode, stay anchored at chapter controls.
            if (select.value === 'o') {
              scrollToChapterControlsStart();
            } else if (select.value === 'm') {
                const currentPage = pages[current];
                if (currentPage) {
                    currentPage.scrollIntoView({ behavior: 'auto', block: 'start' });
                }
            }

            try {
                localStorage.setItem('mangayummy_image_zoom', imageZoom.toString());
            } catch (_e) {
                // ignore storage failures
            }
        }

        function setZoom(value) {
            imageZoom = Math.max(minZoom, Math.min(maxZoom, value));
            applyZoom();
        }

        function scrollToChapterControlsStart() {
          const target = topChapterControls || pagesContainer;
          if (target && typeof target.scrollIntoView === 'function') {
            target.scrollIntoView({ behavior: 'auto', block: 'start' });
          }
        }

        // restore zoom from localStorage if available
        const savedZoom = parseFloat(localStorage.getItem('mangayummy_image_zoom'));
        if (!Number.isNaN(savedZoom)) {
            imageZoom = Math.max(minZoom, Math.min(maxZoom, savedZoom));
        }
        updateZoomFabLabel();

        if (zoomFab && zoomPopup) {
            zoomFab.addEventListener('click', function() {
                const isHidden = zoomPopup.classList.toggle('hidden');
                zoomFab.setAttribute('aria-expanded', (!isHidden).toString());
            });

            // close popup outside click
            document.addEventListener('click', function(evt) {
                if (!zoomFab.contains(evt.target) && !zoomPopup.contains(evt.target)) {
                    zoomPopup.classList.add('hidden');
                    zoomFab.setAttribute('aria-expanded', 'false');
                }
            });
        }

        // dynamic show/hide on mobile based on ya-bottom-nav visibility
        if (yaBottomNav) {
            const observer = new MutationObserver(updateZoomFabVisibility);
            observer.observe(yaBottomNav, { attributes: true, attributeFilter: ['class'] });
        }

        window.addEventListener('resize', updateZoomFabVisibility);
        window.addEventListener('scroll', updateZoomFabVisibility);
        updateZoomFabVisibility();

        if (zoomOutBtn) {
            zoomOutBtn.addEventListener('click', function(event) {
                event.stopPropagation();
                setZoom(imageZoom - zoomStep);
            });
        }
        if (zoomInBtn) {
            zoomInBtn.addEventListener('click', function(event) {
                event.stopPropagation();
                setZoom(imageZoom + zoomStep);
            });
        }

        function updateMode() {
            const mode = select.value;
            pagesContainer.classList.remove('one-page', 'manual', 'long-strip', 'webtoon', 'single-page');
            if (mode === 'a') {
                pagesContainer.classList.add('long-strip');
                pages.forEach(p => p.style.display = 'block');
            } else if (mode === 'o' || mode === 'm') {
                pagesContainer.classList.add(mode === 'o' ? 'one-page' : 'manual');
                pagesContainer.classList.add('single-page');
                pages.forEach((p, i) => {
                    const visible = i === current;
                    p.style.display = visible ? 'block' : 'none';
                    p.classList.toggle('current', visible);
                });
            }
            updateCounter();

            // In one-page mode, keep navigation anchored at chapter controls.
            if (mode === 'o') {
              scrollToChapterControlsStart();
            } else if (mode === 'm') {
                const currentPage = pages[current];
                if (currentPage && typeof currentPage.scrollIntoView === 'function') {
                    currentPage.scrollIntoView({ behavior: 'auto', block: 'start' });
                }
            }

            applyZoom();
        }

          select.addEventListener('change', function() {
            current = 0;
            // save for future chapters
            localStorage.setItem('mangayummy_load_mode', select.value);
            updateMode();
        });

          // mimic dropdown open animation by toggling .open on container
          if (pageLoadToggle) {
            select.addEventListener('mousedown', function() { pageLoadToggle.classList.add('open'); });
            select.addEventListener('focus', function() { pageLoadToggle.classList.add('open'); });
            select.addEventListener('blur', function() { pageLoadToggle.classList.remove('open'); });
            select.addEventListener('change', function() { pageLoadToggle.classList.remove('open'); });
          }

          // Mobile: toggle chapter controls (dropdown + load mode) via hamburger button
          const mobileNavBtn = document.querySelector('.mobile-nav-btn');
          const controlsLeft = document.querySelector('.controls-left');
          const CONTROLS_OPEN_KEY = 'mangayummy_chapter_controls_open';

          function updatePagesOffset(isOpen) {
            if (!pagesContainer || !controlsLeft) return;
            if (isOpen) {
              const height = controlsLeft.getBoundingClientRect().height;
              pagesContainer.style.marginTop = `${height}px`;
            } else {
              pagesContainer.style.marginTop = '';
            }
          }

          function setControlsOpen(isOpen) {
            if (!mobileNavBtn || !controlsLeft) return;
            controlsLeft.classList.toggle('open', isOpen);
            mobileNavBtn.classList.toggle('open', isOpen);
            mobileNavBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            pagesContainer.classList.toggle('controls-open', isOpen);
            updatePagesOffset(isOpen);
            try {
              localStorage.setItem(CONTROLS_OPEN_KEY, isOpen ? '1' : '0');
            } catch (e) {
              // ignore storage failures (incognito/private mode)
            }
          }

          if (mobileNavBtn && controlsLeft) {
            const isMobileView = () => window.matchMedia('(max-width: 768px)').matches;

            // Restore state from previous chapter visit (only in mobile mode)
            if (isMobileView()) {
              const storedOpen = localStorage.getItem(CONTROLS_OPEN_KEY);
              if (storedOpen === '1') {
                setControlsOpen(true);
              }
            } else {
              // Ensure desktop layout doesn't keep mobile overlay state active
              setControlsOpen(false);
              try {
                localStorage.removeItem(CONTROLS_OPEN_KEY);
              } catch (e) {
                // ignore storage failures
              }
            }

            mobileNavBtn.addEventListener('click', function(event) {
              event.stopPropagation();
              const isOpen = !controlsLeft.classList.contains('open');
              setControlsOpen(isOpen);
            });

            window.addEventListener('resize', function() {
              if (!isMobileView()) {
                setControlsOpen(false);
              } else if (controlsLeft.classList.contains('open')) {
                updatePagesOffset(true);
              }
            });
          }

        // attach a single click listener to the pages container so we
        // handle navigation regardless of which IMG element is active
        pagesContainer.addEventListener('click', function(event) {
            // When the mobile chapter controls are open, keep them open while
            // navigating via the image tap zones (so tapping next doesn't close them)
            if (controlsLeft && controlsLeft.classList.contains('open')) {
                event.stopPropagation();
            }

            const mode = select.value;
            if (mode !== 'o' && mode !== 'm') return;
            const rect = pagesContainer.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const half = rect.width / 2;
            const isLast = current === pages.length - 1;
            if (x < half) {
                // backwards
                if (current > 0) {
                    current--;
                } else {
                    // already on first page
                    const prevUrl = pagesContainer.getAttribute('data-prev-chapter');
                    if (prevUrl) {
                        // include hash so we can land on last page
                        window.location.href = prevUrl + '#last';
                        return;
                    }
                    // no previous chapter available â€“ do nothing
                    return;
                }
            } else {
                // forwards
                if (!isLast) {
                    current++;
                } else {
                    // at final page
                    const nextUrl = pagesContainer.getAttribute('data-next-chapter');
                    if (nextUrl) {
                        window.location.href = nextUrl;
                        return; // navigate away
                    }
                    // no next chapter available â€“ do nothing
                    return;
                }
            }
            updateMode();
        });

        const optO = select.querySelector('option[value="o"]');
        function updateCounter(){
            if (!optO) {
                console.warn('no optO');
                return;
            }
            const mode = select.value;
            if(mode === 'a'){
                optO.textContent = 'One page';
            } else {
                optO.textContent = 'One page (' + (current + 1) + '/' + pages.length + ')';
            }
        }
        updateMode();

        /* DISABLED - backup mode-lock webtoon detection
        document.addEventListener('DOMContentLoaded', function() {
            const images = document.querySelectorAll('.chapter-page');
            if (!images.length) return;

            let tallCount = 0;
            images.forEach(img => {
                const w = parseInt(img.getAttribute('width'));
                const h = parseInt(img.getAttribute('height'));
                if (w > 0 && h > 0 && h / w > 2.5) {
                    tallCount++;
                }
            });

            if (tallCount > images.length / 2) {
                const modeSelector = document.getElementById('loadMode');
                if (modeSelector) {
                    Array.from(modeSelector.options).forEach(option => {
                        if (option.value === 'o' || option.value === 'm') {
                            option.remove();
                        }
                    });
                    modeSelector.value = 'a';
                    modeSelector.dispatchEvent(new Event('change'));
                }
            }
        });
        */
    });
    </script>

    <?php if ($show_english_suggestion): ?>
    <!-- English Continuation Suggestion -->
    <div class="english-continuation-notice" id="english-continuation-notice" style="display: block;">
      <div class="notice-content">
        <div class="notice-icon">
          <svg width="32" height="24" viewBox="0 0 60 30" class="flag-icon">
            <clipPath id="english-flag-clip">
              <path d="m30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
            </clipPath>
            <path d="m0,0 v30 h60 v-30 z" fill="#012169"/>
            <path d="m0,0 l60,30 m0,-30 l-60,30" stroke="#fff" stroke-width="6"/>
            <path d="m0,0 l60,30 m0,-30 l-60,30" clip-path="url(#english-flag-clip)" stroke="#C8102E" stroke-width="4"/>
            <path d="m30,0 v30 m-30,-30 v30" stroke="#fff" stroke-width="10"/>
            <path d="m30,0 v30 m-30,-30 v30" stroke="#C8102E" stroke-width="6"/>
          </svg>
        </div>
        <div class="notice-text">
          <strong>You've reached the last chapter in Romanian.</strong>
          <p>There are newer chapters available in English. Do you want to continue reading?</p>
        </div>
        <div class="notice-actions">
          <a href="<?php echo esc_url($english_next_chapter_url); ?>" class="btn-continue-english">
            <i class="fa fa-play"></i> Continue in English
          </a>
          <button type="button" class="btn-dismiss-notice" onclick="dismissEnglishNotice()">
            <i class="fa fa-times"></i> No thanks
          </button>
        </div>
      </div>
    </div>

    <script>
    function dismissEnglishNotice() {
      // Just set cookie to not show again, but keep notice visible on current page
      const mangaId = <?php echo json_encode($manga_id); ?>;
      const cookieName = 'dismissed_english_notice_' + mangaId;
      const d = new Date();
      d.setTime(d.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 days
      const expires = "expires=" + d.toUTCString();
      document.cookie = cookieName + "=1; " + expires + "; path=/";
      
      // Optionally show a small confirmation that the dismissal was recorded
      const btn = event.target.closest('.btn-dismiss-notice');
      if (btn) {
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa fa-check"></i> Got it';
        btn.style.background = '#666';
        setTimeout(() => {
          btn.innerHTML = originalText;
          btn.style.background = '';
        }, 1500);
      }
    }

    // Check if user already dismissed this notice for this manga
    document.addEventListener('DOMContentLoaded', function() {
      const mangaId = <?php echo json_encode($manga_id); ?>;
      const cookieName = 'dismissed_english_notice_' + mangaId;
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === cookieName && value === '1') {
          const notice = document.getElementById('english-continuation-notice');
          if (notice) {
            notice.style.display = 'none';
          }
          break;
        }
      }
    });
    </script>
    <?php endif; ?>

    <div class="chapter-topbar">
        <div class="topbar-left">
            <div class="topbar-title"><a href="<?php echo esc_url($home_url); ?>"><?php echo esc_html($manga_title); ?></a></div>
            <div class="topbar-chapter"><?php echo $chapter_header_count; ?></div>
        </div>

        <div class="topbar-right">
            <button type="button" class="topbar-action topbar-like-btn<?php echo $user_has_liked_chapter ? ' active' : ''; ?>" data-chapter-id="<?php echo esc_attr($chapter_id); ?>" aria-label="Like chapter" aria-pressed="<?php echo $user_has_liked_chapter ? 'true' : 'false'; ?>">
                <i class="fa fa-thumbs-up"></i>
                <span class="topbar-like-count"><?php echo esc_html($chapter_like_count); ?></span>
            </button>
            <a href="<?php echo esc_url( home_url('/') ); ?>" class="topbar-action home-btn" aria-label="Back to home page">
                <i class="fa fa-home"></i>
            </a>
        </div>
    </div>

    <script>
    (function() {
      const likeBtn = document.querySelector('.topbar-like-btn');
      if (!likeBtn) return;

      function showChapterToast(message, type = 'error') {
        const existing = document.querySelector('.chapter-like-toast');
        if (existing) {
          existing.remove();
        }
        const toast = document.createElement('div');
        toast.className = 'chapter-like-toast ' + type;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => {
          toast.style.opacity = '0';
          setTimeout(() => toast.remove(), 300);
        }, 2800);
      }

      likeBtn.addEventListener('click', function() {
        const chapterId = this.dataset.chapterId;
        const currentUserId = window.ya_ajax?.currentUserId || 0;
        if (!currentUserId) {
          showChapterToast('You must be logged in to like this chapter.', 'error');
          return;
        }

        const formData = new FormData();
        formData.append('action', 'mangayummy_like_chapter');
        formData.append('nonce', (window.ya_ajax && ya_ajax.nonce) ? ya_ajax.nonce : '<?php echo wp_create_nonce('ya_ajax_nonce'); ?>');
        formData.append('chapter_id', chapterId);

        const ajaxUrl = (window.ya_ajax && ya_ajax.ajax_url) ? ya_ajax.ajax_url : '<?php echo admin_url('admin-ajax.php'); ?>';

        fetch(ajaxUrl, {
          method: 'POST',
          body: formData
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (!data || !data.success) {
            var message = (data && data.data && data.data.message) ? data.data.message : (data && data.data ? data.data : 'An error occurred.');
            showChapterToast(message, 'error');
            return;
          }

          const newCount = data.data.like_count;
          const liked = !!data.data.liked;
          likeBtn.classList.toggle('active', liked);
          likeBtn.setAttribute('aria-pressed', liked ? 'true' : 'false');
          likeBtn.querySelector('.topbar-like-count').textContent = newCount;
        })
        .catch(() => {
          showChapterToast('Network error. Please try again.', 'error');
        });
      });
    })();
    </script>

    <!-- BOTTOM NAVIGATION CONTROLS -->
    <div class="chapter-controls bottom-controls">
        <?php
        // Debug
        
        // Previous chapter: first lower index
        $prev_chapter_post = null;
        if ($current_index !== false && $current_index > 0) {
            $prev_id = $chapter_ids_sorted[$current_index - 1];
            $prev_chapter_post = get_post($prev_id);
        }
        
        if ($prev_chapter_post) {
            echo '<a href="' . esc_url(get_permalink($prev_chapter_post->ID)) . '" class="nav-btn prev"><span class="arrow left"></span> Previous</a>';
        } else {
            echo '<span class="nav-btn prev disabled"><span class="arrow left"></span> Previous</span>';
        }
        
        // Check if this is the last chapter
        $is_last_chapter = ($current_index === false || $current_index >= count($chapter_ids_sorted) - 1);

        // Next button: normally goes to next chapter, but on last chapter it becomes a back-to-manga icon
        if ($is_last_chapter) {
            echo '<a href="' . esc_url(get_permalink($manga_id)) . '" class="nav-btn next back-to-manga">Back to Manga <svg class="icon-info" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.5"></circle><circle cx="12" cy="8" r="1" fill="currentColor"></circle><line x1="12" y1="11" x2="12" y2="17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line></svg></a>';
        } else {
            // Next chapter: first higher index
            $next_chapter_post = null;
            if ($current_index !== false && $current_index < count($chapter_ids_sorted) - 1) {
                $next_id = $chapter_ids_sorted[$current_index + 1];
                $next_chapter_post = get_post($next_id);
            }

            if ($next_chapter_post) {
                echo '<a href="' . esc_url(get_permalink($next_chapter_post->ID)) . '" class="nav-btn next">Next <span class="arrow"></span></a>';
            } else {
                echo '<span class="nav-btn next disabled">Next <span class="arrow"></span></span>';
            }
        }
        ?>
    </div>

    <!-- CHAPTER COMMENTS SECTION - IDENTICAL TO MANGA -->
    <section class="manga-comments-section">
      <div class="tabs-block content-page offset-top no-padding">
        <div class="tabs-header" style="overflow: visible;">
          <ul class="tabs bordered-top">
            <li class="active tabs-li bordered-top-left materiable" data-id="#comments-tab" id="comments">
              <span class="title" style="display: initial"><i class="fa fa-comment"></i> Comments</span>
              <span class="count"><?php echo get_comments_number(); ?></span>
            </li>
          </ul>
        </div>
        
        <div class="tabs-content" style="min-height: 130px; padding: 10px;">
          <div id="comments-tab" class="tab-content active">
            
            <!-- Comment form (visible to all users) -->
            <div class="comment-form-wrapper">
              <div class="comment-form-header">
                <span class="comment-form-title"><i class="fa fa-pencil"></i> Add a comment</span>
              </div>
              
              <div id="manga-comment-form" class="manga-comment-form" data-post-id="<?php echo get_the_ID(); ?>">
                <!-- Text formatting toolbar -->
                <div class="comment-toolbar">
                    <div class="toolbar-left">
                      <button type="button" class="format-btn text-format-btn" data-format="bold" title="Bold (Ctrl+B)">
                        <i class="fa fa-bold"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="italic" title="Italic (Ctrl+I)">
                        <i class="fa fa-italic"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="underline" title="Underline">
                        <i class="fa fa-underline"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="spoiler" title="Spoiler">
                        <i class="fa fa-eye-slash"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="code" title="Code">
                        <i class="fa fa-code"></i>
                      </button>
                    </div>
                    <div class="toolbar-right">
                      <button type="button" class="format-btn emoji-picker-btn" title="Add emoji">
                        <i class="fa fa-smile-o"></i>
                      </button>
                      <?php if ($has_giphy_api): ?><button type="button" class="format-btn gif-picker-btn" title="Add GIF" style="font-weight:700; font-size:12px;">GIF</button><?php endif; ?>
                      <!-- Emoji picker popup -->
                      <div class="emoji-picker-popup" style="display: none;">
                        <div class="emoji-categories">
                          <button type="button" class="emoji-category active" data-category="smileys">😊</button>
                          <button type="button" class="emoji-category" data-category="hand">👋</button>
                          <button type="button" class="emoji-category" data-category="heart">❤️</button>
                          <button type="button" class="emoji-category" data-category="fire">🔥</button>
                          <button type="button" class="emoji-category" data-category="star">⭐</button>
                        </div>
                        <div class="emoji-grid" id="emoji-grid">
                          <!-- Will be populated by JavaScript -->
                        </div>
                      </div>
                      <!-- GIF picker popup -->
                      <?php if ($has_giphy_api): ?>
                      <div class="gif-picker-popup" style="display: none;">
                        <div class="gif-search-wrapper">
                          <input type="text" id="gif-search-input" class="gif-search-input" placeholder="Search GIFs...">
                          <button type="button" id="gif-search-btn" class="gif-search-btn">🔍</button>
                        </div>
                        <div class="gif-grid" id="gif-grid">
                          <div class="gif-loading">Loading GIFs...</div>
                        </div>
                      </div>
                      <?php endif; ?>
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <div id="gif-preview" class="gif-preview" style="display:none; margin-bottom:8px;"></div>
                    <textarea 
                      id="manga-comment-text" 
                      class="comment-textarea" 
                      placeholder="Share your thoughts about this chapter..." 
                      rows="4" 
                      minlength="1"
                      maxlength="1000"
                      required></textarea>
                    <small class="comment-help">0/1000 characters</small>
                  </div>
                  <div class="form-actions">
                    <button type="button" class="btn-submit-comment" id="submit-manga-comment">
                      <i class="fa fa-send"></i> Post comment
                    </button>
                  </div>
                  <?php wp_nonce_field( 'mangayummy_comment_nonce', 'nonce' ); ?>
                </div>
                <div id="comment-message" class="comment-message" style="display:none;"></div>
              </div>

<?php
$all_comments = get_comments([
  'post_id' => $chapter_id,
  'parent'  => 0,
  'status'  => 'approve',
  'orderby' => 'date',
  'order'   => 'DESC',
]);
?>

<!-- Comments sorting -->
        <div class="comments-sort-block"<?php echo empty($all_comments) ? ' style="display:none"' : ''; ?>>
          <div class="sort-label">Sort:</div>
          <div class="sort-buttons">
            <button type="button" class="sort-btn active" data-sort="newest" title="Newest comments">
              <i class="fa fa-clock-o"></i> Newest
            </button>
            <button type="button" class="sort-btn" data-sort="oldest" title="Oldest comments">
              <i class="fa fa-history"></i> Oldest
            </button>
            <button type="button" class="sort-btn" data-sort="liked" title="Most liked comments">
              <i class="fa fa-heart"></i> Most liked
            </button>
          </div>
        </div>

            <!-- Comments list -->
            <div class="comments-list-wrapper">
              <?php if (!empty($all_comments)): ?>
                <div class="comments-list" data-sort-type="newest">
                  <?php foreach ($all_comments as $comment): ?>
                    <?php
                      $GLOBALS['comment'] = $comment;
                      manga_comment_callback($comment);
                    ?>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>

    <script>
    window.MANGA_COMMENTS_CONTEXT = {
      type: 'chapter',
      post_id: <?php echo intval($chapter_id); ?>
    };
    </script>

    <!-- TEXT FORMATTING & EMOJI MANAGER - IDENTICAL TO MANGA -->
    <script>
    class CommentFormatter {
      constructor(textareaSelectorOrElement) {
        this.textarea = (typeof textareaSelectorOrElement === 'string') ? document.querySelector(textareaSelectorOrElement) : textareaSelectorOrElement;
        
        // Only initialize if textarea exists (user is logged in)
        if (this.textarea) {
          this.emojiMap = {
            smileys: ['😊', '😂', '😍', '😭', '😠', '😴', '😵', '🤔', '😎', '🥳', '😘', '🤗'],
            hand: ['👋', '🙌', '👏', '🤝', '👍', '👎', '✌️', '🤟', '💪', '👊', '✊', '🖐️'],
            heart: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '💕', '💞'],
            fire: ['🔥', '⭐', '✨', '💫', '🌟', '💥', '🎉', '🎊', '⚡', '🔆', '🌈', '👑'],
            star: ['⭐', '🌟', '✨', '💫', '🌠', '🎆', '🎇', '💥', '🔆', '🌠', '⭐', '✨']
          };
          
          // Mention autocomplete properties
          this.mentionDropdown = null;
          this.currentMentionStart = -1;
          this.currentMentionQuery = '';
          this.selectedIndex = -1;
          this.mentionResults = [];
          
          // Find the help element relative to the textarea
          this.helpElement = this.textarea.closest('.form-group') ? this.textarea.closest('.form-group').querySelector('.comment-help') : null;
          
          this.init();
        }
      }

      init() {
        // Text format buttons
        document.querySelectorAll('.text-format-btn').forEach(btn => {
          // Prevent the button from stealing focus (preserve textarea selection)
          btn.addEventListener('mousedown', (e) => e.preventDefault());
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            const format = btn.dataset.format;
            this.applyFormat(format);
          });
        });

        // Emoji picker button
        const emojiBtn = document.querySelector('.emoji-picker-btn');
        const emojiPopup = document.querySelector('.emoji-picker-popup');
        const toolbarRight = document.querySelector('.toolbar-right');
        
        if (emojiBtn && emojiPopup) {
          emojiBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            emojiPopup.style.display = emojiPopup.style.display === 'none' ? 'block' : 'none';
            if (emojiPopup.style.display === 'block') {
              this.populateEmojiGrid('smileys');
            }
          });
          
          // Close emoji picker when clicking outside
          document.addEventListener('click', (e) => {
            if (toolbarRight && !toolbarRight.contains(e.target)) {
              emojiPopup.style.display = 'none';
            }
          });
          
          // Category buttons
          document.querySelectorAll('.emoji-category').forEach(btn => {
            btn.addEventListener('mousedown', (e) => e.preventDefault());
            btn.addEventListener('click', (e) => {
              e.preventDefault();
              e.stopPropagation();
              document.querySelectorAll('.emoji-category').forEach(b => b.classList.remove('active'));
              btn.classList.add('active');
              this.populateEmojiGrid(btn.dataset.category);
            });
          });
        }

        // GIF picker initialization
        const gifBtn = document.querySelector('.gif-picker-btn');
        const gifPopup = document.querySelector('.gif-picker-popup');
        const gifSearchInput = document.getElementById('gif-search-input');
        const gifSearchBtn = document.getElementById('gif-search-btn');

        const showGifLoginError = () => {
          const message = document.getElementById('comment-message');
          if (message) {
            message.style.display = 'block';
            message.textContent = 'You must be logged in to use GIFs.';
            message.style.color = '#ff4d4d';
            setTimeout(() => {
              message.style.display = 'none';
              message.textContent = '';
            }, 3500);
          }
        };

        if (gifBtn && gifPopup) {
          gifBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();

            if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
              showGifLoginError();
              return;
            }

            gifPopup.style.display = gifPopup.style.display === 'none' ? 'block' : 'none';
            if (gifPopup.style.display === 'block') {
              this.loadTrendingGIFs();
              if (emojiPopup) emojiPopup.style.display = 'none';
              if (gifSearchInput) gifSearchInput.focus();
            }
          });

          if (gifSearchInput) {
            gifSearchInput.addEventListener('keydown', (e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                this.searchGIFs(gifSearchInput.value.trim());
              }
            });
          }

          if (gifSearchBtn) {
            gifSearchBtn.addEventListener('click', (e) => {
              e.preventDefault();
              this.searchGIFs(gifSearchInput?.value.trim() || '');
            });
          }
        }

        // Close popups when clicking outside
        document.addEventListener('click', (e) => {
          if (toolbarRight && !toolbarRight.contains(e.target)) {
            if (emojiPopup) emojiPopup.style.display = 'none';
            if (gifPopup) gifPopup.style.display = 'none';
          }
        });

        // Keyboard shortcuts
        if (this.textarea) {
          this.textarea.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
              e.preventDefault();
              this.applyFormat('bold');
            } else if ((e.ctrlKey || e.metaKey) && e.key === 'i') {
              e.preventDefault();
              this.applyFormat('italic');
            }
          });

          // Character counter
          this.textarea.addEventListener('input', (e) => {
            this.updateCharacterCount();
          });
          
          // Also update on paste
          this.textarea.addEventListener('paste', (e) => {
            setTimeout(() => this.updateCharacterCount(), 0);
          });
        }

        // Initialize mention autocomplete
        this.initMentionAutocomplete();

        // Initialize character count
        this.updateCharacterCount();
      }

      applyFormat(format) {
        const start = this.textarea.selectionStart;
        const end = this.textarea.selectionEnd;
        const text = this.textarea.value;
        const selectedText = text.substring(start, end) || 'text';

        let formattedText = '';
        
        switch(format) {
          case 'bold':
            formattedText = `**${selectedText}**`;
            break;
          case 'italic':
            formattedText = `*${selectedText}*`;
            break;
          case 'underline':
            formattedText = `__${selectedText}__`;
            break;
          case 'spoiler':
            formattedText = `||${selectedText}||`;
            break;
          case 'code':
            formattedText = `\`${selectedText}\``;
            break;
          default:
            return;
        }

        const newText = text.substring(0, start) + formattedText + text.substring(end);
        this.textarea.value = newText;
        this.textarea.focus();
        this.textarea.selectionStart = start + formattedText.length;
      }

      populateEmojiGrid(category) {
        const grid = document.getElementById('emoji-grid');
        const emojis = this.emojiMap[category] || [];
        
        grid.innerHTML = '';
        emojis.forEach(emoji => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'emoji-btn';
          btn.textContent = emoji;
          // prevent focus steal on mousedown
          btn.addEventListener('mousedown', (e) => e.preventDefault());
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            this.insertEmoji(emoji);
            document.querySelector('.emoji-picker-popup').style.display = 'none';
          });
          grid.appendChild(btn);
        });
      }

      insertEmoji(emoji) {
        const start = this.textarea.selectionStart;
        const end = this.textarea.selectionEnd;
        const text = this.textarea.value;
        
        const newText = text.substring(0, start) + emoji + text.substring(end);
        this.textarea.value = newText;
        this.textarea.focus();
        this.textarea.selectionStart = this.textarea.selectionEnd = start + emoji.length;
      }

      loadTrendingGIFs() {
        const gifGrid = document.getElementById('gif-grid');
        if (!gifGrid) return;

        gifGrid.innerHTML = '<div class="gif-loading">Loading GIFs...</div>';

        fetch((typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : (typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php')), {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=mangayummy_get_gifs&type=featured'
        })
        .then(r => r.json())
        .then(data => {
          if (data.success && data.data && data.data.gifs) {
            this.displayGIFs(data.data.gifs);
          } else {
            gifGrid.innerHTML = '<div class="gif-error">Error loading GIFs</div>';
          }
        })
        .catch(() => {
          gifGrid.innerHTML = '<div class="gif-error">Error loading GIFs</div>';
        });
      }

      searchGIFs(query) {
        const gifGrid = document.getElementById('gif-grid');
        if (!gifGrid) return;

        if (!query) {
          this.loadTrendingGIFs();
          return;
        }

        gifGrid.innerHTML = '<div class="gif-loading">Searching GIFs...</div>';

        fetch((typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : (typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php')), {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=mangayummy_get_gifs&type=search&query=' + encodeURIComponent(query)
        })
        .then(r => r.json())
        .then(data => {
          if (data.success && data.data && data.data.gifs) {
            this.displayGIFs(data.data.gifs);
          } else {
            gifGrid.innerHTML = '<div class="gif-error">No GIFs found</div>';
          }
        })
        .catch(() => {
          gifGrid.innerHTML = '<div class="gif-error">Error searching GIFs</div>';
        });
      }

      displayGIFs(gifs) {
        const gifGrid = document.getElementById('gif-grid');
        if (!gifGrid) return;

        if (!Array.isArray(gifs) || gifs.length === 0) {
          gifGrid.innerHTML = '<div class="gif-no-results">No GIFs found</div>';
          return;
        }

        gifGrid.innerHTML = gifs.map(gif => `
          <div class="gif-item" data-url="${gif.url}">
            <img src="${gif.preview}" alt="${gif.title}" loading="lazy" />
          </div>
        `).join('');

        gifGrid.querySelectorAll('.gif-item').forEach(item => {
          item.addEventListener('click', (e) => {
            e.preventDefault();
            const gifUrl = item.dataset.url;

            const start = this.textarea.selectionStart;
            const end = this.textarea.selectionEnd;
            const value = this.textarea.value;
            const insertText = gifUrl;

            this.textarea.value = value.substring(0, start) + insertText + value.substring(end);
            this.textarea.focus();
            this.textarea.selectionStart = this.textarea.selectionEnd = start + insertText.length;

            const preview = document.getElementById('gif-preview');
            if (preview) {
              preview.style.display = 'block';
              preview.innerHTML = `
                <div style="position: relative; display: flex; align-items: center; gap: 8px; justify-content: flex-end;">
                  <button type="button" id="gif-preview-clear" style="background:#ff4d4d;color:#fff;border:none;border-radius:999px;padding:2px 8px;cursor:pointer;font-size:11px;">X</button>
                </div>
                <img src="${gifUrl}" alt="GIF preview" style="max-width:100%;border-radius:8px;margin-top:8px;display:block;" loading="lazy" />
              `;
              const clear = document.getElementById('gif-preview-clear');
              if (clear) {
                clear.addEventListener('click', () => {
                  preview.style.display = 'none';
                  preview.innerHTML = '';
                  if (this.textarea.value.includes(gifUrl)) {
                    this.textarea.value = this.textarea.value.replace(gifUrl, '').trim();
                  }
                });
              }
            }

            if (gifPopup) gifPopup.style.display = 'none';
          });
        });
      }

      // Initialize mention autocomplete
      initMentionAutocomplete() {
        if (!this.textarea) {
          console.warn('Textarea not found, skipping mention autocomplete initialization');
          return;
        }

        // Create dropdown element
        this.mentionDropdown = document.createElement('div');
        this.mentionDropdown.className = 'mention-autocomplete';
        document.body.appendChild(this.mentionDropdown);

        // Handle input events
        this.textarea.addEventListener('input', (e) => this.handleMentionInput(e));
        this.textarea.addEventListener('keydown', (e) => this.handleMentionKeydown(e));
        this.textarea.addEventListener('blur', () => setTimeout(() => this.hideMentionDropdown(), 150));

        // Handle clicks on dropdown items
        this.mentionDropdown.addEventListener('click', (e) => {
          const item = e.target.closest('.mention-item');
          if (item) {
            e.preventDefault();
            const index = parseInt(item.dataset.index);
            this.selectMention(index);
          }
        });
      }

      // Handle textarea input for mentions
      handleMentionInput(e) {
        const cursorPos = this.textarea.selectionStart;
        const text = this.textarea.value;

        // Find the current word being typed
        const beforeCursor = text.substring(0, cursorPos);
        const words = beforeCursor.split(/\s+/);
        const currentWord = words[words.length - 1];

        // Check if current word starts with @
        if (currentWord.startsWith('@') && currentWord.length > 1) {
          const query = currentWord.substring(1); // Remove @
          this.currentMentionQuery = query;
          // Use the actual '@' position so we don't duplicate the '@' when inserting
          const atPos = beforeCursor.lastIndexOf('@');
          this.currentMentionStart = atPos >= 0 ? atPos : (cursorPos - query.length - 1);
          this.searchUsers(query);
        } else {
          this.hideMentionDropdown();
        }
      }

      // Handle keyboard navigation in mention dropdown
      handleMentionKeydown(e) {
        if (!this.mentionDropdown.classList.contains('show')) return;

        switch (e.key) {
          case 'ArrowDown':
            e.preventDefault();
            this.selectedIndex = Math.min(this.selectedIndex + 1, this.mentionResults.length - 1);
            this.updateDropdownSelection();
            break;
          case 'ArrowUp':
            e.preventDefault();
            this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
            this.updateDropdownSelection();
            break;
          case 'Enter':
          case 'Tab':
            if (this.selectedIndex >= 0) {
              e.preventDefault();
              this.selectMention(this.selectedIndex);
            }
            break;
          case 'Escape':
            this.hideMentionDropdown();
            break;
        }
      }

      // Search users via AJAX
      async searchUsers(query) {
        if (typeof mangayummy_comments === 'undefined') {
          console.error('mangayummy_comments object not available');
          this.hideMentionDropdown();
          return;
        }

        try {
          const response = await fetch(`${mangayummy_comments.ajax_url}?action=mangayummy_search_users&q=${encodeURIComponent(query)}`);
          const results = await response.json();

          this.mentionResults = results;
          if (results.length > 0) {
            this.showMentionDropdown(results);
          } else {
            this.hideMentionDropdown();
          }
        } catch (error) {
          console.error('Error searching users:', error);
          this.hideMentionDropdown();
        }
      }

      // Show mention dropdown with results
      showMentionDropdown(results) {
        this.mentionDropdown.innerHTML = '';
        this.selectedIndex = 0;

        results.forEach((user, index) => {
          const item = document.createElement('div');
          item.className = `mention-item ${index === 0 ? 'active' : ''} ${user.is_friend ? 'friend' : ''}`;
          item.dataset.index = index;

          item.innerHTML = `
            <img src="${user.avatar}" alt="${user.display_name}" class="mention-avatar">
            <div class="mention-info">
              <div class="mention-username">
                @${user.display_name}
                ${user.is_friend ? '<span class="mention-friend-badge">Friend</span>' : ''}
              </div>
              <div class="mention-display-name">${user.display_name}</div>
            </div>
          `;

          this.mentionDropdown.appendChild(item);
        });

        // Position dropdown - simple approach: below the textarea
        const textareaRect = this.textarea.getBoundingClientRect();

        this.mentionDropdown.style.left = `${textareaRect.left + window.scrollX}px`;
        this.mentionDropdown.style.top = `${textareaRect.bottom + window.scrollY + 5}px`;

        this.mentionDropdown.classList.add('show');
      }

      // Hide mention dropdown
      hideMentionDropdown() {
        this.mentionDropdown.classList.remove('show');
        this.currentMentionStart = -1;
        this.currentMentionQuery = '';
        this.selectedIndex = -1;
        this.mentionResults = [];
      }

      // Update visual selection in dropdown
      updateDropdownSelection() {
        const items = this.mentionDropdown.querySelectorAll('.mention-item');
        items.forEach((item, index) => {
          item.classList.toggle('active', index === this.selectedIndex);
        });
      }

      // Select a mention from dropdown
      selectMention(index) {
        const user = this.mentionResults[index];
        if (!user) return;
        
        const text = this.textarea.value;
        const beforeMention = text.substring(0, this.currentMentionStart);
        const afterMention = text.substring(this.textarea.selectionStart);
        
        // Insert the selected username
        const newText = beforeMention + '@' + user.display_name + ' ' + afterMention;
        this.textarea.value = newText;
        
        // Set cursor position after the mention
        const newCursorPos = this.currentMentionStart + user.display_name.length + 2; // +2 for @ and space
        this.textarea.selectionStart = this.textarea.selectionEnd = newCursorPos;
        
        this.hideMentionDropdown();
        this.textarea.focus();
      }

      // Get cursor position for dropdown placement
      getCursorPosition() {
        const textareaRect = this.textarea.getBoundingClientRect();
        const style = window.getComputedStyle(this.textarea);
        
        // Create a temporary div to measure text
        const div = document.createElement('div');
        div.style.position = 'absolute';
        div.style.visibility = 'hidden';
        div.style.whiteSpace = 'pre-wrap';
        div.style.font = style.font;
        div.style.fontSize = style.fontSize;
        div.style.fontFamily = style.fontFamily;
        div.style.padding = style.padding;
        div.style.border = style.border;
        div.style.width = style.width;
        div.style.wordWrap = 'break-word';
        
        const text = this.textarea.value.substring(0, this.textarea.selectionStart);
        div.textContent = text;
        
        document.body.appendChild(div);
        const rect = div.getBoundingClientRect();
        document.body.removeChild(div);
        
        return {
          left: textareaRect.left + rect.width,
          top: textareaRect.top
        };
      }

      // Update character count display
      updateCharacterCount() {
        const count = this.textarea.value.length;
        if (this.helpElement) {
          this.helpElement.textContent = count + '/1000 caractere';
          // Add warning class if close to limit
          if (count > 900) {
            this.helpElement.classList.add('warning');
          } else {
            this.helpElement.classList.remove('warning');
          }
        }
      }
    }

// Comment Sorting Manager (same behavior as on single-manga)
class CommentSorter {
  constructor() {
    this.commentsList = document.querySelector('.comments-list');
    this.sortButtons = document.querySelectorAll('.sort-btn');
    this.currentSort = 'newest';
    
    this.init();
  }

  init() {
    this.sortButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Update active button
        this.sortButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const sortType = btn.dataset.sort;
        this.sortComments(sortType);
      });
    });
  }

  sortComments(sortType) {
    if (!this.commentsList) return;

    // CRITICAL: Select ONLY top-level comments (not replies)
    const comments = Array.from(this.commentsList.querySelectorAll(':scope > .comment'));
    this.commentsList.dataset.sortType = sortType;

    comments.sort((a, b) => {
      const timeA = parseInt(a.dataset.time || 0);
      const timeB = parseInt(b.dataset.time || 0);
      const likesA = parseInt(a.dataset.likes || 0);
      const likesB = parseInt(b.dataset.likes || 0);

      switch(sortType) {
        case 'newest':
          return timeB - timeA;
        case 'oldest':
          return timeA - timeB;
        case 'liked':
          return likesB - likesA;
        default:
          return 0;
      }
    });

    // Helper: Get comment block (comment + button + replies as one unit)
    const getCommentBlock = (comment) => {
      const commentId = comment.dataset.commentId || comment.id.replace('comment-', '');
      
      // Find the toggle button and replies via data attributes, not by position.
      const btn = document.querySelector(
        `.toggle-replies[data-comment-id="${commentId}"]`
      );
      const replies = document.querySelector(
        `.comment-replies[data-parent-id="${commentId}"]`
      );
      
      return [comment, btn, replies].filter(Boolean);
    };

    // Animate sorting
    comments.forEach(comment => {
      comment.style.opacity = '0.7';
      comment.style.transform = 'translateY(5px)';
    });

    setTimeout(() => {
      // Reattach comments with their full blocks (comment + button + replies)
      comments.forEach(comment => {
        getCommentBlock(comment).forEach(el => {
          this.commentsList.appendChild(el);
        });
      });

      comments.forEach(comment => {
        comment.style.opacity = '1';
        comment.style.transform = 'translateY(0)';
      });
      
      // Reset all replies to hidden after sort (using classList instead of inline style)
      document.querySelectorAll('.comment-replies').forEach(replies => {
        replies.classList.remove('open');
        replies.style.display = 'none'; // Explicit inline style
      });
    }, 100);
  }
}
    </script>

    <!-- CHAPTER COMMENT FORM AJAX HANDLER -->
    <script>
    function updateSortVisibility() {
      const block = document.querySelector('.comments-sort-block');
      const list = document.querySelector('.comments-list');
      if (!block) return;
      if (list && list.querySelector(':scope > .comment')) {
        block.style.display = '';
      } else {
        block.style.display = 'none';
      }
    }

    document.addEventListener('DOMContentLoaded', function() {
      updateSortVisibility();
      // Initialize text formatter if textarea exists
      const textarea = document.getElementById('manga-comment-text');
      if (textarea) {
        new CommentFormatter('#manga-comment-text');
      }

      // Initialize comment sorter (same behavior as single-manga)
      if (typeof CommentSorter === 'function') {
        new CommentSorter();
      }
      
      // Constants used in comment handler
      const MIN_COMMENT_DELAY = 5000; // 5 seconds anti-spam
      const commentForm = document.getElementById('manga-comment-form');
      const submitBtn = document.getElementById('submit-manga-comment');
      const commentText = document.getElementById('manga-comment-text');
      const messageDiv = document.getElementById('comment-message');

      if (commentForm && submitBtn) {
        submitBtn.addEventListener('click', function(e) {
          e.preventDefault();

          // must be logged in client-side as well
          if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
            showMessage('You must be logged in to comment.', 'error');
            return;
          }

          // Rate limit: 1 comment every 5 seconds
          const now = Date.now();
          const lastSubmit = window._lastMangaCommentSubmit || 0;
          if (now - lastSubmit < MIN_COMMENT_DELAY) {
            const waitSeconds = Math.ceil((MIN_COMMENT_DELAY - (now - lastSubmit)) / 1000);
            showMessage('Wait ' + waitSeconds + ' seconds before posting again.', 'error');
            return;
          }

          // Validate
          if (!commentText.value.trim()) {
            showMessage('Comment cannot be empty.', 'error');
            return;
          }

          // Disable button during submission
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Posting...';

          // Prepare data
          const formData = new FormData();
          formData.append('action', 'mangayummy_add_chapter_comment');
          formData.append('post_id', commentForm.dataset.postId);
          formData.append('comment', commentText.value);
          
          // Get nonce from the nonce field inside the form
          const nonceField = commentForm.querySelector('input[name="nonce"]');
          if (nonceField) {
            formData.append('nonce', nonceField.value);
          }

          // Send AJAX request
          fetch(ya_ajax.ajax_url, {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              showMessage(data.data.message, 'success');
              commentText.value = '';

              // Clear GIF preview after successful post
              const gifPreview = document.getElementById('gif-preview');
              if (gifPreview) {
                gifPreview.style.display = 'none';
                gifPreview.innerHTML = '';
              }

              // Insert server-rendered HTML (single source of truth)
              if (data.data && data.data.html) {
                let list = document.querySelector('.comments-list');
                
                // If no comments exist, create the list container and remove "no comments" message
                if (!list) {
                  const wrapper = document.querySelector('.comments-list-wrapper');
                  if (wrapper) {
                    const noComments = wrapper.querySelector('.no-comments');
                    if (noComments) noComments.remove();
                    
                    list = document.createElement('div');
                    list.className = 'comments-list';
                    list.setAttribute('data-sort-type', 'newest');
                    wrapper.appendChild(list);
                  }
                }
                
                if (list) {
                  // Remove "no comments" message if it still exists
                  const noComments = document.querySelector('.no-comments');
                  if (noComments) {
                    noComments.remove();
                  }
                  
                  // prepend the HTML returned by server
                  list.insertAdjacentHTML('afterbegin', data.data.html);
                  
                  // Remove chapter-related markup from newly injected comment (on single-chapter page)
                  const newComment = list.firstElementChild;
                  if (newComment && document.body.classList.contains('single-chapter')) {
                    newComment.querySelectorAll('.comment-chapter-ref, .chapter-badge')
                      .forEach(el => el.remove());
                  }
                  
                  // Reinitialize event listeners for the newly added comment
                  attachCommentEventListeners();
                  updateSortVisibility();
                  
                  // Check if new comment needs "show more" button
                  if (window.checkCommentTextHeights) {
                    window.checkCommentTextHeights();
                  }
                }
              }
              // Update counter
              updateCommentCounter();
              
              // Clear browser history to prevent form resubmission alert
              window.history.replaceState(null, '', window.location.href);
            } else {
              showMessage(data.data || 'Error posting comment.', 'error');
            }
          })
          .catch(error => {
            console.error('Error:', error);
            showMessage('Connection error.', 'error');
          })
          .finally(() => {
            // Re-enable button
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa fa-send"></i> Post comment';
          });
        });
      }

      function attachCommentEventListeners() {
        // Attach like/dislike handlers to newly added comments
        const likes = document.querySelectorAll('.comment-like:not([data-bound])');
        const dislikes = document.querySelectorAll('.comment-dislike:not([data-bound])');
        
        const handleReaction = (btn) => {
          btn.setAttribute('data-bound', '1');
          
          btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            // Prevent double-click
            if (btn.dataset.processing === '1') return;
            btn.dataset.processing = '1';
            
            const commentId = btn.dataset.id;
            const action = btn.dataset.action;
            
            if (!commentId || !action) {
              btn.dataset.processing = '0';
              return;
            }

            const formData = new FormData();
            formData.append('action', 'mangayummy_react_comment');
            // Use mangayummy_comments.nonce (the correct nonce for comments)
            const nonce = typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.nonce : (typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
            formData.append('nonce', nonce);
            formData.append('comment_id', commentId);
            formData.append('reaction', action);

            fetch((typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : (typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '')), {
              method: 'POST',
              body: formData
            })
            .then(r => r.json())
            .then(res => {
              if (res.success) {
                const box = btn.closest('.comment-actions');
                if (box) {
                  // Update counts
                  const likeBtn = box.querySelector('.comment-like');
                  const dislikeBtn = box.querySelector('.comment-dislike');
                  
                  if (likeBtn) likeBtn.querySelector('.count').textContent = res.data.likes;
                  if (dislikeBtn) dislikeBtn.querySelector('.count').textContent = res.data.dislikes;

                  // Update active state - remove from both buttons first
                  if (likeBtn) likeBtn.classList.remove('active');
                  if (dislikeBtn) dislikeBtn.classList.remove('active');

                  // Add active to correct button
                  if (res.data.current) {
                    const activeBtn = box.querySelector('.comment-' + res.data.current);
                    if (activeBtn) activeBtn.classList.add('active');
                  }
                }
              } else {
                console.error('React error:', res);
              }
            })
            .catch(err => console.error('React error:', err))
            .finally(() => {
              btn.dataset.processing = '0';
            });
          });
        };

        likes.forEach(handleReaction);
        dislikes.forEach(handleReaction);
      }

      function updateCommentCounter() {
        const commentCount = document.querySelectorAll('.comments-list .comment').length;
        const counter = document.querySelector('.tabs-li[data-id="#comments-tab"] .count');
        if (counter) {
          counter.textContent = commentCount;
        }
      }

      function showMessage(message, type) {
        messageDiv.style.display = 'block';
        messageDiv.className = 'comment-message ' + type;
        messageDiv.innerHTML = '<i class="fa ' + (type === 'success' ? 'fa-check' : 'fa-exclamation') + '"></i> ' + message;
        
        // Auto hide after 5 seconds
        setTimeout(() => {
          messageDiv.style.display = 'none';
        }, 5000);
      }
      // make available outside this DOMContentLoaded closure
      window.showMessage = showMessage;
      
      // Initialize event listeners for existing comments
      attachCommentEventListeners();
      
      // CommentFormatter is already initialized above
      // const commentFormatter = new CommentFormatter('#manga-comment-text');
    });
    </script>

    <!-- âœ… Delete confirm modal -->
    <div id="deleteModal" class="modal">
      <div class="modal-box">
        <p>Are you sure you want to delete this comment?</p>
        <button type="button" id="confirmDelete">Yes</button>
        <button type="button" id="cancelDelete">No</button>
      </div>
    </div>

    <!-- âœ… Report comment modal (like YummyAnime) -->
    <div id="reportModal" class="report-modal">
      <div class="report-box">
        <button type="button" class="report-close">×</button>
        <h3>Report a comment</h3>
        
        <ul class="report-list">
          <li><button type="button" data-reason="spoiler">Spoiler</button></li>
          <li><button type="button" data-reason="limbaj_obscen">Obscene language</button></li>
          <li><button type="button" data-reason="insulte">Insulting other participants</button></li>
          <li><button type="button" data-reason="offtopic">Off-topic or nonsensical comment</button></li>
          <li><button type="button" data-reason="link">Link to a third-party website</button></li>
        </ul>
      </div>
    </div>

    <!-- âœ… Toast notification -->
    <div id="toast" class="toast"></div>

    <?php if (get_comments_number() > 0): ?>
      <!-- BOTTOM NAVIGATION CONTROLS (Under comments) -->
      <div class="chapter-controls bottom-controls">
          <?php
          // Debug
          
          // Previous chapter: first lower index
          $prev_chapter_post = null;
          if ($current_index !== false && $current_index > 0) {
              $prev_id = $chapter_ids_sorted[$current_index - 1];
              $prev_chapter_post = get_post($prev_id);
          }
          
          if ($prev_chapter_post) {
                echo '<a href="' . esc_url(get_permalink($prev_chapter_post->ID)) . '" class="nav-btn prev"><span class="arrow left"></span> Previous</a>';
          } else {
                echo '<span class="nav-btn prev disabled"><span class="arrow left"></span> Previous</span>';
          }

          // Next chapter (or back to manga when on last chapter)
          if ($is_last_chapter) {
              echo '<a href="' . esc_url(get_permalink($manga_id)) . '" class="nav-btn next back-to-manga">Back to Manga <svg class="icon-info" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.5"></circle><circle cx="12" cy="8" r="1" fill="currentColor"></circle><line x1="12" y1="11" x2="12" y2="17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line></svg></a>';
          } else {
              $next_chapter_post = null;
              if ($current_index !== false && $current_index < count($chapter_ids_sorted) - 1) {
                  $next_id = $chapter_ids_sorted[$current_index + 1];
                  $next_chapter_post = get_post($next_id);
              }
              if ($next_chapter_post) {
                    echo '<a href="' . esc_url(get_permalink($next_chapter_post->ID)) . '" class="nav-btn next">Next <span class="arrow"></span></a>';
              } else {
                    echo '<span class="nav-btn next disabled">Next <span class="arrow"></span></span>';
              }
          }
          ?>
      </div>
    <?php endif; ?>

</main>

<!-- CHAPTER READER: Select dropdown navigation -->
<script>
// Custom Chapter Dropdown Handler
document.addEventListener('DOMContentLoaded', function() {
    var dropdown = document.querySelector('.chapter-dropdown');
    if (!dropdown) return;
    
    var button = dropdown.querySelector('.chapter-current');
    var list = dropdown.querySelector('.chapter-list');
    var items = list.querySelectorAll('li');
    
    // Toggle dropdown on button click
    button.addEventListener('click', function(e) {
        e.stopPropagation();
        button.classList.toggle('open');
        list.classList.toggle('open');
    });
    
    // Handle item click
    items.forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            var url = this.getAttribute('data-url');
            if (url) {
                window.location.href = url;
            }
        });
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!dropdown.contains(e.target)) {
            button.classList.remove('open');
            list.classList.remove('open');
        }
    });
});
</script>

<!-- âœ… Comment menu (3 dots - edit/delete/report) + Delete + Report + Spoilers - FULL FROM SINGLE-MANGA -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  // âœ… Comment menu (3 dots - edit/delete/report)
  document.addEventListener('click', e => {
    // Toggle menu
    const menuBtn = e.target.closest('.comment-menu-btn');
    if (menuBtn) {
      const menu = menuBtn.nextElementSibling;
      if (menu && menu.classList.contains('comment-menu-dropdown')) {
        if (menu.children.length === 0) {
          menu.textContent = 'No options';
          menu.style.display = 'block';
        } else {
          menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }
      }
      return;
    }
    
    // Close all menus when clicking outside
    document.querySelectorAll('.comment-menu-dropdown').forEach(m => m.style.display = 'none');
  });
  
  // Show/hide options based on user role
  document.querySelectorAll('.comment').forEach(comment => {
    const authorId = comment.dataset.authorId;
    const currentId = comment.dataset.currentUserId;
    const isGuestComment = comment.dataset.isGuestComment === 'true';
    const isCurrentUserGuest = currentId === '0' || !currentId;
    
    if (isGuestComment && isCurrentUserGuest) {
      return;
    }
    
    if (authorId && currentId) {
      if (authorId !== currentId) {
        comment.querySelector('.comment-edit')?.remove();
        comment.querySelector('.comment-delete')?.remove();
      } else {
        comment.querySelector('.comment-report')?.remove();
      }
    }
  });
  
  // âœ… EDIT INLINE
  document.addEventListener('click', e => {
    if (e.target.classList.contains('comment-edit')) {
      const body = e.target.closest('.comment').querySelector('.comment-body');
      const text = body.querySelector('.comment-text');
      const moreBtn = body.querySelector('.more-text');
      const textarea = body.querySelector('.comment-edit-textarea');
      const actions = body.querySelector('.comment-edit-actions');
      
      // Show full text during editing
      text.classList.remove('hide-text');
      text.classList.add('show-text');
      if (moreBtn) moreBtn.style.display = 'none';
      
      textarea.value = text.textContent.trim();
      text.style.display = 'none';
      textarea.style.display = 'block';
      actions.style.display = 'flex';
      textarea.focus();
    }
    
    if (e.target.classList.contains('comment-cancel')) {
      const body = e.target.closest('.comment-body');
      const text = body.querySelector('.comment-text');
      
      // Reset to truncated state
      text.classList.remove('show-text');
      text.classList.add('hide-text');
      
      text.style.display = 'block';
      body.querySelector('.comment-edit-textarea').style.display = 'none';
      body.querySelector('.comment-edit-actions').style.display = 'none';
      
      // Restore truncation state after cancelling
      if (window.checkCommentTextHeights) {
        window.checkCommentTextHeights();
      }
    }
    
    if (e.target.classList.contains('comment-save')) {
      const comment = e.target.closest('.comment');
      const body = comment.querySelector('.comment-body');
      const textarea = body.querySelector('.comment-edit-textarea');
      const commentId = comment.dataset.commentId;
      
      const formData = new FormData();
      formData.append('action', 'mangayummy_edit_comment');
      formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
      formData.append('comment_id', commentId);
      formData.append('content', textarea.value);
      
      fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          const textDiv = body.querySelector('.comment-text');
          textDiv.innerHTML = res.data.rendered;

          // Show edited label in comment body
          const commentEl = e.target.closest('.comment');
          if (commentEl) {
            const bodyEl = commentEl.querySelector('.comment-body');
            if (bodyEl && !bodyEl.querySelector('.comment-edited')) {
              const editedSpan = document.createElement('span');
              editedSpan.className = 'comment-edited';
              editedSpan.textContent = '(edited)';
              bodyEl.insertBefore(editedSpan, bodyEl.querySelector('.more-text'));
            }
          }

          textDiv.style.display = 'block';
          textarea.style.display = 'none';
          body.querySelector('.comment-edit-actions').style.display = 'none';
          
          // Reset to hide-text class and check if truncation is needed
          textDiv.classList.remove('show-text');
          textDiv.classList.add('hide-text');
          if (window.checkCommentTextHeights) {
            window.checkCommentTextHeights();
          }
        } else {
          alert('Error: ' + (res.data?.message || 'Unknown'));
        }
      })
      .catch(err => {
        console.error('Edit error:', err);
        alert('Error editing comment');
      });
    }
  });
  
  // âœ… DELETE with confirm modal - FULL VERSION WITH NESTED REPLY HANDLING
  let deleteTarget = null;
  
  document.addEventListener('click', e => {
    if (e.target.classList.contains('comment-delete')) {
      deleteTarget = e.target.closest('.comment');
      document.getElementById('deleteModal').style.display = 'block';
    }
  });
  
  document.getElementById('cancelDelete').onclick = () => {
    document.getElementById('deleteModal').style.display = 'none';
  };
  
  document.getElementById('confirmDelete').onclick = () => {
    if (!deleteTarget) return;
    
    const formData = new FormData();
    formData.append('action', 'mangayummy_delete_comment');
    formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
    formData.append('comment_id', deleteTarget.dataset.commentId);
    
    const deletedCommentId = deleteTarget.dataset.commentId;
    const deletedParentId = deleteTarget.dataset.parentId;
    
    fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
      method: 'POST',
      body: formData
    })
    .then(r => r.json())
    .then(res => {
      if (res.success || res === '') {
        const deletedCommentId = deleteTarget.dataset.commentId;
        let deletedParentId = deleteTarget.dataset.parentId;
        
        // If this comment is a reply, traverse UP to find the root parent comment
        if (deletedParentId) {
          // This reply's parent - but we might need to go UP further if parent is also a reply
          let container = deleteTarget.closest('.comment-replies');
          if (container) {
            const firstLevelParentId = container.dataset.parentId;
            
            // Check if we need to go UP further (nested replies)
            let currentContainer = container;
            let rootParentId = firstLevelParentId;
            while (currentContainer) {
              const parentComment = currentContainer.previousElementSibling;
              if (parentComment && parentComment.classList.contains('comment')) {
                const parentId = parentComment.dataset.commentId;
                // Check if this comment also has a parent (it's a reply)
                const parentParentId = parentComment.dataset.parentId;
                if (parentParentId && parentParentId !== '0') {
                  // This is also a reply, keep going up
                  currentContainer = parentComment.closest('.comment-replies');
                  if (currentContainer) {
                    rootParentId = currentContainer.dataset.parentId;
                  }
                } else {
                  // This is a root comment
                  rootParentId = parentId;
                  break;
                }
              } else {
                break;
              }
            }
            deletedParentId = rootParentId;
          }
        }
        
        // fade out before removing
        const targetComment = deleteTarget;
        if (targetComment) {
            targetComment.classList.add('fade-out');
        }
        setTimeout(() => {
            if (targetComment) {
                targetComment.remove();
            }
            document.getElementById('deleteModal').style.display = 'none';
            showMessage(res.data?.message || 'Comment deleted.', 'error');
            
            // Update comment count
            const countSpan = document.querySelector('.tabs-li[data-id="#comments-tab"] .count');
            if (countSpan) {
              const currentCount = parseInt(countSpan.textContent) || 0;
              countSpan.textContent = Math.max(0, currentCount - 1);
            }
            updateSortVisibility();
        }, 300);
        const countSpan = document.querySelector('.tabs-li[data-id="#comments-tab"] .count');
        if (countSpan) {
          const currentCount = parseInt(countSpan.textContent) || 0;
          countSpan.textContent = Math.max(0, currentCount - 1);
        }
        
        // ========== UPDATE TOGGLE BUTTON IF THIS WAS A REPLY ==========
        if (deletedParentId) {
          // Wait for DOM to fully update - 100ms should be safe
          setTimeout(() => {
            const toggleBtn = document.querySelector(`.toggle-replies[data-comment-id="${deletedParentId}"]`);
            const repliesContainer = document.querySelector(`.comment-replies[data-parent-id="${deletedParentId}"]`);
            
            if (toggleBtn && repliesContainer) {
              // Count remaining replies AFTER DOM update - re-query to be sure
              const remainingReplies = repliesContainer.querySelectorAll(':scope > .comment').length;
              
              if (remainingReplies === 0) {
                // No more replies - DELETE container completely, not just hide
                repliesContainer.remove();
                toggleBtn.remove();
              } else {
                // Replies still exist - keep button visible and container open
                toggleBtn.style.display = 'inline-block';
                toggleBtn.textContent = 'Hide replies (' + remainingReplies + ')';
                repliesContainer.style.display = 'block';
                repliesContainer.classList.add('open');
                toggleBtn.dataset.expanded = 'true';
              }
            }
          }, 100);
        }
        
        deleteTarget = null;
      }
    })
    .catch(err => console.error('Delete error:', err));
  };
  
  // âœ… REPORT comment
  let reportCommentId = null;
  
  document.addEventListener('click', e => {
    if (e.target.classList.contains('comment-report')) {
      reportCommentId = e.target.closest('.comment').dataset.commentId;
      document.getElementById('reportModal').classList.add('show');
    }
  });
  
  document.querySelector('.report-close').addEventListener('click', () => {
    document.getElementById('reportModal').classList.remove('show');
  });
  
  document.querySelectorAll('.report-list button').forEach(btn => {
    btn.addEventListener('click', () => {
      const reason = btn.dataset.reason;
      const nonceField = document.querySelector('input[name="nonce"]');
      const nonce = nonceField ? nonceField.value : '';
      
      const formData = new FormData();
      formData.append('action', 'report_comment');
      formData.append('nonce', nonce);
      formData.append('comment_id', reportCommentId);
      formData.append('reason', reason);
      
      fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          const comment = document.querySelector('[data-comment-id="' + reportCommentId + '"]');
          if (comment) {
            const reportBtn = comment.querySelector('.comment-report');
            if (reportBtn) reportBtn.remove();
          }
        }
        document.getElementById('reportModal').classList.remove('show');
      })
      .catch(err => {
        console.error('Report error:', err);
        document.getElementById('reportModal').classList.remove('show');
      });
    });
  });
});

function initSpoilerHandlers() {
  function toggleSpoiler(el) {
    el.classList.toggle('revealed');
  }

  document.addEventListener('click', function(e) {
    const spoiler = e.target.closest('.spoiler');
    if (spoiler) {
      toggleSpoiler(spoiler);
    }
  });

  document.addEventListener('touchstart', function(e) {
    const spoiler = e.target.closest('.spoiler');
    if (spoiler) {
      e.preventDefault();
      toggleSpoiler(spoiler);
    }
  }, { passive: false });
}
</script>

<?php 
// Prefetch next chapter for faster navigation
if (isset($next_chapter_post) && $next_chapter_post) {
    $next_url = get_permalink($next_chapter_post->ID);
    echo '<link rel="prefetch" href="' . esc_url($next_url) . '" as="document">' . "\n";
}
?>

</content>

<?php get_footer(); ?>


