<?php
/**
 * Search Results Template
 * Displays search results for manga
 */

get_header();
?>

<main class="main-content">
    <section class="ya-search">
        <input type="text" placeholder="GĂSEȘTE MANGA DUPĂ TITLU" value="<?php echo get_search_query(); ?>">
        <a href="<?php echo home_url('/browse/'); ?>" class="ya-filter"><i class="fa fa-filter"></i></a>
        <div class="ya-search-results"></div>
    </section>
    <div class="search-info">
        <?php
        $search_query = get_search_query();
        $total_results = $wp_query->found_posts;
        if ($search_query) {
            echo '<p class="search-summary">';
            if ($total_results > 0) {
                echo 'Am găsit <strong>' . $total_results . '</strong> rezultat' . ($total_results == 1 ? '' : 'e') . ' pentru "<strong>' . esc_html($search_query) . '</strong>"';
            } else {
                echo 'Nu am găsit rezultate pentru "<strong>' . esc_html($search_query) . '</strong>"';
            }
            echo '</p>';
        }
        ?>
    </div>

    <section class="search-results">
        <div class="manga-grid">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="manga-card">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>" loading="lazy" decoding="async">
                        </a>
                        <?php
                        $manga_type = get_post_meta(get_the_ID(), '_manga_type', true);
                        $manga_status = get_post_meta(get_the_ID(), '_status', true);
                        $type_display = '';
                        if ($manga_type) {
                          $type_labels = ['manga' => 'Manga', 'manhua' => 'Manhua', 'manhwa' => 'Manhwa'];
                          $type_display = $type_labels[$manga_type] ?? '';
                        }

                        $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
                        $status_display = '';
                        if ($manga_status) {
                          $status_labels = ['ongoing' => 'În curs', 'completed' => 'Finalizat', 'hiatus' => 'Pus pe pauză', 'dropped' => 'Abandonat'];
                          $status_display = $status_labels[$manga_status] ?? '';
                        }
                        ?>
                        <div class="poster-rating-overlay">
                          <div class="overlay-left">
                            <?php if ($type_display): ?>
                              <span class="manga-type <?php echo esc_attr($type_class); ?>"><?php echo esc_html($type_display); ?></span>
                            <?php endif; ?>
                            <?php if ($status_display): ?>
                              <span class="manga-status status-<?php echo esc_attr($manga_status); ?>"><?php echo esc_html($status_display); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <?php 
                        $is_18_content = get_post_meta(get_the_ID(), '_manga_18', true);
                        if ($is_18_content): 
                        ?>
                          <div class="manga-18-overlay">18+</div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <h3 class="manga-title-overlay">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h3>
                </div>
            <?php endwhile; else : ?>
                <div class="no-results">
                    <h3>Niciun rezultat găsit</h3>
                    <p>Încearcă să cauți cu alte cuvinte sau verifică ortografia.</p>
                    <a href="<?php echo home_url('/browse/'); ?>" class="advanced-search-link">Browse</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if (have_posts() && $wp_query->max_num_pages > 1) : ?>
        <div class="pagination-wrapper">
            <?php
            echo paginate_links(array(
                'total' => $wp_query->max_num_pages,
                'prev_text' => '‹',
                'next_text' => '›',
            ));
            ?>
        </div>
        <?php endif; ?>
    </section>
</main>

<?php get_footer(); ?>