<?php
/**
 * Template Name: Manga Indisponibil
 */
get_header();
?>

<main class="site-main unavailable-page">
  <div class="unavailable-container">
    <div class="unavailable-card">
      <h1 class="unavailable-title">Catalogul Manga</h1>
      <p class="unavailable-message">Ne pare rău, dar catalogul manga nu este disponibil în acest moment.</p>
      <p class="unavailable-subtitle">Te rugăm să încerci din nou mai târziu.</p>
      <a href="<?php echo home_url(); ?>" class="unavailable-button">← Înapoi</a>
    </div>
  </div>
</main>

<?php
get_footer();
?>
