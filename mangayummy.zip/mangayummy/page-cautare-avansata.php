﻿<?php
/**
 * Template Name: Advanced Search
 * Description: Advanced search functionality
 */
get_header();
?>

<?php
// expose reader preferences to the advanced search page so we can
// pre-block genres saved in user settings. preferences helper returns
// an array with defaults even for guests (empty allowed list).
$advanced_reader_prefs = mangayummy_get_reader_prefs();
?>

<script>
window.YA_READER_PREFS = <?php echo wp_json_encode($advanced_reader_prefs); ?>;
</script>

<main id="main" class="site-main">
  <section class="cautare-avansata">
    <div class="container">

      <!-- SEARCH SECTION FROM FRONT PAGE -->
      <section class="ya-search">
                <input type="text" class="ya-search-input" placeholder="FIND MANGA BY TITLE" value="<?php echo isset($_GET['s']) ? esc_attr($_GET['s']) : ''; ?>">
                                <button class="ya-filter"><i class="fa fa-filter"></i> Browse</button>
        <div class="ya-search-results"></div>
      </section>

      <div class="browser-layout">
        <div class="filters-sidebar">
          <div class="filters-content">
          <div class="filters-section">
                        <h3>SORT BY</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                                <div class="dropdown-option" data-value="updated">Update date</div>
                                <div class="dropdown-option" data-value="created">Creation date</div>
                                <div class="dropdown-option" data-value="title_asc">Title ascending</div>
                                <div class="dropdown-option" data-value="year_desc">Year descending</div>
                                <div class="dropdown-option" data-value="rating">Average score</div>
                                <div class="dropdown-option" data-value="views">Views</div>
                                <div class="dropdown-option" data-value="follows">Most followed</div>
              </div>
              <input type="hidden" id="sort-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>TYPES</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                <div class="dropdown-option" data-value="manga">Manga</div>
                <div class="dropdown-option" data-value="manhwa">Manhwa</div>
                <div class="dropdown-option" data-value="manhua">Manhua</div>
              </div>
              <input type="hidden" id="type-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>GENRES</h3>
            <div class="custom-dropdown" data-type="multiple">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-chips"></div>
              <div class="dropdown-menu" id="genre-menu">
                <div class="genre-search-container">
                                    <input type="text" class="genre-search" placeholder="Search genres..." autocomplete="off">
                </div>
                                <div class="dropdown-option" data-value="">Any</div>
                <!-- Genres will be loaded dynamically -->
              </div>
              <input type="hidden" id="genre-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>LANGUAGE</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                                <div class="dropdown-option" data-value="ro">Romanian</div>
                                <div class="dropdown-option" data-value="en">English</div>
              </div>
              <input type="hidden" id="language-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>RELEASE STATUS</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                                <div class="dropdown-option" data-value="releasing">Releasing</div>
                                <div class="dropdown-option" data-value="finished">Finished</div>
                                <div class="dropdown-option" data-value="cancelled">Cancelled</div>
                                <div class="dropdown-option" data-value="hiatus">Hiatus</div>
              </div>
              <input type="hidden" id="status-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>RELEASE YEAR</h3>
            <div class="year-inputs">
                            <input type="number" id="year-from" placeholder="From" min="1900" max="2099">
                            <input type="number" id="year-to" placeholder="To" min="1900" max="2099">
            </div>
          </div>

          <div class="filters-section">
                        <h3>AUTHORS</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu" id="author-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                <!-- Authors will be loaded dynamically -->
              </div>
              <input type="hidden" id="author-select" value="">
            </div>
          </div>

          <div class="filters-section">
                        <h3>ARTISTS</h3>
            <div class="custom-dropdown" data-type="single">
              <div class="dropdown-trigger">
                                <span class="dropdown-value">Any</span>
                                <span class="dropdown-arrow">&#9662;</span>
              </div>
              <div class="dropdown-menu" id="artist-menu">
                                <div class="dropdown-option" data-value="">Any</div>
                <!-- Artists will be loaded dynamically -->
              </div>
              <input type="hidden" id="artist-select" value="">
            </div>
          </div>

          </div>

          <div class="filters-actions">
                        <button id="reset-filters" class="filter-btn secondary">RESET</button>
                        <button id="lucky-btn" class="filter-btn">I'M FEELING LUCKY</button>
          </div>
        </div>

        <div class="results-main">
          <div class="results-header">
            <div class="results-count">
                            <span id="total-items">Loading...</span>
            </div>
            <div class="results-actions">
            </div>
          </div>

          <div id="manga-grid" class="manga-grid">
            <!-- Manga cards will be loaded here -->
            <div class="loading-state">
              <div class="loading-spinner"></div>
                            <p>Loading manga...</p>
            </div>
          </div>

          <div class="pagination" id="pagination-container"></div>

        </div>
      </div>

    </div>
  </section>
</main>

<script>
// global timers must be declared with var to avoid TDZ when applyFilters
var mangayummy_apply_filters_timer = null;
var mangayummy_last_filters_json = null;
document.addEventListener('DOMContentLoaded', function() {
    function parseAjaxJson(raw) {
        const cleaned = String(raw || '').replace(/^\uFEFF+/, '').trim();
        if (!cleaned || cleaned === '0') {
            throw new Error('Invalid AJAX response: ' + (cleaned || '(empty)'));
        }
        return JSON.parse(cleaned);
    }

    function postAjax(data) {
        return fetch(ya_ajax.ajax_url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(data)
        })
        .then(response => response.text())
        .then(parseAjaxJson);
    }

    // Initialize custom dropdowns
    initCustomDropdowns();

    // Load dynamic options
    loadGenres();
    loadAuthors();
    loadArtists();

    // Load saved filter selections from localStorage
    loadSavedFilters();

    // Parse URL parameters and pre-populate filters (URL overrides localStorage)
    populateFiltersFromURL();

    // If URL contains author/artist, pre-fill hidden inputs & visible labels _before_ AJAX option load
    // This prevents the unfiltered results flash and applies the filter immediately.
    (function() {
        const urlParams = new URLSearchParams(window.location.search);
        const authorParam = urlParams.get('filter_author');
        const artistParam = urlParams.get('filter_artist');
        let preApplied = false;

        if (authorParam) {
            const hidden = document.getElementById('author-select');
            if (hidden) {
                hidden.value = authorParam;
                const dropdown = hidden.closest('.custom-dropdown');
                if (dropdown) dropdown.querySelector('.dropdown-value').textContent = decodeURIComponent(authorParam).replace(/[-_]/g, ' ');
                localStorage.setItem('mangayummy_filter_author-select', hidden.value);
                preApplied = true;
            }
        }

        if (artistParam) {
            const hidden = document.getElementById('artist-select');
            if (hidden) {
                hidden.value = artistParam;
                const dropdown = hidden.closest('.custom-dropdown');
                if (dropdown) dropdown.querySelector('.dropdown-value').textContent = decodeURIComponent(artistParam).replace(/[-_]/g, ' ');
                localStorage.setItem('mangayummy_filter_artist-select', hidden.value);
                preApplied = true;
            }
        }

        if (preApplied) {
            window.mangayummy_initial_filters_applied = true;
            // apply immediately so the result grid shows filtered content without flash
            applyFilters();
        }
    })();

    // Initialize the browser after a longer delay to allow URL processing and AJAX loading
    function initAdvancedSearch() {
        // Wait until the localized AJAX object is available.
        if (typeof ya_ajax === 'undefined') {
            setTimeout(initAdvancedSearch, 100);
            return;
        }

        if (!window.mangayummy_initial_filters_applied) {
            loadInitialManga(getInitialPage());
        }
    }

    // Start initialization after a small delay so other scripts can register their globals.
    setTimeout(initAdvancedSearch, 300);

    // Filter event listeners
    document.getElementById('reset-filters').addEventListener('click', resetFilters);
    document.getElementById('lucky-btn').addEventListener('click', feelingLucky);

    // Search input event listener
    const searchInput = document.querySelector('.ya-search input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            // Debounce search to avoid too many requests
            clearTimeout(searchInput.searchTimeout);
            searchInput.searchTimeout = setTimeout(function() {
                applyFilters();
            }, 300);
        });
    }

    // Auto-apply filters on change - now handled by custom dropdowns
    // the explicit listeners below are unnecessary because each dropdown click
    // already calls applyFilters(). we keep them commented out in case we revert
    // to native selects later.
    // document.getElementById('sort-select').addEventListener('change', applyFilters);
    // document.getElementById('type-select').addEventListener('change', applyFilters);
    // document.getElementById('genre-select').addEventListener('change', applyFilters);
    document.getElementById('language-select').addEventListener('change', applyFilters);
    document.getElementById('status-select').addEventListener('change', applyFilters);
    // Year inputs: apply on change and on input (debounced) so typing updates results immediately
    const yearFromEl = document.getElementById('year-from');
    const yearToEl = document.getElementById('year-to');
    function debounce(fn, delay = 300) {
        let t;
        return function(...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), delay); };
    }

    // Helper: keep year validation internal-only (do NOT show messages to users)
    // Stores the error text on the container dataset for debugging and logs to console.
    function showYearValidation(msg) {
        const container = document.querySelector('.year-inputs');
        if (container) {
            if (msg) {
                // store non-visible error for dev/debug; not shown in UI
                container.setAttribute('data-year-error', msg);
            } else {
                container.removeAttribute('data-year-error');
            }
        }
        if (msg) {
            // console.warn('Year validation (hidden):', msg); // suppressed
        }
    }

    if (yearFromEl) {
        yearFromEl.addEventListener('change', applyFilters);
        yearFromEl.addEventListener('input', debounce(applyFilters, 350));
        yearFromEl.addEventListener('focus', () => showYearValidation(''));
    }
    if (yearToEl) {
        yearToEl.addEventListener('change', applyFilters);
        yearToEl.addEventListener('input', debounce(applyFilters, 350));
        yearToEl.addEventListener('focus', () => showYearValidation(''));
    }
    document.getElementById('author-select').addEventListener('change', applyFilters);
    document.getElementById('artist-select').addEventListener('change', applyFilters);

    // Custom dropdown functionality

    // Global function for updating multiple selection dropdowns
    function updateMultipleSelection(dropdown, hiddenInput) {
        const selectedOptions = dropdown.querySelectorAll('.dropdown-option.selected:not([data-value=""])');
        const blockedOptions = dropdown.querySelectorAll('.dropdown-option.blocked:not([data-value=""])');
        const chipsContainer = dropdown.querySelector('.dropdown-chips');
        const selectedValues = [];
        const blockedValues = [];

        chipsContainer.innerHTML = '';

        // Add selected chips (green)
        selectedOptions.forEach(option => {
            const value = option.dataset.value;
            const text = option.textContent;
            selectedValues.push(value);

            // Create chip
            const chip = document.createElement('div');
            chip.className = 'dropdown-chip chip-selected';
            chip.innerHTML = `${text}<span class="chip-remove" data-value="${value}">&times;</span>`;
            chipsContainer.appendChild(chip);
        });

        // Add blocked chips (red)
        blockedOptions.forEach(option => {
            const value = option.dataset.value;
            const text = option.textContent;
            blockedValues.push(value);

            // Create chip
            const chip = document.createElement('div');
            chip.className = 'dropdown-chip chip-blocked';
            chip.innerHTML = `${text}<span class="chip-remove" data-value="${value}">&times;</span>`;
            chipsContainer.appendChild(chip);
        });

        const totalChips = selectedOptions.length + blockedOptions.length;

        if (totalChips === 0) {
            dropdown.querySelector('.dropdown-value').textContent = 'Any';
            hiddenInput.value = '';
        } else {
            dropdown.querySelector('.dropdown-value').textContent = `${totalChips} selected`;
            // Store both selected and blocked values, maybe with a separator
            hiddenInput.value = selectedValues.join(',') + (blockedValues.length > 0 ? '|' + blockedValues.join(',') : '');
        }

        // Handle chip removal
        chipsContainer.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent event bubbling
            if (e.target.classList.contains('chip-remove')) {
                e.stopPropagation();
                const value = e.target.dataset.value;
                const option = dropdown.querySelector(`.dropdown-option[data-value="${value}"]`);
                if (option) {
                    option.classList.remove('selected');
                    option.classList.remove('blocked');
                    updateMultipleSelection(dropdown, hiddenInput);
                    applyFilters();
                }
            }
        });

        // Save selection to localStorage for persistence
        const dropdownId = hiddenInput.id;
        if (dropdownId) {
            localStorage.setItem('mangayummy_filter_' + dropdownId, hiddenInput.value);
        }
    }

    function initCustomDropdowns() {
        document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
            const trigger = dropdown.querySelector('.dropdown-trigger');
            const menu = dropdown.querySelector('.dropdown-menu');
            const hiddenInput = dropdown.querySelector('input[type="hidden"]');
            const type = dropdown.dataset.type;

            // Toggle dropdown
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                
                // If this dropdown is already open, just close it
                if (dropdown.classList.contains('open')) {
                    dropdown.classList.remove('open');
                } else {
                    // Otherwise, close all dropdowns and open this one
                    closeAllDropdowns();
                    dropdown.classList.add('open');
                }
            });

            // Handle option selection
            menu.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent event bubbling
                if (e.target.classList.contains('dropdown-option')) {
                    e.stopPropagation(); // Extra stop for the option itself
                    const option = e.target;
                    const value = option.dataset.value;
                    const text = option.textContent;

                    if (type === 'single') {
                        // Single selection
                        dropdown.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                        option.classList.add('selected');
                        dropdown.querySelector('.dropdown-value').textContent = text;
                        hiddenInput.value = value;
                        dropdown.classList.remove('open');
                        
                        // Save selection to localStorage for persistence
                        const dropdownId = hiddenInput.id;
                        if (dropdownId) {
                            localStorage.setItem('mangayummy_filter_' + dropdownId, value);
                        }
                        
                        applyFilters();
                    } else if (type === 'multiple') {
                        // Multiple selection
                        if (value === '') {
                            // "Any" option - clear all selections
                            dropdown.querySelectorAll('.dropdown-option').forEach(opt => {
                                opt.classList.remove('selected');
                                opt.classList.remove('blocked');
                            });
                            dropdown.querySelector('.dropdown-chips').innerHTML = '';
                            dropdown.querySelector('.dropdown-value').textContent = 'Any';
                            hiddenInput.value = '';
                            dropdown.classList.remove('open');
                            applyFilters();
                        } else {
                            // Three-state selection: normal -> selected -> blocked -> normal
                            if (option.classList.contains('blocked')) {
                                // Remove blocked state (back to normal)
                                option.classList.remove('blocked');
                            } else if (option.classList.contains('selected')) {
                                // Change from selected to blocked
                                option.classList.remove('selected');
                                option.classList.add('blocked');
                            } else {
                                // Add selected state
                                option.classList.add('selected');
                            }
                            updateMultipleSelection(dropdown, hiddenInput);
                            applyFilters();
                        }
                    }
                }
            });
        });

        // Close dropdowns when clicking outside
        document.addEventListener('click', closeAllDropdowns);

        function closeAllDropdowns() {
            document.querySelectorAll('.custom-dropdown.open').forEach(dropdown => {
                dropdown.classList.remove('open');
            });
        }
    }

    // Load saved filter selections from localStorage
    function loadSavedFilters() {
        document.querySelectorAll('.custom-dropdown[data-type="single"]').forEach(dropdown => {
            const hiddenInput = dropdown.querySelector('input[type="hidden"]');
            const dropdownId = hiddenInput.id;
            
            if (dropdownId) {
                const savedValue = localStorage.getItem('mangayummy_filter_' + dropdownId);
                if (savedValue) {
                    const menu = dropdown.querySelector('.dropdown-menu');
                    const option = menu.querySelector(`.dropdown-option[data-value="${savedValue}"]`);
                    
                    if (option) {
                        // Clear existing selections
                        menu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                        
                        // Select the saved option
                        option.classList.add('selected');
                        dropdown.querySelector('.dropdown-value').textContent = option.textContent;
                        hiddenInput.value = savedValue;
                    }
                } else if (dropdownId === 'sort-select') {
                    // Default advanced search sort: most popular first
                    const menu = dropdown.querySelector('.dropdown-menu');
                    const option = menu.querySelector('.dropdown-option[data-value="views"]');
                    if (option) {
                        option.classList.add('selected');
                        dropdown.querySelector('.dropdown-value').textContent = option.textContent;
                        hiddenInput.value = 'views';
                    }
                }
            }
        });
    }

    function loadGenres() {
        postAjax({
            'action': 'mangayummy_load_genres',
            'nonce': ya_ajax.nonce
        })
        .then(data => {
            if (data.success) {
                const genreMenu = document.getElementById('genre-menu');
                // Clear existing options but keep search container
                const searchContainer = genreMenu.querySelector('.genre-search-container');
                genreMenu.innerHTML = '';
                genreMenu.appendChild(searchContainer);
                
                // Add "Any" option
                const oricareOption = document.createElement('div');
                oricareOption.className = 'dropdown-option';
                oricareOption.setAttribute('data-value', '');
                oricareOption.textContent = 'Any';
                genreMenu.appendChild(oricareOption);
                
                // Add genre options
                genreMenu.innerHTML += data.data.options;
                
                // Initialize genre search functionality
                initGenreSearch();

                // Determine genre selection based on URL or localStorage
                const urlParams = new URLSearchParams(window.location.search);
                const genresParam = urlParams.get('genres') || urlParams.get('genre');
                const blockedGenresParam = urlParams.get('blocked_genres');

                const dropdown = document.querySelector('.custom-dropdown[data-type="multiple"]');
                const hiddenInput = document.getElementById('genre-select');

                // Clear any existing selections
                genreMenu.querySelectorAll('.dropdown-option').forEach(opt => {
                    opt.classList.remove('selected');
                    opt.classList.remove('blocked');
                });

                // Apply URL-based selections
                if (genresParam) {
                    const selectedValues = genresParam.split(',').map(v => v.trim()).filter(v => v);
                    selectedValues.forEach(value => {
                        const option = genreMenu.querySelector(`.dropdown-option[data-value="${value}"]`);
                        if (option) option.classList.add('selected');
                    });
                }
                if (blockedGenresParam) {
                    const blockedValues = blockedGenresParam.split(',').map(v => v.trim()).filter(v => v);
                    blockedValues.forEach(value => {
                        const option = genreMenu.querySelector(`.dropdown-option[data-value="${value}"]`);
                        if (option) option.classList.add('blocked');
                    });
                }

                // If no URL params, fall back to localStorage
                if (!genresParam && !blockedGenresParam) {
                    const savedGenreValue = localStorage.getItem('mangayummy_filter_genre-select');
                    if (savedGenreValue) {
                        const parts = savedGenreValue.split('|');
                        const selectedValues = parts[0] ? parts[0].split(',').filter(v => v) : [];
                        const blockedValues = parts[1] ? parts[1].split(',').filter(v => v) : [];

                        selectedValues.forEach(value => {
                            const option = genreMenu.querySelector(`.dropdown-option[data-value="${value}"]`);
                            if (option) option.classList.add('selected');
                        });
                        blockedValues.forEach(value => {
                            const option = genreMenu.querySelector(`.dropdown-option[data-value="${value}"]`);
                            if (option) option.classList.add('blocked');
                        });
                    }
                }

                // Update the multiple selection display
                updateMultipleSelection(dropdown, hiddenInput);

                // If the URL contained genres/blocked_genres, re-apply filters now that they're set
                if (genresParam || blockedGenresParam) {
                    window.mangayummy_initial_filters_applied = true;
                    applyFilters();
                }
            }
        })
        .then(() => {
            // after localStorage/URL pre-selection, apply reader preferences
            applyPrefsToGenres();
        })
        .catch(error => console.error('Error loading genres:', error));
    }

    // after genres are added we honour reader preferences by blocking any
    // genres explicitly listed in prefs.genres. checked genres now mean "hide".
    function applyPrefsToGenres() {
        const prefs = window.YA_READER_PREFS || {};
        if (!prefs.genres || prefs.genres.length === 0) return;

        const genreMenu = document.getElementById('genre-menu');
        if (!genreMenu) return;
        const dropdown = document.querySelector('.custom-dropdown[data-type="multiple"]');
        const hiddenInput = document.getElementById('genre-select');

        let changed = false;
        prefs.genres.forEach(value => {
            const opt = genreMenu.querySelector(`.dropdown-option[data-value="${value}"]`);
            if (opt && !opt.classList.contains('blocked')) {
                opt.classList.add('blocked');
                changed = true;
            }
        });

        if (changed && dropdown && hiddenInput) {
            updateMultipleSelection(dropdown, hiddenInput);
        }
    }

    function loadAuthors() {
        postAjax({
            'action': 'mangayummy_load_authors',
            'nonce': ya_ajax.nonce
        })
        .then(data => {
            if (data.success) {
                const authorMenu = document.getElementById('author-menu');
                // Clear existing options except "Any"
                authorMenu.innerHTML = '<div class="dropdown-option" data-value="">Any</div>';
                // Add new options
                authorMenu.innerHTML += data.data.options;

                // If URL has ?filter_author=slug or name, pre-select it
                const urlParams = new URLSearchParams(window.location.search);
                const authorParam = urlParams.get('filter_author');
                if (authorParam) {
                    // try match by data-value (slug or exact value)
                    let match = Array.from(authorMenu.querySelectorAll('.dropdown-option')).find(opt => opt.dataset.value === authorParam);
                    if (!match) {
                        // try match by display name (case-insensitive)
                        const lower = decodeURIComponent(authorParam).replace(/[-_]/g, ' ').toLowerCase();
                        match = Array.from(authorMenu.querySelectorAll('.dropdown-option')).find(opt => opt.textContent.trim().toLowerCase() === lower);
                    }
                    if (match) {
                        const dropdown = document.querySelector('#author-select').closest('.custom-dropdown');
                        const hiddenInput = document.getElementById('author-select');
                        // clear previous selection
                        authorMenu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                        match.classList.add('selected');
                        dropdown.querySelector('.dropdown-value').textContent = match.textContent.trim();
                        hiddenInput.value = match.dataset.value || match.textContent.trim();
                        // store in localStorage for persistence
                        localStorage.setItem('mangayummy_filter_author-select', hiddenInput.value);
                        // Trigger filter
                        applyFilters();
                    }
                } else {
                    // restore from localStorage if present
                    const saved = localStorage.getItem('mangayummy_filter_author-select');
                    if (saved) {
                        const savedOpt = Array.from(authorMenu.querySelectorAll('.dropdown-option')).find(opt => opt.dataset.value === saved) || Array.from(authorMenu.querySelectorAll('.dropdown-option')).find(opt => opt.textContent.trim() === saved);
                        if (savedOpt) {
                            const dropdown = document.querySelector('#author-select').closest('.custom-dropdown');
                            const hiddenInput = document.getElementById('author-select');
                            authorMenu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                            savedOpt.classList.add('selected');
                            dropdown.querySelector('.dropdown-value').textContent = savedOpt.textContent.trim();
                            hiddenInput.value = saved;
                        }
                    }
                }
            }
        })
        .catch(error => console.error('Error loading authors:', error));
    }

    function loadArtists() {
        postAjax({
            'action': 'mangayummy_load_artists',
            'nonce': ya_ajax.nonce
        })
        .then(data => {
            if (data.success) {
                const artistMenu = document.getElementById('artist-menu');
                // Clear existing options except "Any"
                artistMenu.innerHTML = '<div class="dropdown-option" data-value="">Any</div>';
                // Add new options
                artistMenu.innerHTML += data.data.options;

                // Pre-select if URL has ?artist=slug or name
                const urlParams = new URLSearchParams(window.location.search);
                const artistParam = urlParams.get('filter_artist');                if (artistParam) {
                    let match = Array.from(artistMenu.querySelectorAll('.dropdown-option')).find(opt => opt.dataset.value === artistParam);
                    if (!match) {
                        const lower = decodeURIComponent(artistParam).replace(/[-_]/g, ' ').toLowerCase();
                        match = Array.from(artistMenu.querySelectorAll('.dropdown-option')).find(opt => opt.textContent.trim().toLowerCase() === lower);
                    }
                    if (match) {
                        const dropdown = document.querySelector('#artist-select').closest('.custom-dropdown');
                        const hiddenInput = document.getElementById('artist-select');
                        artistMenu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                        match.classList.add('selected');
                        dropdown.querySelector('.dropdown-value').textContent = match.textContent.trim();
                        hiddenInput.value = match.dataset.value || match.textContent.trim();
                        localStorage.setItem('mangayummy_filter_artist-select', hiddenInput.value);
                        applyFilters();
                    }
                } else {
                    const saved = localStorage.getItem('mangayummy_filter_artist-select');
                    if (saved) {
                        const savedOpt = Array.from(artistMenu.querySelectorAll('.dropdown-option')).find(opt => opt.dataset.value === saved) || Array.from(artistMenu.querySelectorAll('.dropdown-option')).find(opt => opt.textContent.trim() === saved);
                        if (savedOpt) {
                            const dropdown = document.querySelector('#artist-select').closest('.custom-dropdown');
                            const hiddenInput = document.getElementById('artist-select');
                            artistMenu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
                            savedOpt.classList.add('selected');
                            dropdown.querySelector('.dropdown-value').textContent = savedOpt.textContent.trim();
                            hiddenInput.value = saved;
                        }
                    }
                }
            }
        })
        .catch(error => console.error('Error loading artists:', error));
    }

    function initGenreSearch() {
        const genreSearch = document.querySelector('.genre-search');
        const genreMenu = document.getElementById('genre-menu');
        const genreOptions = genreMenu.querySelectorAll('.dropdown-option');

        genreSearch.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase().trim();
            
            genreOptions.forEach(option => {
                const optionText = option.textContent.toLowerCase();
                const isVisible = optionText.includes(searchTerm) || option.getAttribute('data-value') === '';
                
                if (isVisible) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });
        });

        // Clear search when dropdown closes
        const genreDropdown = genreMenu.closest('.custom-dropdown');
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (!genreDropdown.classList.contains('open')) {
                        genreSearch.value = '';
                        // Reset all options to visible
                        genreOptions.forEach(option => {
                            option.style.display = 'block';
                        });
                    }
                }
            });
        });
        
        observer.observe(genreDropdown, {
            attributes: true,
            attributeFilter: ['class']
        });
    }

    function setDropdownFromUrlParam(hiddenInputId, paramValue) {
        if (!paramValue) return;
        const hidden = document.getElementById(hiddenInputId);
        if (!hidden) return;
        const dropdown = hidden.closest('.custom-dropdown');
        const menu = dropdown?.querySelector('.dropdown-menu');
        if (!menu) return;

        const option = menu.querySelector(`.dropdown-option[data-value="${paramValue}"]`);
        if (!option) return;

        menu.querySelectorAll('.dropdown-option').forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');

        const display = dropdown.querySelector('.dropdown-value');
        if (display) display.textContent = option.textContent;

        hidden.value = paramValue;
    }

    function populateFiltersFromURL() {
        const urlParams = new URLSearchParams(window.location.search);

        // Genre selection is now handled in loadGenres() after AJAX loading

        // Track whether any URL filter was found so we can auto-apply
        let hasUrlFilter = false;
        const urlGenres = urlParams.get('genres') || urlParams.get('genre');
        const urlBlockedGenres = urlParams.get('blocked_genres');
        if (urlGenres || urlBlockedGenres) {
            hasUrlFilter = true;
        }

        // Handle year parameters (supports ?year=YYYY, ?year_from=YYYY and ?year_to=YYYY)
        const yearParam = urlParams.get('year') || urlParams.get('year_from');
        const yearToParam = urlParams.get('year_to');
        const yearFromInput = document.getElementById('year-from');
        const yearToInput = document.getElementById('year-to');
        if (yearParam && yearFromInput) {
            yearFromInput.value = yearParam;
            hasUrlFilter = true;
        }
        if (yearToParam && yearToInput) {
            yearToInput.value = yearToParam;
            hasUrlFilter = true;
        }

        // Handle type/sort/language/status parameters
        const typeParam = urlParams.get('type');
        if (typeParam) { setDropdownFromUrlParam('type-select', typeParam); hasUrlFilter = true; }

        const sortParam = urlParams.get('sort');
        if (sortParam) { setDropdownFromUrlParam('sort-select', sortParam); hasUrlFilter = true; }

        const languageParam = urlParams.get('language');
        if (languageParam) { setDropdownFromUrlParam('language-select', languageParam); hasUrlFilter = true; }

        const statusParam = urlParams.get('status');
        if (statusParam) { setDropdownFromUrlParam('status-select', statusParam); hasUrlFilter = true; }

        // Handle search parameter
        const searchParam = (urlParams.get('s') || urlParams.get('search') || '').trim();
        if (searchParam) {
            const decodedSearch = decodeURIComponent(searchParam);
            const searchInput = document.querySelector('.ya-search input, .ya-search-input');
            if (searchInput) {
                searchInput.value = decodedSearch;
            }
            // Store in fallback, so getCurrentFilters can always use it if input is missing / hidden.
            window.mangayummy_url_search = decodedSearch;
            hasUrlFilter = true;
        }

        // Fallback: if there is an input but it's empty, fill from window.mangayummy_url_search
        const fallbackInput = document.querySelector('.ya-search input, .ya-search-input');
        if (fallbackInput && !fallbackInput.value && window.mangayummy_url_search) {
            fallbackInput.value = window.mangayummy_url_search;
        }

        // If any filter was loaded from URL, apply them (including genres after loadGenres)
        if (hasUrlFilter) {
            window.mangayummy_initial_filters_applied = true;
            applyFilters();
        }
    }

    function getPageFromUrl() {
        const params = new URLSearchParams(window.location.search);
        const page = parseInt(params.get('page'), 10);
        return (!isNaN(page) && page >= 1) ? page : null;
    }

    function setPageInUrl(page) {
        const url = new URL(window.location.href);
        if (page && page > 1) {
            url.searchParams.set('page', page);
        } else {
            url.searchParams.delete('page');
        }
        window.history.replaceState({}, '', url);
    }

    function getInitialPage() {
        const pageFromUrl = getPageFromUrl();
        if (pageFromUrl) return pageFromUrl;

        // If user comes from front page or opens advanced search fresh,
        // do not reuse stale saved page number; start from 1.
        return 1;
    }

    function saveCurrentPage(page) {
        if (!page || page < 1) return;
        sessionStorage.setItem('mangayummy_search_page', String(page));
        setPageInUrl(page);
    }

    function loadInitialManga(page = 1) {
        const filters = getCurrentFilters();
        showLoading();

        const payload = {
            action: 'mangayummy_test_manga',
            nonce: ya_ajax.nonce,
            page: page,
            per_page: 24,
        };
        // append all filter keys explicitly (skip empty values)
        Object.keys(filters).forEach(k => {
            const v = filters[k];
            if (v !== undefined && v !== null && v !== '') {
                payload[k] = v;
            }
        });

        postAjax(payload)
        .then(data => {
            if (data.success) {
                displayManga(data.data.manga);
                updateTotalCount(data.data.count);
                updatePagination(data.data.page, data.data.total_pages);
                saveCurrentPage(page);
            } else {
                showError('Failed to load manga');
                updateTotalCount(0);
            }
        })
        .catch(error => {
            showError('Network error: ' + error.message);
            updateTotalCount(0);
        });
    }

    function getCurrentFilters() {
        // Parse genre value: "selected1,selected2|blocked1,blocked2"
        const genreValue = document.getElementById('genre-select').value;
        let includedGenres = '';
        let excludedGenres = '';
        
        if (genreValue) {
            const parts = genreValue.split('|');
            includedGenres = parts[0] || '';
            excludedGenres = parts[1] || '';
        }

        // Merge reader preference blocked genres (checked in settings)
        const prefs = window.YA_READER_PREFS || {};
        if (prefs.genres && Array.isArray(prefs.genres)) {
            const excList = excludedGenres ? excludedGenres.split(',') : [];
            prefs.genres.forEach(g => {
                if (!excList.includes(g)) {
                    excList.push(g);
                }
            });
            excludedGenres = excList.join(',');
        }

        // Year validation (UI-level) - only include years in the allowed range
        const MIN_YEAR = 1900;
        const MAX_YEAR = 2099;
        const rawYearFrom = document.getElementById('year-from')?.value?.trim() || '';
        const rawYearTo = document.getElementById('year-to')?.value?.trim() || '';
        let yearFrom = '';
        let yearTo = '';
        let yearError = '';

        // Normalize input by stripping non-digit characters (handles invisible chars/pasting)
        const digitsFrom = rawYearFrom.replace(/\D/g, '');
        const digitsTo = rawYearTo.replace(/\D/g, '');

        if (digitsFrom !== '') {
            const yf = parseInt(digitsFrom, 10);
            if (!isNaN(yf) && yf >= MIN_YEAR && yf <= MAX_YEAR) {
                yearFrom = String(yf);
            } else {
                yearError = 'Enter a valid year (e.g. 2020)';
            }
        }
        if (digitsTo !== '') {
            const yt = parseInt(digitsTo, 10);
            if (!isNaN(yt) && yt >= MIN_YEAR && yt <= MAX_YEAR) {
                yearTo = String(yt);
            } else {
                yearError = 'Enter a valid year (e.g. 2022)';
            }
        }

        if (yearFrom && yearTo && parseInt(yearFrom, 10) > parseInt(yearTo, 10)) {
            yearError = '"From" cannot be greater than "To"';
        }

        // Set global error flag for applyFilters() to check
        window.mangayummy_year_error = yearError || '';

        // Do NOT display visible validation to users - keep error internal and log for debugging
        if (yearError) {
            // console.warn('Year filter ignored (hidden to users):', yearError); // suppressed
            showYearValidation(yearError); // stores on dataset + console.warn
        } else {
            showYearValidation('');
        }

        return {
            search: (document.querySelector('.ya-search input, .ya-search-input')?.value?.trim() || window.mangayummy_url_search || ''),
            sort: document.getElementById('sort-select').value,
            type: document.getElementById('type-select').value,
            included_genres: includedGenres,
            excluded_genres: excludedGenres,
            language: document.getElementById('language-select').value,
            status: document.getElementById('status-select').value,
            year_from: yearFrom,
            year_to: yearTo,
            author: document.getElementById('author-select').value,
            artist: document.getElementById('artist-select').value
        };
    }

    // Debounced global applyFilters (prevents rapid duplicate requests)
    // timers initialized earlier to avoid TDZ
    function updateUrlFromFilters(page) {
        const filters = getCurrentFilters();
        const url = new URL(window.location.href);
        const params = url.searchParams;

        // Search
        if (filters.search) {
            params.set('s', filters.search);
        } else {
            params.delete('s');
        }

        // Sorting and filtering
        const mapParam = (key, value) => {
            if (value) params.set(key, value);
            else params.delete(key);
        };

        mapParam('sort', filters.sort);
        mapParam('type', filters.type);
        mapParam('language', filters.language);
        mapParam('status', filters.status);
        mapParam('year_from', filters.year_from);
        mapParam('year_to', filters.year_to);
        mapParam('filter_author', filters.author);
        mapParam('filter_artist', filters.artist);

        // Genres (selected + blocked)
        const genreValue = document.getElementById('genre-select')?.value || '';
        if (genreValue) {
            const parts = genreValue.split('|');
            const selected = parts[0] || '';
            const blocked = parts[1] || '';
            mapParam('genres', selected);
            mapParam('blocked_genres', blocked);
        } else {
            params.delete('genres');
            params.delete('blocked_genres');
        }

        // Page
        if (page && page > 1) {
            params.set('page', page);
        } else {
            params.delete('page');
        }

        window.history.replaceState({}, '', url);
    }

    function applyFilters() {
        // debounce all callers (inputs, dropdowns, AJAX loaders)
        clearTimeout(mangayummy_apply_filters_timer);
        mangayummy_apply_filters_timer = setTimeout(() => {
            const filters = getCurrentFilters();

            // if year validation failed, abort and focus invalid input
            if (window.mangayummy_year_error) {
                // console.warn('Year validation failed - aborting filter apply:', window.mangayummy_year_error);
                // focus first invalid input
                const firstInvalid = document.querySelector('.year-inputs input.input-invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }

            const filtersJSON = JSON.stringify(filters);
            // log hidden year errors but DO NOT abort - invalid year fields are ignored and the other filters still apply
            if (window.mangayummy_year_error) {
                // console.warn('Year validation present (hidden):', window.mangayummy_year_error);
            }

            // skip if identical filters already applied
            if (filtersJSON === mangayummy_last_filters_json) {
                return;
            }
            mangayummy_last_filters_json = filtersJSON;
            updateUrlFromFilters(1);
            loadInitialManga(1); // Reset to first page
        }, 350);
    }

    function resetFilters() {
        // Clear all saved filter selections from localStorage
        const filterKeys = [
            'mangayummy_filter_sort-select',
            'mangayummy_filter_type-select',
            'mangayummy_filter_language-select',
            'mangayummy_filter_status-select',
            'mangayummy_filter_genre-select',
            'mangayummy_filter_author-select',
            'mangayummy_filter_artist-select'
        ];

        filterKeys.forEach(key => {
            localStorage.removeItem(key);
        });

        // Reset all custom dropdowns
        document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
            const type = dropdown.dataset.type;
            const hiddenInput = dropdown.querySelector('input[type="hidden"]');

            // Reset selections
            dropdown.querySelectorAll('.dropdown-option').forEach(option => {
                option.classList.remove('selected');
                option.classList.remove('blocked');
            });

            // Reset trigger text
            dropdown.querySelector('.dropdown-value').textContent = 'Any';

            // Clear chips for multiple selection
            if (type === 'multiple') {
                dropdown.querySelector('.dropdown-chips').innerHTML = '';
            }

            // Reset hidden input
            hiddenInput.value = '';

            // Close dropdown
            dropdown.classList.remove('open');
        });

        // Reset year inputs
        document.getElementById('year-from').value = '';
        document.getElementById('year-to').value = '';

        // Reset search input (both selectors) and URL state
        const searchInput = document.querySelector('.ya-search input, .ya-search-input');
        if (searchInput) {
            searchInput.value = '';
        }
        window.mangayummy_url_search = '';

        // Clear visible results immediately so user sees reset effect
        const grid = document.getElementById('manga-grid');
        if (grid) {
            grid.innerHTML = '<div class="no-results"><p>Results have been reset.</p></div>';
        }

        updateTotalCount(0);
        updatePagination(1, 0);

        // Ensure URL query is cleared now (including ?s)
        updateUrlFromFilters(1);

        // Reload results from defaults (cleared filters)
        loadInitialManga(1);

        // re-apply preference-based blocks after UI reset
        applyPrefsToGenres();
    }

    function feelingLucky() {
        // Get a random manga
        postAjax({
            'action': 'mangayummy_get_random_manga',
            'nonce': ya_ajax.nonce
        })
        .then(data => {
            if (data.success) {
                // Redirect to the random manga
                window.location.href = data.data.permalink;
            } else {
                alert('Error finding a random manga: ' + (data.data?.message || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error getting random manga:', error);
            alert('Network error. Try again.');
        });
    }

    function displayManga(mangaList) {
        const grid = document.getElementById('manga-grid');
        grid.innerHTML = '';

        const searchTerm = (document.querySelector('.ya-search input, .ya-search-input')?.value || '').trim().toLowerCase();
        // Log all searches to console (useful for debugging, especially for 'c' too)
        console.groupCollapsed('DEBUG /advanced-search: search=' + (searchTerm || '(empty)') + ' -> ' + (mangaList ? mangaList.length : 0) + ' results');
        (mangaList || []).forEach(m => {
        });
        console.groupEnd();

        if (!mangaList || mangaList.length === 0) {
            grid.innerHTML = '<div class="no-results"><p>No manga matched your criteria.</p></div>';
            return;
        }

        mangaList.forEach(manga => {
            const mangaCard = createMangaCard(manga);
            grid.appendChild(mangaCard);
        });
    }

    function createMangaCard(manga) {
        const card = document.createElement('div');
        card.className = 'manga-card';

        // Format type class
        let typeClass = 'manga-type';
        switch (manga.type.toLowerCase()) {
            case 'manga':
                typeClass = 'manga-type type-manga';
                break;
            case 'manhua':
                typeClass = 'manga-type type-manhua';
                break;
            case 'manhwa':
                typeClass = 'manga-type type-manhwa';
                break;
        }

        // Format status
        let statusText = 'UNKNOWN';
        let statusClass = 'manga-status';
        switch (manga.status.toLowerCase()) {
            case 'ongoing':
                statusText = 'ONGOING';
                statusClass = 'manga-status status-ongoing';
                break;
            case 'completed':
                statusText = 'COMPLETED';
                statusClass = 'manga-status status-completed';
                break;
            case 'hiatus':
                statusText = 'HIATUS';
                statusClass = 'manga-status status-hiatus';
                break;
            case 'cancelled':
                statusText = 'CANCELLED';
                statusClass = 'manga-status status-cancelled';
                break;
        }

        card.innerHTML = `
            <a href="${manga.permalink}" class="manga-cover-link">
                <div class="manga-cover">
                    <img src="${manga.thumbnail}" alt="${manga.title}" loading="lazy">
                </div>
            </a>
            <div class="manga-info">
                <h3 class="manga-title">
                    <a href="${manga.permalink}">${manga.title}</a>
                </h3>
                <div class="manga-meta">
                    <span class="${typeClass}">${manga.type.charAt(0).toUpperCase() + manga.type.slice(1)}</span>
                    <span class="manga-year">${manga.year}</span>
                    <span class="${statusClass}">${statusText}</span>
                    <span class="manga-chapters">CH.${manga.chapters}</span>
                </div>
                <div class="manga-stats">
                    <span class="views">${manga.views}</span>
                    <span class="rating">${manga.rating}</span>
                </div>
                <p class="manga-description">
                    ${manga.description}
                </p>
                ${(() => {
                    // Show "Updated recently" badge only if the manga was modified in the last 7 days.
                    // `manga.updated` is a UNIX timestamp (seconds since epoch).
                    const updatedTs = parseInt(manga.updated, 10);
                    if (!updatedTs || Number.isNaN(updatedTs)) return '';
                    const ageMs = Date.now() - (updatedTs * 1000);
                    const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
                    return ageMs <= sevenDaysMs ? '<div class="manga-updated">Updated recently</div>' : '';
                })()}
            </div>
        `;

        return card;
    }

    function updateTotalCount(count) {
        document.getElementById('total-items').textContent = count.toLocaleString() + ' items';
    }

    function updatePagination(currentPage, totalPages) {
        const pagination = document.querySelector('.pagination');
        if (!pagination || totalPages <= 1) {
            pagination.style.display = 'none';
            return;
        }

        pagination.style.display = 'flex';
        let paginationHtml = '';

        // Previous button
        if (currentPage > 1) {
            paginationHtml += `<a href="#" class="page-link" data-page="${currentPage - 1}">&larr;</a>`;
        }

        // Page numbers
        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(totalPages, currentPage + 2);

        if (startPage > 1) {
            paginationHtml += `<a href="#" class="page-link" data-page="1">1</a>`;
        }

        for (let i = startPage; i <= endPage; i++) {
            const activeClass = i === currentPage ? ' active' : '';
            paginationHtml += `<a href="#" class="page-link${activeClass}" data-page="${i}">${i}</a>`;
        }

        if (endPage < totalPages) {
            paginationHtml += `<a href="#" class="page-link" data-page="${totalPages}">${totalPages}</a>`;
        }

        // Next button
        if (currentPage < totalPages) {
            paginationHtml += `<a href="#" class="page-link next" data-page="${currentPage + 1}">&rarr;</a>`;
        }

        pagination.innerHTML = paginationHtml;

        // Add click handlers for pagination
        pagination.querySelectorAll('.page-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = parseInt(link.dataset.page);
                if (page && page !== currentPage) {
                    updateUrlFromFilters(page);
                    loadInitialManga(page);
                    // Scroll to top of results
                    document.querySelector('.results-main').scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    }

    function showLoading() {
        const grid = document.getElementById('manga-grid');
        grid.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>Loading manga...</p></div>';
    }

    function showError(message) {
        const grid = document.getElementById('manga-grid');
        grid.innerHTML = `<div class="error-state"><p>Error: ${message}</p></div>`;
    }
});
</script>

<?php get_footer(); ?>
