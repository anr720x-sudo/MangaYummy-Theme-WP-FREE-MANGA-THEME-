# 📋 MangaYummy – WP Admin Complete Inventory

## 1. 📚 CUSTOM POST TYPES (CPTs)

### Manga
- **Slug:** `manga`
- **Capabilities:** `edit_manga`, `read_manga`, `delete_manga`
- **Features:** title, editor, excerpt, thumbnail, author, revisions, comments
- **Archive:** Enabled
- **REST:** Yes
- **Rewrite:** `manga`
- **Menu Icon:** dashicons-book-alt

### Chapter  
- **Slug:** `chapter`
- **Capabilities:** `edit_chapter`, `read_chapter`, `delete_chapter`
- **Features:** title, editor, excerpt, thumbnail, author, revisions, comments
- **Archive:** Disabled
- **REST:** Yes
- **Rewrite:** `capitolul`
- **Menu Icon:** dashicons-format-image

### News (Știri)
- **Slug:** `stire`
- **Capabilities:** `edit_stire`, `read_stire`, `delete_stire`
- **Features:** title, editor, excerpt, thumbnail, author, revisions, comments
- **Archive:** Disabled
- **REST:** Yes
- **Rewrite:** `stire`
- **Menu Icon:** dashicons-megaphone

---

## 2. 🏷️ CUSTOM TAXONOMIES

### Translator Group (Chapter)
- **Name:** Translator Group
- **Slug:** `translator_group`
- **CPT:** chapter
- **Hierarchical:** No
- **Rewrite Slug:** `translator-group`
- **Admin Column:** Yes
- **REST:** Yes

### Genre (Manga)
- **Name:** Genres
- **Slug:** `genre`
- **CPT:** manga
- **Hierarchical:** Yes
- **Rewrite Slug:** `gen`
- **Admin Column:** Yes
- **REST:** Yes

### Author (Manga)
- **Name:** Authors
- **Slug:** `author`
- **CPT:** manga
- **Hierarchical:** No
- **Rewrite Slug:** `autor`
- **Admin Column:** Yes
- **REST:** Yes

### Artist (Manga)
- **Name:** Artists
- **Slug:** `artist`
- **CPT:** manga
- **Hierarchical:** No
- **Rewrite Slug:** `artist`
- **Admin Column:** Yes
- **REST:** Yes

### News Categories
- **Name:** News Categories
- **Slug:** `stiri_category`
- **CPT:** stire
- **Hierarchical:** Yes
- **Rewrite Slug:** `stiri-category`
- **Admin Column:** Yes
- **REST:** Yes

---

## 3. 📦 META BOXES

### Chapter Meta Boxes
| Name | ID | Title | Location |
|------|----|----|----------|
| Chapter Images | `chapter_images` | Chapter Images | normal, high |
| ZIP Upload | `chapter_zip_upload` | Upload ZIP with Images | normal, high |
| Chapter Details | `chapter_details` | Chapter Details | normal |
| Chapter Importer | `chapter_importer` | Import External Chapter | side, high |
| Trashed Chapters | `trashed_chapters` | Trashed Chapters | normal |

### Manga Meta Boxes
| Name | ID | Title | Location |
|------|----|----|----------|
| Manga Details | `manga_details` | Manga Details | normal |
| Age Restrictions | `manga_18` | Age Restrictions | normal |
| English Title | `manga_english_title` | English Title | normal |
| External Import | `manga_importer` | External Import (MangaDex / MangaTerra) | side, high |

### News (Stire) Meta Boxes
| Name | ID | Title | Location |
|------|----|----|----------|
| YouTube Embed | `stire_youtube` | YouTube Embed | normal |
| Cover Image | `stire_cover` | Cover Image | normal |

---

## 4. ⚙️ CUSTOMIZER SECTIONS & SETTINGS

### Section: Site Identity (Built-in)
- Logo
- Site Title
- Tagline

### Section: Colors (Built-in)
- Primary Color

### Section: MangaYummy Colors
- **ID:** `mangayummy_colors`
- **Settings:** (Custom color settings)

### Section: Manga Sites
- **ID:** `mangayummy_siteuri`
- **Settings (1-5 repeatable blocks):**
  - Site Name #N
  - Site Logo #N (image)
  - Site URL #N (url)
  - Site Description #N (textarea)

### Section: Footer Contact
- **ID:** `mangayummy_footer_contact`
- **Settings:**
  - Discord URL
  - Support Email

---

## 5. 🎛️ ADMIN MENU ITEMS

### Under Tools
| Menu Item | Page | Slug | Capability |
|-----------|------|------|------------|
| Blocked IPs | Manage Blocked IPs | `mangayummy-blocked-ips` | manage_options |
| User Groups | Manage User Groups | `mangayummy-user-groups` | manage_options |
| Migrate Groups | Migrate Translator Groups | `mangayummy-migrate-groups` | manage_options |
| ~~Șterge EN capitole~~ | Delete EN Chapters | `mangayummy-delete-en-chapters` | manage_options |
| ~~Șterge Manga + Capitole~~ | Delete Manga + Chapters | `mangayummy-delete-manga-with-chapters` | manage_options |
| ~~Migrează Imagini Capitole~~ | Migrate Chapter Images | `mangayummy-migrate-chapter-images` | manage_options |
| Fix Profile Images | Fix Profile Images (WebP) | `fix-profile-images` | manage_options |

### Under Users
| Menu Item | Page | Slug | Capability |
|-----------|------|------|------------|
| Unverified Accounts | Cleanup Unverified Accounts | `mangayummy-unverified-accounts` | manage_options |

### Top Level Menu
| Menu Item | Page | Slug | Icon | Position |
|-----------|------|------|------|----------|
| Manga Manager | Manga Manager | `mangayummy-manga-manager` | dashicons-book | 61 |
| Reported Comments | Reported Comments | `reported-comments` | dashicons-flag | 25 |

### Under Settings
| Menu Item | Page | Slug |
|-----------|------|------|
| IndexNow Settings | IndexNow API Key | `indexnow-settings` |
| Cloudflare Settings | Cloudflare Settings | `mangayummy-cloudflare` |
| Welcome Message | Welcome Message | `mangayummy-welcome-message` |

### Under Tools (Built-in)
| Menu Item | Page | Slug |
|-----------|------|------|
| Reset Reader Prefs | Reset Reader Preferences | `ya-reset-reader-prefs` |

---

## 6. 📄 ADMIN PAGES & FORMS

### Blocked IPs Page
- View/manage blocked IP addresses
- Add new blocked IPs
- Remove from block list

### User Groups Manager
- Manage translator user groups
- Create/edit/delete groups
- Assign users to groups

### Migrate Translator Groups
- Bulk migrate content between translator groups
- Confirm migration action
- Track migration status

### Unverified Accounts
- List unverified user accounts
- Verify accounts
- Delete unverified accounts
- Cleanup tool

### Delete EN Chapters
- Remove all English chapters
- Move to trash (preserve data)
- Filter by manga
- Confirmation prompt

### Delete Manga + Chapters
- Delete manga and associated chapters
- Delete images from server
- Confirmation (cannot be undone)
- Search by ID/slug

### Migrate Chapter Images
- Migrate images between servers/locations
- Batch processing
- Status tracking
- Resume functionality

### Fix Profile Images (WebP)
- Regenerate WebP profile images
- Fix corrupted images
- Batch processing

### Manga Manager
- Centralized manga management interface
- Quick actions for bulk operations
- Status filters

### Reset Reader Preferences
- Reset user reading preferences
- Clear bookmark history
- Reset settings per user

### Reported Comments
- View all flagged comments
- Approve/reject reports
- Ban/warn users
- Comment moderation

### IndexNow API
- Set IndexNow key
- Configure instant indexing
- Test API connection

### Cloudflare Settings
- Zone ID configuration
- API key setup
- Cache purge options
- SSL settings

### Welcome Message
- Edit welcome message for new users
- Set welcome page content

---

## 7. 📊 DASHBOARD WIDGETS

### Popular & Recent
- **ID:** `mangayummy-dashboard-popular-recent`
- **Location:** Dashboard
- **Shows:** Popular manga, Recent chapters

---

## 8. 🔌 AJAX HANDLERS (Admin-related)

| Action | Capability | Purpose |
|--------|-----------|---------|
| `mangayummy_get_manga_info` | manage_options | Fetch manga info (import preview) |
| `mangayummy_import_local_chapters` | manage_options | Import chapters in batches |
| `mangayummy_verify_account` | manage_options | Verify user account |
| `mangayummy_block_user` | moderate_comments | Block user IP |
| `mangayummy_delete_en_chapters` | manage_options | Delete English chapters |
| `mangayummy_delete_manga` | manage_options | Delete manga + chapters |
| `mangayummy_migrate_chapter_images` | manage_options | Start image migration |
| `mangayummy_reset_reader_prefs` | manage_options | Reset user preferences |
| `mangayummy_approve_comment_report` | moderate_comments | Approve flagged comment |
| `mangayummy_reject_comment_report` | moderate_comments | Reject flagged comment |
| `mangayummy_delete_chapter_images` | edit_posts | Delete all chapter images |

---

## 9. 🎨 THEME SUPPORTS

- Post Thumbnails
- Title Tag
- Custom Logo
- HTML5 (search-form, comment-form, comment-list)

---

## 10. 📝 MENU REGISTRATIONS

### Primary Menu
- Location: Header navigation

### Footer Menu  
- Location: Footer section

---

## 11. ✅ TRANSLATION COMPLETE

All WP Admin interface text has been translated from Romanian to English.

**Previous Romanian items (NOW TRANSLATED):**
- ✅ `'Șterge capitole EN'` → "Delete EN Chapters"
- ✅ `'Șterge EN capitole'` → "Delete EN Chapters"  
- ✅ `'Șterge Manga + Capitole'` → "Delete Manga + Chapters"
- ✅ `'Migrează Imagini Capitole'` → "Migrate Chapter Images"

---

## 12. 📋 CUSTOMIZER FIELD LABELS (Sample)

### Manga Details Form Fields
- Manga Type (Manga/Manhua/Manhwa)
- Alternative Titles
- Status (Ongoing/Completed/Hiatus/Cancelled)
- Release Year
- Translator User
- Translation Status
- Show Translator Donation Message
- Translator Wallet Link
- Recommended (checkbox)
- External Links (AniList, MyAnimeList, Official Raw URLs)

### Chapter Details Form Fields
- Chapter Number
- Language
- Translator Group
- Upload Images (direct links)
- Sequential URL Generation
- Upload ZIP with Images

### News (Stire) Form Fields
- Title
- Content
- Featured Image
- YouTube Embed URL
- Cover Image

---

## 13. 📦 SYSTEM CAPABILITIES

### Manga
- `edit_manga`, `edit_others_manga`, `publish_manga`, `read_manga`, `read_private_manga`, `delete_manga`, `delete_others_manga`, `delete_published_manga`, `delete_private_manga`

### Chapter
- `edit_chapter`, `edit_others_chapter`, `publish_chapter`, `read_chapter`, `read_private_chapter`, `delete_chapter`, `delete_others_chapter`, `delete_published_chapter`, `delete_private_chapter`

### News (Stire)
- `edit_stire`, `edit_others_stire`, `publish_stire`, `read_stire`, `read_private_stire`, `delete_stire`, `delete_others_stire`, `delete_published_stire`, `delete_private_stire`

---

## 14. 🔐 USER ROLES & CAPABILITIES

### Admin
- All capabilities

### Translator / Contributor
- Can create/edit own chapters
- Can moderate comments on own chapters
- Cannot access admin tools

### Editor
- Can create/edit/delete content
- Can moderate comments
- Cannot access advanced admin tools

---

## 15. 📱 REST API ENDPOINTS

- `/wp-json/wp/v2/manga`
- `/wp-json/wp/v2/chapter`
- `/wp-json/wp/v2/stire`
- `/wp-json/wp/v2/genre`
- `/wp-json/wp/v2/author`
- `/wp-json/wp/v2/artist`
- `/wp-json/wp/v2/translator_group`
- `/wp-json/wp/v2/stiri_category`

---

**Last Updated:** May 10, 2026  
**Translation Status:** ✅ Mostly Complete (4 items remaining in Romanian)
