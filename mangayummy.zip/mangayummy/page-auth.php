<?php
/**
 * Template Name: Modern Auth
 * Login & Register in one page with tabs
 */
get_header();
?>

<div class="auth-container">
  <div class="auth-wrapper">
    <!-- Auth Card -->
    <div class="auth-card">
      <!-- Branding -->
      <div class="auth-header">
        <a href="<?php echo home_url(); ?>" class="auth-logo">
          <span class="logo-text">MangaYummy</span>
        </a>
        <p class="auth-tagline">Citește manga online gratuit</p>
      </div>

      <!-- Tab Navigation -->
      <div class="auth-tabs">
        <button class="auth-tab active" data-tab="login">
          <span class="tab-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg></span> Logare
        </button>
        <button class="auth-tab" data-tab="register">
          <span class="tab-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg></span> Înregistrare
        </button>
      </div>

      <!-- Login Form -->
      <div class="auth-form-wrapper active" id="login-tab">
        <form class="auth-form" id="login-form">
          <!-- Username -->
          <div class="form-group">
            <label for="login-username" class="form-label">Utilizator sau Email</label>
            <input 
              type="text" 
              id="login-username" 
              name="username" 
              class="form-input"
              placeholder="Introdu utilizatorul sau emailul"
            >
            <span class="form-error" id="login-username-error"></span>
          </div>

          <!-- Password -->
          <div class="form-group">
            <label for="login-password" class="form-label">Parolă</label>
            <div class="password-wrapper">
              <input 
                type="password" 
                id="login-password" 
                name="password" 
                class="form-input"
                placeholder="Introdu parola"
              >
              <button type="button" class="toggle-password" data-target="login-password">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </button>
            </div>
            <span class="form-error" id="login-password-error"></span>
          </div>

          <!-- Remember Me -->
          <div class="form-group checkbox-group">
            <input 
              type="checkbox" 
              id="login-remember" 
              name="remember" 
              class="checkbox-input"
            >
            <label for="login-remember" class="checkbox-label">Ține-mă conectat</label>
          </div>

          <!-- Submit Button -->
          <button type="submit" class="btn btn-primary btn-block">
            <span class="btn-text">Conectare</span>
            <span class="btn-loader hidden">⏳</span>
          </button>

          <!-- Divider -->
          <div class="form-divider">SAU</div>

          <!-- Social Login (Optional) -->
          <div class="social-login">
            <p class="social-text">Conectare rapidă:</p>
            <div class="social-buttons">
              <button type="button" class="social-btn google" title="Google">G</button>
              <button type="button" class="social-btn facebook" title="Facebook">f</button>
            </div>
          </div>

          <!-- Links -->
          <div class="form-links">
            <a href="#forgot-password" class="link-forgot">Ai uitat parola?</a>
          </div>
        </form>
      </div>

      <!-- Register Form -->
      <div class="auth-form-wrapper" id="register-tab">
        <form class="auth-form" id="register-form">
          <!-- Username -->
          <div class="form-group">
            <label for="register-username" class="form-label">Utilizator</label>
            <input 
              type="text" 
              id="register-username" 
              name="username" 
              class="form-input"
              placeholder="Alege un utilizator (3-20 caractere)"
              maxlength="20"
            >
            <span class="form-error" id="register-username-error"></span>
          </div>

          <!-- Email -->
          <div class="form-group">
            <label for="register-email" class="form-label">Email</label>
            <input 
              type="email" 
              id="register-email" 
              name="email" 
              class="form-input"
              placeholder="Introdu email-ul"
            >
            <span class="form-error" id="register-email-error"></span>
          </div>

          <!-- Password -->
          <div class="form-group">
            <label for="register-password" class="form-label">Parolă</label>
            <div class="password-wrapper">
              <input 
                type="password" 
                id="register-password" 
                name="password" 
                class="form-input password-strength"
                placeholder="Alege o parolă puternică"
              >
              <button type="button" class="toggle-password" data-target="register-password">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </button>
            </div>
            <div class="password-strength-bar">
              <div class="strength-fill"></div>
            </div>
            <span class="password-strength-text"></span>
            <span class="form-error" id="register-password-error"></span>
          </div>

          <!-- Confirm Password -->
          <div class="form-group">
            <label for="register-password-confirm" class="form-label">Confirmă Parola</label>
            <div class="password-wrapper">
              <input 
                type="password" 
                id="register-password-confirm" 
                name="password_confirm" 
                class="form-input"
                placeholder="Confirmă parola"
              >
              <button type="button" class="toggle-password" data-target="register-password-confirm">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </button>
            </div>
            <span class="form-error" id="register-password-confirm-error"></span>
          </div>

          <!-- Gender Selection -->
          <div class="form-group">
            <label class="form-label">Gen</label>
            <div class="gender-select" style="display:flex; justify-content:space-between; gap:0;">
              <label class="gender-option">
                <input type="radio" name="gender" value="masculin">
                <span class="gender-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2"/><path d="M5 21v-2a7 7 0 0114 0v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></span>
                <span class="gender-label">Masculin</span>
              </label>
              <label class="gender-option">
                <input type="radio" name="gender" value="feminin">
                <span class="gender-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2"/><path d="M5 21v-2a7 7 0 0114 0v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 11v4m-2-2h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></span>
                <span class="gender-label">Feminin</span>
              </label>
            </div>
          </div>

          <!-- Terms & Conditions -->
          <div class="form-group checkbox-group">
            <input 
              type="checkbox" 
              id="register-terms" 
              name="terms" 
              class="checkbox-input"
              required
            >
            <label for="register-terms" class="checkbox-label">
              Accept <a href="#terms" class="link">Termenii de utilizare</a>
            </label>
            <span class="form-error" id="register-terms-error"></span>
          </div>

          <!-- Submit Button -->
          <button type="submit" class="btn btn-primary btn-block">
            <span class="btn-text">Înregistrare</span>
            <span class="btn-loader hidden">⏳</span>
          </button>

          <!-- Links -->
          <p class="form-text-center">
            Ai deja cont? <button type="button" class="link-switch" data-tab="login">Conectare</button>
          </p>
        </form>
      </div>
    </div>

    <!-- Side Graphics -->
    <div class="auth-side">
      <div class="auth-graphic">
        <div class="graphic-circle"></div>
        <p class="graphic-text">Citește 1000+ manga-uri</p>
      </div>
    </div>
  </div>
</div>

<?php
get_footer();
?>
