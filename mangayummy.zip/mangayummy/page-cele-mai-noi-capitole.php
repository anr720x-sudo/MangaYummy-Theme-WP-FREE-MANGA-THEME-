<?php
/**
 * Template Name: Cele Mai Noi Capitole
 * Template for Latest Chapters page
 * Shows paginated list of latest RO/EN chapters
 */

get_header();

// Pagination
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 51;
$offset = ($current_page - 1) * $per_page;

// Get all recent chapters - only published ones
$all_chapters = get_posts(array(
    'post_type' => 'chapter',
    'post_status' => 'publish',
    'posts_per_page' => -1, // Get ALL published chapters
    'orderby' => 'post_date',
    'order' => 'DESC',
    'no_found_rows' => true,
    'update_post_term_cache' => false,
    'update_post_meta_cache' => true,
));

$all_recent_chapters = $all_chapters; // Use only published for final display

// Group by manga and language - up to 2 chapters per manga (RO + EN)
$chapters_by_manga_lang = array();

foreach ($all_recent_chapters as $chapter) {
    $manga_id = get_post_meta($chapter->ID, '_manga_id', true);
    $chapter_language = get_post_meta($chapter->ID, '_chapter_language', true) ?: 'ro';

    // Only include RO and EN chapters
    if (!in_array($chapter_language, array('ro', 'en'))) {
        continue;
    }

    if (!$manga_id) continue;

    $manga = get_post($manga_id);
    if (!$manga || $manga->post_type !== 'manga' || $manga->post_status !== 'publish') continue;

    $key = $manga_id . '_' . $chapter_language;

    // Keep only the highest chapter number per manga-language combo
    $current_chapter_num = (float) get_post_meta($chapter->ID, '_chapter_number', true);
    $existing_chapter_num = isset($chapters_by_manga_lang[$key]) ? 
        (float) get_post_meta($chapters_by_manga_lang[$key]->ID, '_chapter_number', true) : -1;

    if (!isset($chapters_by_manga_lang[$key]) || $current_chapter_num > $existing_chapter_num) {
        $chapters_by_manga_lang[$key] = $chapter;
    }
}

// Sort by date (most recent first)
usort($chapters_by_manga_lang, function($a, $b) {
    return strtotime($b->post_date) - strtotime($a->post_date);
});

// Calculate pagination
$total_chapters = count($chapters_by_manga_lang);
$total_pages = ceil($total_chapters / $per_page);

// Get paginated results
$offset = ($current_page - 1) * $per_page;
$chapters = array_slice($chapters_by_manga_lang, $offset, $per_page);
?>

<section class="ya-section">
  <div class="section-header">
    <h1>CELE MAI NOI CAPITOLE</h1>
  </div>

  <div class="latest-updates-list" role="list" aria-label="Lista celor mai noi capitole">
    <?php if (!empty($chapters)): ?>
      <?php foreach ($chapters as $chapter):
        $chapter_id = $chapter->ID;
        $manga_id = get_post_meta($chapter_id, '_manga_id', true);
        $chapter_number = get_post_meta($chapter_id, '_chapter_number', true);
        $chapter_language = get_post_meta($chapter_id, '_chapter_language', true) ?: 'ro';
        $translation_group = get_post_meta($chapter_id, '_translation_group', true) ?: 'Unknown';

        // Get translator group link
        $group_link = '';
        if ($translation_group && $translation_group !== 'Unknown') {
          $term = get_term_by('name', $translation_group, 'translator_group');
          if ($term && !is_wp_error($term)) {
            $group_link = get_term_link($term);
          }
        }

        if (!$manga_id) continue;

        $manga = get_post($manga_id);
        if (!$manga || $manga->post_status !== 'publish') continue;

        $manga_title = get_the_title($manga);
        $manga_permalink = get_permalink($manga);
        $chapter_permalink = get_permalink($chapter);
        $time_ago = mangayummy_time_ago(strtotime($chapter->post_date));
        $comment_count = get_comments_number($chapter_id);

        // Format chapter display
        $chapter_display = '';
        if ($chapter_number !== '' && $chapter_number !== null) {
          $chapter_display = 'Ch. ' . $chapter_number;
        } else {
          // Fallback to post title if no chapter number
          $post_title = get_the_title($chapter);
          if (preg_match('/Chapter (\d+)/i', $post_title, $matches)) {
            $chapter_display = 'Ch. ' . $matches[1];
          } else {
            $chapter_display = 'Ch. -';
          }
        }

        // Add volume if exists
        $chapter_volume = get_post_meta($chapter_id, '_chapter_volume', true);
        if ($chapter_volume) {
          $chapter_display = 'Vol. ' . $chapter_volume . ' ' . $chapter_display;
        }

        // Add title if exists
        $chapter_title = get_the_title($chapter);
        if ($chapter_title && $chapter_title !== 'Chapter ' . $chapter_number) {
          $chapter_display .= ' - ' . $chapter_title;
        }

        if ($chapter_language === 'ro') {
          $flag_html = '<img class="inline-block select-none flag-icon" title="Romanian" src="' . get_template_directory_uri() . '/assets/img/flags/ro.svg?v=1.1" alt="Romanian flag" width="20" height="20" style="height: 16px; width: 16px; margin-left: 1px; vertical-align: middle;">';
        } elseif ($chapter_language === 'en') {
          $flag_html = '<img class="inline-block select-none flag-icon" title="English" src="' . get_template_directory_uri() . '/assets/img/flags/gb.svg?v=1.1" alt="English flag" width="20" height="20" style="height: 16px; width: 16px; margin-left: 1px; vertical-align: middle;">';
        }
        ?>
        <article class="latest-update-item" itemscope itemtype="https://schema.org/Article" role="listitem">
          <div class="update-poster">
            <a href="<?php echo esc_url($manga_permalink); ?>" aria-label="Vezi manga <?php echo esc_attr($manga_title); ?>">
              <?php echo get_the_post_thumbnail($manga_id, 'manga-card', [
                'loading' => 'lazy',
                'decoding' => 'async',
                'alt' => esc_attr($manga_title),
                'itemprop' => 'image'
              ]); ?>
            </a>
          </div>
          <div class="update-content">
            <header class="update-manga-info">
              <a href="<?php echo esc_url($manga_permalink); ?>" class="update-manga-title" itemprop="name"><?php echo esc_html($manga_title); ?></a>
            </header>
            <div class="update-chapter-row">
              <?php if ($chapter_language === 'ro'): ?>
                <img class="inline-block select-none flag-icon" title="Romanian" src="<?php echo get_template_directory_uri(); ?>/assets/img/flags/ro.svg?v=1.1" alt="Romanian flag" width="20" height="20" style="height: 16px; width: 16px; margin-left: 1px; vertical-align: middle;" role="img" aria-label="Romanian chapter">
              <?php elseif ($chapter_language === 'en'): ?>
                <img class="inline-block select-none flag-icon" title="English" src="<?php echo get_template_directory_uri(); ?>/assets/img/flags/gb.svg?v=1.1" alt="English flag" width="20" height="20" style="height: 16px; width: 16px; margin-left: 1px; vertical-align: middle;" role="img" aria-label="English chapter">
              <?php endif; ?>
              <a href="<?php echo esc_url($chapter_permalink); ?>" class="update-chapter-link" itemprop="url"><?php echo esc_html($chapter_display); ?></a>
              <a href="<?php echo esc_url($chapter_permalink); ?>#comments" class="update-comments" title="<?php echo esc_attr($comment_count); ?> comentarii" aria-label="<?php echo esc_attr($comment_count); ?> comments">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <span><?php echo $comment_count; ?></span>
              </a>
            </div>
            <footer class="update-meta">
              <?php if ($group_link): ?>
                <a href="<?php echo esc_url($group_link); ?>" class="update-group" aria-label="Translation group: <?php echo esc_attr($translation_group); ?>"><?php echo esc_html($translation_group); ?></a>
              <?php else: ?>
                <span class="update-group" aria-label="Translation group: <?php echo esc_attr($translation_group); ?>"><?php echo esc_html($translation_group); ?></span>
              <?php endif; ?>
              <time class="update-time" datetime="<?php echo esc_attr($chapter->post_date); ?>" title="<?php echo esc_attr($chapter->post_date); ?>"><?php echo esc_html($time_ago); ?></time>
            </footer>
          </div>
        </article>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="no-chapters-message" role="status" aria-live="polite">
        <p>Nu există capitole disponibile în acest moment.</p>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($total_pages > 1): ?>
  <nav class="pagination" aria-label="Navigare capitole" role="navigation">
    <?php
    $base_url = get_permalink();
    if ($current_page > 1): ?>
      <a href="<?php echo esc_url(add_query_arg('pag', $current_page - 1, $base_url)); ?>" class="page-link" aria-label="Pagina anterioară" rel="prev">
        <span aria-hidden="true">←</span>
      </a>
    <?php endif; ?>

    <?php
    $start_page = max(1, $current_page - 2);
    $end_page = min($total_pages, $current_page + 2);

    if ($start_page > 1): ?>
      <a href="<?php echo esc_url(add_query_arg('pag', 1, $base_url)); ?>" class="page-link" aria-label="Prima pagină">1</a>
    <?php endif; ?>

    <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
      <?php if ($i == $current_page): ?>
        <span class="page-link current" aria-current="page" aria-label="Pagina curentă <?php echo $i; ?>"><?php echo $i; ?></span>
      <?php else: ?>
        <a href="<?php echo esc_url(add_query_arg('pag', $i, $base_url)); ?>" class="page-link" aria-label="Pagina <?php echo $i; ?>"><?php echo $i; ?></a>
      <?php endif; ?>
    <?php endfor; ?>

    <?php if ($end_page < $total_pages): ?>
      <a href="<?php echo esc_url(add_query_arg('pag', $total_pages, $base_url)); ?>" class="page-link" aria-label="Ultima pagină"><?php echo $total_pages; ?></a>
    <?php endif; ?>

    <?php if ($current_page < $total_pages): ?>
      <a href="<?php echo esc_url(add_query_arg('pag', $current_page + 1, $base_url)); ?>" class="page-link" aria-label="Pagina următoare" rel="next">
        <span aria-hidden="true">→</span>
      </a>
    <?php endif; ?>
  </nav>
  <?php endif; ?>
</section>

<?php get_footer(); ?>