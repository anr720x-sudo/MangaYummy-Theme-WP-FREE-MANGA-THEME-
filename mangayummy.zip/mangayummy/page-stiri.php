<?php
/**
 * Template Name: Știri
 */
get_header();

$stiri_paged = mangayummy_get_stiri_current_page();

function mangayummy_get_stiri_posts($category_slug = '', $paged = 1) {
    $args = array(
        'post_type'      => 'stire',
        'posts_per_page' => 9,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    );

    if ($paged > 1) {
        $args['paged'] = $paged;
    }

    if ($category_slug) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'stiri_category',
                'field'    => 'slug',
                'terms'    => $category_slug,
            ),
        );
    }

    return new WP_Query($args);
}

function mangayummy_get_stiri_current_page() {
    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = trim(parse_url($request_uri, PHP_URL_PATH), '/');
    if (!$path) {
        return 1;
    }

    $segments = explode('/', $path);
    $news_index = array_search('news', $segments, true);
    if ($news_index === false) {
        $news_index = array_search('stiri', $segments, true);
    }
    if ($news_index !== false && isset($segments[$news_index + 1]) && preg_match('/^[0-9]+$/', $segments[$news_index + 1])) {
        return max(1, intval($segments[$news_index + 1]));
    }

    return 1;
}

function mangayummy_render_stiri_pagination($current_page, $total_pages) {
    if ($total_pages <= 1) {
        return;
    }

    $base = trailingslashit(home_url('/news')) . '%#%/';
    $links = paginate_links(array(
        'base'      => $base,
        'format'    => '%#%/',
        'current'   => $current_page,
        'total'     => $total_pages,
        'prev_text' => '«',
        'next_text' => '»',
        'type'      => 'list',
        'add_args'  => false,
    ));

    if ($links) {
        echo '<div class="stiri-pagination">' . $links . '</div>';
    }
}

function mangayummy_render_stiri_grid_with_pagination($query, $current_page) {
    mangayummy_render_stiri_grid($query);
    mangayummy_render_stiri_pagination($current_page, $query->max_num_pages);
}

function mangayummy_render_stiri_grid($query) {
    if (!$query || !$query->have_posts()) {
        echo '<div class="news-grid"><div class="news-card"><div class="news-card-body"><p class="about-desc">Nu există știri publicate încă pentru această categorie.</p></div></div></div>';
        return;
    }

    echo '<div class="news-grid">';
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();
        $thumb = get_the_post_thumbnail_url($post_id, 'large');
        if (!$thumb) {
            $thumb = get_post_meta($post_id, '_stire_cover_url', true);
        }
        if (!$thumb) {
            $thumb = get_template_directory_uri() . '/assets/img/default-manga.jpg';
        }
        $terms = get_the_terms($post_id, 'stiri_category');
        $term_label = '';
        if ($terms && !is_wp_error($terms)) {
            $term_label = strtoupper($terms[0]->name);
        }
        $excerpt = get_the_excerpt();
        if (!$excerpt) {
            $excerpt = wp_trim_words(get_the_content(), 24, '...');
        }
        $author_id = intval(get_post_field('post_author', $post_id));
        if (!$author_id) {
            $author_id = intval(get_post_meta($post_id, '_stire_author_id', true));
        }
        $author_name = $author_id ? get_the_author_meta('display_name', $author_id) : get_the_author();
        $author_avatar_url = $author_id ? get_user_meta($author_id, 'profile_avatar', true) : '';
        if (!$author_avatar_url) {
            $author_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }
        $author_avatar = $author_id ? '<img src="' . esc_url($author_avatar_url) . '" class="news-author-avatar" style="width:16px;height:16px;" width="16" height="16" alt="' . esc_attr($author_name) . '" />' : '';
        $profile_url = $author_id ? add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $author_id), home_url('/')) : '';
        $stire_number = function_exists('mangayummy_get_stire_number') ? mangayummy_get_stire_number($post_id) : intval($post_id);
        echo '<a href="' . esc_url(home_url('/stire/' . $stire_number . '/')) . '" class="news-card">';
        echo '<img src="' . esc_url($thumb) . '" alt="' . esc_attr(get_the_title()) . '">';
        echo '<div class="news-card-body">';
        echo '<span class="news-chip">' . esc_html($term_label ?: 'Știre') . '</span>';
        echo '<h2 class="news-card-title">' . esc_html(get_the_title()) . '</h2>';
        echo '<p class="news-card-excerpt">' . esc_html($excerpt) . '</p>';
        echo '<div class="news-card-meta"><span class="news-card-author" data-profile-url="' . esc_url($profile_url) . '">' . $author_avatar . '<strong>' . esc_html($author_name) . '</strong></span><span>' . esc_html(get_the_date('j F Y')) . '</span></div>';
        echo '</div>';
        echo '</a>';
    }
    echo '</div>';
    wp_reset_postdata();
}
?>

<style>
body {
    background: none !important;
}
.about-container {
    max-width: 1200px;
    margin: 30px auto;
    background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
    box-shadow: -4px 6px 4px rgba(0, 0, 0, 0.25), 4px 0 4px rgba(0, 0, 0, 0.25), 0 5px 4px rgba(0, 0, 0, 0.28);
    position: relative;
    overflow: hidden !important;
    display: flex;
    flex-direction: column;
    gap: 0;
    border-radius: 8px 8px 0 0;
}
.about-tabs {
    display: flex;
    position: relative;
    overflow: hidden;
    background: rgba(26, 26, 26, 0.92);
}
.about-tab-button {
    background: none;
    border: none;
    padding: 15px 25px;
    color: #aaa;
    font-size: 1.1rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 3px solid transparent;
    position: relative;
}
.about-tab-button:hover {
    color: #fff;
    background: rgba(255, 77, 79, 0.1);
}
.about-tab-button.active {
    color: #af75e4;
    border-bottom-color: #af75e4;
    background: rgba(175, 117, 228, 0.1);
}
.about-tab-content {
    display: none;
    padding: 30px 24px 40px 24px;
}
.about-tab-content.active {
    display: block;
}
.about-title {
    font-size: 2.3rem;
    margin-bottom: 16px;
    font-weight: bold;
    text-align: left;
    color: #fff;
}
.about-desc {
    font-size: 1.13rem;
    margin-bottom: 0;
    margin-left: auto;
    margin-right: auto;
    text-align: left;
    line-height: 1.7;
    color: #ccc;
}
.news-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 24px;
    margin-top: 24px;
}
.news-card {
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-height: 420px;
}
.news-card img {
    width: 100%;
    height: 220px;
    object-fit: cover;
    display: block;
}
.news-card-body {
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    flex: 1;
}
.news-card,
.news-card * {
    text-decoration: none !important;
}
.news-card-title {
    font-size: 1.15rem;
    color: #fff;
    margin: 0;
    font-weight: 700;
}
.news-card-excerpt {
    color: #ddd;
    font-size: 0.98rem;
    line-height: 1.6;
    flex: 1;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
    min-height: calc(1.6em * 3);
}
.news-card-meta {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    align-items: center;
    color: #aaa;
    font-size: 0.95rem;
}
.news-card-author {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
}
.news-author-avatar {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    object-fit: cover;
    display: inline-block;
}
.news-card-author span {
    display: inline-block;
    vertical-align: middle;
}
.news-chip {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 2px 10px;
    border-radius: 999px;
    background: #13667a;
    color: #fff;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.news-card a {
    color: inherit;
    text-decoration: none;
}
.stiri-pagination {
    margin-top: 28px;
    display: flex;
    justify-content: center;
}
.stiri-pagination .page-numbers {
    display: inline-flex;
    list-style: none;
    padding: 0;
    margin: 0;
    gap: 10px;
    flex-wrap: wrap;
}
.stiri-pagination .page-numbers li {
    display: inline-block;
}
.stiri-pagination .page-numbers a,
.stiri-pagination .page-numbers .current {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 38px;
    height: 38px;
    padding: 0 12px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,0.15);
    background: rgba(255, 255, 255, 0.05);
    color: #fff;
    text-decoration: none;
    font-size: 0.95rem;
    transition: all 0.2s ease;
}
.stiri-pagination .page-numbers a:hover {
    background: rgba(255, 255, 255, 0.14);
}
.stiri-pagination .page-numbers .current {
    background: #af75e4;
    border-color: #af75e4;
}
@media (max-width: 900px) {
    .about-container {
        margin: 20px 10px;
        border-radius: 15px;
    }
    .about-tab-content { padding: 20px 16px 24px 16px; }
    .about-title { font-size: 2rem; }
    .news-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}
@media (max-width: 600px) {
    .about-container {
        margin: 15px 5px;
        border-radius: 10px;
    }
    .about-tab-button {
        font-size: 0.9rem;
        padding: 10px 15px;
    }
    .news-grid {
        grid-template-columns: 1fr;
    }
}
.about-credit-box {
    position: absolute;
    top: 60px;
    right: 22px;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    padding: 10px 14px;
    border-radius: 8px;
    color: #fff;
    font-size: 0.9rem;
    z-index: 15;
    box-shadow: 0 4px 14px rgba(0,0,0,0.35);
    max-width: 220px;
    line-height: 1.3;
}
@media (max-width: 900px) {
    .about-credit-box { display: none; }
}
.profile-banner-top {
    display: flex;
    background: var(--head);
    color: #fff;
    border-bottom: 3px solid #13667a;
    text-transform: none;
    position: relative;
    border-radius: var(--radius) var(--radius) 0 0;
    font-size: 14px;
    font-weight: 600;
    justify-content: center;
    align-items: center;
    min-height: 50px;
    width: 100%;
    gap: 5px;
    padding-right: 10px;
    padding-left: 20px;
    text-align: center;
    padding: 15px;
}
.profile-banner-top .profile-banner-label {
    color: #fff;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
}
.profile-banner-top .profile-banner-label > a {
    position: absolute;
    right: 0;
    line-height: 0;
}
.profile-banner-top .profile-banner-label > a svg {
    fill: #fff;
    cursor: pointer;
    transition: opacity 0.2s;
}
.profile-banner-top .profile-banner-label > a:hover svg {
    opacity: 0.75;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.about-tab-button');
    const tabContents = document.querySelectorAll('.about-tab-content');

    function switchTab(tabId) {
        tabContents.forEach(content => content.classList.remove('active'));
        tabButtons.forEach(button => button.classList.remove('active'));
        const target = document.getElementById(tabId);
        if (target) target.classList.add('active');
        const activeButton = document.querySelector(`[data-tab="${tabId}"]`);
        if (activeButton) activeButton.classList.add('active');
        if (history.replaceState) {
            history.replaceState(null, null, '#' + tabId);
        } else {
            window.location.hash = tabId;
        }
    }

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            switchTab(this.getAttribute('data-tab'));
        });
    });

    const hash = window.location.hash.substring(1);
    if (hash && document.getElementById(hash)) {
        switchTab(hash);
    } else if (tabContents.length > 0) {
        tabContents[0].classList.add('active');
        tabButtons[0].classList.add('active');
    }

    document.querySelectorAll('.news-card-author[data-profile-url]').forEach(function(authorLink) {
        authorLink.addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            const url = this.dataset.profileUrl;
            if (url) {
                window.location.href = url;
            }
        });
    });
});
</script>

<main class="about-container">
    <div class="profile-banner-top">
        <span class="profile-banner-label">NEWS <a href="<?php echo esc_url(home_url('/news/create')); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M7.8 12.3H2.2c-.6 0-1.1-.3-1.6-.7-.4-.5-.6-1-.6-1.6S.2 8.9.6 8.4c.5-.4 1-.6 1.6-.6h5.6V2.2c0-.6.2-1 .6-1.5C9 .2 9.4 0 10 0s1.1.2 1.6.7c.4.4.6 1 .6 1.5v5.6h5.6A2.2 2.2 0 0120 10c0 .6-.2 1.1-.6 1.6-.5.4-1 .7-1.6.7h-5.6v5.5c0 .6-.2 1-.6 1.5-.5.5-1 .7-1.6.7s-1.1-.2-1.6-.7c-.4-.4-.6-1-.6-1.5v-5.5Z" transform="translate(0, 0)"></path></svg></a></span>
    </div>

    <div class="about-tabs">
        <button class="about-tab-button active" data-tab="toate">ALL</button>
        <button class="about-tab-button" data-tab="site">SITE</button>
        <button class="about-tab-button" data-tab="anime">ANIME</button>
        <button class="about-tab-button" data-tab="manga">MANGA</button>
    </div>

    <div id="toate" class="about-tab-content active">
        <?php mangayummy_render_stiri_grid_with_pagination(mangayummy_get_stiri_posts('', $stiri_paged), $stiri_paged); ?>
    </div>

    <div id="site" class="about-tab-content">
        <?php mangayummy_render_stiri_grid_with_pagination(mangayummy_get_stiri_posts('site', $stiri_paged), $stiri_paged); ?>
    </div>

    <div id="anime" class="about-tab-content">
        <?php mangayummy_render_stiri_grid_with_pagination(mangayummy_get_stiri_posts('anime', $stiri_paged), $stiri_paged); ?>
    </div>

    <div id="manga" class="about-tab-content">
        <?php mangayummy_render_stiri_grid_with_pagination(mangayummy_get_stiri_posts('manga', $stiri_paged), $stiri_paged); ?>
    </div>
</main>

<?php get_footer(); ?>
