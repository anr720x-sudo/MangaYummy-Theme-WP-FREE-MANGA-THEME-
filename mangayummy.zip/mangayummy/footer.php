<?php
$footer_discord_url = trim((string) get_theme_mod('mangayummy_footer_discord_url', ''));
$footer_email = trim((string) get_theme_mod('mangayummy_footer_email', ''));
$has_footer_discord = !empty($footer_discord_url);
$has_footer_email = is_email($footer_email);

$site_info_links = [];

// Resolve About page by common slugs and show only links that actually exist.
$about_page = get_page_by_path('about');
if (!$about_page) {
    $about_page = get_page_by_path('despre');
}

if ($about_page instanceof WP_Post) {
    $about_url = get_permalink($about_page);
    if ($about_url) {
        $site_info_links[] = [
            'label' => 'About us',
            'url'   => $about_url,
        ];
    }

    $about_content = strtolower((string) $about_page->post_content);

    if (strpos($about_content, 'id="terms"') !== false || strpos($about_content, "id='terms'") !== false) {
        $site_info_links[] = [
            'label' => 'Terms & Conditions',
            'url'   => trailingslashit($about_url) . '#terms',
        ];
    }

    if (strpos($about_content, 'id="dmca"') !== false || strpos($about_content, "id='dmca'") !== false) {
        $site_info_links[] = [
            'label' => 'DMCA',
            'url'   => trailingslashit($about_url) . '#dmca',
        ];
    }

    if (strpos($about_content, 'id="contact"') !== false || strpos($about_content, "id='contact'") !== false) {
        $site_info_links[] = [
            'label' => 'Contact',
            'url'   => trailingslashit($about_url) . '#contact',
        ];
    }
}

$privacy_page = get_page_by_path('privacy-policy');
if (!$privacy_page) {
    $privacy_page = get_page_by_path('politica-de-confidentialitate');
}
if ($privacy_page instanceof WP_Post) {
    $privacy_url = get_permalink($privacy_page);
    if ($privacy_url) {
        $site_info_links[] = [
            'label' => 'Privacy Policy',
            'url'   => $privacy_url,
        ];
    }
}

$site_info_links = array_values(array_unique($site_info_links, SORT_REGULAR));
$has_site_info_links = !empty($site_info_links);
?>

    <footer class="site-footer">
        <div class="footer-inner<?php echo (!$has_footer_discord && !$has_footer_email) ? ' footer-minimal' : ''; ?>">

            <?php if ($has_footer_discord): ?>
            <div class="footer-col">
                <h4 class="footer-col-title">SOCIAL MEDIA</h4>
                <div class="footer-social-icons">
                    <a href="<?php echo esc_url($footer_discord_url); ?>" target="_blank" rel="noopener" aria-label="Discord">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M16.9 3.3A15.9 15.9 0 0012.8 2c-.2.3-.4.8-.5 1.1a14.7 14.7 0 00-4.6 0c-.1-.3-.3-.8-.5-1.1-1.4.3-2.8.7-4.1 1.3a18.4 18.4 0 00-3 12A16.3 16.3 0 005.2 18c.4-.6.8-1.2 1.1-1.9-.6-.2-1.2-.5-1.7-.8L5 15c3.3 1.6 6.9 1.6 10.1 0l.4.3c-.5.3-1.1.6-1.7.9.3.6.7 1.3 1.1 1.8a16.3 16.3 0 005.1-2.7c.4-4.5-.7-8.5-3-12ZM6.7 12.9c-1 0-1.8-1-1.8-2.1 0-1.2.8-2.1 1.8-2.1s1.8.9 1.8 2.1-.8 2.1-1.8 2.1Zm6.6 0c-1 0-1.8-1-1.8-2.1 0-1.2.8-2.1 1.8-2.1s1.8.9 1.8 2.1-.8 2.1-1.8 2.1Z" transform="translate(0, 0)"></path></svg>
                    </a>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($has_site_info_links): ?>
            <div class="footer-col">
                <h4 class="footer-col-title">SITE INFORMATION</h4>
                <ul class="footer-links">
                    <?php foreach ($site_info_links as $site_info_link): ?>
                        <li><a href="<?php echo esc_url($site_info_link['url']); ?>"><?php echo esc_html($site_info_link['label']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php if ($has_footer_email || $has_footer_discord): ?>
            <div class="footer-col">
                <h4 class="footer-col-title">TECHNICAL SUPPORT</h4>
                <?php if ($has_footer_email): ?>
                <p class="footer-support-email">Email: <a href="mailto:<?php echo antispambot($footer_email); ?>"><?php echo esc_html(antispambot($footer_email)); ?></a></p>
                <?php endif; ?>
                <?php if ($has_footer_discord): ?>
                <a href="<?php echo esc_url($footer_discord_url); ?>" target="_blank" rel="noopener" class="footer-discord-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><path d="M16.9 3.3A15.9 15.9 0 0012.8 2c-.2.3-.4.8-.5 1.1a14.7 14.7 0 00-4.6 0c-.1-.3-.3-.8-.5-1.1-1.4.3-2.8.7-4.1 1.3a18.4 18.4 0 00-3 12A16.3 16.3 0 005.2 18c.4-.6.8-1.2 1.1-1.9-.6-.2-1.2-.5-1.7-.8L5 15c3.3 1.6 6.9 1.6 10.1 0l.4.3c-.5.3-1.1.6-1.7.9.3.6.7 1.3 1.1 1.8a16.3 16.3 0 005.1-2.7c.4-4.5-.7-8.5-3-12ZM6.7 12.9c-1 0-1.8-1-1.8-2.1 0-1.2.8-2.1 1.8-2.1s1.8.9 1.8 2.1-.8 2.1-1.8 2.1Zm6.6 0c-1 0-1.8-1-1.8-2.1 0-1.2.8-2.1 1.8-2.1s1.8.9 1.8 2.1-.8 2.1-1.8 2.1Z" transform="translate(0, 0)"></path></svg>
                    Server Discord
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>
        <div class="footer-bottom">
            <strong><span class="footer-copyright-main">© 2026 MangaYummy.</span> All rights reserved.</strong>
            <div style="margin-top: 8px; font-size: 12px; opacity: 0.8;">
                Powered by <a href="https://buymeacoffee.com/mangayummy9" target="_blank" rel="noopener" style="color: inherit; text-decoration: underline;">MangaYummy</a> - Free & Open Source WordPress Theme. 
                <a href="https://buymeacoffee.com/mangayummy9" target="blank" style="color: inherit; text-decoration: underline;">Support the developer ☕</a>
            </div>
        </div>
    </footer>

    <!-- FORCE FOOTER TEXT WHITE - IMMEDIATE FIX -->
    <script>
    (function() {
        // Force footer text color immediately
        var footer = document.querySelector('.site-footer');
        if (footer) {
            footer.style.color = '#fff !important';
            footer.style.background = '#1a1a1a !important';

            // Force all footer text elements except the storage disclaimer (it has its own color)
            var footerTexts = footer.querySelectorAll('*, p, span, .footer-strong, .footer-site-name, a');
            footerTexts.forEach(function(el) {
                if (el.classList.contains('storage-info')) return; // skip disclaimer
                if (el.closest('.footer-support-email')) return; // skip support email so it keeps its own color
                if (el.closest('.footer-bottom')) return; // skip footer-bottom group for custom color
                el.style.color = '#fff !important';
                el.style.setProperty('color', '#fff', 'important');
                if (el.tagName === 'A') {
                    el.style.textDecoration = 'none !important';
                    el.style.setProperty('text-decoration', 'none', 'important');
                }
            });

            // Remove any conflicting inline styles
            var allFooterElements = footer.querySelectorAll('*');
            allFooterElements.forEach(function(el) {
                if (el.style.color && el.style.color !== '#fff') {
                    el.style.color = '#fff !important';
                }
            });
        }
    })();
    </script>

    <?php wp_footer(); ?>

    <?php if (is_user_logged_in()): ?>
    <div id="globalSettingsModal" class="global-settings-modal" hidden>
        <div class="global-settings-modal__backdrop" data-close-global-settings="1"></div>
        <div class="global-settings-modal__dialog" role="dialog" aria-modal="true" aria-label="Settings">
            <iframe id="globalSettingsFrame" class="global-settings-modal__frame" title="Settings" loading="lazy"></iframe>
        </div>
    </div>
    <script>
    (function() {
        var modal = document.getElementById('globalSettingsModal');
        var frame = document.getElementById('globalSettingsFrame');
        if (!modal || !frame) return;

        var baseSrc = '<?php echo esc_js(home_url('/settings/?ya_embed=1')); ?>';

        function buildFrameSrc() {
            var url = new URL(baseSrc, window.location.origin);
            var params = new URLSearchParams(window.location.search);
            if (params.has('discord_linked')) {
                url.searchParams.set('discord_linked', params.get('discord_linked'));
            }
            if (params.has('discord_error')) {
                url.searchParams.set('discord_error', params.get('discord_error'));
            }
            return url.toString();
        }

        function openModal() {
            frame.src = buildFrameSrc();
            modal.hidden = false;
            document.body.classList.add('global-settings-open');
        }

        function closeModal() {
            modal.hidden = true;
            document.body.classList.remove('global-settings-open');
            frame.removeAttribute('src');
        }

        // Capture phase to intercept settings clicks before third-party handlers.
        document.addEventListener('click', function(e) {
            var trigger = e.target.closest('a[href="#settings"], a[href="#settings"], [data-open-settings="1"]');
            if (trigger) {
                e.preventDefault();
                e.stopPropagation();
                openModal();
                return;
            }

            if (e.target.closest('[data-close-global-settings="1"]')) {
                e.preventDefault();
                closeModal();
            }
        }, true);

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && !modal.hidden) {
                closeModal();
            }
        });

        if (window.location.hash === '#settings' || window.location.hash === '#settings') {
            openModal();
            history.replaceState({}, '', window.location.pathname + window.location.search);
        }
    })();
    </script>
    <?php endif; ?>
    
    <?php if (is_user_logged_in()): 
        $chat_user_id = get_current_user_id();
    ?>
    <!-- Chat System -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/chat.css?v=3.2">
    <script>
        var mangayummy_chat = {
            ajaxurl: '<?php echo admin_url("admin-ajax.php"); ?>',
            userId: <?php echo $chat_user_id; ?>,
            nonce: '<?php echo wp_create_nonce("ya_ajax_nonce"); ?>'
        };
    </script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/chat.js?v=<?php echo intval(@filemtime(get_template_directory() . '/js/chat.js')); ?>"></script>
    <?php endif; ?>

    <?php if (is_singular('manga')): ?>
    <!-- Chapters Progress Modal -->
    <div id="chapters-progress-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Chapters Read</h3>
                <button class="modal-close" aria-label="Close">&times;</button>
            </div>
            <div class="modal-body">
                <div class="progress-info">
                    <span class="progress-text">Progress: <span id="modal-current-progress">0</span> chapters</span>
                </div>
                <div class="input-group">
                    <label for="chapter-input">Chapter number:</label>
                    <input type="number" id="chapter-input" min="0" step="1">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-primary" id="modal-save">Save</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    </div> <!-- #page-rotate-wrapper -->
</body>
</html>