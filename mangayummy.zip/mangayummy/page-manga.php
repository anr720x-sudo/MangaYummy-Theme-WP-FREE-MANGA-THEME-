<?php
get_header();
$filter_type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 30;

// OPTIMIZED: Cache transient based on filter type (5 minute cache)
$cache_key = 'manga_all_' . ($filter_type ?: 'all');
$cached_data = get_transient($cache_key);

if ($cached_data === false) {
    // Get ALL manga with chapters - no limit
    global $wpdb;
    
    // Get all manga IDs that have chapters, ordered by latest chapter date
    $manga_query_sql = "
        SELECT DISTINCT pm.meta_value as manga_id, MAX(p.post_date) as latest_chapter_date
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_manga_id'
        WHERE p.post_type = 'chapter' 
        AND p.post_status = 'publish'
        AND pm.meta_value != ''
        GROUP BY pm.meta_value
        ORDER BY latest_chapter_date DESC
    ";
    $manga_results = $wpdb->get_results($manga_query_sql);
    
    $manga_ids = [];
    $unique_manga = [];
    
    foreach ($manga_results as $row) {
        $manga_id = intval($row->manga_id);
        if ($manga_id && !isset($unique_manga[$manga_id])) {
            $manga = get_post($manga_id);
            if ($manga && $manga->post_status === 'publish' && $manga->post_type === 'manga') {
                // Skip if this is a chapter (has _manga_id pointing elsewhere)
                if (!get_post_meta($manga_id, '_manga_id', true)) {
                    $manga_type_check = get_post_meta($manga_id, '_manga_type', true);
                    if (!$filter_type || $manga_type_check === $filter_type) {
                        $unique_manga[$manga_id] = true;
                        $manga_ids[] = $manga_id;
                    }
                }
            }
        }
    }

    // Batch fetch all chapter data for collected manga IDs
    $manga_data = [];
    if (!empty($manga_ids)) {
        $ids_placeholder = implode(',', array_map('intval', $manga_ids));
        
        // Get latest 2 chapters for each manga in one query
        $chapters_sql = "
            SELECT p.ID, p.post_title, pm1.meta_value as manga_id, pm2.meta_value as chapter_number
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_manga_id'
            LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_chapter_number'
            WHERE p.post_type = 'chapter' 
            AND p.post_status = 'publish'
            AND pm1.meta_value IN ($ids_placeholder)
            ORDER BY CAST(pm2.meta_value AS DECIMAL(10,2)) DESC
        ";
        $all_chapters = $wpdb->get_results($chapters_sql);
        
        // Group chapters by manga
        $chapters_by_manga = [];
        foreach ($all_chapters as $ch) {
            $mid = intval($ch->manga_id);
            if (!isset($chapters_by_manga[$mid])) {
                $chapters_by_manga[$mid] = [];
            }
            if (count($chapters_by_manga[$mid]) < 2) {
                $chapters_by_manga[$mid][] = $ch;
            }
        }

        // Build final data array
        $type_labels = ['manga' => 'Manga', 'manhua' => 'Manhua', 'manhwa' => 'Manhwa'];
        $status_labels = ['ongoing' => 'În curs', 'completed' => 'Finalizat', 'hiatus' => 'Pus pe pauză', 'dropped' => 'Abandonat'];
        
        foreach ($manga_ids as $manga_id) {
            $manga = get_post($manga_id);
            $manga_type = get_post_meta($manga_id, '_manga_type', true);
            $manga_status = get_post_meta($manga_id, '_status', true);
            
            $manga_data[] = [
                'id' => $manga_id,
                'title' => $manga->post_title,
                'permalink' => get_permalink($manga_id),
                'thumbnail' => get_the_post_thumbnail($manga_id, 'manga-card', ['decoding' => 'async']),
                'type' => $manga_type,
                'type_display' => $type_labels[$manga_type] ?? '',
                'status' => $manga_status,
                'status_display' => $status_labels[$manga_status] ?? '',
                'chapters' => $chapters_by_manga[$manga_id] ?? []
            ];
        }
    }
    
    $cached_data = $manga_data;
    set_transient($cache_key, $cached_data, 5 * MINUTE_IN_SECONDS);
}

// Pagination calculations
$total_manga = count($cached_data);
$total_pages = ceil($total_manga / $per_page);
$current_page = min($current_page, max(1, $total_pages));
$offset = ($current_page - 1) * $per_page;
$paged_data = array_slice($cached_data, $offset, $per_page);
$manga_count = count($paged_data);

// Build base URL for pagination
// If this template is used as a regular WP "page" (ex: /recente-actualizari/)
// use the page permalink. Otherwise default to the manga archive URL.
if (is_page()) {
    $base_url = trailingslashit(get_permalink());
} else {
    $base_url = home_url('/manga/');
}
$url_params = [];
if ($filter_type) {
    $url_params['type'] = $filter_type;
}
?>

<main class="site-main">
  <div class="ya-section">

    <?php if (is_page('recent-updates') || is_page('recente-actualizari')): ?>
    <div class="page-description">
      <h1 class="page-title">RECENT MANGA UPDATES</h1>
    </div>
    <?php endif; ?>

    <!-- Filter buttons -->
    <?php if (!is_page('recent-updates') && !is_page('recente-actualizari')): ?>
    <div class="manga-type-filters">
      <a href="<?php echo home_url('/manga/'); ?>" class="filter-btn <?php echo empty($filter_type) ? 'active' : ''; ?>">All</a>
      <a href="<?php echo home_url('/manga/?type=manga'); ?>" class="filter-btn <?php echo $filter_type === 'manga' ? 'active' : ''; ?>">Manga</a>
      <a href="<?php echo home_url('/manga/?type=manhua'); ?>" class="filter-btn <?php echo $filter_type === 'manhua' ? 'active' : ''; ?>">Manhua</a>
      <a href="<?php echo home_url('/manga/?type=manhwa'); ?>" class="filter-btn <?php echo $filter_type === 'manhwa' ? 'active' : ''; ?>">Manhwa</a>
    </div>
    <?php endif; ?>

    <div class="latest-manga-grid">
      <?php
      $item_index = 0;
      foreach ($cached_data as $manga_item):
          $manga_id = $manga_item['id'];
          $manga_type = $manga_item['type'];
          $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
          
          // First 6 images: eager load with high priority for LCP
          $img_html = $manga_item['thumbnail'];
          if ($item_index < 6) {
              $img_html = str_replace('<img ', '<img loading="eager" fetchpriority="high" ', $img_html);
          } else {
              $img_html = str_replace('<img ', '<img loading="lazy" ', $img_html);
          }
          $item_index++;
          ?>
          
          <div class="latest-manga-item<?php echo $item_index > $per_page ? ' hidden' : ''; ?>" data-manga-type="<?php echo esc_attr($manga_type ?: ''); ?>">
            <div class="manga-poster-wrap">
              <a href="<?php echo esc_url($manga_item['permalink']); ?>">
                <?php echo $img_html; ?>
              </a>

              <div class="poster-rating-overlay">
                <div class="overlay-left">
                  <?php if ($manga_item['type_display']): ?>
                    <span class="manga-type <?php echo esc_attr($type_class); ?>"><?php echo esc_html($manga_item['type_display']); ?></span>
                  <?php endif; ?>
                  <?php if ($manga_item['status_display']): ?>
                    <span class="manga-status status-<?php echo esc_attr($manga_item['status']); ?>"><?php echo esc_html($manga_item['status_display']); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <?php 
              $is_18_content = get_post_meta($manga_id, '_manga_18', true);
              if ($is_18_content): 
              ?>
                <div class="manga-18-overlay">18+</div>
              <?php endif; ?>
            </div>

            <h3 class="manga-title">
              <a href="<?php echo esc_url($manga_item['permalink']); ?>">
                <?php echo esc_html($manga_item['title']); ?>
              </a>
            </h3>

            <div class="chapters">
              <?php if (!empty($manga_item['chapters']) && (is_page('recent-updates') || is_page('recente-actualizari'))): ?>
                <?php foreach ($manga_item['chapters'] as $chapter): ?>
                  <?php
                  $chapter_number = $chapter->chapter_number;
                  $chapter_title = $chapter->post_title;
                  $chapter_permalink = get_permalink($chapter->ID);
                  ?>
                  <div class="chapter-link">
                    <a href="<?php echo esc_url($chapter_permalink); ?>">
                      <div class="chapter-row">
                        <span class="chapter-title">
                          <?php
                          if ($chapter_number !== '' && $chapter_number !== null) {
                            if ($chapter_title !== '') {
                              echo 'Ch. ' . esc_html($chapter_number) . ' – ' . esc_html($chapter_title);
                            } else {
                              echo 'Ch. ' . esc_html($chapter_number);
                            }
                          } else {
                            echo esc_html($chapter_title);
                          }
                          ?>
                        </span>
                      </div>
                    </a>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
              <?php endif; ?>
            </div>
          </div>
          
          <?php endforeach; ?>
    </div>

    <?php if ($total_manga > $per_page): ?>
    <div class="load-more-wrapper">
      <button id="load-more-manga" class="load-more-btn" data-chunk="<?php echo esc_attr($per_page); ?>">Load more</button>
    </div>
    <?php endif; ?>

    <?php if ($total_manga === 0): ?>
      <div class="no-results">
        <p>No recent manga were found.</p>
      </div>
    <?php endif; ?>
  </div>
</main>

<style>
.load-more-wrapper {
  text-align: center;
  margin: 20px 0;
}

.load-more-btn {
  background-color: #13667a;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 10px 20px;
  font-size: 15px;
  cursor: pointer;
}

.load-more-btn:hover {
  background-color: #ff6f71;
}

.latest-manga-item.hidden {
  display: none;
}

</style>

<script>
(function() {
  const button = document.getElementById('load-more-manga');
  if (!button) return;

  const chunkSize = parseInt(button.dataset.chunk, 10) || 30;

  button.addEventListener('click', function() {
    const hiddenItems = Array.from(document.querySelectorAll('.latest-manga-item.hidden'));
    for (let i = 0; i < chunkSize && hiddenItems[i]; i++) {
      hiddenItems[i].classList.remove('hidden');
    }

    if (document.querySelectorAll('.latest-manga-item.hidden').length === 0) {
      button.remove();
    }
  });
})();
</script>

    <?php if ($manga_count === 0): ?>
      <div class="no-results">
        <p>No recent manga were found.</p>
      </div>
    <?php endif; ?>
  </div>
</main>

<style>
.manga-type-filters {
  display: flex;
  gap: 10px;
  margin-bottom: 30px;
  justify-content: center;
  flex-wrap: wrap;
  padding-top: 15px;
}

.filter-btn {
  padding: 10px 20px;
  border: 2px solid #13667a;
  background: transparent;
  color: #13667a;
  border-radius: 25px;
  cursor: pointer;
  font-weight: 600;
  font-size: 14px;
  text-transform: uppercase;
  text-decoration: none;
  display: inline-block;
  -webkit-tap-highlight-color: rgba(255, 77, 79, 0.4);
}

.filter-btn:hover,
.filter-btn:active,
.filter-btn:focus {
  background: #13667a;
  color: #fff;
}

.filter-btn.active {
  background: #13667a;
  color: #fff;
}

.latest-manga-item.hidden {
  display: none;
}

/* Pagination - override global styles */
.pagination {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

.page-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 40px;
  height: 40px;
  padding: 8px 14px;
  background: #1a1a1a !important;
  color: #fff !important;
  border: 1px solid #333 !important;
  border-radius: 8px;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s ease;
  -webkit-tap-highlight-color: transparent !important;
}

.page-link:hover {
  background: #252525 !important;
  border-color: #13667a !important;
  color: #13667a !important;
}

.page-link:active,
.page-link:focus {
  background: #13667a !important;
  border-color: #13667a !important;
  color: #0f0f0f !important;
  outline: none !important;
}

.page-link.active {
  background: #13667a !important;
  color: #0f0f0f !important;
  border-color: #13667a !important;
  font-weight: 600;
}

.page-link.prev,
.page-link.next {
  padding: 8px 18px;
  font-size: 24px;
  font-weight: bold;
  line-height: 1;
}

.page-ellipsis {
  display: none;
  color: #666;
  padding: 0 8px;
}

.pagination-info {
  color: #888;
  font-size: 13px;
  margin-top: 10px;
}

@media (max-width: 600px) {
  .page-link {
    min-width: 36px;
    height: 36px;
    padding: 6px 10px;
    font-size: 13px;
  }
  .page-link.prev,
  .page-link.next {
    padding: 6px 14px;
    font-size: 20px;
  }
}

/* Disable green tap highlight globally for this page */
* {
  -webkit-tap-highlight-color: transparent;
}
a {
  -webkit-tap-highlight-color: rgba(255, 77, 79, 0.3);
}
</style>

<?php
get_footer();
?>
