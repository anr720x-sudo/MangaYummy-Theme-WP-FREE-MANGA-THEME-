<?php
/**
 * Translator Group Page Template
 * 
 * Displays a translation group with SEO optimization
 * URL: /translator/{group-slug}/
 */

// Helper function to normalize group names for comparison
function normalize_group_name($name) {
    // Convert to lowercase
    $name = strtolower($name);
    
    // Remove/replace diacritics using transliteration
    // Common Romanian diacritics: ă, â, î, ș, ț → a, a, i, s, t
    $replacements = array(
        'ă' => 'a', 'â' => 'a', 'î' => 'i', 'ș' => 's', 'ț' => 't',
        'Ă' => 'a', 'Â' => 'a', 'Î' => 'i', 'Ș' => 's', 'Ț' => 't',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'á' => 'a', 'à' => 'a', 'ä' => 'a',
        'ó' => 'o', 'ò' => 'o', 'ö' => 'o', 'ô' => 'o',
        'ú' => 'u', 'ù' => 'u', 'ü' => 'u', 'û' => 'u',
    );
    $name = strtr($name, $replacements);
    
    // Remove special characters, keep only alphanumeric and hyphens
    $name = preg_replace('/[^a-z0-9-]/', '-', $name);
    
    // Remove multiple consecutive hyphens
    $name = preg_replace('/-+/', '-', $name);
    
    // Trim hyphens from start and end
    $name = trim($name, '-');
    
    return $name;
}

// Helper function to adjust color brightness
function adjust_color_brightness($hex, $steps) {
    // Remove # if present
    $hex = ltrim($hex, '#');
    
    // Convert to RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    // Adjust brightness
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    // Convert back to hex
    return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
}

// Get group name from query var
$raw_group = get_query_var('translator_group');
$group_slug = sanitize_title(urldecode($raw_group));
if (empty($group_slug)) {
    wp_die('Invalid translator group');
}

// Normalize the slug for comparison
$normalized_slug = normalize_group_name($group_slug);

// DEBUG - Temporarily show what we're looking for
// echo '<pre>DEBUG: Looking for slug: ' . esc_html($group_slug) . ' -> normalized: ' . esc_html($normalized_slug) . '</pre>';

// Get ALL chapters first
$all_chapters = get_posts(array(
    'post_type' => 'chapter',
    'numberposts' => -1,
    'orderby' => 'meta_value_num',
    'meta_key' => '_chapter_number',
    'order' => 'DESC'
));

// Filter chapters by normalized group name
$chapters = array();
foreach ($all_chapters as $chapter) {
    $saved_group = get_post_meta($chapter->ID, '_translation_group', true);
    if ($saved_group) {
        $normalized_saved = normalize_group_name($saved_group);
        // echo '<pre>DEBUG: Chapter ' . $chapter->ID . ': "' . esc_html($saved_group) . '" -> "' . esc_html($normalized_saved) . '" matches=' . ($normalized_saved === $normalized_slug ? 'YES' : 'NO') . '</pre>';
        
        if ($normalized_saved === $normalized_slug) {
            $chapters[] = $chapter;
        }
    }
}

// sort chapters by post date descending so newest appear first
usort($chapters, function($a, $b) {
    return strcmp($b->post_date, $a->post_date);
});

// Get unique manga from chapters
$manga_ids = array();
$manga_list = array();
foreach ($chapters as $chapter) {
    $manga_id = get_post_meta($chapter->ID, '_manga_id', true);
    if ($manga_id && !in_array($manga_id, $manga_ids)) {
        $manga_ids[] = $manga_id;
        $manga = get_post($manga_id);
        if ($manga && $manga->post_type === 'manga') {
            $manga_list[] = $manga;
        }
    }
}

// Prepare SEO data
$group_name = ucwords(str_replace('-', ' ', urldecode($group_slug)));
$total_chapters = count($chapters);
$total_manga = count($manga_list);
$site_name = get_bloginfo('name');

// Generate dynamic SEO title and description
$seo_title = "Translator Group " . $group_name;
$unknown_phrase = 'Unknown translator for chapters';
$is_unknown_group = false;
$current_group_key = null; // Initialize to track if this is an official group
$seo_description = $group_name . " is a translation group. Read " . $total_chapters . " translated chapters on " . $site_name . ".";
$canonical_url = get_home_url() . '/translator/' . $group_slug . '/';

// If the group resolves to the literal 'Unknown', prefer the requested fallback phrase
if (strtolower(trim($group_name)) === 'unknown') {
    $seo_description = $unknown_phrase;
    $is_unknown_group = true;
}

// Add SEO meta tags via WordPress hooks
add_filter('pre_get_document_title', function() use ($seo_title) {
    return $seo_title . ' | ' . get_bloginfo('name');
});

add_action('wp_head', function() use ($seo_description, $canonical_url, $seo_title, $group_name) {
    echo '<meta name="description" content="' . esc_attr($seo_description) . '">' . "\n";
    echo '<meta name="robots" content="index, follow">' . "\n";
    echo '<link rel="canonical" href="' . esc_url($canonical_url) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($seo_title) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($seo_description) . '">' . "\n";
    echo '<meta property="og:type" content="website">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($canonical_url) . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . '">' . "\n";
    ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "<?php echo esc_js($group_name); ?>",
        "url": "<?php echo esc_url($canonical_url); ?>",
        "description": "<?php echo esc_js($seo_description); ?>",
        "memberOf": {
            "@type": "Organization",
            "name": "<?php echo esc_js(get_bloginfo('name')); ?>",
            "url": "<?php echo esc_url(home_url()); ?>"
        }
    }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "<?php echo esc_url(home_url('/')); ?>"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "Translator Groups",
                "item": "<?php echo esc_url(home_url('/translator-groups/')); ?>"
            },
            {
                "@type": "ListItem",
                "position": 3,
                "name": "<?php echo esc_js($group_name); ?>",
                "item": "<?php echo esc_url($canonical_url); ?>"
            }
        ]
    }
    </script>
    <?php
}, 1);

get_header();
?>

<main class="translator-group-main">
        <div class="translator-group-container">
            
            <!-- SEO Content: H1 -->
            <h1><?php echo esc_html($group_name); ?></h1>
            
            <!-- SEO Content: Description -->
            <?php if (!empty($is_unknown_group)) : ?>
                <p class="translator-group-description">
                    <?php echo esc_html($unknown_phrase); ?>
                </p>
            <?php else: ?>
                <p class="translator-group-description">
                    <?php if (!$current_group_key) : ?>
                        <strong><?php echo esc_html($group_name); ?></strong> is a translation group. Here you can find information about translated chapters.
                    <?php endif; ?>
                    <!-- always show totals inline with description -->
                    <br />
                    <?php echo absint($total_chapters); ?> translated chapter<?php echo $total_chapters === 1 ? '' : 's'; ?>
                    <?php if ($total_manga > 0) : ?>
                        • <?php echo absint($total_manga); ?> manga
                    <?php endif; ?>
                </p>

                <?php if ($normalized_slug === 'mangaterra') : ?>
                    <p class="translator-group-description">
                        Website oficial: <a href="https://mangaterra.ro" target="_blank" rel="noopener noreferrer" class="official-website-link">mangaterra.ro</a>
                    </p>
                <?php endif; ?>
            <?php endif; ?>

            <?php
            // Defensive default: keep banner logic safe even when no official groups are configured.
            $official_groups = get_option('mangayummy_official_groups', array());
            if (!is_array($official_groups)) {
                $official_groups = array();
            }
          
            foreach ($official_groups as $key => $group) {
                if ($normalized_slug === normalize_group_name($key)) {
                    $current_group_key = $key;
                    break;
                }
            }
            
            if ($current_group_key) :
                $official_group = $official_groups[$current_group_key];
            ?>
                <div class="server-group-banner" style="background: linear-gradient(135deg, <?php echo esc_attr($official_group['color']); ?>, <?php echo esc_attr(adjust_color_brightness($official_group['color'], -20)); ?>);">
                    <div class="server-badge" style="background: #fff; color: <?php echo esc_attr($official_group['color']); ?>;"><?php echo esc_html($official_group['badge']); ?></div>
                    <div class="server-info">
                        <div class="server-title">
                            <?php echo esc_html($official_group['name']); ?>
                            <?php if ($official_group['website'] !== home_url('/')) : ?>
                                <a href="<?php echo esc_url($official_group['website']); ?>" target="_blank" rel="noopener noreferrer" class="official-website-link">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <polyline points="15,3 21,3 21,9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <line x1="10" y1="14" x2="21" y2="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    Website oficial
                                </a>
                            <?php endif; ?>
                        </div>
                        <div class="server-stats"><?php echo absint($total_chapters); ?> translated chapters • <?php echo absint($total_manga); ?> <?php echo $total_manga === 1 ? 'manga' : 'manga'; ?></div>
                    </div>
                </div>
            <?php endif; ?>

            
            <!-- Manga Section -->
            <?php if (!empty($manga_list)) : ?>
                <section class="translator-group-manga">
                    <h2>Manga translated by <?php echo esc_html($group_name); ?></h2>
                    
                    <div class="manga-grid">
                        <?php foreach ($manga_list as $manga) : 
                            $manga_id = $manga->ID;
                            $chapters_count = count(array_filter($chapters, function($ch) use ($manga_id) {
                                return get_post_meta($ch->ID, '_manga_id', true) == $manga_id;
                            }));
                            ?>
                            <div class="manga-item">
                                <?php if (has_post_thumbnail($manga_id)) : ?>
                                    <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" title="<?php echo esc_attr($manga->post_title); ?>">
                                        <img src="<?php echo get_the_post_thumbnail_url($manga_id, 'full'); ?>" alt="<?php echo esc_attr($manga->post_title); ?>" class="manga-thumbnail" loading="lazy" decoding="async">
                                    </a>
                                <?php endif; ?>
                                <h3>
                                    <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" title="<?php echo esc_attr($manga->post_title); ?>">
                                        <?php echo esc_html($manga->post_title); ?>
                                    </a>
                                </h3>
                                <p class="chapter-count">
                                    <?php printf(
                                        _n('%d translated chapter', '%d translated chapters', $chapters_count, 'mangayummy'),
                                        $chapters_count
                                    ); ?>
                                </p>
                                <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" class="read-link">Read →</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>
            
            <!-- Chapters List Section (Crawlable Content) -->
            <?php if (!empty($chapters)) : ?>
                <section class="translator-group-chapters">
                    <h2>Most recent translated chapters</h2>
                    
                    <div class="chapters-list">
                        <?php 
                        $chapter_count = 0;
                        $max_initial_chapters = 10;
                        foreach ($chapters as $chapter) : 
                            $chapter_count++;
                            $manga_id = get_post_meta($chapter->ID, '_manga_id', true);
                            $manga = get_post($manga_id);
                            $chapter_number = mangayummy_get_chapter_number($chapter->ID);
                            $is_hidden = $chapter_count > $max_initial_chapters ? 'hidden-chapter' : '';
                            ?>
                            <div class="chapter-item <?php echo $is_hidden; ?>" data-chapter-id="<?php echo absint($chapter->ID); ?>">
                                <a href="<?php echo esc_url(get_permalink($chapter->ID)); ?>" title="<?php echo esc_attr($chapter->post_title); ?>">
                                    <span class="chapter-title">Chapter <?php echo esc_html($chapter_number); ?>: <?php echo esc_html($chapter->post_title); ?></span>
                                    <span class="manga-title"><?php echo $manga ? esc_html($manga->post_title) : 'Unknown'; ?></span>
                                </a>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if (count($chapters) > $max_initial_chapters) : ?>
                            <div class="show-more-container">
                                <button class="show-more-btn" data-expanded="false">
                                    <span class="show-more-text">Show more chapters</span>
                                    <span class="show-less-text" style="display: none;">Show fewer chapters</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>
            
            <!-- Fallback Content (if no chapters) -->
            <?php if (empty($chapters)) : ?>
                <div class="translator-group-empty">
                    <p><?php echo esc_html($group_name); ?> hasn't translated anything yet. Come back later!</p>
                </div>
            <?php endif; ?>
            
        </div>
    </main>
    
    <?php get_footer(); ?>
