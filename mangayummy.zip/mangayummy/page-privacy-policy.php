<?php
/**
 * Template Name: Privacy Policy
 */
get_header();
?>

<style>
body {
    background: #222 !important;
}
.privacy-container {
    max-width: 1200px;
    margin: 30px auto;
    padding: 30px;
    background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(255, 77, 79, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1);
    position: relative;
    overflow: hidden !important;
}

.privacy-container::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #13667a, #ff6b6b, #13667a);
    border-radius: 20px 20px 0 0;
    z-index: 1;
}

.privacy-content {
    position: relative;
    z-index: 2;
    color: #fff;
}

.privacy-title {
    font-size: 2.5em;
    margin-bottom: 20px;
    color: #13667a;
    text-align: center;
}

.privacy-desc {
    font-size: 1.1em;
    line-height: 1.6;
    text-align: left;
}

.privacy-desc p {
    margin-bottom: 20px;
}

.privacy-desc h2 {
    color: #13667a;
    margin-top: 30px;
    margin-bottom: 15px;
}

.privacy-desc ul {
    margin-left: 20px;
    margin-bottom: 20px;
}

.privacy-desc li {
    margin-bottom: 10px;
}

.contact-email {
    color: #13667a;
    font-weight: bold;
    background: rgba(255, 77, 79, 0.1);
    padding: 2px 6px;
    border-radius: 4px;
}
</style>

<main class="privacy-container">
    <div class="privacy-content">
        <h1 class="privacy-title">Politica de Confidențialitate</h1>
        <div class="privacy-desc">
            <p>La MangaYummy, respectăm confidențialitatea utilizatorilor noștri și ne angajăm să protejăm datele personale în conformitate cu Regulamentul General privind Protecția Datelor (GDPR) al Uniunii Europene și legislația românească aplicabilă.</p>

            <h2>1. Datele Colectate</h2>
            <p>Colectăm doar datele minime necesare pentru funcționarea site-ului:</p>
            <p><strong>Ce informații colectăm?</strong><br>
            Informații personale pe care ni le dezvăluiți: Colectăm informații personale pe care ni le furnizați în mod voluntar atunci când vă înregistrați în cadrul Serviciilor, vă exprimați interesul de a obține informații despre noi sau despre produsele și Serviciile noastre, atunci când participați la activități în cadrul Serviciilor sau în alt mod atunci când ne contactați. Informațiile personale pe care le colectăm pot include următoarele:</p>
            <ul>
                <li>adrese de e-mail</li>
                <li>nume de utilizator</li>
                <li>parole</li>
            </ul>
            <ul>
                <li><strong>Date de înregistrare:</strong> Nume de utilizator, adresă de email (pentru autentificare și comunicare)</li>
                <li><strong>Date de utilizare:</strong> Preferințe de citire, marcaje, rating-uri (stocate local sau în contul utilizatorului)</li>
            </ul>

            <h2>2. Utilizarea Datelor</h2>
            <p>Datele colectate sunt utilizate exclusiv pentru:</p>
            <ul>
                <li>Oferirea serviciilor de citire manga</li>
                <li>Îmbunătățirea funcționalităților site-ului</li>
                <li>Comunicarea cu utilizatorii (notificări, suport)</li>
            </ul>

            <h2>3. Cookies</h2>
            <p>Utilizăm cookies pentru:</p>
            <ul>
                <li><strong>Cookies esențiale:</strong> Pentru funcționarea autentificării și sesiunilor</li>
                <li><strong>Cookies de preferințe:</strong> Pentru salvarea setărilor utilizatorului (temă, limbă)</li>
            </ul>
            <p>Puteți controla cookies-urile prin setările browser-ului dumneavoastră.</p>

            <h2>4. Partajarea Datelor</h2>
            <p>Nu vindem, nu închiriem și nu partajăm datele personale cu terțe părți, cu excepția:</p>
            <ul>
                <li>Cazurilor prevăzute de lege (cereri judiciare, DMCA)</li>
                <li>Furnizorilor de servicii esențiali (hosting, analytics) care respectă GDPR</li>
            </ul>

            <h2>6. Contact</h2>
            <p>Pentru orice întrebări privind confidențialitatea sau pentru a exercita drepturile GDPR, contactați-ne la: <span class="contact-email">mangayummyteam@gmail.com</span></p>

            <h2>7. Actualizări</h2>
            <p>Această politică poate fi actualizată periodic. Vă vom informa despre modificări semnificative prin email sau notificări pe site.</p>

            <p><em>Ultima actualizare: Februarie 2026</em></p>
        </div>
    </div>
</main>

<?php get_footer(); ?>