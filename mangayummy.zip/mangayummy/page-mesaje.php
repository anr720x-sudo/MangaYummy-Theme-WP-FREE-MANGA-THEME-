<?php
/**
 * Mesaje (Messages) Page Template - rewritten
 *
 * Tabs:
 * - Capitole noi (manga_notifications)
 * - Mesaje (private_messages)
 * - Mențiuni (comment_notifications)
 */

get_header();

if (!is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

$current_user_id = get_current_user_id();

global $wpdb;

$notifications_table = $wpdb->prefix . 'manga_notifications';
$comment_notifs_table = $wpdb->prefix . 'comment_notifications';

// Fetch Capitole noi
$capitole_noi = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM $notifications_table WHERE user_id = %d ORDER BY created_at DESC LIMIT 100",
        $current_user_id
    )
);

// Fetch Mesaje
$mesaje = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}private_messages WHERE receiver_id = %d AND sender_id != 0 AND message NOT LIKE %s ORDER BY created_at DESC LIMIT 100",
        $current_user_id,
        '[NOTIF%'
    )
);

// Fetch reply notifications (private_messages) for Mențiuni tab
$reply_notifications = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}private_messages WHERE receiver_id = %d AND sender_id != 0 AND message LIKE %s ORDER BY created_at DESC LIMIT 100",
        $current_user_id,
        '[NOTIF:%'
    )
);

// Fetch Mențiuni (comment_notifications)
$mentiuni = [];
// check if table exists and has type column
$cols = $wpdb->get_results("SHOW COLUMNS FROM $comment_notifs_table LIKE 'type'");
if (!empty($cols)) {
    $mentiuni = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $comment_notifs_table WHERE user_id = %d AND (type = 'mention' OR type = 'reply') ORDER BY created_at DESC LIMIT 100",
            $current_user_id
        )
    );
}

// Merge private_message reply notifications into the mentions tab list
if (!empty($reply_notifications)) {
    foreach ($reply_notifications as $reply_notif) {
        // flag as reply and keep message/link in the object
        $reply_notif->type = 'reply';
        $mentiuni[] = $reply_notif;
    }
}

// Friend requests (incoming)
$friend_requests = get_user_meta($current_user_id, 'friend_requests', true);
if (!is_array($friend_requests)) {
    $friend_requests = [];
}

// Friend requests history log (accepted/rejected)
$friend_requests_log = get_user_meta($current_user_id, 'friend_requests_log', true);
if (!is_array($friend_requests_log)) {
    $friend_requests_log = [];
}

// Filter out invalid/deleted mention notifications so counts stay accurate
$filtered_mentiuni = [];
foreach ($mentiuni as $mn) {
    // Classic comment notification (mentions)
    if (isset($mn->comment_id) && $mn->comment_id) {
        $comment = get_comment(intval($mn->comment_id));
        if (!$comment) {
            continue;
        }
        if (isset($comment->comment_approved) && $comment->comment_approved !== '1') {
            continue;
        }
        $filtered_mentiuni[] = $mn;
        continue;
    }

    // Otherwise this is a reply notification stored in private_messages
    // We can optionally validate that the comment the notification links to still exists
    if (!empty($mn->message) && preg_match('/^\[NOTIF:(.+?)\]/s', $mn->message, $matches)) {
        $link = trim($matches[1]);
        if ($link) {
            if (preg_match('/(?:#comment-|comment_id=)(\d+)/', $link, $link_matches)) {
                $linked_comment_id = intval($link_matches[1]);
                $linked_comment = get_comment($linked_comment_id);
                if (!$linked_comment || (isset($linked_comment->comment_approved) && $linked_comment->comment_approved !== '1')) {
                    continue;
                }
            }
        }
    }

    $filtered_mentiuni[] = $mn;
}

$mentiuni = $filtered_mentiuni;

function mangayummy_time_ago_short($timestamp) {
    if (!$timestamp) return '';
    $timestamp = is_numeric($timestamp) ? intval($timestamp) : strtotime($timestamp);
    $diff = time() - $timestamp;
    if ($diff < 60) return __('acum câteva secunde', 'mangayummy');
    if ($diff < 3600) return sprintf(__('%d minute în urmă', 'mangayummy'), floor($diff / 60));
    if ($diff < 86400) return sprintf(__('%d ore în urmă', 'mangayummy'), floor($diff / 3600));
    return sprintf(__('%d zile în urmă', 'mangayummy'), floor($diff / 86400));
}
?>

<div class="messages-page">
  <header class="messages-header">
    <h1>Mesaje & Notificări</h1>
    <p class="messages-subtitle">Aici găsești cele mai recente notificări și mesaje.</p>

    <?php
      $pref_replies = get_user_meta($current_user_id, 'mangayummy_email_notif_replies', true);
      $pref_chapters = get_user_meta($current_user_id, 'mangayummy_email_notif_chapters', true);
      $pref_replies = $pref_replies === '1' ? '1' : '0';
      $pref_chapters = $pref_chapters === '1' ? '1' : '0';
    ?>
    <div class="message-prefs">
      <div class="pref-item">
        <label>
          <input type="checkbox" id="emailPrefReplies" <?php echo $pref_replies === '1' ? 'checked' : ''; ?> />
          Primește email când cineva îți răspunde la comentariu
        </label>
      </div>
      <div class="pref-item">
        <label>
          <input type="checkbox" id="emailPrefChapters" <?php echo $pref_chapters === '1' ? 'checked' : ''; ?> />
          Primește email când apare capitol nou la manga urmărită
        </label>
      </div>
      <div id="prefsMessage" class="prefs-message" style="display:none; margin-top:8px; font-size:13px;"></div>
    </div>
  </header>

  <nav class="messages-tabs" role="tablist">
    <button class="tab-btn active" data-tab="capitole">Capitole noi <span class="tab-count"><?php echo count($capitole_noi); ?></span></button>
    <button class="tab-btn" data-tab="mesaje">Mesaje <span class="tab-count"><?php echo count($mesaje); ?></span></button>
    <button class="tab-btn" data-tab="mentiuni">Mențiuni <span class="tab-count"><?php echo count($mentiuni); ?></span></button>
    <button class="tab-btn" data-tab="cereri-prietenie">Cereri prietenie <span class="tab-count"><?php echo count($friend_requests); ?></span></button>
  </nav>

  <section class="tab-content active" data-tab="capitole">
    <?php if (empty($capitole_noi)): ?>
      <div class="empty-state"><p>Nu ai capitole noi încă.</p></div>
    <?php else: ?>
      <?php foreach ($capitole_noi as $notif):
        $manga = get_post(intval($notif->manga_id));
        $chapter_id = intval($notif->chapter_id);
        $chapter_link = $chapter_id ? get_permalink($chapter_id) : '';
        if (!$chapter_link && $manga) {
            // Fallback to manga page when chapter link is unavailable
            $chapter_link = get_permalink($manga);
        }
        $cover = $manga ? get_the_post_thumbnail_url($manga, 'thumbnail') : '';
        $manga_title = $manga ? $manga->post_title : __('Manga necunoscută', 'mangayummy');
        $is_unread = intval($notif->is_read) === 0;
      ?>
        <a href="<?php echo esc_url($chapter_link ?: '#'); ?>" class="notif-card<?php echo $is_unread ? ' unread' : ''; ?>">
          <div class="notif-thumb">
            <?php if ($cover): ?>
              <img src="<?php echo esc_url($cover); ?>" alt="<?php echo esc_attr($manga_title); ?>" loading="lazy">
            <?php else: ?>
              <div class="thumb-placeholder">📖</div>
            <?php endif; ?>
          </div>
          <div class="notif-body">
            <div class="notif-header">
              <strong class="notif-title"><?php echo esc_html($manga_title); ?></strong>
              <div class="notif-meta-group">
                <?php if ($is_unread): ?><span class="badge">Nou</span><?php endif; ?>
                <span class="notif-meta"><?php echo esc_html(mangayummy_time_ago_short($notif->created_at)); ?></span>
              </div>
            </div>
            <div class="notif-subtitle">
              <?php
                $chapter_number = trim((string) ($notif->chapter_number ?? ''));
                $chapter_title = trim((string) ($notif->chapter_title ?? ''));

                if (!$chapter_title && $chapter_number) {
                  $chapter_title = sprintf('Chapter %s', $chapter_number);
                }

                $chapter_text = '';
                if ($chapter_number) {
                    $chapter_text = 'Cap. ' . $chapter_number;
                }
                if ($chapter_title) {
                    $chapter_text .= $chapter_text ? ' - ' : '';
                    $chapter_text .= $chapter_title;
                }

                echo esc_html($chapter_text ?: __('New chapter', 'mangayummy'));
              ?>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>

  <section class="tab-content" data-tab="mesaje">
    <?php if (empty($mesaje)): ?>
      <div class="empty-state"><p>Nu ai mesaje.</p></div>
    <?php else: ?>
      <?php foreach ($mesaje as $msg):
        $sender = get_user_by('ID', intval($msg->sender_id));
        $sender_name = $sender ? $sender->display_name : __('Utilizator necunoscut', 'mangayummy');
        $avatar_url = $sender ? get_user_meta($sender->ID, 'profile_avatar', true) : '';
        if (!$avatar_url) {
          $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }
        $excerpt = wp_trim_words($msg->message, 20);
      ?>
        <div class="notif-card">
          <div class="notif-thumb">
            <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($sender_name); ?>" loading="lazy">
          </div>
          <div class="notif-body">
            <div class="notif-header">
              <strong class="notif-title"><?php echo esc_html($sender_name); ?></strong>
              <span class="notif-meta"><?php echo esc_html(mangayummy_time_ago_short($msg->created_at)); ?></span>
            </div>
            <div class="notif-subtitle"><?php echo esc_html($excerpt); ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>

  <section class="tab-content" data-tab="mentiuni">
    <?php if (empty($mentiuni)): ?>
      <div class="empty-state"><p>Nu ai mențiuni.</p></div>
    <?php else: ?>
      <?php foreach ($mentiuni as $mn):
        // If this is a classic comment notification (mentions)
        if (isset($mn->comment_id) && $mn->comment_id) {
          $comment = get_comment(intval($mn->comment_id));
          if (!$comment) continue;
          // Skip deleted/trashed/unapproved comments
          if (isset($comment->comment_approved) && $comment->comment_approved !== '1') {
            continue;
          }

          $comment_link = get_comment_link($comment->comment_ID);
          $author = $comment->user_id ? get_user_by('ID', $comment->user_id) : null;
          $author_name = $author ? $author->display_name : $comment->comment_author;
          $excerpt = wp_trim_words($comment->comment_content, 20);
          $type_label = (isset($mn->type) && $mn->type === 'reply') ? 'Răspuns' : 'Mențiune';
          $link = $comment_link;

          // Avatar: comment author
          $avatar_url = '';
          if ($comment->user_id) {
            $avatar_url = get_user_meta($comment->user_id, 'profile_avatar', true);
          }
          if (!$avatar_url) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          }

        // Otherwise this is a reply notification stored in private_messages
        } else {
          $link = '';
          $excerpt = '';
          $type_label = 'Răspuns';

          if (!empty($mn->message) && preg_match('/^\[NOTIF:(.+?)\](.*)$/s', $mn->message, $matches)) {
            $link = trim($matches[1]);
            $excerpt = trim($matches[2]);
          } else {
            $excerpt = trim($mn->message ?? '');
          }

          // If the notification points to a comment that no longer exists, skip it
          if ($link) {
            if (preg_match('/(?:#comment-|comment_id=)(\d+)/', $link, $link_matches)) {
              $linked_comment_id = intval($link_matches[1]);
              $linked_comment = get_comment($linked_comment_id);
              if (!$linked_comment || (isset($linked_comment->comment_approved) && $linked_comment->comment_approved !== '1')) {
                continue;
              }
            }
          }

          $sender = get_user_by('ID', intval($mn->sender_id));
          $author_name = $sender ? $sender->display_name : __('Utilizator', 'mangayummy');

          // Avatar: sender
          $avatar_url = $sender ? get_user_meta($sender->ID, 'profile_avatar', true) : '';
          if (!$avatar_url) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          }
        }
      ?>
        <a href="<?php echo esc_url($link ?: '#'); ?>" class="notif-card">
          <div class="notif-thumb">
            <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($author_name); ?>" loading="lazy">
          </div>
          <div class="notif-body">
            <div class="notif-header">
              <strong class="notif-title"><?php echo esc_html($author_name); ?></strong>
              <div class="notif-meta-group">
                <span class="notif-badge"><?php echo esc_html($type_label); ?></span>
                <span class="notif-meta"><?php echo esc_html(mangayummy_time_ago_short($mn->created_at)); ?></span>
              </div>
            </div>
            <div class="notif-subtitle"><?php echo esc_html($excerpt); ?></div>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>

  <section class="tab-content" data-tab="cereri-prietenie">
    <?php if (empty($friend_requests) && empty($friend_requests_log)): ?>
      <div class="empty-state"><p>Nu ai cereri de prietenie.</p></div>
    <?php else: ?>
      <?php if (!empty($friend_requests)): ?>
        <div class="subsection-title subsection-title-padded"><strong>Cereri în așteptare</strong></div>
        <?php foreach ($friend_requests as $requester_id):
          $requester = get_user_by('ID', intval($requester_id));
          if (!$requester) continue;
          $requester_name = $requester->display_name;
          $avatar_url = get_user_meta($requester->ID, 'profile_avatar', true);
          if (!$avatar_url) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          }
        ?>
          <div class="notif-card friend-request-item">
            <div class="notif-thumb">
              <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($requester_name); ?>" loading="lazy">
            </div>
            <div class="notif-body">
              <div class="notif-header">
                <strong class="notif-title"><?php echo esc_html($requester_name); ?></strong>
                <div class="notif-meta-group">
                  <span class="notif-badge">Cerere prietenie</span>
                  <span class="notif-meta"><?php echo __('Acum', 'mangayummy'); ?></span>
                </div>
              </div>
              <div class="notif-subtitle"><?php echo __('A îți trimis o cerere de prietenie.', 'mangayummy'); ?></div>
              <div class="friend-request-actions">
                <button class="accept-friend-btn" data-user-id="<?php echo intval($requester_id); ?>"><?php echo __('Acceptă', 'mangayummy'); ?></button>
                <button class="reject-friend-btn" data-user-id="<?php echo intval($requester_id); ?>"><?php echo __('Respinge', 'mangayummy'); ?></button>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>

      <?php if (!empty($friend_requests_log)): ?>
        <div class="subsection-title subsection-title-padded" style="margin-top: 20px;"><strong>Istoric cereri</strong></div>
        <?php
          $sorted_requests_log = $friend_requests_log;
          usort($sorted_requests_log, function($a, $b) {
              $ta = strtotime($a['timestamp']);
              $tb = strtotime($b['timestamp']);
              return $tb <=> $ta; // newest first
          });
        ?>
        <?php foreach ($sorted_requests_log as $log_item):
          $requester = get_user_by('ID', intval($log_item['user_id']));
          if (!$requester) continue;
          $requester_name = $requester->display_name;
          $avatar_url = get_user_meta($requester->ID, 'profile_avatar', true);
          if (!$avatar_url) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          }
          $status_text = $log_item['status'] === 'accepted' ? __('Acceptat', 'mangayummy') : __('Respins', 'mangayummy');
          $status_class = $log_item['status'] === 'accepted' ? 'status-accepted' : 'status-rejected';
        ?>
          <div class="notif-card friend-request-item <?php echo esc_attr($status_class); ?>">
            <div class="notif-thumb">
              <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($requester_name); ?>" loading="lazy">
            </div>
            <div class="notif-body">
              <div class="notif-header">
                <strong class="notif-title"><?php echo esc_html($requester_name); ?></strong>
                <div class="notif-meta-group">
                  <span class="notif-badge"><?php echo esc_html($status_text); ?></span>
                  <span class="notif-meta"><?php echo esc_html($log_item['timestamp']); ?></span>
                </div>
              </div>
              <div class="notif-subtitle"><?php echo esc_html($status_text . ' cerere de prietenie'); ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    <?php endif; ?>
  </section>
</div>

<style>
.messages-page { max-width: 920px; margin: 40px auto; padding: 0 16px; }
.messages-page > .messages-header,
.messages-page > .messages-tabs {
  display: block;
  background: var(--head);
  border-radius: var(--radius);
  padding: 16px;
  margin-bottom: 20px;
}

.messages-page > .tab-content {
  background: var(--head);
  border-radius: var(--radius);
  padding: 16px;
  margin-bottom: 20px;
}

.messages-header { text-align: center; margin-bottom: 0; }
.messages-header h1 { font-size: 28px; margin: 0 0 8px; }
.messages-subtitle { color: #ccc; margin: 0; }

.messages-tabs { display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; margin-bottom: 0; }
.tab-btn { border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.04); color: #ddd; padding: 10px 14px; border-radius: 999px; cursor: pointer; font-weight: 600; }
.tab-btn.active { background: rgba(3,199,90,0.2); border-color: rgba(3,199,90,0.4); color: #fff; }
.tab-count { margin-left: 6px; background: rgba(0,0,0,0.2); padding: 2px 8px; border-radius: 999px; font-size: 12px; }

.tab-content { display: none; }
.tab-content.active { display: block; }

.notif-card { display: flex; gap: 14px; padding: 14px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; margin-bottom: 12px; text-decoration: none; color: inherit; opacity: 0.75; }
.notif-card:hover { background: rgba(255,255,255,0.06); border-color: rgba(3,199,90,0.2); }
.notif-card.unread { opacity: 1; border-color: rgba(3,199,90,0.5); }

.friend-request-item.status-accepted,
.friend-request-item.status-rejected {
  opacity: 0.6;
  background: rgba(255,255,255,0.08);
  border-color: rgba(255,255,255,0.12);
}

.subsection-title-padded {
  padding: 14px 0 8px;
}

.friend-request-item.status-accepted .notif-badge {
  background: rgba(3,199,90,0.15);
  color: #13667a;
}

.friend-request-item.status-rejected .notif-badge {
  background: rgba(231,76,60,0.15);
  color: #e74c3c;
}

.notif-thumb { width: 68px; height: 68px; flex-shrink: 0; border-radius: 10px; background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.notif-thumb img { width: 100%; height: 100%;  }
.thumb-placeholder { font-size: 24px; }

.notif-body { flex: 1; min-width: 0; }
.notif-header { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.notif-meta-group { display: flex; align-items: center; gap: 10px; }
.notif-title { font-weight: 700; font-size: 14px; }
.badge { background: rgba(3,199,90,0.25); color: #13667a; padding: 2px 8px; border-radius: 999px; font-size: 11px; }
.notif-subtitle {
  margin: 6px 0 0;
  color: #ccc;
  font-size: 13px;
  max-height: 40px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-word;
}
.friend-request-actions {
  margin-top: 10px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.accept-friend-btn,
.reject-friend-btn {
  border: 1px solid rgba(255,255,255,0.25);
  background: rgba(3,199,90,0.15);
  color: #13667a;
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}
.reject-friend-btn {
  border-color: rgba(231,76,60,0.35);
  background: rgba(231,76,60,0.14);
  color: #e74c3c;
}
.accept-friend-btn:hover {
  background: rgba(3,199,90,0.25);
  color: #fff;
}
.reject-friend-btn:hover {
  background: rgba(231,76,60,0.25);
  color: #fff;
}
.notif-meta { color: rgba(255,255,255,0.6); font-size: 12px; margin-left: auto; }

.message-prefs { display: flex; flex-wrap: wrap; gap: 16px; justify-content: center; margin-top: 18px; }
.message-prefs .pref-item { display: flex; align-items: center; gap: 10px; font-size: 13px; color: #ccc; }
.message-prefs .pref-item label { cursor: pointer; display: flex; align-items: center; gap: 10px; }
.message-prefs input[type="checkbox"] { width: 18px; height: 18px; accent-color: #13667a; }
.prefs-message { text-align: center; }

.empty-state { padding: 40px; text-align: center; color: #888; }

@media (max-width: 768px) {
  .messages-tabs {
    flex-wrap: nowrap !important;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
  .messages-tabs .tab-btn {
    display: block;
    width: 100%;
    text-align: center;
    margin-bottom: 8px;
  }
  .notif-card { flex-direction: row; }
  .notif-thumb { width: 68px; height: 68px; }
  .notif-card .notif-body { margin-left: 12px; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const tabs = Array.from(document.querySelectorAll('.tab-btn'));
  const panels = Array.from(document.querySelectorAll('.tab-content'));

  function activate(tabName) {
    tabs.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tabName));
    panels.forEach(panel => panel.classList.toggle('active', panel.dataset.tab === tabName));
  }

  function getInitialTab() {
    const hash = window.location.hash.replace('#', '');
    const valid = tabs.find(btn => btn.dataset.tab === hash);
    return valid ? hash : 'capitole';
  }

  const initialTab = getInitialTab();
  activate(initialTab);
  if (window.location.hash !== '#' + initialTab) {
    history.replaceState(null, '', '#' + initialTab);
  }

  tabs.forEach(btn => {
    btn.addEventListener('click', function() {
      activate(this.dataset.tab);
      history.replaceState(null, '', '#' + this.dataset.tab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  // Email preference toggles
  const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
  const ajaxNonce = '<?php echo wp_create_nonce('ya_ajax_nonce'); ?>';
  const prefReplies = document.getElementById('emailPrefReplies');
  const prefChapters = document.getElementById('emailPrefChapters');
  const prefsMessage = document.getElementById('prefsMessage');

  function savePrefs() {
    if (!prefReplies || !prefChapters) return;
    const payload = new URLSearchParams();
    payload.append('action', 'mangayummy_save_email_prefs');
    payload.append('nonce', ajaxNonce);
    payload.append('replies', prefReplies.checked ? '1' : '0');
    payload.append('chapters', prefChapters.checked ? '1' : '0');

    fetch(ajaxUrl, {
      method: 'POST',
      body: payload,
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          if (prefsMessage) {
            prefsMessage.textContent = res.data.message || 'Preferințele au fost salvate.';
            prefsMessage.style.color = '#13667a';
            prefsMessage.style.display = 'block';
            setTimeout(() => prefsMessage.style.display = 'none', 2500);
          }
        } else {
          if (prefsMessage) {
            prefsMessage.textContent = res.data?.message || 'Eroare la salvare.';
            prefsMessage.style.color = '#ff6b6b';
            prefsMessage.style.display = 'block';
            setTimeout(() => prefsMessage.style.display = 'none', 2500);
          }
        }
      })
      .catch(() => {
        if (prefsMessage) {
          prefsMessage.textContent = 'Eroare la salvare.';
          prefsMessage.style.color = '#ff6b6b';
          prefsMessage.style.display = 'block';
          setTimeout(() => prefsMessage.style.display = 'none', 2500);
        }
      });
  }

  if (prefReplies) prefReplies.addEventListener('change', savePrefs);
  if (prefChapters) prefChapters.addEventListener('change', savePrefs);
});
</script>

<?php
// Mark all notifications as read after they have been displayed
$notifications_table = $wpdb->prefix . 'manga_notifications';
$wpdb->query($wpdb->prepare(
    "UPDATE $notifications_table SET is_read = 1 WHERE user_id = %d",
    $current_user_id
));

$comment_notifs_table = $wpdb->prefix . 'comment_notifications';
$wpdb->query($wpdb->prepare(
    "UPDATE $comment_notifs_table SET is_read = 1 WHERE user_id = %d AND (type = 'mention' OR type = 'reply')",
    $current_user_id
));

// Mark system/private notifications (NOTIF messages) as read as well
$wpdb->query($wpdb->prepare(
    "UPDATE {$wpdb->prefix}private_messages SET is_read = 1 WHERE receiver_id = %d AND is_read = 0",
    $current_user_id
));

get_footer();

