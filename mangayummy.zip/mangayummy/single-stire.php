<?php
get_header();

$has_giphy_api = function_exists('mangayummy_has_giphy_api_key') ? mangayummy_has_giphy_api_key() : (trim((string) get_option('mangayummy_giphy_api_key', '')) !== '');

$post_id = get_the_ID();
$excerpt = get_post_field('post_excerpt', $post_id);
if (!$excerpt) {
    $excerpt = wp_trim_words(get_the_content(), 30, '...');
}
$thumbnail = get_the_post_thumbnail_url($post_id, 'large');
if (!$thumbnail) {
    $thumbnail = get_post_meta($post_id, '_stire_cover_url', true);
}
$youtube_embed = get_post_meta($post_id, '_stire_youtube_url', true);
$author_id = intval(get_post_field('post_author', $post_id));
if (!$author_id) {
    $author_id = intval(get_post_meta($post_id, '_stire_author_id', true));
}
$author_name = $author_id ? get_the_author_meta('display_name', $author_id) : '';
$author_profile_url = $author_id ? add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $author_id), home_url('/')) : '';
$author_avatar = '';
$stire_likes = intval(get_post_meta($post_id, '_stire_likes', true));
$stire_dislikes = intval(get_post_meta($post_id, '_stire_dislikes', true));
$stire_reaction = '';
if ($author_id) {
    $author_avatar_url = get_user_meta($author_id, 'profile_avatar', true);
    if (!$author_avatar_url) {
        $author_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
    }
    $author_avatar = '<img src="' . esc_url($author_avatar_url) . '" class="stire-author-avatar" width="28" height="28" alt="' . esc_attr($author_name) . '" />';
}
$current_user_id = get_current_user_id();
if ($current_user_id) {
    $stire_reaction = get_user_meta($current_user_id, 'reacted_stire_' . $post_id, true) ?: '';
}
$comments_count = get_comments_number($post_id);
?>

<main class="stire-page" id="main-page">
    <section class="stire-hero">
        <div class="stire-hero-inner">
            <h1 class="stire-title"><?php the_title(); ?></h1>
        </div>
    </section>

    <section class="stire-content">
        <?php
        // Get processed content (runs do_blocks, wpautop, and all the_content filters)
        $stire_processed = apply_filters('the_content', get_the_content());
        // If content still has no <p> tags (e.g. classic editor with single newlines), force wpautop
        if (strpos($stire_processed, '<p') === false) {
            $stire_raw = get_the_content();
            $stire_raw = str_replace(["\r\n", "\r"], "\n", $stire_raw);
            // Ensure each non-empty line becomes its own paragraph
            $stire_raw = preg_replace('/\n(?!\n)/', "\n\n", $stire_raw);
            echo wpautop($stire_raw);
        } else {
            echo $stire_processed;
        }
        ?>
    </section>

    <?php if (!empty($youtube_embed)): ?>
        <section class="stire-video">
            <div class="video-wrapper">
                <iframe src="<?php echo esc_url($youtube_embed); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($thumbnail)): ?>
        <section class="stire-cover">
            <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" loading="lazy" decoding="async">
        </section>
    <?php endif; ?>

    <section class="stire-summary">
        <?php echo wp_kses_post(nl2br($excerpt)); ?>
    </section>

    <?php if ($author_id): ?>
        <section class="stire-author-section">
            <div class="stire-author-row">
                <a href="<?php echo esc_url($author_profile_url); ?>" class="stire-author-link">
                    <?php echo $author_avatar; ?>
                    <span><?php echo esc_html($author_name); ?></span>
                </a>
                <span class="stire-author-date"><?php echo esc_html(get_the_date('j F Y')); ?></span>
                <div class="stire-author-actions">
                    <button type="button" class="comment-action-btn comment-like like-btn<?php echo $stire_reaction === 'like' ? ' active' : ''; ?>" title="Like" data-action="like" data-post-id="<?php echo esc_attr($post_id); ?>">
                        <i class="fa fa-thumbs-up"></i>
                        <span class="count"><?php echo $stire_likes; ?></span>
                    </button>
                    <button type="button" class="comment-action-btn comment-dislike dislike-btn<?php echo $stire_reaction === 'dislike' ? ' active' : ''; ?>" title="Dislike" data-action="dislike" data-post-id="<?php echo esc_attr($post_id); ?>">
                        <i class="fa fa-thumbs-down"></i>
                        <span class="count"><?php echo $stire_dislikes; ?></span>
                    </button>
                </div>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php
$comments_cache_key = 'mangayummy_stire_comments_' . $post_id;
$all_comments = get_transient($comments_cache_key);
if ($all_comments === false) {
    $all_comments = get_comments([
        'post_id' => $post_id,
        'parent'  => 0,
        'status'  => 'approve',
        'orderby' => 'date',
        'order'   => 'DESC',
    ]);
    set_transient($comments_cache_key, $all_comments, 5);
}
$comments_count = get_comments_number();

?>

    <section class="manga-comments-section">
      <div class="tabs-block content-page offset-top no-padding">
        <div class="tabs-header" style="overflow: visible;">
          <ul class="tabs bordered-top">
            <li class="active tabs-li bordered-top-left materiable" data-id="#comments-tab" id="comments">
              <span class="title" style="display: initial"><i class="fa fa-comment"></i> Comentarii</span>
              <span class="count"><?php echo $comments_count; ?></span>
            </li>
          </ul>
        </div>

        <div class="tabs-content" style="min-height: 130px; padding: 10px;">
          <div id="comments-tab" class="tab-content active">
            <div class="comment-form-wrapper">
              <div class="comment-form-header">
                <span class="comment-form-title"><i class="fa fa-pencil"></i> Add a comment</span>
              </div>

              <div id="manga-comment-form" class="manga-comment-form" data-post-id="<?php echo get_the_ID(); ?>">
                <div class="comment-toolbar">
                    <div class="toolbar-left">
                      <button type="button" class="format-btn text-format-btn" data-format="bold" title="Bold (Ctrl+B)">
                        <i class="fa fa-bold"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="italic" title="Italic (Ctrl+I)">
                        <i class="fa fa-italic"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="underline" title="Underline">
                        <i class="fa fa-underline"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="spoiler" title="Spoiler">
                        <i class="fa fa-eye-slash"></i>
                      </button>
                      <button type="button" class="format-btn text-format-btn" data-format="code" title="Code">
                        <i class="fa fa-code"></i>
                      </button>
                    </div>
                    <div class="toolbar-right">
                      <button type="button" class="format-btn emoji-picker-btn" title="Adaugă emoji">
                        <i class="fa fa-smile-o"></i>
                      </button>
                      <?php if ($has_giphy_api): ?>
                      <button type="button" class="format-btn gif-picker-btn" title="Adaugă GIF" style="font-weight:700; font-size:12px;">GIF</button>
                      <?php endif; ?>
                      <div class="emoji-picker-popup" style="display: none;">
                        <div class="emoji-categories">
                          <button type="button" class="emoji-category active" data-category="smileys">😊</button>
                          <button type="button" class="emoji-category" data-category="hand">👋</button>
                          <button type="button" class="emoji-category" data-category="heart">❤️</button>
                          <button type="button" class="emoji-category" data-category="fire">🔥</button>
                          <button type="button" class="emoji-category" data-category="star">⭐</button>
                        </div>
                        <div class="emoji-grid" id="emoji-grid">
                        </div>
                      </div>
                      <?php if ($has_giphy_api): ?>
                      <div class="gif-picker-popup" style="display: none;">
                        <div class="gif-search-wrapper">
                          <input type="text" id="gif-search-input" class="gif-search-input" placeholder="Caută GIF-uri...">
                          <button type="button" id="gif-search-btn" class="gif-search-btn">🔍</button>
                        </div>
                        <div class="gif-grid" id="gif-grid">
                          <div class="gif-loading">Loading GIFs...</div>
                        </div>
                      </div>
                      <?php endif; ?>
                    </div>
                  </div>

                  <div class="form-group">
                    <div id="gif-preview" class="gif-preview" style="display:none; margin-bottom:8px;"></div>
                    <textarea 
                      id="manga-comment-text" 
                      class="comment-textarea" 
                      placeholder="Share your opinion about this news..." 
                      rows="4" 
                      minlength="1"
                      maxlength="1000"
                      required></textarea>
                    <small class="comment-help">0/1000 caractere</small>
                  </div>
                  <div class="form-actions">
                    <button type="button" class="btn-submit-comment" id="submit-manga-comment">
                      <i class="fa fa-send"></i> Postează comentariu
                    </button>
                  </div>
                  <?php wp_nonce_field( 'mangayummy_comment_nonce', 'nonce' ); ?>
                </div>
                <div id="comment-message" class="comment-message" style="display:none;"></div>
              </div>

            <div class="comments-sort-block"<?php echo empty($all_comments) ? ' style="display:none"' : ''; ?>>
              <div class="sort-label">Sortare:</div>
              <div class="sort-buttons">
                <button type="button" class="sort-btn active" data-sort="newest" title="Cel mai nou comentariu">
                  <i class="fa fa-clock-o"></i> Cele mai noi
                </button>
                <button type="button" class="sort-btn" data-sort="oldest" title="Cele mai vechi comentariu">
                  <i class="fa fa-history"></i> Cele mai vechi
                </button>
                <button type="button" class="sort-btn" data-sort="liked" title="Cele mai apreciate comentarii">
                  <i class="fa fa-heart"></i> Cele mai apreciate
                </button>
              </div>
            </div>

            <div class="comments-list-wrapper">
              <?php
              if ( !empty($all_comments) ) :
                echo '<div class="comments-list" data-sort-type="newest">';
                foreach ( $all_comments as $comment ) :
                  $GLOBALS['comment'] = $comment;
                  manga_comment_callback($comment);
                endforeach;
                echo '</div>';
              endif;
              ?>
            </div>
          </div>
        </div>
      </div>
    </section>


<style>
.stire-page {
    max-width: 1200px;
    margin: 30px auto 1px;
    padding: 0 16px;
    background: var(--head);
    border-radius: 24px;
    padding-bottom: 10px;
    padding-top: 10px;
}
.stire-hero {
    text-align: left;
    padding: 30px 0 20px;
    background: var(--head);
}
.stire-title {
    font-size: clamp(1.4rem, 2vw, 1.8rem);
    line-height: 1.1;
    text-align: left;
    letter-spacing: -0.03em;
    color: #fff;
    margin: 0;
    font-weight: 800;
}
.stire-cover {
    margin: 0 auto 28px;
    max-width: 100%;
    overflow: hidden;
    border-radius: 18px;
}
.stire-video {
    margin: 0 auto 24px;
    max-width: 100%;
}
.stire-video .video-wrapper {
    position: relative;
    width: 100%;
    padding-top: 56.25%;
    overflow: hidden;
    border-radius: 18px;
    background: #000;
}
.stire-video iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 0;
}
.stire-cover img {
    width: auto;
    max-width: 100%;
    height: auto;
    max-height: 700px;
    display: block;
    margin: 0 auto;
    object-fit: contain;
}
.stire-author-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    object-fit: cover;
    display: block;
}
.stire-author-section {
    margin: 18px -16px 1px;
    width: calc(100% + 32px);
    border-top: 3px solid #13667a;
    padding: 12px 16px 0;
}
.stire-author-row {
    display: flex;
    align-items: center;
    gap: 5px;
}
.stire-author-link {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    border-radius: 999px;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}
.stire-author-link:hover {
    background: rgba(255, 255, 255, 0.1);
}
.stire-author-date {
    color: #bbb;
    font-size: 0.95rem;
}
.stire-author-actions {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
    gap: 2px;
}
.stire-author-actions .comment-action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    background: transparent;
    border: 1px solid #2a2a2a;
    color: #999;
    border-radius: 5px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    transition: all 0.2s ease;
}
.stire-author-actions .comment-action-btn i {
    font-size: 14px;
    color: #999;
    transition: color 0.2s ease;
}
.stire-author-actions .comment-action-btn.like-btn:hover {
    background: #333;
    color: #13667a;
    border-color: #13667a;
    transform: translateY(-1px);
}
.stire-author-actions .comment-action-btn.like-btn:hover i {
    color: #13667a;
}
.stire-author-actions .comment-action-btn.dislike-btn:hover {
    background: #333;
    color: #13667a;
    border-color: #13667a;
    transform: translateY(-1px);
}
.stire-author-actions .comment-action-btn.dislike-btn:hover i {
    color: #13667a;
}
.stire-author-actions .comment-action-btn.like-btn.active,
.stire-author-actions .comment-action-btn.like-btn.active:hover {
    color: #13667a;
    background: #333;
    border-color: #13667a;
}
.stire-author-actions .comment-action-btn.like-btn.active i,
.stire-author-actions .comment-action-btn.like-btn.active:hover i {
    color: #13667a;
}
.stire-author-actions .comment-action-btn.dislike-btn.active,
.stire-author-actions .comment-action-btn.dislike-btn.active:hover {
    color: #13667a;
    background: #333;
    border-color: #13667a;
}
.stire-author-actions .comment-action-btn.dislike-btn.active i,
.stire-author-actions .comment-action-btn.dislike-btn.active:hover i {
    color: #cf0000;
}
.stire-author-meta .stire-author-date {
    font-size: 0.95rem;
}
.stire-summary {
    margin: 24px 0;
    font-size: 1.05rem;
    line-height: 1.8;
    color: #ddd;
    background: #333;
    border: 1px solid #13667a;
    border-radius: 16px;
    padding: 22px 24px;
}
.stire-summary a,
.stire-summary a *,
.stire-content a,
.stire-content a * {
    color: #13667a !important;
    text-decoration: none !important;
}
.stire-summary a:hover,
.stire-summary a:hover *,
.stire-content a:hover,
.stire-content a:hover * {
    color: #13667a !important;
}
.stire-content {
    color: #f2f2f2;
    line-height: 1.9;
    font-size: 1rem;
}
/* Paragraphs – classic editor & Gutenberg paragraph blocks */
.stire-content p,
.stire-content > div > p,
.stire-content .wp-block-paragraph {
    margin-top: 0 !important;
    margin-bottom: 1.2em !important;
}
/* Gutenberg group/cover/etc blocks wrap content in a div — give that div spacing too */
.stire-content > div {
    margin-bottom: 1.2em;
}
/* br-based line breaks: add a small gap so single-newline content breathes */
.stire-content br {
    display: block;
    margin-bottom: 0.7em;
    content: "";
}
.stire-content h1,
.stire-content h2,
.stire-content h3,
.stire-content h4,
.stire-content h5,
.stire-content h6 {
    margin-top: 1.5em !important;
    margin-bottom: 0.6em !important;
    color: #fff;
    font-weight: 700;
}
.stire-content ul,
.stire-content ol {
    margin: 0.8em 0 1.2em 1.5em;
    padding-left: 1em;
}
.stire-content li {
    margin-bottom: 0.4em;
}
.stire-content blockquote {
    margin: 1.2em 0;
    padding: 0.8em 1.2em;
    border-left: 3px solid #13667a;
    background: #333;
    border-radius: 4px;
    color: #ccc;
}
.stire-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1em 0;
}
.stire-comments-section {
    background: #333;
    border: 1px solid #13667a;
    border-radius: 18px;
    padding: 24px;
}
.stire-comments-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    margin-bottom: 18px;
}
.stire-comments-header h2 {
    margin: 0;
    font-size: 1.55rem;
    color: #fff;
}
.stire-comments-count {
    color: #aaa;
    font-size: 0.95rem;
}
.stire-comment-form {
    margin-bottom: 24px;
}
.stire-page ~ .manga-comments-section .comment-textarea {
    background: #222 !important;
    color: #fff !important;
    border: 1px solid #333 !important;
    padding: 12px;
    font-size: 14px;
    min-height: 100px;
    border-radius: 6px;
    font-family: inherit;
    resize: vertical;
    transition: all 0.2s ease;
}
.stire-page ~ .manga-comments-section .comment-textarea:focus {
    border-color: #222 !important;
    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.15);
    outline: none;
}
.single-manga .comment-textarea {
    background: #222 !important;
    color: #fff !important;
    border: 1px solid #333 !important;
    padding: 12px;
    font-size: 14px;
    min-height: 100px;
    border-radius: 6px;
    font-family: inherit;
    resize: vertical;
    transition: all 0.2s ease;
}
.single-manga .comment-textarea:focus {
    border-color: #222 !important;
    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.15);
    outline: none;
}
.stire-comment-form label {
    display: block;
    margin-bottom: 8px;
    color: #ccc;
    font-size: 0.95rem;
}
.stire-comment-form .btn {
    margin-top: 12px;
}
.stire-comments-list {
    display: grid;
    gap: 18px;
}
.stire-comment {
    background: #333;
    border: 1px solid #13667a;
    border-radius: 16px;
    padding: 18px;
}
.stire-comment-meta {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 12px;
    color: #bbb;
    font-size: 0.95rem;
}
.stire-comment-body {
    color: #e5e5e5;
    line-height: 1.8;
}
.stire-no-comments {
    color: #ddd;
    font-size: 1rem;
}
@media (max-width: 768px) {
    .stire-comments-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

<script>
(function() {
  function initMangaCommentHandler() {
    const commentForm = document.getElementById('manga-comment-form');
    const submitBtn = document.getElementById('submit-manga-comment');
    const commentText = document.getElementById('manga-comment-text');
    const messageDiv = document.getElementById('comment-message');

  if (!commentForm || !submitBtn || !commentText || !messageDiv) {
    return;
  }

  if (window.mangaCommentHandlerInitialized) {
    return;
  }
  window.mangaCommentHandlerInitialized = true;

  let deleteTarget = null;
  const deleteModal = document.getElementById('deleteModal');
  const confirmDeleteBtn = document.getElementById('confirmDelete');
  const cancelDeleteBtn = document.getElementById('cancelDelete');

  const MIN_COMMENT_DELAY = 5000;
  const initialSubmitLabel = submitBtn.innerHTML;

  submitBtn.addEventListener('click', function(e) {
    e.preventDefault();

    if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
      showMessage('Trebuie să fii logat pentru a comenta.', 'error');
      return;
    }

    const now = Date.now();
    const lastSubmit = window._lastMangaCommentSubmit || 0;
    if (now - lastSubmit < MIN_COMMENT_DELAY) {
      const waitSeconds = Math.ceil((MIN_COMMENT_DELAY - (now - lastSubmit)) / 1000);
      showMessage('Așteaptă ' + waitSeconds + ' secunde înainte de a posta din nou.', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Se postează...';

    const formData = new FormData();
    formData.append('action', 'mangayummy_add_manga_comment');
    formData.append('post_id', commentForm.dataset.postId);
    formData.append('comment', commentText.value);

    const nonceField = commentForm.querySelector('input[name="nonce"]');
    if (nonceField) {
      formData.append('nonce', nonceField.value);
    }

    fetch(ya_ajax.ajax_url, {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window._lastMangaCommentSubmit = Date.now();
        showMessage(data.data.message, 'success');
        commentText.value = '';

        const gifPreview = document.getElementById('gif-preview');
        if (gifPreview) {
          gifPreview.style.display = 'none';
          gifPreview.innerHTML = '';
        }

        if (data.data && data.data.html) {
          const commentsTab = document.querySelector('#comments-tab.active') || document.getElementById('comments-tab');
          if (!commentsTab) {
            console.error('Comments tab not found');
            return;
          }

          let list = commentsTab.querySelector('.comments-list');
          const listWasCreated = !list;

          if (!list) {
            const wrapper = commentsTab.querySelector('.comments-list-wrapper');
            if (wrapper) {
              const noComments = wrapper.querySelector('.no-comments');
              if (noComments) noComments.remove();

              list = document.createElement('div');
              list.className = 'comments-list';
              list.setAttribute('data-sort-type', 'newest');
              wrapper.appendChild(list);
            }
          }

          if (list) {
            const noComments = commentsTab.querySelector('.no-comments');
            if (noComments) {
              noComments.remove();
            }

            const insertComment = () => {
              list.insertAdjacentHTML('afterbegin', data.data.html);
              requestAnimationFrame(() => {
                if (typeof window.attachMangaCommentEventListeners === 'function') {
                  window.attachMangaCommentEventListeners();
                }
                if (typeof window.updateCommentCounter === 'function') {
                  window.updateCommentCounter();
                }
                if (typeof window.updateSortVisibility === 'function') {
                  window.updateSortVisibility();
                }
              });
            };

            if (listWasCreated) {
              requestAnimationFrame(insertComment);
            } else {
              insertComment();
            }
          }
        }

        window.history.replaceState(null, '', window.location.href);
      } else {
        showMessage(data.data || 'Eroare la postare', 'error');
      }
    })
    .catch(error => {
      console.error('Eroare:', error);
      showMessage('Eroare la conexiune', 'error');
      window._lastMangaCommentSubmit = 0;
    })
    .finally(() => {
      submitBtn.disabled = false;
      submitBtn.innerHTML = initialSubmitLabel || '<i class="fa fa-send"></i> Postează comentariu';
    });
  });

  function expandGifComments() {
    document.querySelectorAll('.comment-text').forEach(el => {
      if (el.querySelector('img.comment-gif')) {
        el.classList.remove('hide-text');
        el.classList.add('show-text');
        el.classList.add('comment-has-gif');

        const moreTextBtn = el.parentNode.querySelector('.more-text');
        if (moreTextBtn) {
          moreTextBtn.style.display = 'none';
        }
      }
    });
  }

  window.attachMangaCommentEventListeners = function() {
    expandGifComments();

    const likes = document.querySelectorAll('.comment-like:not([data-bound])');
    const dislikes = document.querySelectorAll('.comment-dislike:not([data-bound])');

    const handleReaction = (btn) => {
      btn.setAttribute('data-bound', '1');
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (btn.dataset.processing === '1') return;
        btn.dataset.processing = '1';

        const commentId = btn.dataset.id;
        const postId = btn.dataset.postId;
        const action = btn.dataset.action;

        if ((!commentId && !postId) || !action) {
          btn.dataset.processing = '0';
          return;
        }

        const formData = new FormData();
        const ajaxAction = commentId ? 'mangayummy_react_comment' : 'mangayummy_react_stire';
        formData.append('action', ajaxAction);
        const nonce = typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.nonce : (typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
        formData.append('nonce', nonce);
        if (commentId) {
          formData.append('comment_id', commentId);
        } else {
          formData.append('post_id', postId);
        }
        formData.append('reaction', action);

        fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : (typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : '/wp-admin/admin-ajax.php'), {
          method: 'POST',
          body: formData
        })
        .then(r => r.json())
        .then(res => {
          if (res.success) {
            const box = btn.closest('.comment-actions');
            if (box) {
              const likeBtn = box.querySelector('.comment-like');
              const dislikeBtn = box.querySelector('.comment-dislike');

              if (likeBtn) likeBtn.querySelector('.count').textContent = res.data.likes;
              if (dislikeBtn) dislikeBtn.querySelector('.count').textContent = res.data.dislikes;

              if (likeBtn) likeBtn.classList.remove('active');
              if (dislikeBtn) dislikeBtn.classList.remove('active');

              if (res.data.current) {
                const activeBtn = box.querySelector('.comment-' + res.data.current);
                if (activeBtn) activeBtn.classList.add('active');
              }
            }

            const stireActions = btn.closest('.stire-author-actions');
            if (!box && stireActions) {
              stireActions.querySelectorAll('.comment-action-btn').forEach(b => b.classList.remove('active'));
              if (res.data.current) {
                const activeBtn = stireActions.querySelector('.comment-' + res.data.current);
                if (activeBtn) activeBtn.classList.add('active');
              }
              const likeBtn = stireActions.querySelector('.comment-like .count');
              const dislikeBtn = stireActions.querySelector('.comment-dislike .count');
              if (likeBtn) likeBtn.textContent = res.data.likes;
              if (dislikeBtn) dislikeBtn.textContent = res.data.dislikes;
            }
          } else {
            console.error('React error:', res);
          }
        })
        .catch(err => console.error('React error:', err))
        .finally(() => {
          btn.dataset.processing = '0';
        });
      });
    };

    likes.forEach(handleReaction);
    dislikes.forEach(handleReaction);
  };

  window.attachStireReactionListeners = function() {
    const stireButtons = document.querySelectorAll('.stire-author-actions .comment-action-btn:not([data-stire-bound])');

    stireButtons.forEach((btn) => {
      btn.dataset.stireBound = '1';
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        if (btn.dataset.processing === '1') return;
        btn.dataset.processing = '1';

        const postId = btn.dataset.postId;
        const action = btn.dataset.action;
        if (!postId || !action) {
          btn.dataset.processing = '0';
          return;
        }

        const formData = new FormData();
        formData.append('action', 'mangayummy_react_stire');
        const nonceInput = document.querySelector('#manga-comment-form input[name="nonce"]');
        const nonce = nonceInput ? nonceInput.value : (typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
        formData.append('nonce', nonce);
        formData.append('post_id', postId);
        formData.append('reaction', action);

        fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
          method: 'POST',
          body: formData
        })
        .then((r) => r.json())
        .then((res) => {
          if (res.success) {
            const stireActions = btn.closest('.stire-author-actions');
            if (stireActions) {
              stireActions.querySelectorAll('.comment-action-btn').forEach((b) => b.classList.remove('active'));
              if (res.data.current) {
                const activeBtn = stireActions.querySelector('.comment-' + res.data.current);
                if (activeBtn) activeBtn.classList.add('active');
              }
              const likeCount = stireActions.querySelector('.comment-like .count');
              const dislikeCount = stireActions.querySelector('.comment-dislike .count');
              if (likeCount) likeCount.textContent = res.data.likes;
              if (dislikeCount) dislikeCount.textContent = res.data.dislikes;
            }
          } else {
            console.error('Stire react error:', res);
          }
        })
        .catch((err) => console.error('Stire react error:', err))
        .finally(() => {
          btn.dataset.processing = '0';
        });
      });
    });
  };

  window.updateCommentCounter = function() {
    const countElement = document.querySelector('.tabs-li[data-id="#comments-tab"] .count');
    if (countElement) {
      const currentCount = parseInt(countElement.textContent) || 0;
      countElement.textContent = currentCount + 1;
    }
  };

  const emojiMap = {
    smileys: ['😀','😄','😁','😆','😂','🤣','😊','😇','🙂','😉','😍','😘','😜','🤪','😎','😏'],
    hand: ['👋','🤚','🖐️','✋','👌','👍','👎','✊','🤛','🤜','👏','🙌','🤝'],
    heart: ['❤️','💛','💚','💙','💜','🖤','💖','💗','💘','💕','💞'],
    fire: ['🔥','✨','💫','🌟','🎉','🎊','⚡','💥','🌈'],
    star: ['⭐','🌠','🌟','✨','🌙','☀️','⚡','💫']
  };

  const emojiBtn = document.querySelector('.emoji-picker-btn');
  const emojiPopup = document.querySelector('.emoji-picker-popup');
  const gifBtn = document.querySelector('.gif-picker-btn');
  const gifPopup = document.querySelector('.gif-picker-popup');
  const gifSearchInput = document.getElementById('gif-search-input');
  const gifSearchBtn = document.getElementById('gif-search-btn');
  const toolbarRight = document.querySelector('.toolbar-right');
  const emojiCategories = document.querySelectorAll('.emoji-category');
  const gifGrid = document.getElementById('gif-grid');

  function populateEmojiGrid(category) {
    const grid = document.getElementById('emoji-grid');
    if (!grid) return;
    const emojis = emojiMap[category] || [];
    grid.innerHTML = '';
    emojis.forEach(emoji => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'emoji-btn';
      btn.textContent = emoji;
      btn.addEventListener('mousedown', (e) => e.preventDefault());
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        insertEmoji(emoji);
        if (emojiPopup) emojiPopup.style.display = 'none';
      });
      grid.appendChild(btn);
    });
  }

  function insertEmoji(emoji) {
    const start = commentText.selectionStart;
    const end = commentText.selectionEnd;
    const value = commentText.value;
    commentText.value = value.substring(0, start) + emoji + value.substring(end);
    commentText.focus();
    commentText.selectionStart = commentText.selectionEnd = start + emoji.length;
  }

  function showGifLoginError() {
    messageDiv.style.display = 'block';
    messageDiv.className = 'comment-message error';
    messageDiv.innerHTML = '<i class="fa fa-exclamation"></i> Trebuie să fii logat pentru a folosi GIF-urile.';
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 3500);
  }

  function displayGIFs(gifs) {
    if (!gifGrid) return;
    if (!Array.isArray(gifs) || gifs.length === 0) {
      gifGrid.innerHTML = '<div class="gif-error">Niciun GIF găsit</div>';
      return;
    }

    gifGrid.innerHTML = gifs.map(gif => `
      <div class="gif-item" data-url="${gif.url}">
        <img src="${gif.preview}" alt="GIF preview" loading="lazy" />
      </div>
    `).join('');

    gifGrid.querySelectorAll('.gif-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const gifUrl = item.dataset.url;
        const start = commentText.selectionStart;
        const end = commentText.selectionEnd;
        const current = commentText.value;
        commentText.value = current.substring(0, start) + gifUrl + current.substring(end);
        commentText.focus();
        commentText.selectionStart = commentText.selectionEnd = start + gifUrl.length;

        const preview = document.getElementById('gif-preview');
        if (preview) {
          preview.style.display = 'block';
          preview.innerHTML = `
            <div style="position: relative; display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
              <button type="button" id="gif-preview-clear" style="background:#ff4d4d;color:#fff;border:none;border-radius:999px;padding:2px 8px;cursor:pointer;font-size:11px;">X</button>
            </div>
            <img src="${gifUrl}" alt="GIF preview" style="max-width:100%;border-radius:8px;margin-top:8px;display:block;" loading="lazy" />
          `;
          const clear = document.getElementById('gif-preview-clear');
          if (clear) {
            clear.addEventListener('click', () => {
              preview.style.display = 'none';
              preview.innerHTML = '';
              commentText.value = commentText.value.replace(gifUrl, '').trim();
            });
          }
        }

        if (gifPopup) gifPopup.style.display = 'none';
      });
    });
  }

  function loadTrendingGIFs() {
    if (!gifGrid) return;
    gifGrid.innerHTML = '<div class="gif-loading">Loading GIFs...</div>';
    const url = typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : ya_ajax?.ajax_url;
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=mangayummy_get_gifs&type=featured'
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.data && data.data.gifs) {
        displayGIFs(data.data.gifs);
      } else {
        gifGrid.innerHTML = '<div class="gif-error">Eroare la încărcarea GIF-urilor</div>';
      }
    })
    .catch(() => {
      gifGrid.innerHTML = '<div class="gif-error">Eroare la încărcarea GIF-urilor</div>';
    });
  }

  function searchGIFs(query) {
    if (!gifGrid) return;
    if (!query) {
      loadTrendingGIFs();
      return;
    }

    gifGrid.innerHTML = '<div class="gif-loading">Searching GIFs...</div>';
    const url = typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : ya_ajax?.ajax_url;
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=mangayummy_get_gifs&type=search&query=' + encodeURIComponent(query)
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.data && data.data.gifs) {
        displayGIFs(data.data.gifs);
      } else {
        gifGrid.innerHTML = '<div class="gif-error">Nu s-au găsit GIF-uri</div>';
      }
    })
    .catch(() => {
      gifGrid.innerHTML = '<div class="gif-error">Eroare la căutarea GIF-urilor</div>';
    });
  }

  if (emojiBtn && emojiPopup) {
    emojiBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isOpen = emojiPopup.style.display === 'block';
      emojiPopup.style.display = isOpen ? 'none' : 'block';
      if (!isOpen) {
        populateEmojiGrid('smileys');
        if (gifPopup) gifPopup.style.display = 'none';
      }
    });
  }

  if (gifBtn && gifPopup) {
    gifBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (typeof ya_ajax === 'undefined' || !ya_ajax.currentUserId) {
        showGifLoginError();
        return;
      }
      const isOpen = gifPopup.style.display === 'block';
      gifPopup.style.display = isOpen ? 'none' : 'block';
      if (!isOpen) {
        loadTrendingGIFs();
        if (emojiPopup) emojiPopup.style.display = 'none';
        gifSearchInput?.focus();
      }
    });

    if (gifSearchInput) {
      gifSearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          searchGIFs(gifSearchInput.value.trim());
        }
      });
    }

    if (gifSearchBtn) {
      gifSearchBtn.addEventListener('click', (e) => {
        e.preventDefault();
        searchGIFs(gifSearchInput?.value.trim() || '');
      });
    }
  }

  emojiCategories.forEach(btn => {
    btn.addEventListener('mousedown', (e) => e.preventDefault());
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      emojiCategories.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      populateEmojiGrid(btn.dataset.category);
    });
  });

  document.addEventListener('click', (e) => {
    if (!toolbarRight?.contains(e.target)) {
      if (emojiPopup) emojiPopup.style.display = 'none';
      if (gifPopup) gifPopup.style.display = 'none';
    }
  });

  document.addEventListener('click', function(e) {
    const menuBtn = e.target.closest('.comment-menu-btn');
    if (menuBtn) {
      e.preventDefault();
      e.stopPropagation();
      const menu = menuBtn.nextElementSibling;
      if (menu && menu.classList.contains('comment-menu-dropdown')) {
        document.querySelectorAll('.comment-menu-dropdown').forEach(m => {
          if (m !== menu) m.style.display = 'none';
        });
        menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
      }
      return;
    }

    document.querySelectorAll('.comment-menu-dropdown').forEach(m => m.style.display = 'none');

    if (e.target.classList.contains('comment-edit')) {
      e.preventDefault();
      const comment = e.target.closest('.comment');
      if (!comment) return;
      const body = comment.querySelector('.comment-body');
      const text = body.querySelector('.comment-text');
      const textarea = body.querySelector('.comment-edit-textarea');
      const actions = body.querySelector('.comment-edit-actions');
      if (!textarea || !text || !actions) return;
      textarea.value = text.textContent.trim();
      text.style.display = 'none';
      textarea.style.display = 'block';
      actions.style.display = 'flex';
      textarea.focus();
      return;
    }

    if (e.target.classList.contains('comment-cancel')) {
      e.preventDefault();
      const body = e.target.closest('.comment-body');
      if (!body) return;
      const text = body.querySelector('.comment-text');
      const textarea = body.querySelector('.comment-edit-textarea');
      const actions = body.querySelector('.comment-edit-actions');
      if (text) text.style.display = 'block';
      if (textarea) textarea.style.display = 'none';
      if (actions) actions.style.display = 'none';
      return;
    }

    if (e.target.classList.contains('comment-save')) {
      e.preventDefault();
      const comment = e.target.closest('.comment');
      if (!comment) return;
      const body = comment.querySelector('.comment-body');
      const textarea = body.querySelector('.comment-edit-textarea');
      const text = body.querySelector('.comment-text');
      if (!textarea || !text) return;
      const commentId = comment.dataset.commentId;
      const formData = new FormData();
      formData.append('action', 'mangayummy_edit_comment');
      formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
      formData.append('comment_id', commentId);
      formData.append('content', textarea.value);
      fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : (typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : '/wp-admin/admin-ajax.php'), {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          if (text) text.innerHTML = res.data.rendered || textarea.value;
          if (text) text.style.display = 'block';
          if (textarea) textarea.style.display = 'none';
          const actions = body.querySelector('.comment-edit-actions');
          if (actions) actions.style.display = 'none';
          const bodyEl = comment.querySelector('.comment-body');
          if (bodyEl && !bodyEl.querySelector('.comment-edited')) {
            const editedSpan = document.createElement('span');
            editedSpan.className = 'comment-edited';
            editedSpan.textContent = '(editat)';
            bodyEl.insertBefore(editedSpan, bodyEl.querySelector('.more-text'));
          }
          showMessage(res.data?.message || 'Comentariu editat', 'success');
        } else {
          showMessage(res.data?.message || 'Eroare la editare', 'error');
        }
      })
      .catch(err => {
        console.error('Edit error:', err);
        showMessage('Eroare la editare', 'error');
      });
      return;
    }

    if (e.target.classList.contains('comment-delete')) {
      e.preventDefault();
      deleteTarget = e.target.closest('.comment');
      if (!deleteTarget) return;
      if (deleteModal) {
        deleteModal.style.display = 'block';
      }
      return;
    }
  });

  if (cancelDeleteBtn) {
    cancelDeleteBtn.addEventListener('click', () => {
      if (deleteModal) deleteModal.style.display = 'none';
      deleteTarget = null;
    });
  }

  if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener('click', () => {
      if (!deleteTarget) return;
      const commentId = deleteTarget.dataset.commentId;
      if (!commentId) return;
      if (deleteModal) deleteModal.style.display = 'none';
      submitDelete(commentId, deleteTarget);
      deleteTarget = null;
    });
  }

  function submitDelete(commentId, commentEl) {
    const formData = new FormData();
    formData.append('action', 'mangayummy_delete_comment');
    formData.append('nonce', typeof ya_ajax !== 'undefined' ? ya_ajax.nonce : '');
    formData.append('comment_id', commentId);
    fetch(typeof ya_ajax !== 'undefined' ? ya_ajax.ajax_url : (typeof mangayummy_comments !== 'undefined' ? mangayummy_comments.ajax_url : '/wp-admin/admin-ajax.php'), {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(res => {
      if (res.success) {
        commentEl.remove();
        showMessage(res.data?.message || 'Comentariu șters', 'success');
        const countSpan = document.querySelector('#comments .count');
        if (countSpan) {
          const currentCount = parseInt(countSpan.textContent) || 0;
          countSpan.textContent = Math.max(0, currentCount - 1);
        }
        if (typeof window.updateSortVisibility === 'function') {
          window.updateSortVisibility();
        }
      } else {
        showMessage(res.data?.message || 'Eroare la ștergere', 'error');
      }
    })
    .catch(err => {
      console.error('Delete error:', err);
      showMessage('Eroare la ștergere', 'error');
    });
  }

  function showMessage(message, type) {
    messageDiv.style.display = 'block';
    messageDiv.className = 'comment-message ' + type;
    messageDiv.innerHTML = '<i class="fa ' + (type === 'success' ? 'fa-check' : 'fa-exclamation') + '"></i> ' + message;
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 5000);
  }
  window.showMessage = showMessage;

  function applyFormat(format) {
    const start = commentText.selectionStart;
    const end = commentText.selectionEnd;
    const text = commentText.value;
    const selectedText = text.substring(start, end) || 'text';
    let formattedText = '';
    switch (format) {
      case 'bold':      formattedText = `**${selectedText}**`; break;
      case 'italic':    formattedText = `*${selectedText}*`; break;
      case 'underline': formattedText = `__${selectedText}__`; break;
      case 'spoiler':   formattedText = `||${selectedText}||`; break;
      case 'code':      formattedText = `\`${selectedText}\``; break;
      default: return;
    }
    commentText.value = text.substring(0, start) + formattedText + text.substring(end);
    commentText.focus();
    commentText.selectionStart = commentText.selectionEnd = start + formattedText.length;
  }

  document.querySelectorAll('.text-format-btn').forEach(btn => {
    btn.addEventListener('mousedown', (e) => e.preventDefault());
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      applyFormat(btn.dataset.format);
    });
  });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && document.activeElement === commentText) {
      if (e.key === 'b') { e.preventDefault(); applyFormat('bold'); }
      if (e.key === 'i') { e.preventDefault(); applyFormat('italic'); }
    }
  });

  if (typeof window.attachMangaCommentEventListeners === 'function') {
    window.attachMangaCommentEventListeners();
  }
  if (typeof window.attachStireReactionListeners === 'function') {
    window.attachStireReactionListeners();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initMangaCommentHandler);
} else {
  initMangaCommentHandler();
}
})();
</script>

<div id="deleteModal" class="modal" style="display:none;">
  <div class="modal-box">
    <p>Sigur vrei să ștergi comentariul?</p>
    <button type="button" id="confirmDelete">Da</button>
    <button type="button" id="cancelDelete">Nu</button>
  </div>
</div>

<?php get_footer(); ?>
