<?php
/**
 * Template Name: Despre Site
 */

$about_title = get_theme_mod('mangayummy_about_title', 'About Us');
$about_label = trim((string) get_theme_mod('mangayummy_about_tab_label', 'About'));
$about_desc_1 = get_theme_mod('mangayummy_about_desc_1', '');
$about_desc_2 = get_theme_mod('mangayummy_about_desc_2', '');
$about_desc_3 = get_theme_mod('mangayummy_about_desc_3', '');

$contact_label = trim((string) get_theme_mod('mangayummy_tab_contact_label', 'Contact'));
$contact_title = trim((string) get_theme_mod('mangayummy_tab_contact_title', ''));
$contact_content = trim((string) get_theme_mod('mangayummy_tab_contact_content', ''));

$dmca_label = trim((string) get_theme_mod('mangayummy_tab_dmca_label', 'DMCA'));
$dmca_title = trim((string) get_theme_mod('mangayummy_tab_dmca_title', ''));
$dmca_content = trim((string) get_theme_mod('mangayummy_tab_dmca_content', ''));

$custom_tabs = [];
for ($tab_i = 1; $tab_i <= 6; $tab_i++) {
    $label = trim((string) get_theme_mod("mangayummy_tab_custom_{$tab_i}_label", ''));
    $title = trim((string) get_theme_mod("mangayummy_tab_custom_{$tab_i}_title", ''));
    $content = trim((string) get_theme_mod("mangayummy_tab_custom_{$tab_i}_content", ''));
    if ($label !== '' && ($title !== '' || $content !== '')) {
        $custom_tabs[] = [
            'id' => 'custom-' . $tab_i,
            'label' => $label,
            'title' => $title,
            'content' => $content,
        ];
    }
}

$has_about_tab = ($about_label !== '' && ($about_title !== '' || $about_desc_1 !== '' || $about_desc_2 !== '' || $about_desc_3 !== ''));
$has_contact_tab = ($contact_label !== '' && ($contact_title !== '' || $contact_content !== ''));
$has_dmca_tab = ($dmca_label !== '' && ($dmca_title !== '' || $dmca_content !== ''));

$tab_ids = [];
if ($has_about_tab) {
    $tab_ids[] = 'despre';
}
if ($has_contact_tab) {
    $tab_ids[] = 'contact';
}
if ($has_dmca_tab) {
    $tab_ids[] = 'dmca';
}
foreach ($custom_tabs as $custom_tab) {
    $tab_ids[] = $custom_tab['id'];
}
$first_tab_id = $tab_ids[0] ?? '';

get_header();
?>


<style>
body {
    background: none !important;
}
.about-container {
    max-width: 1200px;
    margin: 30px auto;
    background: linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 100%);
    box-shadow: -4px 6px 4px rgba(0, 0, 0, 0.25), 4px 0 4px rgba(0, 0, 0, 0.25), 0 5px 4px rgba(0, 0, 0, 0.28);
    position: relative;
    overflow: hidden !important;
    display: flex;
    flex-direction: column;
    gap: 0;
    border-radius: 8px 8px 0 0
}

/* Tab styles */
.about-tabs {
    display: flex;
    position: relative;
    overflow: hidden;
    background: rgba(26, 26, 26, 0.92);
}

.about-tab-button {
    background: none;
    border: none;
    padding: 15px 25px;
    color: #aaa;
    font-size: 1.1rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 3px solid transparent;
    position: relative;
}

.about-tab-button:hover {
    color: #fff;
    background: #13667a;
}

.about-tab-button.active {
    color: #13667a;
    border-bottom-color: #13667a;
    background: #333;
}

.about-tab-content {
    display: none;
}

.about-tab-content.active {
    display: block;
}

.about-card {
    background: rgba(255, 255, 255, 0.02);
    padding: 24px 20px 22px 20px;
    margin-bottom: 24px;
    width: 100%;
    max-width: 100%;
    display: block;
    position: relative;
}
.about-title {
    font-size: 2.3rem;
    margin-bottom: 16px;
    font-weight: bold;
    text-align: left;
    color: #fff;
    background: linear-gradient(135deg, #13667a, #fff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.about-desc {
    font-size: 1.13rem;
    margin-bottom: 0;
    margin-left: auto;
    margin-right: auto;
    text-align: left;
    line-height: 1.7;
}
.official-groups-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 10px;
    letter-spacing: 0.5px;
    text-align: left;
}
.official-groups-list {
    margin-bottom: 0;
    text-align: left;
}
.team-section {
    text-align: center;
}
.team-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 10px;
    letter-spacing: 0.5px;
    text-align: left;
}
.team-subtitle {
    font-size: 1.05rem;
    color: #aaa;
    margin-bottom: 12px;
}
.team-separator {
    width: auto;
    height: 3px;
    background: #13667a;
    margin: 0 auto 32px auto;
    border-radius: 2px;
    opacity: 0.7;
}
.team-grid {
    display: grid;
    gap: 32px 24px;
    justify-items: center;
    align-items: start;
    margin-right: auto;
    width: 100%;
    max-width: 900px;
}
.team-member {
    display: flex;
    align-items: center;
}
.team-avatar {
    width: 150px;
    height: 150px;
    border-radius: 8px;
    
    margin-bottom: 14px;
    background: #222;
}
.team-role {
    font-size: 1.05rem;
    margin-bottom: 4px;
    font-weight: 500;
}
.team-role.fondator { color: #ffb300; }
.team-role.designer { color: #13667a; }
.team-role.tester { color: #00bcd4; }
.team-role.editor { color: #e91e63; }
.team-role.review_chief { color: #13667a; }
.team-role.moderator { color: #8e44ad; }
.team-role.discord_manager { color: #5865F2; }
.team-name {
    font-size: 1.13rem;
    font-weight: 500;
    color: #fff;
    margin-bottom: 0;
}
@media (max-width: 900px) {
    .about-container {
        margin: 20px 10px;
        border-radius: 15px;
    }
    
    .about-card { padding: 16px 15px 12px 15px; }
    .about-title { font-size: 2rem; }
    
    .about-tabs {
        justify-content: center;
    }
}

@media (max-width: 600px) {
    .about-container {
        margin: 15px 5px;
        border-radius: 10px;
    }
    
    .about-card { padding: 10px 10px 8px 10px; }
    .team-avatar { width: 115px; height: 115px; border-radius: 8px; }
    .about-title { font-size: 1.8rem; }
    
    .about-tabs {
        justify-content: center;
        flex-wrap: wrap;
    }
    
    .about-tab-button {
        font-size: 0.9em;
        padding: 10px 15px;
    }
}

.about-credit-box {
    position: absolute;
    top: 60px;
    right: 22px;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    padding: 10px 14px;
    border-radius: 8px;
    color: #fff;
    font-size: 0.9rem;
    z-index: 15;
    box-shadow: 0 4px 14px rgba(0,0,0,0.35);
    max-width: 220px;
    line-height: 1.3;
}

@media (max-width: 900px) {
    .about-credit-box { display: none; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.about-tab-button');
    const tabContents = document.querySelectorAll('.about-tab-content');

    function switchTab(tabId) {
        // Hide all tab contents
        tabContents.forEach(content => content.classList.remove('active'));
        // Remove active class from all buttons
        tabButtons.forEach(button => button.classList.remove('active'));

        // Show selected tab content
        document.getElementById(tabId).classList.add('active');
        // Add active class to clicked button
        const activeButton = document.querySelector(`[data-tab="${tabId}"]`);
        if (activeButton) activeButton.classList.add('active');

        // Update URL hash so direct links can be shared/bookmarked
        if (history.replaceState) {
            history.replaceState(null, null, '#' + tabId);
        } else {
            window.location.hash = tabId;
        }
    }

    // Add click event listeners to tab buttons
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            switchTab(tabId);
        });
    });

    // Check for hash in URL and activate corresponding tab
    const hash = window.location.hash.substring(1); // Remove #
    if (hash && document.getElementById(hash)) {
        switchTab(hash);
    } else {
        // Show first tab by default
        if (tabContents.length > 0) {
            tabContents[0].classList.add('active');
            tabButtons[0].classList.add('active');
        }
    }

    // Contact form handler (send via AJAX to server)
    const contactForm = document.getElementById('contact-form');
    const contactStatus = document.getElementById('contact-form-status');
    if (contactForm && contactStatus) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            contactStatus.style.display = 'block';
            contactStatus.style.color = '#ffc107';
            contactStatus.textContent = 'Se trimite...';

            const formData = new FormData(contactForm);
            formData.append('action', 'mangayummy_send_contact_form');
            formData.append('nonce', (typeof ya_ajax !== 'undefined') ? ya_ajax.nonce : '');

            fetch((typeof ya_ajax !== 'undefined') ? ya_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    contactStatus.style.color = '#13667a';
                    contactStatus.textContent = data.data.message || 'Mesaj trimis! Vom reveni în scurt timp.';
                    contactForm.reset();
                } else {
                    contactStatus.style.color = '#13667a';
                    contactStatus.textContent = data.data?.message || 'Eroare la trimitere. Încearcă din nou.';
                }
                setTimeout(() => {
                    contactStatus.style.display = 'none';
                }, 4000);
            })
            .catch(err => {
                console.error('Contact form error', err);
                contactStatus.style.color = '#13667a';
                contactStatus.textContent = 'Eroare de conexiune. Încearcă din nou.';
                setTimeout(() => {
                    contactStatus.style.display = 'none';
                }, 4000);
            });
        });
    }
});
</script>

<main class="about-container">
    <div class="about-tabs">
        <?php if ($has_about_tab) : ?>
            <button class="about-tab-button <?php echo $first_tab_id === 'despre' ? 'active' : ''; ?>" data-tab="despre"><?php echo esc_html($about_label); ?></button>
        <?php endif; ?>
        <?php if ($has_contact_tab) : ?>
            <button class="about-tab-button <?php echo $first_tab_id === 'contact' ? 'active' : ''; ?>" data-tab="contact"><?php echo esc_html($contact_label); ?></button>
        <?php endif; ?>
        <?php if ($has_dmca_tab) : ?>
            <button class="about-tab-button <?php echo $first_tab_id === 'dmca' ? 'active' : ''; ?>" data-tab="dmca"><?php echo esc_html($dmca_label); ?></button>
        <?php endif; ?>
        <?php foreach ($custom_tabs as $custom_tab) : ?>
            <button class="about-tab-button <?php echo $first_tab_id === $custom_tab['id'] ? 'active' : ''; ?>" data-tab="<?php echo esc_attr($custom_tab['id']); ?>"><?php echo esc_html($custom_tab['label']); ?></button>
        <?php endforeach; ?>
    </div>

    <?php if ($has_about_tab) : ?>
    <div id="despre" class="about-tab-content <?php echo $first_tab_id === 'despre' ? 'active' : ''; ?>">
        <div class="about-card">
            <h1 class="about-title"><?php echo esc_html($about_title); ?></h1>
            <p class="about-desc"><?php echo esc_html($about_desc_1); ?></p>
            <p class="about-desc"><?php echo esc_html($about_desc_2); ?></p>
            <p class="about-desc"><?php echo esc_html($about_desc_3); ?></p>
        </div>
        <div class="about-card">
            <div class="team-title">Our Team</div>
            <div class="team-subtitle">The people behind this website</div>
            
            <div class="about-desc">
            </div>


            <div class="team-separator"></div>
            <?php
            // Cache team users for 30 minutes (rarely changes)
            $cache_key = 'about_team_users_v2'; // Changed cache key to force refresh
            $all_team = get_transient($cache_key);
            
            if ($all_team === false) {
                $team_users = get_users([
                    'meta_key' => 'user_group',
                    'meta_compare' => '!=',
                    'meta_value' => '',
                    'orderby' => 'display_name',
                    'order' => 'ASC',
                ]);
                $groups = [
                    'fondator' => 'Fondator',
                    'designer' => 'Designer',
                    'tester' => 'Tester',
                    'editor' => 'Editor',
                    'review_chief' => 'Șef Recenzii',
                    'moderator' => 'Moderator',
                    'discord_manager' => 'Manager Discord',
                ];
                $all_team = [];
                foreach ($team_users as $user) {
                    $group = get_user_meta($user->ID, 'user_group', true);
                    if ($group && isset($groups[$group])) {
                        $avatar = get_user_meta($user->ID, 'profile_avatar', true);
                        if (!$avatar) $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                        $all_team[] = [
                            'user_id' => $user->ID,
                            'display_name' => $user->display_name,
                            'group' => $group,
                            'group_label' => $groups[$group],
                            'avatar' => $avatar
                        ];
                    }
                }
                set_transient($cache_key, $all_team, 30 * MINUTE_IN_SECONDS);
            }
            ?>
            <?php
            $team_by_group = [];
            foreach ($all_team as $entry) {
                $team_by_group[$entry['group_label']][] = $entry;
            }

            // Ordine personalizată: Fondator primul, Moderator al doilea, Designer al treilea
            $group_order = [
                'Fondator',
                'Moderator',
                'Designer'
            ];

            // Afișăm mai întâi grupurile dorite, apoi restul în ordine naturală
            foreach ($group_order as $group_label) {
                if (!empty($team_by_group[$group_label])) {
                    $members = $team_by_group[$group_label];
                    ?>
                    <div class="team-group-section" style="margin-top: 24px; width:100%;">
                        <h3 class="team-group-title" style="color:#fff;font-size:18px;margin-bottom:12px;"><?php echo esc_html($group_label); ?></h3>
                        <div class="team-grid" style="justify-content:flex-start;">
                            <?php foreach ($members as $entry): ?>
                                <div class="team-member">
                                    <a href="<?php echo esc_url(home_url('/profile/?view_user=' . $entry['user_id'])); ?>" title="Vezi profilul lui <?php echo esc_attr($entry['display_name']); ?>">
                                        <img class="team-avatar" src="<?php echo esc_url($entry['avatar']); ?>" alt="Avatar <?php echo esc_attr($entry['display_name']); ?>" loading="lazy">
                                    </a>
                                    <div class="team-details">
                                        <div class="team-name"><?php echo esc_html($entry['display_name']); ?></div>
                                        <?php if ($entry['group'] === 'fondator'): ?>
                                            <div class="team-subtitle">Director</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php
                    unset($team_by_group[$group_label]);
                }
            }

            foreach ($team_by_group as $group_label => $members): ?>
                <div class="team-group-section" style="margin-top: 24px; width:100%;">
                    <h3 class="team-group-title" style="color:#fff;font-size:18px;margin-bottom:12px;"><?php echo esc_html($group_label); ?></h3>
                    <div class="team-grid" style="justify-content:flex-start;">
                        <?php foreach ($members as $entry): ?>
                            <div class="team-member">
                                <a href="<?php echo esc_url(home_url('/profile/?view_user=' . $entry['user_id'])); ?>" title="Vezi profilul lui <?php echo esc_attr($entry['display_name']); ?>">
                                    <img class="team-avatar" src="<?php echo esc_url($entry['avatar']); ?>" alt="Avatar <?php echo esc_attr($entry['display_name']); ?>" loading="lazy">
                                </a>
                                <div class="team-name"><?php echo esc_html($entry['display_name']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($has_contact_tab) : ?>
        <div id="contact" class="about-tab-content <?php echo $first_tab_id === 'contact' ? 'active' : ''; ?>">
            <div class="about-card">
                <?php if ($contact_title !== '') : ?>
                    <h1 class="about-title"><?php echo esc_html($contact_title); ?></h1>
                <?php endif; ?>
                <?php if ($contact_content !== '') : ?>
                    <div class="about-desc"><?php echo wp_kses_post(wpautop($contact_content)); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($has_dmca_tab) : ?>
        <div id="dmca" class="about-tab-content <?php echo $first_tab_id === 'dmca' ? 'active' : ''; ?>">
            <div class="about-card">
                <?php if ($dmca_title !== '') : ?>
                    <h1 class="about-title"><?php echo esc_html($dmca_title); ?></h1>
                <?php endif; ?>
                <?php if ($dmca_content !== '') : ?>
                    <div class="about-desc"><?php echo wp_kses_post(wpautop($dmca_content)); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php foreach ($custom_tabs as $custom_tab) : ?>
        <div id="<?php echo esc_attr($custom_tab['id']); ?>" class="about-tab-content <?php echo $first_tab_id === $custom_tab['id'] ? 'active' : ''; ?>">
            <div class="about-card">
                <?php if ($custom_tab['title'] !== '') : ?>
                    <h1 class="about-title"><?php echo esc_html($custom_tab['title']); ?></h1>
                <?php endif; ?>
                <?php if ($custom_tab['content'] !== '') : ?>
                    <div class="about-desc"><?php echo wp_kses_post(wpautop($custom_tab['content'])); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <?php if (empty($tab_ids)) : ?>
        <div class="about-card">
            <h1 class="about-title">No tabs configured</h1>
            <p class="about-desc">Go to Appearance > Customize > About Site Content and add at least one tab label and content.</p>
        </div>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
