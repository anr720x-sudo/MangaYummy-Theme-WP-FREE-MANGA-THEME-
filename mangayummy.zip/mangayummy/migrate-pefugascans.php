<?php
/**
 * Migration script to move all content from Pefugascans group to MangaYummy
 */

// Include WordPress
require_once('wp-load.php');

// Check if user is admin
if (!current_user_can('administrator')) {
    die('Access denied. Admin privileges required.');
}

echo "<h1>Migrating Pefugascans content to MangaYummy</h1>";

// Get all chapters with Pefugascans group
$chapters = get_posts(array(
    'post_type' => 'chapter',
    'posts_per_page' => -1,
    'meta_query' => array(
        array(
            'key' => '_translation_group',
            'value' => 'Pefugascans',
            'compare' => '='
        )
    )
));

echo "<p>Found " . count($chapters) . " chapters from Pefugascans group.</p>";

$updated_count = 0;
foreach ($chapters as $chapter) {
    // Update the translation group
    update_post_meta($chapter->ID, '_translation_group', 'MangaYummy');

    // Also update taxonomy if it exists
    $term = get_term_by('name', 'Pefugascans', 'translator_group');
    if ($term) {
        wp_remove_object_terms($chapter->ID, $term->term_id, 'translator_group');
    }

    $manga_term = get_term_by('name', 'MangaYummy', 'translator_group');
    if (!$manga_term) {
        $manga_term = wp_insert_term('MangaYummy', 'translator_group');
    }
    if (!is_wp_error($manga_term)) {
        wp_set_post_terms($chapter->ID, $manga_term['term_id'], 'translator_group', false);
    }

    $updated_count++;
    echo "<p>Updated chapter: " . get_the_title($chapter->ID) . " (ID: " . $chapter->ID . ")</p>";
}

echo "<p><strong>Migration completed! Updated $updated_count chapters.</strong></p>";

// Clean up old term if no chapters use it anymore
$pefuga_term = get_term_by('name', 'Pefugascans', 'translator_group');
if ($pefuga_term) {
    $term_usage = get_term_by('id', $pefuga_term->term_id, 'translator_group');
    if ($term_usage && $term_usage->count == 0) {
        wp_delete_term($pefuga_term->term_id, 'translator_group');
        echo "<p>Cleaned up empty Pefugascans term from taxonomy.</p>";
    }
}

echo "<p><a href='" . admin_url() . "'>Return to admin</a></p>";
?></content>
<parameter name="filePath">c:\Users\user1\Desktop\mangayummy\migrate-pefugascans.php