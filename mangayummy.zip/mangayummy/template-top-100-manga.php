<?php
/**
 * Template: TOP 100 MANGA (Automatic Page)
 * This template is loaded automatically for /top-100-manga URL
 */

// Custom SEO for TOP 100 page
add_filter('pre_get_document_title', function($title) {
    return 'Top 100 Best Manga in Romanian Online | MangaYummy';
}, 999);

add_action('wp_head', function() {
    echo '<meta name="description" content="Discover the ranking of the 100 most popular manga, manhwa and manhua in Romanian language. See which are the most read series of the moment on MangaYummy and find top recommendations constantly updated for fans from Romania-Moldova.">' . "\n";
}, 5);


// Include header
get_header();

// Query for top manga by rating (show at least 100, with more on demand)
$args = [
  'post_type'      => 'manga',
  'post_status'    => 'publish',
  'posts_per_page' => 200,
  'meta_key'       => '_rating_avg',
  'orderby'        => 'meta_value_num',
  'order'          => 'DESC',
];

$query = new WP_Query($args);
?>

<section class="top-100-manga-page">
  <div class="page-header">
    <h1>Top 100 Manga</h1>
  </div>

  <?php if ($query->have_posts()) : ?>
    <div class="top-100-grid">
      <?php
      $position = 1;
      $initial_display = 100;
      while ($query->have_posts()) : $query->the_post();
        $manga_id = get_the_ID();
        $rating_avg = floatval(get_post_meta($manga_id, '_rating_avg', true));
        $rating_count = intval(get_post_meta($manga_id, '_rating_count', true));
        $hidden_class = ($position > $initial_display) ? 'top-100-hidden' : '';
      ?>
        <div class="anime-column top-manga-card <?php echo $hidden_class; ?>" data-position="<?php echo $position; ?>">
          <a class="image-block" href="<?php the_permalink(); ?>">
            <?php if (has_post_thumbnail()) : ?>
              <?php the_post_thumbnail('manga-card', ['loading' => 'lazy', 'decoding' => 'async']); ?>
            <?php else : ?>
              <img src="<?php echo get_template_directory_uri(); ?>/assets/img/default-manga.jpg" alt="<?php the_title(); ?>">
            <?php endif; ?>

            <?php if ($rating_avg > 0) : ?>
              <?php
                // Keep numeric score as stored, but display a 5-star visual
                $display_value = ($rating_avg > 5) ? ($rating_avg / 2) : $rating_avg;
                $filled_stars = (int) round($display_value);
              ?>
              <span class="rating-over" aria-hidden="true">
                <span class="rating-info">
                  <i class="fa fa-star"></i>
                  <span class="main-rating"><?php echo number_format($rating_avg, 2); ?></span>
                </span>
              </span>
            <?php endif; ?>

            <span class="top-num" aria-hidden="true">
              <i class="fa fa-hashtag"></i>
              <span class="rank"><?php echo $position; ?></span>
            </span>
          </a>

          <div class="anime-column-info">
            <a class="anime-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
          </div>
        </div>
      <?php
        $position++;
      endwhile;
      $total_posts = $query->post_count;
      wp_reset_postdata();
      ?>
    </div>

    <?php if ($total_posts > $initial_display) : ?>
      <div class="top-100-load-more-wrapper">
        <button id="top-100-load-more" class="top-100-load-more-btn">Mai mult</button>
      </div>
    <?php endif; ?>

    <style>
      .top-100-hidden { display: none !important; }
      .top-100-load-more-wrapper { text-align: center; margin: 25px 0; }
      .top-100-load-more-btn {
        background: #13667a;
        color: #0f0f0f;
        padding: 10px 18px;
        border: 0;
        border-radius: 8px;
        font-size: 0.95rem;
        font-weight: 700;
        cursor: pointer;
      }
      .top-100-load-more-btn:hover { opacity: 0.9; }
    </style>

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        var btn = document.getElementById('top-100-load-more');
        if (!btn) return;

        btn.addEventListener('click', function () {
          document.querySelectorAll('.top-100-hidden').forEach(function (item) {
            item.classList.remove('top-100-hidden');
          });
          btn.style.display = 'none';
        });
      });
    </script>

  <?php else : ?>
    <div class="no-results">
      <p>No manga rated yet.</p>
    </div>
  <?php endif; ?>
</section>

<?php
// Include footer
get_footer();
?>