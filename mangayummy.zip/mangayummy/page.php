<?php 
// Route browse (and legacy advanced-search slugs) to the dedicated template.
if (is_page('browse') || is_page('advanced-search') || is_page('cautare-avansata')) {
    include get_template_directory() . '/page-cautare-avansata.php';
    return;
}

get_header(); 
?>

<main class="main-content">
    <?php while (have_posts()) : the_post(); ?>
        <article class="page-content">
            <h1><?php the_title(); ?></h1>
            <?php the_content(); ?>
        </article>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?> 