<?php
/**
 * Template Name: Community
 * Description: Top utilizatori după nivel și XP
 */

get_header();

// Get top users by level and XP - cached for 5 minutes
$cache_key = 'community_top_users';
$users = get_transient($cache_key);

if ($users === false) {
    global $wpdb;
    $users_raw = get_users([
        'number' => 100,
        'orderby' => 'meta_value_num',
        'meta_key' => 'reader_level',
        'order' => 'DESC',
        'meta_query' => [
            'relation' => 'OR',
            [
                'key' => 'email_verified',
                'compare' => 'NOT EXISTS'
            ],
            [
                'key' => 'email_verified',
                'value' => '1',
                'compare' => '='
            ]
        ]
    ]);

    // Sort by level DESC, then by XP DESC
    usort($users_raw, function($a, $b) {
        $level_a = (int) get_user_meta($a->ID, 'reader_level', true) ?: 1;
        $level_b = (int) get_user_meta($b->ID, 'reader_level', true) ?: 1;
        
        if ($level_a === $level_b) {
            $xp_a = (int) get_user_meta($a->ID, 'reader_xp', true) ?: 0;
            $xp_b = (int) get_user_meta($b->ID, 'reader_xp', true) ?: 0;
            return $xp_b - $xp_a;
        }
        
        return $level_b - $level_a;
    });
    
    // Cache essential data only (not full WP_User objects)
    $users = [];
    foreach ($users_raw as $u) {
        $users[] = [
            'ID' => $u->ID,
            'display_name' => $u->display_name,
            'level' => (int) get_user_meta($u->ID, 'reader_level', true) ?: 1,
            'xp' => (int) get_user_meta($u->ID, 'reader_xp', true) ?: 0,
            'avatar' => get_user_meta($u->ID, 'profile_avatar', true) ?: get_avatar_url($u->ID, ['size' => 80]),
            'registered' => $u->user_registered
        ];
    }
    
    set_transient($cache_key, $users, 5 * MINUTE_IN_SECONDS);
}

// Calculate online time from registration date
function get_user_online_time_from_date($registered) {
    $now = current_time('timestamp');
    $registered_time = strtotime($registered);
    $diff = $now - $registered_time;
    
    $days = floor($diff / 86400);
    $hours = floor(($diff % 86400) / 3600);
    
    if ($days > 0) {
        return $days . ' zile';
    } elseif ($hours > 0) {
        return $hours . ' ore';
    } else {
        return 'Recent';
    }
}

// Get user group info
if (!function_exists('mangayummy_get_user_group')) {
    function get_user_group_info($user_id) {
        $group = get_user_meta($user_id, 'user_group', true);
        if (!$group) {
            return ['name' => 'Cititor', 'color' => '#888'];
        }
        
        $groups = [
            'Admin' => ['name' => 'Admin', 'color' => '#ff0000'],
            'Moderator' => ['name' => 'Moderator', 'color' => '#ff6b35'],
            'Translator' => ['name' => 'Traducător', 'color' => '#13667a'],
            'VIP' => ['name' => 'VIP', 'color' => '#ffd700'],
        ];
        
        return isset($groups[$group]) ? $groups[$group] : ['name' => $group, 'color' => '#13667a'];
    }
} else {
    // Use the existing function from functions.php
    function get_user_group_info($user_id) {
        $group_data = mangayummy_get_user_group($user_id);
        if (!$group_data) {
            return ['name' => 'Cititor', 'color' => '#888'];
        }
        // Convert from 'label' to 'name' and keep 'color' (could be gradient)
        return ['name' => $group_data['label'], 'color' => $group_data['color']];
    }
}
?>

<main class="community-page">
    <div class="community-container">
        <div class="community-header">
            <h1 class="community-title">Top Utilizatori MangaYummy</h1>
            <p class="community-subtitle">Cele mai active persoane ale comunității noastre</p>
        </div>

        <?php if (!empty($users)): ?>
            <!-- TOP 3 PODIUM -->
            <div class="podium-section">
                <?php 
                $top3 = array_slice($users, 0, 3);
                $positions = [1 => 'first', 0 => 'second', 2 => 'third']; // Order: 2nd, 1st, 3rd for visual effect
                $reordered = [
                    isset($top3[1]) ? $top3[1] : null, // 2nd place (left)
                    isset($top3[0]) ? $top3[0] : null, // 1st place (center)
                    isset($top3[2]) ? $top3[2] : null  // 3rd place (right)
                ];
                ?>
                
                <div class="podium">
                    <?php foreach ($reordered as $index => $user): 
                        if (!$user) continue;
                        $position = $index === 0 ? 2 : ($index === 1 ? 1 : 3);
                        $rank_class = $index === 0 ? 'second' : ($index === 1 ? 'first' : 'third');
                        
                        // Use cached data
                        $level = $user['level'];
                        $xp = $user['xp'];
                        $online_time = get_user_online_time_from_date($user['registered']);
                        $group_info = get_user_group_info($user['ID']);
                        $avatar = $user['avatar'];
                    ?>
                        <div class="podium-place <?php echo $rank_class; ?>">
                            <div class="podium-rank">
                                <?php if ($position === 1): ?>
                                    <span class="rank-icon gold">👑</span>
                                <?php elseif ($position === 2): ?>
                                    <span class="rank-icon silver">🥈</span>
                                <?php else: ?>
                                    <span class="rank-icon bronze">🥉</span>
                                <?php endif; ?>
                                <span class="rank-number">#<?php echo $position; ?></span>
                            </div>
                            
                            <div class="podium-avatar-wrapper">
                                <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user['ID']), home_url('/'))); ?>" class="podium-avatar-link">
                                    <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($user['display_name']); ?>" class="podium-avatar" loading="lazy">
                                </a>
                                <div class="podium-level-badge" style="background: <?php echo esc_attr($group_info['color']); ?>">
                                    Nivel <?php echo $level; ?>
                                </div>
                            </div>
                            
                            <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user['ID']), home_url('/'))); ?>" class="podium-username-link">
                                <h3 class="podium-username"><?php echo esc_html($user['display_name']); ?></h3>
                            </a>
                            
                            <div class="podium-stats">
                                <div class="stat-item">
                                    <span class="stat-label">Grup</span>
                                    <span class="stat-value" style="color: <?php echo esc_attr($group_info['color']); ?>">
                                        <?php echo esc_html($group_info['name']); ?>
                                    </span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">XP</span>
                                    <span class="stat-value"><?php echo number_format($xp); ?></span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Pe server</span>
                                    <span class="stat-value"><?php echo esc_html($online_time); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- REST OF USERS -->
            <?php if (count($users) > 3): ?>
                <div class="leaderboard-section">
                    <h2 class="section-title">📊 Clasament Complet</h2>
                    <div class="leaderboard-list">
                        <?php foreach (array_slice($users, 3) as $index => $user): 
                            $position = $index + 4;
                            // Use cached data
                            $level = $user['level'];
                            $xp = $user['xp'];
                            $online_time = get_user_online_time_from_date($user['registered']);
                            $group_info = get_user_group_info($user['ID']);
                            $avatar = $user['avatar'];
                        ?>
                            <div class="leaderboard-item">
                                <div class="item-rank">
                                    <span class="rank-number">#<?php echo $position; ?></span>
                                </div>
                                
                                <div class="item-avatar">
                                    <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user['ID']), home_url('/'))); ?>">
                                        <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($user['display_name']); ?>" loading="lazy">
                                        <div class="level-badge" style="background: <?php echo esc_attr($group_info['color']); ?>">
                                            <?php echo $level; ?>
                                        </div>
                                    </a>
                                </div>
                                
                                <div class="item-info">
                                    <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user['ID']), home_url('/'))); ?>" class="username-link">
                                        <h4 class="item-username"><?php echo esc_html($user['display_name']); ?></h4>
                                    </a>
                                    <div class="item-meta">
                                        <span class="meta-group" style="color: <?php echo esc_attr($group_info['color']); ?>">
                                            <?php echo esc_html($group_info['name']); ?>
                                        </span>
                                        <span class="meta-separator">•</span>
                                        <span class="meta-xp"><?php echo number_format($xp); ?> XP</span>
                                    </div>
                                </div>
                                
                                <div class="item-time">
                                    <i class="fa fa-clock-o"></i>
                                    <span><?php echo esc_html($online_time); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="empty-state">
                <p class="empty-icon">👥</p>
                <h3>Nu există utilizatori încă</h3>
                <p>Fii primul membru al comunității!</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php
get_footer();
?>

