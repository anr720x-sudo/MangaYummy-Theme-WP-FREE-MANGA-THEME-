<?php
/**
 * WordPress admin tool to batch convert chapter JPG/PNG images to WebP.
 *
 * Requirements:
 * - only managers (manage_options)
 * - admin menu under Tools
 * - AJAX batch conversion (5 images per request)
 * - update _chapter_images meta
 * - delete original after success
 * - progress and per-image log
 */

if (!defined('ABSPATH')) {
    exit;
}

// NOTE: WebP conversion functionality has been consolidated into the Media Manager tool.
// The rendering function below is kept for backward compatibility but is no longer directly registered as a menu item.

function mangayummy_render_webp_converter_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }

    $upload_dir = wp_get_upload_dir();
    $chapters_dir = trailingslashit($upload_dir['basedir']) . 'chapters';

    $cleanup_message = '';
    if (isset($_GET['action']) && $_GET['action'] === 'cleanup_empty_webp') {
        $deleted = 0;
        if (is_dir($chapters_dir)) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($chapters_dir, RecursiveDirectoryIterator::SKIP_DOTS)
            );
            foreach ($iterator as $file) {
                if ($file->getExtension() === 'webp' && $file->getSize() < 1000) {
                    @unlink($file->getPathname());
                    $deleted++;
                }
            }
        }
        $cleanup_message = 'Deleted: ' . intval($deleted) . ' empty WebP files';
    }

    $chapter_files = tools_webp_convert_get_image_files($chapters_dir);
    $chapter_total = count($chapter_files);

    $media_files = tools_webp_convert_get_media_image_files($upload_dir['basedir']);
    $media_total = count($media_files);

    $nonce = wp_create_nonce('mangayummy_webp_convert_nonce');

    ?>
    <div class="wrap">
        <h1>WebP Converter</h1>

        <h2>Chapters</h2>
        <p>Scan: <strong><?php echo esc_html($chapter_total); ?></strong> JPG/JPEG/PNG images found in <code>/wp-content/uploads/chapters/</code> and subdirectories.</p>
        <?php if ($cleanup_message): ?>
            <div class="notice notice-success inline" style="margin-bottom:12px;"><?php echo esc_html($cleanup_message); ?></div>
        <?php endif; ?>
        <button id="tools-webp-convert-start-chapters" class="button button-primary" <?php echo ($chapter_total === 0 ? 'disabled' : ''); ?>>Convert Chapters</button>
        <button id="tools-webp-convert-stop-chapters" class="button button-secondary" <?php echo ($chapter_total === 0 ? 'disabled' : ''); ?>>Stop Chapters</button>
        <button id="tools-webp-clean-empty-webp" class="button button-secondary">Clean Empty WebP</button>
        <p id="tools-webp-convert-progress-chapters">0 / <?php echo esc_html($chapter_total); ?> converted</p>

        <div id="tools-webp-convert-log-chapters" style="max-height:240px; overflow:auto; background:#1e1e1e; color:#ddd; padding:12px; border:1px solid #444; font-family:monospace; white-space:pre-wrap;"></div>

        <h3>Chapter Files</h3>
        <ul id="tools-webp-convert-file-list-chapters" style="max-height:180px; overflow:auto; background:#fff; border:1px solid #ccc; padding:8px; list-style-type:decimal; margin-left:20px;">
            <?php foreach ($chapter_files as $file_path): ?>
                <li><?php echo esc_html(str_replace(trailingslashit($upload_dir['basedir']), '', $file_path)); ?></li>
            <?php endforeach; ?>
        </ul>

        <hr style="margin:30px 0; border-top:1px solid #555;">

        <h2>Covers & Media</h2>
        <p>Scan: <strong><?php echo esc_html($media_total); ?></strong> JPG/JPEG/PNG images found in <code>/wp-content/uploads/</code> (excluding <code>/chapters/</code>).</p>
        <div style="margin-bottom:10px;">
            <button type="button" id="tools-webp-select-all-media" class="button button-secondary" <?php echo ($media_total === 0 ? 'disabled' : ''); ?>>Select all</button>
            <button type="button" id="tools-webp-select-none-media" class="button button-secondary" <?php echo ($media_total === 0 ? 'disabled' : ''); ?>>Deselect all</button>
            <span id="tools-webp-selected-count-media" style="margin-left:10px; font-weight:600;">0 selected</span>
        </div>
        <button id="tools-webp-convert-start-media" class="button button-primary" <?php echo ($media_total === 0 ? 'disabled' : ''); ?>>Convert Covers & Media</button>
        <button id="tools-webp-convert-stop-media" class="button button-secondary" <?php echo ($media_total === 0 ? 'disabled' : ''); ?>>Stop Covers & Media</button>
        <button id="tools-webp-db-update" class="button button-secondary" <?php echo ($media_total === 0 ? 'disabled' : ''); ?>>Update DB URLs</button>
        <p id="tools-webp-convert-progress-media">0 / <?php echo esc_html($media_total); ?> converted</p>

        <div id="tools-webp-convert-log-media" style="max-height:240px; overflow:auto; background:#1e1e1e; color:#ddd; padding:12px; border:1px solid #444; font-family:monospace; white-space:pre-wrap;"></div>

        <h3>Media Files</h3>
        <ul id="tools-webp-convert-file-list-media" style="max-height:180px; overflow:auto; background:#fff; border:1px solid #ccc; padding:8px; list-style-type:decimal; margin-left:20px;">
            <?php foreach ($media_files as $file_path): ?>
                <?php $relative_media_path = str_replace(trailingslashit($upload_dir['basedir']), '', $file_path); ?>
                <?php $media_preview_url = str_replace(trailingslashit($upload_dir['basedir']), trailingslashit($upload_dir['baseurl']), $file_path); ?>
                <li>
                    <label class="tools-webp-media-file-row" data-preview-url="<?php echo esc_url($media_preview_url); ?>" data-preview-name="<?php echo esc_attr($relative_media_path); ?>" style="display:flex; gap:8px; align-items:flex-start; cursor:pointer;">
                        <input type="checkbox" class="tools-webp-media-file-checkbox" value="<?php echo esc_attr($relative_media_path); ?>">
                        <span><?php echo esc_html($relative_media_path); ?></span>
                    </label>
                </li>
            <?php endforeach; ?>
        </ul>
        <div id="tools-webp-media-preview-box" style="display:none; margin-top:12px; padding:10px; border:1px solid #444; background:#111; color:#ddd; border-radius:4px; max-width:420px;">
            <div id="tools-webp-media-preview-name" style="font-size:12px; margin-bottom:8px; word-break:break-all;"></div>
            <img id="tools-webp-media-preview-img" src="" alt="Preview" style="display:block; max-width:100%; max-height:260px; width:auto; height:auto; border:1px solid #333; background:#222;">
        </div>
    </div>

    <script>
    (function(){
        const chapterTotal = <?php echo intval($chapter_total); ?>;
        const mediaTotal = <?php echo intval($media_total); ?>;
        const nonce = '<?php echo esc_js($nonce); ?>';
        const batchSize = 5;

        const state = {
            chapters: { startButton: document.getElementById('tools-webp-convert-start-chapters'), stopButton: document.getElementById('tools-webp-convert-stop-chapters'), progressEl: document.getElementById('tools-webp-convert-progress-chapters'), logEl: document.getElementById('tools-webp-convert-log-chapters'), total: chapterTotal, offset: 0, converted: 0, stopRequested: false },
            media: { startButton: document.getElementById('tools-webp-convert-start-media'), stopButton: document.getElementById('tools-webp-convert-stop-media'), progressEl: document.getElementById('tools-webp-convert-progress-media'), logEl: document.getElementById('tools-webp-convert-log-media'), total: mediaTotal, offset: 0, converted: 0, stopRequested: false, selectedFiles: [] }
        };

        const mediaCheckboxes = Array.from(document.querySelectorAll('.tools-webp-media-file-checkbox'));
        const mediaRows = Array.from(document.querySelectorAll('.tools-webp-media-file-row'));
        const mediaSelectedCount = document.getElementById('tools-webp-selected-count-media');
        const mediaSelectAllButton = document.getElementById('tools-webp-select-all-media');
        const mediaSelectNoneButton = document.getElementById('tools-webp-select-none-media');
        const mediaPreviewBox = document.getElementById('tools-webp-media-preview-box');
        const mediaPreviewImg = document.getElementById('tools-webp-media-preview-img');
        const mediaPreviewName = document.getElementById('tools-webp-media-preview-name');

        function getSelectedMediaFiles() {
            return mediaCheckboxes
                .filter(function(cb){ return cb.checked; })
                .map(function(cb){ return cb.value; });
        }

        function updateMediaSelectedCount() {
            if (!mediaSelectedCount) {
                return;
            }
            const selectedCount = getSelectedMediaFiles().length;
            mediaSelectedCount.textContent = selectedCount + ' selectate';
        }

        mediaCheckboxes.forEach(function(cb){
            cb.addEventListener('change', updateMediaSelectedCount);
        });

        if (mediaSelectAllButton) {
            mediaSelectAllButton.addEventListener('click', function(){
                mediaCheckboxes.forEach(function(cb){ cb.checked = true; });
                updateMediaSelectedCount();
            });
        }

        if (mediaSelectNoneButton) {
            mediaSelectNoneButton.addEventListener('click', function(){
                mediaCheckboxes.forEach(function(cb){ cb.checked = false; });
                updateMediaSelectedCount();
            });
        }

        mediaRows.forEach(function(row){
            row.addEventListener('mouseenter', function(){
                if (!mediaPreviewBox || !mediaPreviewImg || !mediaPreviewName) {
                    return;
                }
                const previewUrl = row.getAttribute('data-preview-url') || '';
                const previewName = row.getAttribute('data-preview-name') || '';
                if (!previewUrl) {
                    return;
                }
                mediaPreviewImg.src = previewUrl;
                mediaPreviewName.textContent = previewName;
                mediaPreviewBox.style.display = 'block';
            });
        });

        function appendLog(section, message, type='info') {
            const entry = document.createElement('div');
            entry.textContent = message;
            if (type === 'error') {
                entry.style.color = '#13667a';
            } else if (type === 'success') {
                entry.style.color = '#52c41a';
            } else if (type === 'warning') {
                entry.style.color = '#f5a623';
            } else {
                entry.style.color = '#ddd';
            }
            section.logEl.appendChild(entry);
            section.logEl.scrollTop = section.logEl.scrollHeight;
        }

        function processBatch(mode) {
            const s = state[mode];
            if (s.offset >= s.total) {
                appendLog(s, 'Conversion complete. ' + s.converted + ' out of ' + s.total + ' images converted.', 'success');
                s.startButton.disabled = false;
                s.stopButton.disabled = true;
                return;
            }

            appendLog(s, 'Processing batch ' + (s.offset + 1) + ' - ' + Math.min(s.offset + batchSize, s.total) + '...', 'info');

            const body = new URLSearchParams();
            body.append('action', mode === 'chapters' ? 'mangayummy_webp_convert_batch' : 'mangayummy_webp_convert_media_batch');
            body.append('nonce', nonce);
            body.append('offset', s.offset);
            body.append('batch_size', batchSize);
            if (mode === 'media' && Array.isArray(s.selectedFiles) && s.selectedFiles.length > 0) {
                body.append('selected_files', JSON.stringify(s.selectedFiles));
            }

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString()
            })
            .then(response => response.json())
            .then(data => {
                if (!data || !data.success) {
                    appendLog(s, 'AJAX error: ' + (data && data.data ? JSON.stringify(data.data) : 'invalid response'), 'error');
                    s.startButton.disabled = false;
                    s.stopButton.disabled = true;
                    return;
                }

                const result = data.data;
                if (result.logs && Array.isArray(result.logs)) {
                    result.logs.forEach(item => appendLog(s, item.message, item.status));
                }

                // Update total in case server list shrank due to conversion/deletion
                if (typeof result.total === 'number') {
                    s.total = result.total;
                }

                s.converted = result.converted_total;
                s.offset = result.next_offset;
                    s.progressEl.textContent = s.converted + ' / ' + s.total + ' converted';

                if (s.stopRequested) {
                    appendLog(s, 'Conversion was manually stopped. ' + s.converted + ' out of ' + s.total + ' images converted.', 'warning');
                    s.startButton.disabled = false;
                    s.stopButton.disabled = true;
                    return;
                }

                if (typeof result.finished === 'boolean' && result.finished) {
                    appendLog(s, 'Procesarea s-a încheiat. ' + s.converted + ' din ' + s.total + ' imagini convertite.', 'success');
                    s.startButton.disabled = false;
                    s.stopButton.disabled = true;
                    return;
                }

                if (s.offset >= s.total) {
                    appendLog(s, 'Procesarea s-a încheiat. ' + s.converted + ' din ' + s.total + ' imagini convertite.', 'success');
                    s.startButton.disabled = false;
                    s.stopButton.disabled = true;
                    return;
                }

                processBatch(mode);
            })
            .catch(err => {
                appendLog(s, 'Eroare rețea: ' + err.message, 'error');
                s.startButton.disabled = false;
                s.stopButton.disabled = true;
            });
        }

        function setupHandlers(mode) {
            const s = state[mode];
            if (!s.startButton || !s.stopButton || !s.progressEl || !s.logEl) return;

            s.startButton.addEventListener('click', function(){
                if (s.total === 0) {
                    appendLog(s, 'No files to convert.');
                    return;
                }

                if (mode === 'media') {
                    const selected = getSelectedMediaFiles();
                    if (selected.length === 0) {
                        appendLog(s, 'Select at least one image before converting.', 'warning');
                        return;
                    }
                    s.selectedFiles = selected;
                    s.total = selected.length;
                }

                s.stopRequested = false;
                s.startButton.disabled = true;
                s.stopButton.disabled = false;
                s.offset = 0;
                s.converted = 0;
                s.logEl.textContent = '';
                s.progressEl.textContent = '0 / ' + s.total + ' converted';
                processBatch(mode);
            });

            s.stopButton.addEventListener('click', function(){
                if (s.stopRequested) {
                    return;
                }
                s.stopRequested = true;
                appendLog(s, 'Cerere de oprire primită. Se va termina batch-ul curent și se va opri.', 'warning');
                s.stopButton.disabled = true;
            });
        }

        setupHandlers('chapters');
        setupHandlers('media');
        updateMediaSelectedCount();

        const dbUpdateButton = document.getElementById('tools-webp-db-update');
        const dbUpdateStatus = document.createElement('div');
        dbUpdateStatus.id = 'tools-webp-db-update-status';
        dbUpdateStatus.style.marginTop = '10px';
        dbUpdateStatus.style.color = '#fff';
        if (dbUpdateButton && dbUpdateButton.parentNode) {
            dbUpdateButton.parentNode.insertBefore(dbUpdateStatus, dbUpdateButton.nextSibling);
        }

        const cleanEmptyWebpButton = document.getElementById('tools-webp-clean-empty-webp');
        if (cleanEmptyWebpButton) {
            cleanEmptyWebpButton.addEventListener('click', function() {
                const url = new URL(window.location.href);
                url.searchParams.set('action', 'cleanup_empty_webp');
                window.location.href = url.toString();
            });
        }

        if (dbUpdateButton) {
            dbUpdateButton.addEventListener('click', function() {
                dbUpdateButton.disabled = true;
                dbUpdateStatus.textContent = 'Actualizare DB în curs...';
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'mangayummy_webp_convert_db_update',
                        nonce: nonce
                    }).toString()
                })
                .then(res => res.json())
                .then(data => {
                    if (data && data.success) {
                        dbUpdateStatus.textContent = 'Actualizări DB efectuate: ' + (data.data.replaced_count || 0);
                    } else {
                        dbUpdateStatus.textContent = 'Eroare actualizare DB: ' + (data.data || 'unknown');
                    }
                })
                .catch(err => {
                    dbUpdateStatus.textContent = 'Eroare rețea: ' + err.message;
                })
                .finally(() => {
                    dbUpdateButton.disabled = false;
                });
            });
        }

    })();
    </script>

    <?php
}

function tools_webp_convert_get_image_files($base_dir) {
    $results = array();
    if (!is_dir($base_dir)) {
        return $results;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        if (!$item->isFile()) {
            continue;
        }

        $ext = strtolower(pathinfo($item->getFilename(), PATHINFO_EXTENSION));
        if (!in_array($ext, array('jpg', 'jpeg', 'png', 'webp'), true)) {
            continue;
        }

        $image_size = @getimagesize($item->getPathname());
        if ($image_size !== false) {
            list($width, $height) = $image_size;
            if ($width > 8000) {
                // Width too mare pentru procesare; skip.
                continue;
            }
            if ($height > 40000) {
                // Prea înaltă pentru extrem de multe segmente; skip pentru siguranță.
                continue;
            }
            // H > 16000 va fi tratată prin vertical slicing în procesare.
        }

        // Existing .webp files are included only if they are exactly 8000px tall
        // and not already split into -half-1 / -half-2 files.
        if ($ext === 'webp') {
            $height = isset($image_size[1]) ? intval($image_size[1]) : 0;
            $path_no_ext = preg_replace('/\.webp$/i', '', $item->getPathname());
            $half_1 = $path_no_ext . '-half-1.webp';
            $half_2 = $path_no_ext . '-half-2.webp';
            if ($height === 8000 && !(file_exists($half_1) && file_exists($half_2))) {
                $results[] = $item->getPathname();
            }
            continue;
        }

        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $item->getPathname());
        if (file_exists($webp_path)) {
            $webp_size = @filesize($webp_path);
            if ($webp_size !== false && $webp_size > 1000) {
                // Already converted with valid output
                continue;
            }
            // Dacă .webp există, dar e mic/invalid, reconvertim
        }

        $results[] = $item->getPathname();
    }

    sort($results);

    return $results;
}

function tools_webp_convert_get_media_image_files($base_dir) {
    $results = array();
    if (!is_dir($base_dir)) {
        return $results;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        if (!$item->isFile()) {
            continue;
        }

        $path = $item->getPathname();
        // Exclude /chapters/ (any depth) because already handled in chapters scan
        if (preg_match('#(?:/|\\\\)chapters(?:/|\\\\|$)#i', $path)) {
            continue;
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!in_array($ext, array('jpg', 'jpeg', 'png'), true)) {
            continue;
        }

        $image_size = @getimagesize($path);
        if ($image_size !== false) {
            list($width, $height) = $image_size;
            if ($width > 8000 || $height > 8000) {
                continue;
            }
        }

        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $path);
        if (file_exists($webp_path)) {
            $webp_size = @filesize($webp_path);
            if ($webp_size !== false && $webp_size > 1000) {
                continue;
            }
            // Dacă .webp e sub 1KB, reconvertim originalul
        }

        $results[] = $path;
    }

    sort($results);

    return $results;
}

function tools_webp_convert_update_chapter_images_meta($upload_dir, $old_path, $new_path) {
    $old_url = str_replace(trailingslashit($upload_dir['basedir']), trailingslashit($upload_dir['baseurl']), $old_path);
    $old_url = str_replace('\\', '/', $old_url);
    $new_url = str_replace(trailingslashit($upload_dir['basedir']), trailingslashit($upload_dir['baseurl']), $new_path);
    $new_url = str_replace('\\', '/', $new_url);

    global $wpdb;
    $like = '%' . $wpdb->esc_like($old_url) . '%';
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_chapter_images' AND meta_value LIKE %s",
        $like
    ));

    foreach ($rows as $row) {
        $meta = maybe_unserialize($row->meta_value);
        $updated = false;

        if (is_array($meta)) {
            foreach ($meta as &$img_url) {
                if (!is_string($img_url)) {
                    continue;
                }
                if (strpos($img_url, $old_url) !== false) {
                    $img_url = str_replace($old_url, $new_url, $img_url);
                    $updated = true;
                }
            }
            unset($img_url);
            if ($updated) {
                update_post_meta($row->post_id, '_chapter_images', $meta);
            }
        } elseif (is_string($meta) && strpos($meta, $old_url) !== false) {
            $meta = str_replace($old_url, $new_url, $meta);
            update_post_meta($row->post_id, '_chapter_images', $meta);
        }
    }
}

function tools_webp_convert_update_chapter_images_meta_split($upload_dir, $old_path, $new_paths) {
    if (!is_array($new_paths) || empty($new_paths)) {
        return;
    }

    $old_url = str_replace(trailingslashit($upload_dir['basedir']), trailingslashit($upload_dir['baseurl']), $old_path);
    $old_url = str_replace('\\', '/', $old_url);

    $new_urls = array();
    foreach ($new_paths as $new_path) {
        $url = str_replace(trailingslashit($upload_dir['basedir']), trailingslashit($upload_dir['baseurl']), $new_path);
        $new_urls[] = str_replace('\\', '/', $url);
    }

    global $wpdb;
    $like = '%' . $wpdb->esc_like($old_url) . '%';
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_chapter_images' AND meta_value LIKE %s",
        $like
    ));

    foreach ($rows as $row) {
        $meta = maybe_unserialize($row->meta_value);
        $updated = false;

        if (is_array($meta)) {
            $new_meta = array();
            foreach ($meta as $img_url) {
                if (!is_string($img_url)) {
                    $new_meta[] = $img_url;
                    continue;
                }
                if (strpos($img_url, $old_url) !== false) {
                    foreach ($new_urls as $replacement_url) {
                        $new_meta[] = $replacement_url;
                    }
                    $updated = true;
                } else {
                    $new_meta[] = $img_url;
                }
            }

            if ($updated) {
                update_post_meta($row->post_id, '_chapter_images', $new_meta);
            }
        } elseif (is_string($meta) && strpos($meta, $old_url) !== false) {
            // Fallback for string-serialized URLs
            $replacement = implode(',', $new_urls);
            $meta = str_replace($old_url, $replacement, $meta);
            update_post_meta($row->post_id, '_chapter_images', $meta);
        }
    }
}

function tools_webp_convert_split_webp_8000_in_two($webp_path) {
    if (!is_string($webp_path) || $webp_path === '' || !file_exists($webp_path)) {
        return false;
    }

    if (!class_exists('Imagick')) {
        return false;
    }

    try {
        $imagick = new Imagick();
        $imagick->setResourceLimit(Imagick::RESOURCETYPE_WIDTH, 99999);
        $imagick->setResourceLimit(Imagick::RESOURCETYPE_HEIGHT, 99999);
        $imagick->setResourceLimit(Imagick::RESOURCETYPE_AREA, 99999 * 99999);
        $imagick->readImage($webp_path);

        $width = intval($imagick->getImageWidth());
        $height = intval($imagick->getImageHeight());

        if ($height !== 8000) {
            $imagick->destroy();
            return array($webp_path);
        }

        $half_height = 4000;
        $base_path = preg_replace('/\.webp$/i', '', $webp_path);
        $new_paths = array();

        for ($index = 0; $index < 2; $index++) {
            $y_offset = $index * $half_height;
            $chunk = clone $imagick;
            $chunk->cropImage($width, $half_height, 0, $y_offset);
            $chunk->setImagePage($width, $half_height, 0, 0);
            $chunk->setImageFormat('webp');
            $chunk->setImageCompressionQuality(82);
            $chunk->stripImage();

            $chunk_path = $base_path . '-half-' . ($index + 1) . '.webp';
            $result = $chunk->writeImage($chunk_path);
            $chunk->destroy();

            if (!$result || !file_exists($chunk_path)) {
                foreach ($new_paths as $created_path) {
                    if (file_exists($created_path)) {
                        @unlink($created_path);
                    }
                }
                $imagick->destroy();
                return false;
            }

            $new_paths[] = $chunk_path;
        }

        $imagick->destroy();
        @unlink($webp_path);

        return $new_paths;
    } catch (Exception $e) {
        return false;
    }
}

function mangayummy_webp_convert_batch_callback() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Acces interzis');
    }

    check_ajax_referer('mangayummy_webp_convert_nonce', 'nonce');

    $offset = isset($_POST['offset']) ? max(0, intval($_POST['offset'])) : 0;
    $batch_size = isset($_POST['batch_size']) ? min(20, max(1, intval($_POST['batch_size']))) : 5;

    $upload_dir = wp_get_upload_dir();
    $chapters_dir = trailingslashit($upload_dir['basedir']) . 'chapters';
    $image_files = tools_webp_convert_get_image_files($chapters_dir);
    $total_files = count($image_files);

    if ($offset >= $total_files) {
        wp_send_json_success(array(
            'converted_total' => $total_files,
            'next_offset' => $total_files,
            'logs' => array(),
            'total' => $total_files,
        ));
    }

    $batch_files = array_slice($image_files, $offset, $batch_size);
    $logs = array();
    $converted_count = 0;

    foreach ($batch_files as $file_path) {
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if (!in_array($ext, array('jpg', 'jpeg', 'png', 'webp'), true)) {
            $logs[] = array('status' => 'warning', 'message' => "Saltat: $file_path (extensie neacceptată)");
            continue;
        }

        if ($ext === 'webp') {
            $split_paths = tools_webp_convert_split_webp_8000_in_two($file_path);
            if (is_array($split_paths) && count($split_paths) === 2) {
                tools_webp_convert_update_chapter_images_meta_split($upload_dir, $file_path, $split_paths);
                $logs[] = array('status' => 'success', 'message' => "WebP 8000px tăiat în 2: $file_path");
                $converted_count++;
            } else {
                $logs[] = array('status' => 'info', 'message' => "Ignorat WebP: $file_path (nu are 8000px sau e deja tăiat)");
            }
            continue;
        }

        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file_path);

        if (file_exists($webp_path)) {
            $logs[] = array('status' => 'success', 'message' => "Ignorat: .webp deja existent pentru $file_path");
            $converted_count++;
            continue;
        }

        try {
            $image_size = @getimagesize($file_path);
            $width = isset($image_size[0]) ? intval($image_size[0]) : 0;
            $height = isset($image_size[1]) ? intval($image_size[1]) : 0;

            if ($width > 8000) {
                $logs[] = array('status' => 'error', 'message' => "Saltat: $file_path (lățime > 8000px, nu e suportat)");
                continue;
            }

            if ($height > 16000) {
                $logs[] = array('status' => 'info', 'message' => "Vertical slicing activat pentru $file_path (înălțime $height > 16000)");

                $imagick = new Imagick();
                $imagick->setResourceLimit(Imagick::RESOURCETYPE_WIDTH, 99999);
                $imagick->setResourceLimit(Imagick::RESOURCETYPE_HEIGHT, 99999);
                $imagick->setResourceLimit(Imagick::RESOURCETYPE_AREA, 99999 * 99999);
                $imagick->readImage($file_path);

                $slice_height = 8000;
                $chunks = intval(ceil($height / $slice_height));
                $chunk_paths = array();
                $failed = false;

                for ($index = 0; $index < $chunks; $index++) {
                    $y_offset = $index * $slice_height;
                    $current_height = min($slice_height, $height - $y_offset);
                    $chunk = clone $imagick;
                    $chunk->cropImage($width, $current_height, 0, $y_offset);
                    $chunk->setImagePage($width, $current_height, 0, 0);
                    $chunk->setImageFormat('webp');
                    $chunk->setImageCompressionQuality(82);
                    $chunk->stripImage();

                    $chunk_path = preg_replace('/\.(jpe?g|png)$/i', '', $file_path) . '-' . ($index + 1) . '.webp';
                    $result = $chunk->writeImage($chunk_path);
                    $chunk->destroy();

                    if (!$result || !file_exists($chunk_path)) {
                        $logs[] = array('status' => 'error', 'message' => "Eroare conversie segment $index pentru $file_path");
                        $failed = true;
                        break;
                    }

                    $chunk_paths[] = $chunk_path;
                }

                $imagick->destroy();

                if ($failed) {
                    foreach ($chunk_paths as $p) {
                        if (file_exists($p)) {
                            unlink($p);
                        }
                    }
                    continue;
                }

                $final_chunk_paths = array();
                foreach ($chunk_paths as $chunk_path) {
                    $split_paths = tools_webp_convert_split_webp_8000_in_two($chunk_path);
                    if (is_array($split_paths) && !empty($split_paths)) {
                        foreach ($split_paths as $split_path) {
                            $final_chunk_paths[] = $split_path;
                        }
                    } else {
                        $final_chunk_paths[] = $chunk_path;
                    }
                }

                if (count($final_chunk_paths) > count($chunk_paths)) {
                    $logs[] = array('status' => 'info', 'message' => "Slicing suplimentar 8000->4000 pentru $file_path");
                }
                $chunk_paths = $final_chunk_paths;

                tools_webp_convert_update_chapter_images_meta_split($upload_dir, $file_path, $chunk_paths);

                if (unlink($file_path)) {
                    $logs[] = array('status' => 'success', 'message' => "Convertit și şters original (slicing): $file_path -> " . count($chunk_paths) . " segmente");
                } else {
                    $logs[] = array('status' => 'warning', 'message' => "Convertit, dar nu s-a șters originalul: $file_path");
                }

                $converted_count++;
                continue;
            }

            // Conversie standard pentru imagini < 16000px înălțime
            $imagick = new Imagick();
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_WIDTH, 99999);
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_HEIGHT, 99999);
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_AREA, 99999 * 99999);
            $imagick->readImage($file_path);
            $imagick->setImageFormat('webp');
            $imagick->setImageCompressionQuality(82);
            $imagick->stripImage();
            $result = $imagick->writeImage($webp_path);
            $imagick->destroy();

            if (!$result || !file_exists($webp_path)) {
                $logs[] = array('status' => 'error', 'message' => "Eroare conversie: $file_path (nu s-a creat .webp)");
                continue;
            }

            $split_paths = tools_webp_convert_split_webp_8000_in_two($webp_path);
            if (is_array($split_paths) && count($split_paths) === 2) {
                tools_webp_convert_update_chapter_images_meta_split($upload_dir, $file_path, $split_paths);
                $logs[] = array('status' => 'info', 'message' => "Slicing suplimentar 8000->4000 pentru $file_path");
            } else {
                tools_webp_convert_update_chapter_images_meta($upload_dir, $file_path, $webp_path);
            }

            if (unlink($file_path)) {
                $logs[] = array('status' => 'success', 'message' => "Convertit și șters: $file_path");
            } else {
                $logs[] = array('status' => 'warning', 'message' => "Convertit, dar nu s-a șters originalul: $file_path");
            }

            $converted_count++;
        } catch (Exception $e) {
            $logs[] = array('status' => 'error', 'message' => "Eroare Imagick la $file_path: " . $e->getMessage());
        }
    }

    $next_offset = min($total_files, $offset + $batch_size);

    wp_send_json_success(array(
        'converted_total' => min($total_files, $offset + $converted_count),
        'next_offset' => $next_offset,
        'logs' => $logs,
        'total' => $total_files,
        'finished' => $next_offset >= $total_files,
    ));
}

add_action('wp_ajax_mangayummy_webp_convert_batch', 'mangayummy_webp_convert_batch_callback');
add_action('wp_ajax_mangayummy_webp_convert_media_batch', 'mangayummy_webp_convert_media_batch_callback');
add_action('wp_ajax_mangayummy_webp_convert_db_update', 'mangayummy_webp_convert_db_update_callback');

function mangayummy_webp_convert_db_update_callback() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Acces interzis');
    }

    check_ajax_referer('mangayummy_webp_convert_nonce', 'nonce');

    $upload_dir = wp_get_upload_dir();
    $base_dir = trailingslashit($upload_dir['basedir']);
    $base_url = trailingslashit($upload_dir['baseurl']);

    $replaced_count = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    global $wpdb;

    foreach ($iterator as $item) {
        if (!$item->isFile()) {
            continue;
        }

        $path = $item->getPathname();
        if (preg_match('#(?:/|\\\\)chapters(?:/|\\\\|$)#i', $path)) {
            continue;
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!in_array($ext, array('webp'), true)) {
            continue;
        }

        $webp_url = str_replace($base_dir, $base_url, $path);
        $webp_url = str_replace('\\', '/', $webp_url);
        $old_url = preg_replace('/\.webp$/i', '.jpg', $webp_url);
        $old_url2 = preg_replace('/\.webp$/i', '.png', $webp_url);

        // Update wp_posts with both jpg and png candidates
        $replaced_count += $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s), guid = REPLACE(guid, %s, %s)",
            $old_url, $webp_url, $old_url, $webp_url
        ));

        $replaced_count += $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s), guid = REPLACE(guid, %s, %s)",
            $old_url2, $webp_url, $old_url2, $webp_url
        ));

        $replaced_count += $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->postmeta} SET meta_value = REPLACE(meta_value, %s, %s)",
            $old_url, $webp_url
        ));

        $replaced_count += $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->postmeta} SET meta_value = REPLACE(meta_value, %s, %s)",
            $old_url2, $webp_url
        ));
    }

    wp_send_json_success(['replaced_count' => $replaced_count]);
}

function mangayummy_webp_convert_media_batch_callback() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Acces interzis');
    }

    check_ajax_referer('mangayummy_webp_convert_nonce', 'nonce');

    $offset = isset($_POST['offset']) ? max(0, intval($_POST['offset'])) : 0;
    $batch_size = isset($_POST['batch_size']) ? min(20, max(1, intval($_POST['batch_size']))) : 5;

    $upload_dir = wp_get_upload_dir();
    $media_files = tools_webp_convert_get_media_image_files($upload_dir['basedir']);

    $selected_files = array();
    if (isset($_POST['selected_files'])) {
        $decoded_selected_files = json_decode(wp_unslash($_POST['selected_files']), true);
        if (is_array($decoded_selected_files)) {
            foreach ($decoded_selected_files as $relative_path) {
                if (!is_string($relative_path)) {
                    continue;
                }

                $relative_path = trim(str_replace('\\', '/', $relative_path));
                if ($relative_path === '') {
                    continue;
                }

                $absolute_path = wp_normalize_path(trailingslashit($upload_dir['basedir']) . ltrim($relative_path, '/'));
                if (strpos($absolute_path, wp_normalize_path(trailingslashit($upload_dir['basedir']))) !== 0) {
                    continue;
                }

                $selected_files[] = $absolute_path;
            }
        }
    }

    if (!empty($selected_files)) {
        $selected_lookup = array_fill_keys($selected_files, true);
        $media_files = array_values(array_filter($media_files, function($file_path) use ($selected_lookup) {
            return isset($selected_lookup[wp_normalize_path($file_path)]);
        }));
    }

    $total_files = count($media_files);

    if ($offset >= $total_files) {
        wp_send_json_success(array(
            'converted_total' => $total_files,
            'next_offset' => $total_files,
            'logs' => array(),
            'total' => $total_files,
        ));
    }

    $batch_files = array_slice($media_files, $offset, $batch_size);
    $logs = array();
    $converted_count = 0;

    foreach ($batch_files as $file_path) {
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if (!in_array($ext, array('jpg', 'jpeg', 'png'), true)) {
            $logs[] = array('status' => 'warning', 'message' => "Saltat: $file_path (extensie neacceptată)");
            continue;
        }

        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file_path);

        if (file_exists($webp_path)) {
            $logs[] = array('status' => 'success', 'message' => "Ignorat: .webp deja existent pentru $file_path");
            $converted_count++;
            continue;
        }

        try {
            $imagick = new Imagick();
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_WIDTH, 99999);
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_HEIGHT, 99999);
            $imagick->setResourceLimit(Imagick::RESOURCETYPE_AREA, 99999 * 99999);
            $imagick->readImage($file_path);
            $imagick->setImageFormat('webp');
            $imagick->setImageCompressionQuality(82);
            $imagick->stripImage();
            $result = $imagick->writeImage($webp_path);
            $imagick->destroy();

            if (!$result || !file_exists($webp_path)) {
                $logs[] = array('status' => 'error', 'message' => "Eroare conversie: $file_path (nu s-a creat .webp)");
                continue;
            }

            tools_webp_convert_update_chapter_images_meta($upload_dir, $file_path, $webp_path);

            $webp_size = filesize($webp_path);
            if ($webp_size === false || $webp_size <= 1000) {
                if (file_exists($webp_path)) {
                    unlink($webp_path);
                }
                $logs[] = array('status' => 'error', 'message' => "Conversie eșuată - original păstrat pentru $file_path (webp prea mic: " . ($webp_size === false ? 'n/a' : $webp_size) . " bytes)");
                continue;
            }

            // Update URLs in database for converted media
            global $wpdb;
            $upload_base_dir = trailingslashit($upload_dir['basedir']);
            $upload_base_url = trailingslashit($upload_dir['baseurl']);
            $old_url = str_replace($upload_base_dir, $upload_base_url, $file_path);
            $old_url = str_replace('\\', '/', $old_url);
            $new_url = preg_replace('/\.(jpe?g|png)$/i', '.webp', $old_url);

            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s), guid = REPLACE(guid, %s, %s)",
                $old_url, $new_url, $old_url, $new_url
            ));

            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->postmeta} SET meta_value = REPLACE(meta_value, %s, %s)",
                $old_url, $new_url
            ));

            // Update WordPress attachment metadata for converted files
            $upload_url = str_replace($upload_base_dir, $upload_base_url, $webp_path);
            $upload_url = str_replace('\\', '/', $upload_url);
            $attachment_id = attachment_url_to_postid(preg_replace('/\.webp$/i', '.jpg', $upload_url));
            if (!$attachment_id) {
                $attachment_id = attachment_url_to_postid(preg_replace('/\.webp$/i', '.png', $upload_url));
            }
            if ($attachment_id) {
                update_attached_file($attachment_id, $webp_path);
                $meta = wp_get_attachment_metadata($attachment_id);
                if ($meta) {
                    $meta['file'] = preg_replace('/\.(jpe?g|png)$/i', '.webp', $meta['file'] ?? '');
                    if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
                        foreach ($meta['sizes'] as $size_key => $size_meta) {
                            if (isset($size_meta['file'])) {
                                $meta['sizes'][$size_key]['file'] = preg_replace('/\.(jpe?g|png)$/i', '.webp', $size_meta['file']);
                            }
                            $meta['sizes'][$size_key]['mime-type'] = 'image/webp';
                        }
                    }
                    wp_update_attachment_metadata($attachment_id, $meta);
                }
                wp_update_post(array('ID' => $attachment_id, 'post_mime_type' => 'image/webp'));
            }

            if (unlink($file_path)) {
                $logs[] = array('status' => 'success', 'message' => "Convertit și șters: $file_path");
            } else {
                $logs[] = array('status' => 'warning', 'message' => "Convertit, dar nu s-a șters originalul: $file_path");
            }

            $converted_count++;
        } catch (Exception $e) {
            $logs[] = array('status' => 'error', 'message' => "Eroare Imagick la $file_path: " . $e->getMessage());
        }
    }

    $next_offset = min($total_files, $offset + $batch_size);

    wp_send_json_success(array(
        'converted_total' => min($total_files, $offset + $converted_count),
        'next_offset' => $next_offset,
        'logs' => $logs,
        'total' => $total_files,
    ));
}
