<?php
/**
 * Profile Page Template
 * Displays user profiles with different views for owners vs visitors
 *
 * URL: /profile (own profile) or /profile/?user=ID (other users)
 * Access: Anyone can view other user profiles. Own profile requires login.
 * Owner view: Full editing capabilities, social search
 * Visitor view: Read-only profile with friends list
 */

// Disable caching for profile pages
if (!defined('DONOTCACHEPAGE')) {
    define('DONOTCACHEPAGE', true);
}
nocache_headers();

get_header();
?>
<!-- custom progress edit modal -->
<div id="progress-modal" class="progress-modal" style="display:none;">
    <div class="modal-content">
        <h2>Update progress</h2>
        <input type="number" id="progress-input" min="0" placeholder="Chapter" />
        <div class="modal-buttons">
            <button id="progress-save-btn" class="btn-primary">Save</button>
            <button id="progress-cancel-btn" class="btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<!-- custom rating edit modal -->
<div id="rating-modal" class="progress-modal" style="display:none;">
    <div class="modal-content">
        <h2>Edit rating</h2>
        <input type="number" step="0.5" id="rating-input" min="0" max="10" placeholder="Rating" />
        <div class="modal-buttons">
            <button id="rating-save-btn" class="btn-primary">Save</button>
            <button id="rating-cancel-btn" class="btn-secondary">Cancel</button>
        </div>
    </div>
</div>
<?php

$view_user = intval(get_query_var('view_user')) ?: intval($_GET['view_user'] ?? 0);

// If no specific user requested and not logged in, redirect to login
if ($view_user === 0 && !is_user_logged_in()) {
    wp_redirect(home_url('/login'));
    exit;
}

if ($view_user > 0) {
    $profile_user_id = $view_user;
} else {
    $profile_user_id = get_current_user_id();
}

$is_owner = is_user_logged_in() && get_current_user_id() === $profile_user_id;

// Friend/action buttons for new banner button
if (!$is_owner && is_user_logged_in()) {
    $current_user_id = get_current_user_id();
    $current_friends = get_user_meta($current_user_id, 'friends', true);
    $current_friends = is_array($current_friends) ? $current_friends : [];
    $current_sent_requests = get_user_meta($current_user_id, 'friend_requests_sent', true);
    $current_sent_requests = is_array($current_sent_requests) ? $current_sent_requests : [];
    $profile_requests_to_me = get_user_meta($current_user_id, 'friend_requests', true);
    $profile_requests_to_me = is_array($profile_requests_to_me) ? $profile_requests_to_me : [];
    $is_friend = in_array($profile_user_id, $current_friends);
    $request_received = in_array($profile_user_id, $profile_requests_to_me);
    $request_sent = in_array($profile_user_id, $current_sent_requests);
}

$user = get_user_by('ID', $profile_user_id);
if (!$user) {
    wp_redirect(home_url());
    exit;
}

$verification_status = null;
$verification_code = sanitize_text_field($_GET['verify'] ?? '');
if (!empty($verification_code)) {
    $stored_token = get_user_meta($profile_user_id, 'discord_verification_token', true);
    if (!empty($stored_token) && hash_equals($stored_token, $verification_code)) {
        $verification_status = 'success';
    } else {
        $verification_status = 'invalid';
    }
}

// Check if user is invisible and current user is not admin
if (get_user_meta($profile_user_id, '_invisible', true) && !current_user_can('manage_options')) {
    wp_redirect(home_url('/?invisible_user=1'));
    exit;
}

// DEBUG: Log all user meta for debugging
if (current_user_can('manage_options')) {
    // Get all user meta keys that might contain bookmarks or ratings
    global $wpdb;
    $all_bookmark_meta = $wpdb->get_results($wpdb->prepare(
        "SELECT meta_key, meta_value FROM $wpdb->usermeta 
         WHERE user_id = %d AND (meta_key LIKE '%%bookmark%%' OR meta_key LIKE '%%favorite%%' OR meta_key LIKE '%%rated%%')",
        $profile_user_id
    ));
}

// Get/initialize user meta
$user_xp = get_user_meta($profile_user_id, 'reader_xp', true);
$user_level = get_user_meta($profile_user_id, 'reader_level', true);

// Try different possible meta keys for bookmarks (in order of likelihood)
$bookmarked_manga = get_user_meta($profile_user_id, 'mangayummy_bookmarks', true);
if (empty($bookmarked_manga)) {
    $bookmarked_manga = get_user_meta($profile_user_id, 'bookmarked_manga', true);
}
if (empty($bookmarked_manga)) {
    $bookmarked_manga = get_user_meta($profile_user_id, 'bookmarked_mangas', true);
}

// after sanitization above we might want to refresh bookmarks too
if ($is_owner && function_exists('mangayummy_sanitize_user_manga_meta')) {
    $bookmarked_manga = get_user_meta($profile_user_id, 'mangayummy_bookmarks', true);
    if (empty($bookmarked_manga)) {
        $bookmarked_manga = get_user_meta($profile_user_id, 'bookmarked_manga', true);
    }
    if (empty($bookmarked_manga)) {
        $bookmarked_manga = get_user_meta($profile_user_id, 'bookmarked_mangas', true);
    }
}

// Ensure bookmarked_manga is array (handle serialization)
if (!is_array($bookmarked_manga)) {
    if (is_string($bookmarked_manga) && !empty($bookmarked_manga)) {
        // Try to unserialize if it's serialized
        $unserialized = @unserialize($bookmarked_manga);
        $bookmarked_manga = is_array($unserialized) ? $unserialized : [];
    } else {
        $bookmarked_manga = [];
    }
}

// Set defaults if not exist
if (empty($user_xp)) {
    $user_xp = 0;
    update_user_meta($profile_user_id, 'reader_xp', 0);
}
if (empty($user_level)) {
    $user_level = 1;
    update_user_meta($profile_user_id, 'reader_level', 1);
}
if (empty($bookmarked_manga)) {
    update_user_meta($profile_user_id, 'mangayummy_bookmarks', []);
}

// Get user registration date
$user_registered = strtotime($user->user_registered);
$user_registered_formatted = wp_date('d M Y', $user_registered);

// Get user role
$user_role = implode(', ', $user->roles);

// Get all status arrays for tab counts
$reading_manga = get_user_meta($profile_user_id, 'manga_status_reading', true);
$planned_manga = get_user_meta($profile_user_id, 'manga_status_planned', true);
$completed_manga = get_user_meta($profile_user_id, 'manga_status_completed', true);
$paused_manga = get_user_meta($profile_user_id, 'manga_status_paused', true);
$abandoned_manga = get_user_meta($profile_user_id, 'manga_status_abandoned', true);

// clean up any stale ids (manga deleted/unpublished) when owner views their own profile
if ($is_owner && function_exists('mangayummy_sanitize_user_manga_meta')) {
    mangayummy_sanitize_user_manga_meta($profile_user_id);
    // reload arrays after sanitization
    $reading_manga = get_user_meta($profile_user_id, 'manga_status_reading', true);
    $planned_manga = get_user_meta($profile_user_id, 'manga_status_planned', true);
    $completed_manga = get_user_meta($profile_user_id, 'manga_status_completed', true);
    $paused_manga = get_user_meta($profile_user_id, 'manga_status_paused', true);
    $abandoned_manga = get_user_meta($profile_user_id, 'manga_status_abandoned', true);
}

// Ensure all are arrays
$reading_manga = is_array($reading_manga) ? $reading_manga : [];
$planned_manga = is_array($planned_manga) ? $planned_manga : [];
$completed_manga = is_array($completed_manga) ? $completed_manga : [];
$paused_manga = is_array($paused_manga) ? $paused_manga : [];
$abandoned_manga = is_array($abandoned_manga) ? $abandoned_manga : [];

// Load manga series translated by this profile user.
$translator_manga_items = [];
$translator_meta_queries = [
    'relation' => 'OR',
    [
        'key' => '_translator_user',
        'value' => (string) $profile_user_id,
        'compare' => '=',
    ],
    [
        'key' => '_translator_user',
        'value' => $user->user_login,
        'compare' => '=',
    ],
];

if (!empty($user->display_name) && $user->display_name !== $user->user_login) {
    $translator_meta_queries[] = [
        'key' => '_translator_user',
        'value' => $user->display_name,
        'compare' => '=',
    ];
}

$translator_query = new WP_Query([
    'post_type' => 'manga',
    'post_status' => 'publish',
    'posts_per_page' => -1,
    'meta_query' => $translator_meta_queries,
    'fields' => 'all',
]);

$translator_manga_items = $translator_query->posts;
wp_reset_postdata();

$translator_manga_by_status = [
    'in_progress' => [],
    'completed' => [],
    'abandoned' => [],
];

foreach ($translator_manga_items as $translator_manga) {
    $translator_status = get_post_meta($translator_manga->ID, '_translator_status', true);
    if ($translator_status === 'completed') {
        $translator_manga_by_status['completed'][] = $translator_manga;
    } elseif ($translator_status === 'abandoned') {
        $translator_manga_by_status['abandoned'][] = $translator_manga;
    } else {
        // Fallback to general manga status only if translator-specific status is unset.
        if ($translator_status === '') {
            $series_status = get_post_meta($translator_manga->ID, '_status', true);
            if ($series_status === 'completed') {
                $translator_manga_by_status['completed'][] = $translator_manga;
                continue;
            }
            if (in_array($series_status, ['hiatus', 'abandoned', 'cancelled'], true)) {
                $translator_manga_by_status['abandoned'][] = $translator_manga;
                continue;
            }
        }
        $translator_manga_by_status['in_progress'][] = $translator_manga;
    }
}

$profile_read_count = function_exists('mangayummy_get_user_read_count')
    ? (int) mangayummy_get_user_read_count($profile_user_id)
    : 0;

$profile_type_stats = function_exists('mangayummy_get_user_type_stats')
    ? (array) mangayummy_get_user_type_stats($profile_user_id)
    : ['manga' => 0, 'manhua' => 0, 'manhwa' => 0];

$profile_type_stats = array_merge(
    ['manga' => 0, 'manhua' => 0, 'manhwa' => 0],
    array_intersect_key($profile_type_stats, ['manga' => true, 'manhua' => true, 'manhwa' => true])
);


?>

<?php if ($is_owner): ?>
<!-- Image Crop Modal -->
<div id="cropModal" class="crop-modal">
    <div class="crop-modal-content">
        <div class="crop-modal-header">
            <span class="crop-modal-title">Crop image</span>
            <button type="button" class="crop-modal-close">&times;</button>
        </div>
        <div class="crop-container">
            <img id="cropImage" src="" alt="Crop preview">
        </div>
        <div class="crop-modal-actions">
            <button type="button" class="crop-btn crop-btn-cancel">Cancel</button>
            <button type="button" class="crop-btn crop-btn-save">Save</button>
        </div>
    </div>
</div>
<?php endif; ?>

<main id="main" class="profile-page <?php echo $is_owner ? 'profile-owner' : ''; ?>">
    
    <?php 
    // Check if user is banned and show warning
    $is_banned = get_user_meta($profile_user_id, '_banned', true);
    if ($is_banned): 
    ?>
    <style>
        .profile-container {
            position: relative;
        }
        .banned-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 100;
            background: rgba(15, 15, 15, 0.85);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            pointer-events: none;
        }
        .banned-message {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 16px;
            padding: 40px;
            background: rgba(231, 76, 60, 0.15);
            border: 2px solid rgba(231, 76, 60, 0.5);
            border-radius: 16px;
        }
        .banned-icon {
            flex-shrink: 0;
        }
        .banned-text {
            color: #e74c3c;
            font-size: 22px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
    </style>
    <?php endif; ?>
    
    <div class="profile-container">
        <?php if ($is_banned): ?>
        <div class="banned-overlay">
            <div class="banned-message">
                <svg class="banned-icon" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                <span class="banned-text">This user has been banned</span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Profile Top Bar -->
        <?php $top_group_info = mangayummy_get_user_group($profile_user_id); ?>
        <div class="profile-banner-top">
            <div class="profile-quick-info">
                <button type="button" class="profile-quick-info-trigger" aria-label="Profile info">!</button>
                <div class="profile-quick-info-popover">
                    <div class="profile-quick-info-row">
                        <span class="profile-quick-info-label">Group</span>
                        <span class="profile-quick-info-value"><?php echo esc_html($top_group_info['label'] ?? 'Member'); ?></span>
                    </div>
                    <div class="profile-quick-info-row">
                        <span class="profile-quick-info-label">Level</span>
                        <span class="profile-quick-info-value"><?php echo esc_html((string) intval($user_level)); ?></span>
                    </div>
                    <div class="profile-quick-info-row">
                        <span class="profile-quick-info-label">XP</span>
                        <span class="profile-quick-info-value"><?php echo esc_html(number_format_i18n((int) $user_xp)); ?></span>
                    </div>
                </div>
            </div>

            <span class="profile-banner-label">Profile</span>
            <span class="profile-banner-name"><?php echo esc_html($user->display_name); ?></span>

            <?php if (!$is_owner && is_user_logged_in()): ?>
            <div class="profile-add-friend-wrap">
                <?php if ($is_friend): ?>
                    <button class="profile-add-friend-btn is-friend" disabled title="Friend">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
                    </button>
                <?php elseif ($request_sent): ?>
                    <button class="profile-add-friend-btn is-sent" disabled title="Request sent">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                    </button>
                <?php elseif ($request_received): ?>
                    <button class="profile-add-friend-btn" data-user-id="<?php echo (int)$profile_user_id; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('ya_ajax_nonce')); ?>" title="Accept request">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
                    </button>
                <?php else: ?>
                    <button class="profile-add-friend-btn js-profile-add-friend" data-user-id="<?php echo (int)$profile_user_id; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('ya_ajax_nonce')); ?>" title="Add friend">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                    </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($is_owner): ?>
            <a href="#settings" class="profile-settings-link" aria-label="Profile settings" title="Profile settings" data-open-settings="1">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M12 8.75A3.25 3.25 0 1 0 12 15.25A3.25 3.25 0 1 0 12 8.75Z" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M19.43 12.98C19.47 12.66 19.5 12.33 19.5 12C19.5 11.67 19.47 11.34 19.43 11.02L21.54 9.37C21.73 9.22 21.78 8.95 21.66 8.73L19.66 5.27C19.54 5.05 19.28 4.96 19.05 5.03L16.56 6.03C16.04 5.63 15.47 5.29 14.85 5.03L14.47 2.38C14.43 2.14 14.22 1.96 13.97 1.96H10.03C9.78 1.96 9.57 2.14 9.53 2.38L9.15 5.03C8.53 5.29 7.96 5.63 7.44 6.03L4.95 5.03C4.72 4.96 4.46 5.05 4.34 5.27L2.34 8.73C2.22 8.95 2.27 9.22 2.46 9.37L4.57 11.02C4.53 11.34 4.5 11.67 4.5 12C4.5 12.33 4.53 12.66 4.57 12.98L2.46 14.63C2.27 14.78 2.22 15.05 2.34 15.27L4.34 18.73C4.46 18.95 4.72 19.04 4.95 18.97L7.44 17.97C7.96 18.37 8.53 18.71 9.15 18.97L9.53 21.62C9.57 21.86 9.78 22.04 10.03 22.04H13.97C14.22 22.04 14.43 21.86 14.47 21.62L14.85 18.97C15.47 18.71 16.04 18.37 16.56 17.97L19.05 18.97C19.28 19.04 19.54 18.95 19.66 18.73L21.66 15.27C21.78 15.05 21.73 14.78 21.54 14.63L19.43 12.98Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
                </svg>
            </a>
            <?php endif; ?>
        </div>

        <!-- Profile Banner -->
        <?php
        $banner_url = get_user_meta($profile_user_id, 'profile_banner', true);
        $has_custom_banner = !empty($banner_url);
        $banner_class = $has_custom_banner ? '' : ' is-default-banner';
        ?>
        <div class="profile-banner<?php echo esc_attr($banner_class); ?>" data-user="<?php echo $profile_user_id; ?>"<?php if ($has_custom_banner): ?> style="background-image: url('<?php echo esc_url($banner_url); ?>');"<?php endif; ?>>
            <?php if ($is_owner): ?>
                <input type="file" id="bannerUpload" style="display:none;" accept="image/*" aria-hidden="true">
                <div class="banner-overlay"><span>Change banner</span></div>
            <?php endif; ?>
        </div>

        <!-- Profile Header -->
        <div class="profile-header">
            <div class="header-content">
                <div class="profile-left">
                    <div class="profile-main-row">
                        <?php $avatar_effect_class = mangayummy_get_user_avatar_effect_class($profile_user_id); ?>
                        <div class="avatar-wrapper <?php echo esc_attr($avatar_effect_class); ?>">
                            <?php
                            $avatar_url = get_user_meta($profile_user_id, 'profile_avatar', true);
                            if (!$avatar_url) {
                                $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
                            }
                            list($profile_status, $profile_status_text) = mangayummy_user_status($profile_user_id);
                            if ($profile_status === 'offline') {
                                $last = get_user_meta($profile_user_id, 'last_activity', true);
                                if (!$last) {
                                    $last = get_user_meta($profile_user_id, 'last_active', true);
                                }
                                if ($last) {
                                    $profile_status_text = 'Last online: ' . mangayummy_time_ago((int)$last);
                                }
                            }
                            $profile_is_online = ($profile_status === 'online');
                            ?>
                            <img id="profileAvatar" src="<?php echo esc_url($avatar_url); ?>" class="profile-avatar" alt="Avatar">
                            <span class="avatar-online-dot <?php echo $profile_is_online ? 'online' : 'offline'; ?>" data-tooltip="<?php echo esc_attr($profile_status_text); ?>" aria-label="<?php echo esc_attr($profile_status_text); ?>"></span>
                            <?php if ($is_owner): ?>
                                <input type="file" id="avatarUpload" style="display:none;" accept="image/*" aria-hidden="true">
                                <div class="avatar-overlay"><span>Change avatar</span></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="user-info">
                    <div class="profile-title-row">
                        <?php if (mangayummy_user_has_achievement($profile_user_id, 'bug_hunter')): ?>
                        <span class="achievement-badge" title="Bug Hunter" data-removable="1">🐛</span>

                        <!-- Bug Hunter popup -->
                        <div id="bug-hunter-popup" class="bug-popup" style="display:none;">
                                <div class="bug-popup__overlay"></div>
                                <div class="bug-popup__content">
                                    <h3>Bug Hunter</h3>
                                    <p>Do you want to remove the Bug Hunter achievement?</p>
                                    <div class="bug-popup__actions">
                                        <button type="button" class="btn btn-sm btn-danger" id="remove-bug-btn">Delete</button>
                                        <button type="button" class="btn btn-sm" id="close-bug-block">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="profile-user-meta-row">
                    <!-- User Info: Birthday, Gender -->
                    <div class="user-details">
                        <?php 
                        $birthday = get_user_meta($profile_user_id, 'birthday', true);
                        if (empty($birthday)) {
                            $birthday = get_user_meta($profile_user_id, 'user_birthday', true);
                        }
                        if (empty($birthday)) {
                            $birthday = get_user_meta($profile_user_id, 'profile_birthday', true);
                        }
                        if (empty($birthday)) {
                            $birthday = get_user_meta($profile_user_id, 'birthdate', true);
                        }
                        
                        $gender = mangayummy_get_user_gender($profile_user_id);

                        $birthday_text = 'Not specified';
                        if (!empty($birthday)) {
                            // Parse date directly without any timezone conversion
                            $date_parts = explode('-', $birthday); // YYYY-MM-DD
                            if (count($date_parts) === 3) {
                                $day = intval($date_parts[2]);
                                $month = intval($date_parts[1]);
                                $year = intval($date_parts[0]);
                                
                                // Format directly in English without timestamp conversion
                                $months_ro = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
                                if ($month >= 1 && $month <= 12) {
                                    $birthday_text = $day . ' ' . $months_ro[$month - 1] . ' ' . $year;
                                } else {
                                    $birthday_text = $birthday;
                                }
                            } else {
                                $birthday_text = $birthday;
                            }
                        }

                        $gender_text = 'Not specified';
                        if ($gender === 'masculin') {
                            $gender_text = 'Male';
                        } elseif ($gender === 'feminin') {
                            $gender_text = 'Female';
                        }
                        ?>
                        <span class="detail-item"><span class="detail-label">Joined:</span> <span class="detail-value"><?php echo esc_html($user_registered_formatted); ?></span></span>
                        <span class="detail-item"><span class="detail-label">Birthday:</span> <span class="detail-value"><?php echo esc_html($birthday_text); ?></span></span>
                        <span class="detail-item"><span class="detail-label">Gender:</span> <span class="detail-value"><?php echo esc_html($gender_text); ?></span></span>
                    </div>

                    <div class="user-type-stats profile-inline-stats" aria-label="Manga type statistics">
                        <span class="user-stats-title">Time spent on site</span>
                        <div class="type-stat">
                            <span class="type-count"><?php echo intval($profile_type_stats['manga']); ?></span>
                            <span class="type-label">Manga</span>
                        </div>
                        <div class="type-stat">
                            <span class="type-count"><?php echo intval($profile_type_stats['manhua']); ?></span>
                            <span class="type-label">Manhua</span>
                        </div>
                        <div class="type-stat">
                            <span class="type-count"><?php echo intval($profile_type_stats['manhwa']); ?></span>
                            <span class="type-label">Manhwa</span>
                        </div>
                    </div>

                    </div>

                    <!-- User Bio -->
                    <?php 
                    $user_bio = get_user_meta($profile_user_id, 'bio', true);
                    if ($user_bio): ?>
                        <div class="user-bio">
                            <p><?php echo esc_html($user_bio); ?></p>
                        </div>
                    <?php endif; ?>

                </div> <!-- .user-info -->
                </div> <!-- .profile-main-row -->

                <?php
                $has_news_badge = false;
                if ($profile_user_id) {
                    $news_authors = get_posts([
                        'post_type'      => 'stire',
                        'author'         => $profile_user_id,
                        'post_status'    => $is_owner ? ['publish', 'pending', 'draft', 'private'] : 'publish',
                        'posts_per_page' => 1,
                        'fields'         => 'ids',
                        'no_found_rows'  => true,
                        'update_post_term_cache' => false,
                    ]);

                    $news_meta = get_posts([
                        'post_type'      => 'stire',
                        'post_status'    => $is_owner ? ['publish', 'pending', 'draft', 'private'] : 'publish',
                        'posts_per_page' => 1,
                        'fields'         => 'ids',
                        'no_found_rows'  => true,
                        'update_post_term_cache' => false,
                        'meta_query'     => [
                            [
                                'key'     => '_stire_author_id',
                                'value'   => $profile_user_id,
                                'compare' => '=',
                            ],
                        ],
                    ]);

                    if (!empty($news_authors) || !empty($news_meta)) {
                        $has_news_badge = true;
                    }
                }

                $reading_activity = mangayummy_get_reading_activity($profile_user_id);
                $days_online_count = 0;
                foreach ($reading_activity as $day_info) {
                    if (!empty($day_info['count'])) {
                        $days_online_count++;
                    }
                }
                ?>
                <div class="profile-secondary-row">
                    <?php
                    // Discord icon link
                    $dc_id  = get_user_meta($profile_user_id, 'discord_id', true);
                    $dc_url = get_user_meta($profile_user_id, 'discord_profile_url', true);
                    if (empty($dc_url) && !empty($dc_id)) {
                        $dc_url = 'https://discord.com/users/' . rawurlencode($dc_id);
                    }
                    ?>

                    <?php if ($has_news_badge || (!empty($top_group_info) && in_array(strtolower(trim($top_group_info['label'])), ['fondator', 'tester', 'designer']))): ?>
                    <div class="profile-overview-card profile-news-badge" aria-label="User role">
                            <?php if (!empty($top_group_info) && strtolower(trim($top_group_info['label'])) === 'fondator'): ?>
                        <div class="wn founder" tabindex="0" title="Fondator" data-tooltip-id="user-role-tooltip" data-tooltip-content="Fondator" data-tooltip="Fondator" data-tooltip-place="top">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 20 20"><path d="M4.64 6.49c.1.94.27 2.24.7 3.6.88 2.89 2.45 4.94 4.66 6.11 2.21-1.17 3.78-3.22 4.67-6.11.42-1.36.6-2.66.68-3.6L10 3.86 4.64 6.49ZM19 4.67a.63.63 0 00-.1-.29.57.57 0 00-.23-.2L10.27.06A.66.66 0 0010 0a.66.66 0 00-.27.06L1.34 4.18a.57.57 0 00-.23.2.63.63 0 00-.1.29c0 .12-.14 2.98.85 6.29a15.19 15.19 0 002.56 5.1 12.13 12.13 0 005.37 3.9.6.6 0 00.42 0c2.16-.8 3.96-2.12 5.37-3.9a15.19 15.19 0 002.56-5.1c1-3.31.86-6.17.85-6.29Zm-8.73 12.72a.58.58 0 01-.52 0c-2.66-1.29-4.53-3.63-5.55-6.96a18.7 18.7 0 01-.77-4.25c0-.12.02-.23.08-.33s.15-.18.25-.23l5.98-2.94a.66.66 0 01.27-.06c.1 0 .18.02.27.06l5.98 2.94c.1.05.2.13.25.23.06.1.08.21.08.33a18.7 18.7 0 01-.77 4.25c-1.02 3.33-2.89 5.67-5.55 6.96Z" transform="translate(0, 0)"></path></svg>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($top_group_info) && strtolower(trim($top_group_info['label'])) === 'tester'): ?>
                        <div class="wn tester" tabindex="0" title="Testing Department" data-tooltip-id="user-role-tooltip" data-tooltip-content="Testing Department" data-tooltip="Testing Department" data-tooltip-place="bottom">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 20 20"><path d="M6 2a1 1 0 010-2h8a1 1 0 010 2v5.66l4.5 7.3c1.3 2.13-.1 5.04-2.68 5.04H4.18C1.6 20 .2 17.09 1.5 14.97L6 7.66V2Zm2 0v5.94a1 1 0 01-.15.52L6.29 11h7.42l-1.56-2.54A1 1 0 0112 7.94V2H8Z" transform="translate(0, 0)"></path></svg>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($top_group_info) && strtolower(trim($top_group_info['label'])) === 'designer'): ?>
                        <div class="wn" tabindex="0" title="Design Department" data-tooltip-id="user-role-tooltip" data-tooltip-content="Design Department" data-tooltip="Design Department" data-tooltip-place="bottom" style="background-color: #f2b800;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 20 20"><path d="M13.6 7.4h-.01c.28-.27.28-.69 0-.97a.67.67 0 00-.96 0L4.37 14.7a.67.67 0 000 .96.63.63 0 00.48.2.62.62 0 00.48-.2L13.6 7.4ZM11.87 3.05a7.85 7.85 0 015.1 5.1L6.7 18.42c-.14.13-.21.2-.35.2L.85 20H.71c-.2 0-.34-.07-.49-.21a.56.56 0 01-.2-.62l1.4-5.51c.06-.14.13-.27.2-.34L11.87 3.06ZM20 4.72c0 .21-.07.48-.21.62L18.07 7.06c-.96-2.3-2.8-4.14-5.1-5.1L14.7.24a.56.56 0 01.62-.2A5.96 5.96 0 0120 4.7Z" transform="translate(0, 0)"></path></svg>
                        </div>
                        <?php endif; ?>
                        <?php if ($has_news_badge): ?>
                        <div class="wn" tabindex="0" title="News Department" data-tooltip-id="user-role-tooltip" data-tooltip-content="News Department" data-tooltip="News Department" data-tooltip-place="top">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 20 20"><path d="M18.21 3.57h-1.06v13.57a1.43 1.43 0 002.85 0V5.36a1.79 1.79 0 00-1.79-1.79Zm-2.5 13.57V1.8A1.79 1.79 0 0013.93 0H1.79A1.79 1.79 0 000 1.79V17.5A2.5 2.5 0 002.5 20h15.33l.01-.01.01-.02a.05.05 0 00-.03-.07 2.86 2.86 0 01-2.1-2.76ZM2.86 4.3a.71.71 0 01.71-.72h2.86a.71.71 0 01.71.72v2.85a.71.71 0 01-.71.72H3.57a.71.71 0 01-.71-.72V4.3Zm9.28 12.14H3.6a.73.73 0 01-.73-.68.71.71 0 01.71-.75h8.55c.39 0 .72.3.74.68a.71.71 0 01-.72.75Zm0-2.86H3.6a.73.73 0 01-.73-.68.71.71 0 01.71-.75h8.55c.39 0 .72.3.74.68a.71.71 0 01-.72.75Zm0-2.86H3.6a.73.73 0 01-.73-.68.71.71 0 01.71-.74h8.55c.39 0 .72.3.74.68a.71.71 0 01-.72.74Zm0-2.85H9.31a.73.73 0 01-.74-.68.71.71 0 01.72-.75h2.83c.39 0 .72.3.74.68a.71.71 0 01-.72.75Zm0-2.86H9.31a.73.73 0 01-.74-.68.71.71 0 01.72-.75h2.83c.39 0 .72.3.74.68a.71.71 0 01-.72.75Z" transform="translate(0, 0)"></path></svg>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($dc_url)): ?>
                    <div class="profile-overview-card user-social-links">
                        <a href="<?php echo esc_url($dc_url); ?>" class="social-link discord-link" target="_blank" rel="noopener noreferrer" title="Discord" aria-label="Discord">
                            <svg width="20" height="16" viewBox="0 0 127.14 96.36" fill="currentColor" aria-hidden="true"><path d="M107.7 8.07A105.15 105.15 0 0 0 81.47 0a72.06 72.06 0 0 0-3.36 6.83 97.68 97.68 0 0 0-29.11 0A72.37 72.37 0 0 0 45.64 0a105.89 105.89 0 0 0-26.25 8.09C2.79 32.65-1.71 56.6.54 80.21a105.73 105.73 0 0 0 32.17 16.15 77.7 77.7 0 0 0 6.89-11.11 68.42 68.42 0 0 1-10.85-5.18c.91-.66 1.8-1.34 2.66-2a75.57 75.57 0 0 0 64.32 0c.87.71 1.76 1.39 2.66 2a68.68 68.68 0 0 1-10.87 5.19 77 77 0 0 0 6.89 11.1 105.25 105.25 0 0 0 32.19-16.14c2.64-27.38-4.51-51.11-18.9-72.15zM42.45 65.69C36.18 65.69 31 60 31 53s5-12.74 11.43-12.74S54 46 53.89 53s-5.05 12.69-11.44 12.69zm42.24 0C78.41 65.69 73.25 60 73.25 53s5-12.74 11.44-12.74S96.23 46 96.12 53s-5.04 12.69-11.43 12.69z"/></svg>
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if ($verification_status === 'success'): ?>
                        <div class="profile-verification-message success">✅ Valid Discord verification link. Account confirmed.</div>
                    <?php elseif ($verification_status === 'invalid'): ?>
                        <div class="profile-verification-message error">⚠️ Invalid verification code. Check the link from Discord.</div>
                    <?php endif; ?>

                    <div class="profile-overview-card profile-days-online-card" aria-label="Days online on site">
                        <span class="days-online-count"><?php echo intval($days_online_count); ?></span>
                        <span class="days-online-label">Days online on site</span>
                    </div>

                    <div class="profile-overview-card activity-wrapper">
                        <div class="activity-grid" aria-label="Matrice activitate citire">
                            <?php foreach ($reading_activity as $day => $day_info): ?>
                                <?php
                                    $day_formatted = date('d.m.Y', strtotime($day));
                                    if ($day_info['count'] > 0) {
                                        $tooltip_text = $day_info['count'] . ' chapters read - ' . $day_formatted;
                                    } else {
                                        $tooltip_text = $day_formatted;
                                    }
                                ?>
                                <div class="activity-cell <?php echo esc_attr($day_info['class']); ?>" data-tooltip="<?php echo esc_attr($tooltip_text); ?>" title="<?php echo esc_attr($tooltip_text); ?>"></div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div> <!-- .profile-secondary-row -->
            </div> <!-- .profile-left -->

        </div> <!-- .header-content -->
    </div> <!-- .profile-header -->

    <?php
    $all_count = count($reading_manga) + count($planned_manga) + count($completed_manga) + count($paused_manga) + count($abandoned_manga);

    $fav_count = 0;
    if (is_array($bookmarked_manga)) {
        foreach ($bookmarked_manga as $mid) {
            if (get_post_status(intval($mid)) === 'publish') {
                $fav_count++;
            }
        }
    }

    $comments_count = get_comments([
        'user_id'   => $profile_user_id,
        'count'     => true,
        'post_type' => 'manga',
    ]);

    if ($is_owner) {
        $author_query = new WP_Query([
            'post_type'      => 'stire',
            'author'         => $profile_user_id,
            'post_status'    => ['publish', 'pending', 'draft', 'private'],
            'posts_per_page' => 10,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $meta_query = new WP_Query([
            'post_type'      => 'stire',
            'post_status'    => ['publish', 'pending', 'draft', 'private'],
            'posts_per_page' => 10,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [
                [
                    'key'     => '_stire_author_id',
                    'value'   => $profile_user_id,
                    'compare' => '=',
                ],
            ],
        ]);

        $stiri_ids = array_unique(array_merge(
            wp_list_pluck($author_query->posts, 'ID'),
            wp_list_pluck($meta_query->posts, 'ID')
        ));

        if (!empty($stiri_ids)) {
            $stiri_query = new WP_Query([
                'post_type'      => 'stire',
                'post__in'       => $stiri_ids,
                'post_status'    => ['publish', 'pending', 'draft', 'private'],
                'posts_per_page' => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);
            $stiri_count = count($stiri_ids);
        } else {
            $stiri_query = new WP_Query([
                'post_type'      => 'stire',
                'author'         => $profile_user_id,
                'post_status'    => ['publish', 'pending', 'draft', 'private'],
                'posts_per_page' => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);
            $stiri_count = (int) $stiri_query->found_posts;
        }
    } else {
        $author_query = new WP_Query([
            'post_type'      => 'stire',
            'author'         => $profile_user_id,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ]);

        $meta_query = new WP_Query([
            'post_type'      => 'stire',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'     => '_stire_author_id',
                    'value'   => $profile_user_id,
                    'compare' => '=',
                ],
            ],
        ]);

        $stiri_ids = array_unique(array_merge(
            (array) $author_query->posts,
            (array) $meta_query->posts
        ));

        if (!empty($stiri_ids)) {
            $stiri_query = new WP_Query([
                'post_type'      => 'stire',
                'post__in'       => $stiri_ids,
                'post_status'    => 'publish',
                'posts_per_page' => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);
            $stiri_count = count($stiri_ids);
        } else {
            $stiri_query = new WP_Query([
                'post_type'      => 'stire',
                'author'         => $profile_user_id,
                'post_status'    => 'publish',
                'posts_per_page' => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);
            $stiri_count = (int) $stiri_query->found_posts;
        }
    }

    $friends_count = 0;
    $profile_friends = get_user_meta($profile_user_id, 'friends', true);
    if (is_array($profile_friends)) {
        $friends_count = count($profile_friends);
    }
    ?>

    <div class="profile-dashboard-layout">
        <div class="profile-dashboard-main">

        <div class="profile-tabs profile-tabs--manga" data-section="all">
            <div class="manga-status-tabs" aria-label="Quick status filter">
                <button type="button" class="manga-status-tab active" data-status="reading">
                    Reading<?php echo count($reading_manga) > 0 ? ' (' . count($reading_manga) . ')' : ''; ?>
                </button>
                <button type="button" class="manga-status-tab" data-status="completed">
                    Completed<?php echo count($completed_manga) > 0 ? ' (' . count($completed_manga) . ')' : ''; ?>
                </button>
                <button type="button" class="manga-status-tab" data-status="paused">
                    Paused<?php echo count($paused_manga) > 0 ? ' (' . count($paused_manga) . ')' : ''; ?>
                </button>
                <button type="button" class="manga-status-tab" data-status="abandoned">
                    Dropped<?php echo count($abandoned_manga) > 0 ? ' (' . count($abandoned_manga) . ')' : ''; ?>
                </button>
                <button type="button" class="manga-status-tab" data-status="planned">
                    Planned<?php echo count($planned_manga) > 0 ? ' (' . count($planned_manga) . ')' : ''; ?>
                </button>
                <button type="button" class="manga-status-tab" data-status="favorites">
                    Favorites<?php echo $fav_count > 0 ? ' (' . $fav_count . ')' : ''; ?>
                </button>
            </div>
        </div>

        <div class="profile-tabs profile-tabs--section" data-section="comments" style="display:none">
            <span class="section-tab-label">Comments</span>
        </div>

        <div class="profile-tabs profile-tabs--section" data-section="social" style="display:none">
            <span class="section-tab-label">Friends</span>
        </div>

        <div class="profile-tabs profile-tabs--section" data-section="reviews" style="display:none">
            <span class="section-tab-label">Reviews</span>
        </div>

        <div class="profile-tabs profile-tabs--section" data-section="stiri" style="display:none">
            <span class="section-tab-label">News</span>
        </div>

        <div class="profile-tabs profile-tabs--section" data-section="translations" style="display:none; align-items:center;">
            <button type="button" class="tab-button active" data-translation-tab="in-progress">
                In progress<?php echo !empty($translator_manga_by_status['in_progress']) ? ' (' . count($translator_manga_by_status['in_progress']) . ')' : ''; ?>
            </button>
            <button type="button" class="tab-button" data-translation-tab="completed">
                Completed<?php echo !empty($translator_manga_by_status['completed']) ? ' (' . count($translator_manga_by_status['completed']) . ')' : ''; ?>
            </button>
            <button type="button" class="tab-button" data-translation-tab="abandoned">
                Dropped<?php echo !empty($translator_manga_by_status['abandoned']) ? ' (' . count($translator_manga_by_status['abandoned']) . ')' : ''; ?>
            </button>
        </div>

        <!-- Profile Content Tabs -->
        <div class="profile-content">

            <!-- Tab: My Translations -->
            <div class="profile-tab" id="translations-tab">
                <div class="translation-subtabs">
                    <div class="translation-subtab-content active" id="translations-in-progress">
                        <?php if (!empty($translator_manga_by_status['in_progress'])): ?>
                            <div class="manga-status-grid">
                                <?php foreach ($translator_manga_by_status['in_progress'] as $manga): ?>
                                    <div class="status-item" data-translation-date="<?php echo esc_attr(get_post_modified_time('U', false, $manga->ID)); ?>">
                                        <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="status-cover">
                                            <?php echo get_the_post_thumbnail($manga->ID, 'full') ?: '<div class="no-image">No image</div>'; ?>
                                        </a>
                                        <div class="manga-info">
                                            <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="cover-title"><?php echo esc_html(get_the_title($manga->ID)); ?></a>
                                            <div class="meta-label">In progress</div>
                                            <div class="translation-date">Updated: <?php echo esc_html(get_post_modified_time('d.m.Y', false, $manga->ID)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No in-progress translations" loading="lazy" decoding="async">
                                <h3>No in-progress translations</h3>
                                <p><?php echo $is_owner ? 'When you start a translation, it will appear here.' : 'This user has no translations in progress.'; ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="translation-subtab-content" id="translations-completed">
                        <?php if (!empty($translator_manga_by_status['completed'])): ?>
                            <div class="manga-status-grid">
                                <?php foreach ($translator_manga_by_status['completed'] as $manga): ?>
                                    <div class="status-item" data-translation-date="<?php echo esc_attr(get_post_modified_time('U', false, $manga->ID)); ?>">
                                        <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="status-cover">
                                            <?php echo get_the_post_thumbnail($manga->ID, 'full') ?: '<div class="no-image">No image</div>'; ?>
                                        </a>
                                        <div class="manga-info">
                                            <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="cover-title"><?php echo esc_html(get_the_title($manga->ID)); ?></a>
                                            <div class="meta-label">Completed</div>
                                            <div class="translation-date">Updated: <?php echo esc_html(get_post_modified_time('d.m.Y', false, $manga->ID)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No completed translations" loading="lazy" decoding="async">
                                <h3>No completed translations</h3>
                                <p><?php echo $is_owner ? 'Completed translations will appear here.' : 'This user has no completed translations.'; ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="translation-subtab-content" id="translations-abandoned">
                        <?php if (!empty($translator_manga_by_status['abandoned'])): ?>
                            <div class="manga-status-grid">
                                <?php foreach ($translator_manga_by_status['abandoned'] as $manga): ?>
                                    <div class="status-item" data-translation-date="<?php echo esc_attr(get_post_modified_time('U', false, $manga->ID)); ?>">
                                        <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="status-cover">
                                            <?php echo get_the_post_thumbnail($manga->ID, 'full') ?: '<div class="no-image">No image</div>'; ?>
                                        </a>
                                        <div class="manga-info">
                                            <a href="<?php echo esc_url(get_permalink($manga->ID)); ?>" class="cover-title"><?php echo esc_html(get_the_title($manga->ID)); ?></a>
                                            <div class="meta-label">Dropped</div>
                                            <div class="translation-date">Updated: <?php echo esc_html(get_post_modified_time('d.m.Y', false, $manga->ID)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No dropped translations" loading="lazy" decoding="async">
                                <h3>No dropped translations</h3>
                                <p><?php echo $is_owner ? 'Dropped translations will be listed here.' : 'This user has no dropped translations.'; ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Tab: All Manga List -->
            <div class="profile-tab" id="all-tab">
                <!-- Search & Filter Header -->
                <div class="manga-list-header">
                    <div class="manga-search-wrapper">
                        <input type="text" class="manga-search-input" placeholder="Search manga..." aria-label="Search manga by title" autocomplete="off">
                    </div>
                </div>

                <?php
                // Collect all manga from all status categories
                $all_manga = [];
                
                // Combine all manga IDs from all status arrays
                $all_manga_ids = array_merge($reading_manga, $planned_manga, $completed_manga, $paused_manga, $abandoned_manga);
                $all_manga_ids = array_unique($all_manga_ids);
                
                // Build data array with current status from database
                $unique_manga = [];
                $status_labels = ['reading' => 'Reading', 'planned' => 'Planned', 'completed' => 'Completed', 'paused' => 'Paused', 'abandoned' => 'Dropped'];
                
                foreach ($all_manga_ids as $manga_id) {
                    $manga_id = intval($manga_id);
                    $current_status = function_exists('mangayummy_get_manga_status') ? mangayummy_get_manga_status($profile_user_id, $manga_id) : '';
                    $current_status = $current_status ?: 'reading'; // fallback to reading if no status found
                    // determine viewer rating (same logic used elsewhere)
                    $viewer_id = get_current_user_id();
                    $rating_val = 0;
                    if ($viewer_id) {
                        // choose whose rating to show:
                        // owner sees their own rating (viewer); visitors see profile user's rating only
                        if ($viewer_id === $profile_user_id) {
                            // owner view: allow average fallback afterwards
                            $rating_val = get_user_meta($viewer_id, 'rating_' . $manga_id, true);
                            if (!$rating_val) {
                                $rating_val = get_user_meta($viewer_id, 'manga_rated_' . $manga_id, true);
                            }
                        } else {
                            // visitor view: show only profile user's stored rating, no fallback
                            $rating_val = get_user_meta($profile_user_id, 'rating_' . $manga_id, true);
                            if (!$rating_val) {
                                $rating_val = get_user_meta($profile_user_id, 'manga_rated_' . $manga_id, true);
                            }
                        }
                    }
                    // if still no personal rating and viewer is owner, use manga's average
                    if (!$rating_val && $viewer_id === $profile_user_id) {
                        $rating_val = floatval(get_post_meta($manga_id, '_rating_avg', true));
                    }
                    $rating_val = floatval($rating_val);
                    
                    $unique_manga[] = [
                        'id' => $manga_id,
                        'status' => $current_status,
                        'label' => isset($status_labels[$current_status]) ? $status_labels[$current_status] : 'Reading',
                        'rating' => $rating_val,
                    ];
                }
                // sort by status (reading, completed, planned, paused, abandoned) then by rating desc
                $order = ['reading','completed','planned','paused','abandoned'];
                usort($unique_manga, function($a, $b) use ($order) {
                    $ia = array_search($a['status'], $order);
                    $ib = array_search($b['status'], $order);
                    if ($ia !== $ib) {
                        return $ia < $ib ? -1 : 1;
                    }
                    if ($a['rating'] == $b['rating']) return 0;
                    return ($a['rating'] > $b['rating']) ? -1 : 1;
                });
                
                if (!empty($unique_manga)): 
                    $last_status = null;
                    foreach ($unique_manga as $manga_data): 
                        // when entering new status group, close previous grid and open new one
                        if ($manga_data['status'] !== $last_status) {
                            if ($last_status !== null) {
                                echo '</div>'; // close previous grid
                            }
                            $label_text = strtoupper($manga_data['label']);
                            echo "<h1 class=\"status-group-title\">{$label_text}</h1>";
                            echo '<div class="manga-status-grid">';
                            $last_status = $manga_data['status'];
                        }
                        $manga_id = $manga_data['id'];
                        $manga = get_post($manga_id); 
                        if (!$manga || $manga->post_status !== 'publish') {
                            // log skipped ID for debugging
                                continue;
                        }
                        // calculate reading progress and rating badge
                            $user_progress = mangayummy_get_manga_progress($profile_user_id, $manga_id);
                            $viewer_id = get_current_user_id();
                            $user_rating = '';
                            if ($viewer_id && $viewer_id === $profile_user_id) {
                                // owner view: show their rating or later fallback
                                $user_rating = get_user_meta($viewer_id, 'rating_' . $manga_id, true);
                                if (!$user_rating) {
                                    $user_rating = get_user_meta($viewer_id, 'manga_rated_' . $manga_id, true);
                                }
                                if (!$user_rating) {
                                    $user_rating = floatval(get_post_meta($manga_id, '_rating_avg', true));
                                }
                            } else {
                                // visitor view: show profile owner's stored rating only
                                $user_rating = get_user_meta($profile_user_id, 'rating_' . $manga_id, true);
                                if (!$user_rating) {
                                    $user_rating = get_user_meta($profile_user_id, 'manga_rated_' . $manga_id, true);
                                }
                                // no average fallback so unrated remains blank/0
                            }
                            if ($manga && $manga->post_status === 'publish'): ?>
                            <div class="status-item" data-manga-id="<?php echo intval($manga_id); ?>" data-current-status="<?php echo esc_attr(function_exists('mangayummy_get_manga_status') ? mangayummy_get_manga_status($profile_user_id, $manga_id) : ''); ?>"}>
                                <div class="status-cover-wrapper">
                                    <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" class="status-cover">
                                        <?php echo get_the_post_thumbnail($manga_id, 'full') ?: '<div class="no-image">No image</div>'; ?>
                                    </a>
                                    <!-- overlay title on cover -->
                                    <a class="cover-title" href="<?php echo esc_url(get_permalink($manga_id)); ?>"><?php echo esc_html(get_the_title($manga_id)); ?></a>
                                    <!-- rating/progress badges -->
                                    <div class="cover-overlay">
                                        <?php // show rating; for visitors only display if a personal value exists (owner sees average if unrated) ?>
                                        <div class="cover-rating<?php echo $is_owner ? ' editable' : ''; ?>" data-manga-id="<?php echo intval($manga_id); ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="#13667a" style="vertical-align:middle; margin-right:2px;"><path d="M12 .587l3.668 7.431 8.2 1.193-5.934 5.783 1.4 8.171L12 18.897l-7.334 3.868 1.4-8.171L.132 9.211l8.2-1.193z"/></svg>
                                            <?php
                                            if (!$is_owner && empty($user_rating)) {
                                                // visitor and no rating: leave blank
                                                echo '';
                                            } else {
                                                $rating_val = floatval($user_rating ?: 0);
                                                if ($rating_val == 0) {
                                                    echo '0';
                                                } else {
                                                    // drop decimal when whole number
                                                    if (floor($rating_val) == $rating_val) {
                                                        echo intval($rating_val);
                                                    } else {
                                                        echo number_format($rating_val, 1, '.', '');
                                                    }
                                                }
                                            }
                                            ?></div>
                                        <?php 
                                            // determine total chapters and whether to show badge
                                            $total_chapters = get_post_meta($manga_id, '_final_chapter', true);
                                            $total_chapters = $total_chapters ? intval($total_chapters) : 0;
                                            $post_finished = get_post_meta($manga_id, '_status', true) === 'completed';
                                            $show_progress = ($user_progress > 0) || ($total_chapters > 0 && $post_finished);
                                            if ($show_progress):
                                                if ($user_progress > 0) {
                                                    if ($total_chapters > 0) {
                                                        $badge_text = intval($user_progress) . '/' . $total_chapters;
                                                    } else {
                                                        $badge_text = intval($user_progress);
                                                    }
                                                } else {
                                                    $badge_text = '0/' . $total_chapters;
                                                }
                                        ?>
                                            <div class="cover-progress<?php echo $is_owner ? ' editable' : ''; ?>" data-manga-id="<?php echo intval($manga_id); ?>" data-total-chapters="<?php echo $total_chapters; ?>"><?php echo esc_html($badge_text); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($is_owner): ?>
                                    <div class="manga-actions">
                                        <button class="manga-actions-toggle" aria-haspopup="true" aria-expanded="false">⋯</button>
                                        <ul class="manga-actions-menu" role="menu">
                                            <li class="manga-action" data-status="reading">Reading</li>
                                            <li class="manga-action" data-status="planned">Planned</li>
                                            <li class="manga-action" data-status="completed">Completed</li>
                                            <li class="manga-action" data-status="paused">Paused</li>
                                            <li class="manga-action" data-status="abandoned">Dropped</li>
                                            <li class="manga-action manga-action-remove" data-status="remove">Remove</li>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="manga-info">
                                    <!-- title moved into cover overlay -->
                                    <?php 
                                    // progress removed per user request
                                    $user_progress = mangayummy_get_manga_progress($profile_user_id, $manga_id);
                                    $total_chapters = get_post_meta($manga_id, '_final_chapter', true);
                                    $total_chapters = $total_chapters ? floatval($total_chapters) : 0;
                                    ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <?php if (!empty($profile_friends)): ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No manga" loading="lazy" decoding="async">
                            <h3>You have no manga in any list</h3>
                            <p>Your friends can appear here until you start adding manga.</p>
                            <div class="friends-list friends-list-inline">
                                <?php foreach ($profile_friends as $friend_id):
                                    $friend = get_user_by('ID', $friend_id);
                                    if (!$friend) continue;
                                    $friend_avatar = get_user_meta($friend_id, 'profile_avatar', true);
                                    if (!$friend_avatar) {
                                        $friend_avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                                    }
                                ?>
                                    <a href="<?php echo esc_url(home_url('/profile/?view_user=' . $friend_id)); ?>" class="friend-item friend-item-inline">
                                        <img src="<?php echo esc_url($friend_avatar); ?>" alt="<?php echo esc_attr($friend->display_name); ?>" class="friend-avatar" loading="lazy" decoding="async">
                                        <span><?php echo esc_html($friend->display_name); ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No manga" loading="lazy" decoding="async">
                            <h3>You have no manga in any list</h3>
                            <p>Start exploring and organizing your collection!</p>
                            <a href="<?php echo home_url(); ?>" class="btn-primary">Explore Manga</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Tab: Favorite Manga -->
            <div class="profile-tab" id="favorites-tab">
                <?php if (!empty($bookmarked_manga) && is_array($bookmarked_manga)): 
                    // Prepare favorites data with proper status
                    $status_labels = [
                        'reading' => 'Reading',
                        'planned' => 'Planned',
                        'completed' => 'Completed',
                        'paused' => 'Paused',
                        'abandoned' => 'Dropped'
                    ];
                    
                    $favorites_data = [];
                    foreach ($bookmarked_manga as $manga_id) {
                        $manga_id = intval($manga_id);
                        $manga = get_post($manga_id);
                        $pub = $manga ? $manga->post_status : '(none)';
                        if ($manga && $manga->post_status === 'publish') {
                            $current_status = function_exists('mangayummy_get_manga_status') 
                                ? mangayummy_get_manga_status($profile_user_id, $manga_id) 
                                : '';
                            $status = $current_status ?: 'reading';
                            $favorites_data[] = [
                                'id' => $manga_id,
                                'status' => $status,
                                'label' => isset($status_labels[$status]) ? $status_labels[$status] : 'Reading'
                            ];
                        } else {
                        }
                    }
                    
                    if (!empty($favorites_data)): ?>
                        <div class="manga-status-grid">
                            <?php foreach ($favorites_data as $manga_data): 
                                $manga_id = $manga_data['id'];
                                $manga = get_post($manga_id); 
                                if ($manga && $manga->post_status === 'publish'): ?>
                                <div class="status-item" data-manga-id="<?php echo intval($manga_id); ?>" data-current-status="<?php echo esc_attr(function_exists('mangayummy_get_manga_status') ? mangayummy_get_manga_status($profile_user_id, $manga_id) : ''); ?>">
                                    <div class="status-cover-wrapper">
                                        <a href="<?php echo esc_url(get_permalink($manga_id)); ?>" class="status-cover">
                                            <?php echo get_the_post_thumbnail($manga_id, 'full') ?: '<div class="no-image">No image</div>'; ?>
                                        </a>
                                        <!-- overlay title + badges for favorites too -->
                                        <a class="cover-title" href="<?php echo esc_url(get_permalink($manga_id)); ?>"><?php echo esc_html(get_the_title($manga_id)); ?></a>
                                        <div class="cover-overlay">
                                            <?php // rating in favorites (same logic as main list) ?>
                                            <div class="cover-rating">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="#13667a" style="vertical-align:middle; margin-right:2px;"><path d="M12 .587l3.668 7.431 8.2 1.193-5.934 5.783 1.4 8.171L12 18.897l-7.334 3.868 1.4-8.171L.132 9.211l8.2-1.193z"/></svg>
                                                <?php
                                                // calculate rating for each item like main section
                                                $viewer_id = get_current_user_id();
                                                $user_rating = '';
                                                if ($viewer_id && $viewer_id === $profile_user_id) {
                                                    $user_rating = get_user_meta($viewer_id, 'rating_' . $manga_id, true);
                                                    if (!$user_rating) {
                                                        $user_rating = get_user_meta($viewer_id, 'manga_rated_' . $manga_id, true);
                                                    }
                                                    if (!$user_rating) {
                                                        $user_rating = floatval(get_post_meta($manga_id, '_rating_avg', true));
                                                    }
                                                } else {
                                                    $user_rating = get_user_meta($profile_user_id, 'rating_' . $manga_id, true);
                                                    if (!$user_rating) {
                                                        $user_rating = get_user_meta($profile_user_id, 'manga_rated_' . $manga_id, true);
                                                    }
                                                    // visitor: no fallback to average
                                                }
                                                if (!($viewer_id && $viewer_id !== $profile_user_id && empty($user_rating))) {
                                                    $rating_val = floatval($user_rating ?: 0);
                                                    if ($rating_val == 0) {
                                                        echo '0';
                                                    } else {
                                                        if (floor($rating_val) == $rating_val) {
                                                            echo intval($rating_val);
                                                        } else {
                                                            echo number_format($rating_val, 1, '.', '');
                                                        }
                                                    }
                                                } // else visitor & unrated: skip output
                                                ?></div>
                                            <?php 
                                                $total_chapters = get_post_meta($manga_id, '_final_chapter', true);
                                                $total_chapters = $total_chapters ? intval($total_chapters) : 0;
                                                $post_finished = get_post_meta($manga_id, '_status', true) === 'completed';
                                                $show_progress = ($user_progress > 0) || ($total_chapters > 0 && $post_finished);
                                                if ($show_progress):
                                                    if ($user_progress > 0) {
                                                        if ($total_chapters > 0) {
                                                            $badge_text = intval($user_progress) . '/' . $total_chapters;
                                                        } else {
                                                            $badge_text = intval($user_progress);
                                                        }
                                                    } else {
                                                        $badge_text = '0/' . $total_chapters;
                                                    }
                                            ?>
                                                <div class="cover-progress<?php echo $is_owner ? ' editable' : ''; ?>" data-manga-id="<?php echo intval($manga_id); ?>" data-total-chapters="<?php echo $total_chapters; ?>"><?php echo esc_html($badge_text); ?></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($is_owner): ?>
                                        <div class="manga-actions">
                                            <button class="manga-actions-toggle" aria-haspopup="true" aria-expanded="false">⋯</button>
                                            <ul class="manga-actions-menu" role="menu">
                                                <li class="manga-action" data-status="reading">Reading</li>
                                                <li class="manga-action" data-status="planned">Planned</li>
                                                <li class="manga-action" data-status="completed">Completed</li>
                                                <li class="manga-action" data-status="paused">Paused</li>
                                                <li class="manga-action" data-status="abandoned">Dropped</li>
                                                <li class="manga-action manga-action-remove" data-status="remove">Remove</li>
                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="manga-info">
                                        <h3><?php echo esc_html(get_the_title($manga_id)); ?></h3>
                                        <?php 
                                        // progress removed from favorites list as well
                                        $user_progress = mangayummy_get_manga_progress($profile_user_id, $manga_id);
                                        $total_chapters = get_post_meta($manga_id, '_final_chapter', true);
                                        $total_chapters = $total_chapters ? floatval($total_chapters) : 0;
                                        ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No favorite manga" loading="lazy" decoding="async">
                            <h3>You have no favorites</h3>
                            <p>Explore manga and add them to favorites!</p>
                            <a href="<?php echo home_url(); ?>" class="btn-primary">Explore Manga</a>
                        </div>
                    <?php endif;
                else: ?>
                    <div class="empty-state">
                        <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No favorite manga" loading="lazy" decoding="async">
                        <h3>You have no favorites</h3>
                        <p>Explore manga and add them to favorites!</p>
                        <a href="<?php echo home_url(); ?>" class="btn-primary">Explore Manga</a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Tab: Social -->
            <div class="profile-tab" id="social-tab">
                <?php if ($is_owner): ?>
                
                <!-- Search Section (ABOVE friends) -->
                <div class="search-section">
                    <h3>Search users</h3>
                    <input id="social-search" placeholder="Search users..." autocomplete="off">
                </div>

                <div id="social-results"></div>

                <!-- Friends List Section -->
                <div class="friends-section">
                    <h3>My friends</h3>
                    <?php 
                    $friends = get_user_meta($profile_user_id, 'friends', true);
                    if (!is_array($friends)) {
                        $friends = [];
                    }

                    if (!empty($friends)): ?>
                        <div class="friends-list">
                            <?php foreach ($friends as $friend_id): 
                                $friend = get_user_by('ID', $friend_id);
                                if (!$friend) continue;
                                $friend_avatar = get_user_meta($friend_id, 'profile_avatar', true);
                                if (!$friend_avatar) {
                                    $friend_avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                                }
                                $friend_level = get_user_meta($friend_id, 'reader_level', true) ?: 1;
                                list($friend_status, $friend_text) = mangayummy_user_status($friend_id);
                                ?>
                                <div class="friend-item">
                                    <img src="<?php echo esc_url($friend_avatar); ?>" alt="<?php echo esc_attr($friend->display_name); ?>" class="friend-avatar" loading="lazy" decoding="async">
                                    <div class="friend-info">
                                        <a href="<?php echo esc_url(home_url('/profile/?view_user=' . $friend_id)); ?>">
                                            <strong><?php echo esc_html($friend->display_name); ?></strong>
                                        </a>
                                        <small class="user-status <?php echo esc_attr($friend_status); ?>">Lv.<?php echo intval($friend_level); ?> • <?php echo esc_html($friend_text); ?></small>
                                    </div>
                                    <div class="friend-actions">
                                        <button class="message-friend-btn" data-user-id="<?php echo intval($friend_id); ?>" title="Send message">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
</button>
                                        <button class="delete-friend-btn" data-user-id="<?php echo intval($friend_id); ?>" title="Remove friend">✕</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No friends" loading="lazy" decoding="async">
                            <h3>You have no friends</h3>
                            <p>Add new friends!</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <!-- Friends List Section for Visitors -->
                <div class="friends-section">
                    <h3>User's friends</h3>
                    <?php 
                    $friends = get_user_meta($profile_user_id, 'friends', true);
                    if (!is_array($friends)) {
                        $friends = [];
                    }

                    if (!empty($friends)): ?>
                        <div class="friends-list">
                            <?php foreach ($friends as $friend_id): 
                                $friend = get_user_by('ID', $friend_id);
                                if (!$friend) continue;
                                $friend_avatar = get_user_meta($friend_id, 'profile_avatar', true);
                                if (!$friend_avatar) {
                                    $friend_avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
                                }
                                $friend_level = get_user_meta($friend_id, 'reader_level', true) ?: 1;
                                list($friend_status, $friend_text) = mangayummy_user_status($friend_id);
                                ?>
                                <div class="friend-item">
                                    <img src="<?php echo esc_url($friend_avatar); ?>" alt="<?php echo esc_attr($friend->display_name); ?>" class="friend-avatar" loading="lazy" decoding="async">
                                    <div class="friend-info">
                                        <a href="<?php echo esc_url(home_url('/profile/?view_user=' . $friend_id)); ?>">
                                            <strong><?php echo esc_html($friend->display_name); ?></strong>
                                        </a>
                                        <small class="user-status <?php echo esc_attr($friend_status); ?>">Lv.<?php echo intval($friend_level); ?> • <?php echo esc_html($friend_text); ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No friends" loading="lazy" decoding="async">
                            <h3>No friends yet</h3>
                            <p>This user has not added any friends yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Tab: Comments -->
            <div class="profile-tab" id="comments-tab">
                <div class="comments-section">
                    <?php
                    $user_comments = get_comments(array(
                        'user_id'   => $profile_user_id,
                        'number'    => 20,
                        'orderby'   => 'comment_date',
                        'order'     => 'DESC',
                        'status'    => 'approve',
                        'post_type' => 'manga',
                    ));

                    if (!empty($user_comments)): ?>
                        <div class="comments-list">
                            <?php foreach ($user_comments as $comment):
                                $post_obj    = get_post($comment->comment_post_ID);
                                $post_type   = get_post_type($comment->comment_post_ID);
                                $post_title  = get_the_title($comment->comment_post_ID);
                                $post_link   = get_permalink($comment->comment_post_ID);
                                $c_time      = date('H:i', strtotime($comment->comment_date));
                                $c_likes     = (int) get_comment_meta($comment->comment_ID, 'likes', true);
                                $c_dislikes  = (int) get_comment_meta($comment->comment_ID, 'dislikes', true);

                                // Current user's existing reaction
                                $c_user_react = '';
                                if (is_user_logged_in()) {
                                    $c_user_react = get_user_meta(get_current_user_id(), 'reacted_' . $comment->comment_ID, true) ?: '';
                                }

                                // Thumbnail: manga or parent manga of chapter
                                $post_thumb = '';
                                if ($post_type === 'manga') {
                                    $post_thumb = get_the_post_thumbnail($post_obj->ID, 'thumbnail');
                                } elseif ($post_type === 'chapter') {
                                    $manga_id = get_post_meta($post_obj->ID, '_manga_id', true);
                                    if ($manga_id) {
                                        $post_thumb = get_the_post_thumbnail($manga_id, 'thumbnail');
                                    }
                                }

                                // Highlight @mentions in comment text
                                $c_content = wp_kses_post($comment->comment_content);
                                $c_content = preg_replace('/@(\w+)/', '<span class="comment-mention">@$1</span>', $c_content);
                                ?>
                                <div class="comment-item" data-comment-id="<?php echo intval($comment->comment_ID); ?>">
                                    <div class="comment-thumb<?php echo $post_thumb ? '' : ' comment-thumb-empty'; ?>">
                                        <?php echo $post_thumb; ?>
                                    </div>
                                    <div class="comment-body">
                                        <div class="comment-header">
                                            <a href="<?php echo esc_url($post_link); ?>" class="comment-post-title">
                                                <?php echo esc_html($post_title); ?>
                                            </a>
                                            <span class="comment-date"><?php echo esc_html($c_time); ?></span>
                                        </div>
                                        <div class="comment-reactions">
                                            <button type="button" class="comment-react-btn comment-react-btn--like<?php echo $c_user_react === 'like' ? ' active' : ''; ?>" data-reaction="like" title="Like">
                                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z"/><path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"/></svg>
                                                <span class="react-count"><?php echo $c_likes; ?></span>
                                            </button>
                                            <button type="button" class="comment-react-btn comment-react-btn--dislike<?php echo $c_user_react === 'dislike' ? ' active' : ''; ?>" data-reaction="dislike" title="Dislike">
                                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3H10z"/><path d="M17 2h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17"/></svg>
                                                <span class="react-count"><?php echo $c_dislikes; ?></span>
                                            </button>
                                        </div>
                                        <div class="comment-content">
                                            <a href="<?php echo esc_url($post_link . '#comment-' . $comment->comment_ID); ?>" class="comment-content-link">
                                                <?php echo $c_content; ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No comments" loading="lazy" decoding="async">
                            <h3>No comments</h3>
                            <p><?php echo $is_owner ? 'You have not posted any comments yet.' : 'This user has not posted any comments yet.'; ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tab: News -->
            <div class="profile-tab" id="stiri-tab">
                <div class="profile-news-section">
                    <?php if ($stiri_query->have_posts()): ?>
                        <div class="news-grid">
                            <?php while ($stiri_query->have_posts()): $stiri_query->the_post();
                                $post_id = get_the_ID();
                                $thumb = get_the_post_thumbnail_url($post_id, 'large');
                                if (!$thumb) {
                                    $thumb = get_post_meta($post_id, '_stire_cover_url', true);
                                }
                                if (!$thumb) {
                                    $thumb = get_template_directory_uri() . '/assets/img/default-manga.jpg';
                                }
                                $terms = get_the_terms($post_id, 'stiri_category');
                                $term_label = '';
                                if ($terms && !is_wp_error($terms)) {
                                    $term_label = strtoupper($terms[0]->name);
                                }
                                $excerpt = get_the_excerpt();
                                if (!$excerpt) {
                                    $excerpt = wp_trim_words(get_the_content(), 24, '...');
                                }
                            ?>
                                <?php $post_status = get_post_status();
                                $current_user_id = get_current_user_id();
                                $post_author_id = intval(get_post_field('post_author', $post_id));
                                $stire_author_id = intval(get_post_meta($post_id, '_stire_author_id', true));
                                $can_edit_stire = mangayummy_user_can_edit_stire($post_id);
                                $edit_link = $can_edit_stire ? home_url('/news/create?post_id=' . $post_id) : '';
                                ?>
                                <div class="news-card">
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="news-card-link">
                                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                        <div class="news-card-body">
                                            <span class="news-chip"><?php echo esc_html($term_label ?: 'News'); ?></span>
                                            <h2 class="news-card-title"><?php echo esc_html(get_the_title()); ?></h2>
                                            <?php if ($post_status === 'pending'): ?>
                                                <div class="news-card-status">Pending approval</div>
                                            <?php endif; ?>
                                            <p class="news-card-excerpt"><?php echo esc_html($excerpt); ?></p>
                                            <?php
                                            $author_id = $post_author_id;
                                            if (!$author_id) {
                                                $author_id = $stire_author_id;
                                            }
                                            $author_name = $author_id ? get_the_author_meta('display_name', $author_id) : get_the_author();
                                            $author_avatar_url = $author_id ? get_user_meta($author_id, 'profile_avatar', true) : '';
                                            if (!$author_avatar_url) {
                                                $author_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
                                            }
                                            $author_avatar = $author_id ? '<img src="' . esc_url($author_avatar_url) . '" class="news-author-avatar" style="width:16px;height:16px;" width="16" height="16" alt="' . esc_attr($author_name) . '" />' : '';
                                            $profile_url = $author_id ? add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $author_id), home_url('/')) : '';
                                            ?>
                                            <div class="news-card-meta"><span class="news-card-author" data-profile-url="<?php echo esc_url($profile_url); ?>"><?php echo $author_avatar; ?><strong><?php echo esc_html($author_name); ?></strong></span><span><?php echo esc_html(get_the_date('j F Y')); ?></span></div>
                                        </div>
                                    </a>
                                    <?php if ($edit_link): ?>
                                        <a href="<?php echo esc_url($edit_link); ?>" class="news-card-edit-button" target="_blank" rel="noopener noreferrer">Edit</a>
                                    <?php endif; ?>
                                </div>
                            <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No news" loading="lazy" decoding="async">
                            <h3>No news published yet</h3>
                            <p><?php echo $is_owner ? 'Your published news will appear here.' : 'This user has not published any news yet.'; ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tab: Recenzii (chapter comments) -->
            <div class="profile-tab" id="reviews-tab">
                <div class="comments-section">
                    <?php
                    $chapter_comments = get_comments(array(
                        'user_id'   => $profile_user_id,
                        'number'    => 20,
                        'orderby'   => 'comment_date',
                        'order'     => 'DESC',
                        'status'    => 'approve',
                        'post_type' => 'chapter',
                    ));

                    if (!empty($chapter_comments)): ?>
                        <div class="comments-list">
                            <?php foreach ($chapter_comments as $comment):
                                $post_obj     = get_post($comment->comment_post_ID);
                                $post_title   = get_the_title($comment->comment_post_ID);
                                $post_link    = get_permalink($comment->comment_post_ID);
                                $c_time       = date('H:i', strtotime($comment->comment_date));
                                $c_likes      = (int) get_comment_meta($comment->comment_ID, 'likes', true);
                                $c_dislikes   = (int) get_comment_meta($comment->comment_ID, 'dislikes', true);

                                $c_user_react = '';
                                if (is_user_logged_in()) {
                                    $c_user_react = get_user_meta(get_current_user_id(), 'reacted_' . $comment->comment_ID, true) ?: '';
                                }

                                $manga_id   = get_post_meta($post_obj->ID, '_manga_id', true);
                                $post_thumb = $manga_id ? get_the_post_thumbnail($manga_id, 'thumbnail') : '';

                                $c_content = wp_kses_post($comment->comment_content);
                                $c_content = preg_replace('/@(\w+)/', '<span class="comment-mention">@$1</span>', $c_content);
                                ?>
                                <div class="comment-item" data-comment-id="<?php echo intval($comment->comment_ID); ?>">
                                    <div class="comment-thumb<?php echo $post_thumb ? '' : ' comment-thumb-empty'; ?>">
                                        <?php echo $post_thumb; ?>
                                    </div>
                                    <div class="comment-body">
                                        <div class="comment-header">
                                            <a href="<?php echo esc_url($post_link); ?>" class="comment-post-title">
                                                <?php echo esc_html($post_title); ?>
                                            </a>
                                            <span class="comment-date"><?php echo esc_html($c_time); ?></span>
                                        </div>
                                        <div class="comment-reactions">
                                            <button type="button" class="comment-react-btn comment-react-btn--like<?php echo $c_user_react === 'like' ? ' active' : ''; ?>" data-reaction="like" title="Like">
                                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z"/><path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"/></svg>
                                                <span class="react-count"><?php echo $c_likes; ?></span>
                                            </button>
                                            <button type="button" class="comment-react-btn comment-react-btn--dislike<?php echo $c_user_react === 'dislike' ? ' active' : ''; ?>" data-reaction="dislike" title="Dislike">
                                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3H10z"/><path d="M17 2h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17"/></svg>
                                                <span class="react-count"><?php echo $c_dislikes; ?></span>
                                            </button>
                                        </div>
                                        <div class="comment-content">
                                            <a href="<?php echo esc_url($post_link . '#comment-' . $comment->comment_ID); ?>" class="comment-content-link">
                                                <?php echo $c_content; ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <img class="empty-state-image" src="<?php echo get_template_directory_uri(); ?>/assets/img/ayoo.avif" alt="No reviews" loading="lazy" decoding="async">
                            <h3>No reviews</h3>
                            <p><?php echo $is_owner ? 'You have not posted any chapter comments yet.' : 'This user has not posted any chapter comments yet.'; ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        </div>
        <aside class="profile-side-panel" aria-label="Profile quick stats">
            <?php $translator_total = count($translator_manga_items); ?>
            <button type="button" class="profile-side-tab" data-tab="translations">
                <span class="side-tab-label">My Translations</span>
                <span class="side-tab-count"><?php echo intval($translator_total); ?></span>
            </button>
            <button type="button" class="profile-side-tab" data-tab="all">
                <span class="side-tab-label">Manga List</span>
                <span class="side-tab-count"><?php echo intval($all_count); ?></span>
            </button>
            <button type="button" class="profile-side-tab" data-tab="social">
                <span class="side-tab-label">Friends</span>
                <span class="side-tab-count"><?php echo intval($friends_count); ?></span>
            </button>
            <button type="button" class="profile-side-tab" data-tab="stiri">
                <span class="side-tab-label">News</span>
                <span class="side-tab-count"><?php echo $stiri_count; ?></span>
            </button>
            <button type="button" class="profile-side-tab" data-tab="reviews">
                <span class="side-tab-label">Reviews</span>
                <span class="side-tab-count"><?php echo (int) get_comments(['user_id' => $profile_user_id, 'count' => true, 'post_type' => 'chapter']); ?></span>
            </button>
            <button type="button" class="profile-side-tab" data-tab="comments">
                <span class="side-tab-label">Comments</span>
                <span class="side-tab-count"><?php echo intval($comments_count); ?></span>
            </button>

        </aside>
    </div>

    </div>
</main>

<style>
/* recent comments thumbnail styling */
.comment-item {
    display: flex;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #2a2a2a;
}
.comment-thumb img {
    width: 78px;
    height: 78px;
    
    border-radius: 4px;
}
@media (max-width: 768px) {
    .comment-thumb img {
        width: 120px;
        height: 120px;
    }
}
.comment-body {
    flex: 1;
}
.comment-header {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    font-size: 14px;
}
@media (max-width: 768px) {
    /* make header items align top on small screens so text isn't vertically centered to large thumbnails */
    .comment-header {
        align-items: flex-start;
    }
}
.comment-header .comment-date {
    margin-left: auto;
    margin-right: 10px; 
    padding-left: 8px;
}
.comment-post-title {
    font-weight: 600;
    color: #fff;
    /* one‑line ellipsis on desktop */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.4;
    max-height: 1.4em;
}
@media (max-width: 768px) {
    .comment-post-title {
        /* allow two lines on mobile */
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        max-height: calc(1.4em * 2);
        white-space: normal;
    }
}
.comment-date {
    color: #999;
    font-size: 12px;
}

.recent-progress {
    margin: 5px 0 3px 0;
    color: #13667a;
    font-size: 13px;
}

.recent-time {
    margin: 3px 0 0 0;
    color: #888;
    font-size: 11px;
}

.no-recent-activity {
    text-align: center;
    color: #888;
    padding: 20px;
    font-size: 14px;
}
    .translation-subtabs {
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }

    .translation-subtabs .tab-button {
        border: 1px solid #2a2a2a;
        background: #111;
        color: #fff;
        padding: 10px 16px;
        border-radius: 10px;
        cursor: pointer;
    }

    .translation-subtabs .tab-button.active {
        background: #13667a;
        color: #0a0a0a;
        border-color: transparent;
    }

    .translation-subtab-content {
        display: none;
    }

    .translation-subtab-content.active {
        display: block;
    }

    .translation-subtab-content .empty-state {
        text-align: center;
        padding: 40px 20px;
    }

    .translation-subtab-content .empty-state h3,
    .translation-subtab-content .empty-state p {
        margin-left: auto;
        margin-right: auto;
        max-width: 520px;
    }

    .empty-state-image {
        max-width: 40vw;
        max-height: 27vh;
        background-color: transparent;
    }

    .profile-news-list {
        display: grid;
        gap: 14px;
    }

    .profile-news-item {
        display: block;
        padding: 18px;
        background: #111;
        border: 1px solid #222;
        border-radius: 16px;
        color: #fff;
        text-decoration: none;
        transition: border-color 0.2s ease, transform 0.2s ease;
    }

    .profile-news-item:hover,
    .profile-news-item:focus-visible {
        border-color: #13667a;
        transform: translateY(-1px);
    }

    .profile-news-item-main {
        margin-bottom: 10px;
    }

    .profile-news-item-title {
        margin: 0 0 6px;
        font-size: 1rem;
        line-height: 1.3;
    }

    .profile-news-item-excerpt {
        margin: 0;
        color: #ccc;
        font-size: 0.95rem;
        line-height: 1.5;
    }

    .profile-news-item-meta {
        color: #999;
        font-size: 0.84rem;
    }

    .news-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 24px;
        margin-top: 24px;
    }
    @media (max-width: 768px) {
        .news-grid {
            grid-template-columns: 1fr;
        }
    }
    .news-card {
        position: relative;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 16px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        min-height: 420px;
    }
    .news-card-link {
        display: flex;
        flex-direction: column;
        min-height: 100%;
        color: inherit;
        text-decoration: none;
    }
    .news-card img {
        width: 100%;
        height: 220px;
        object-fit: cover;
        display: block;
    }
    .news-card-body {
        padding: 18px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex: 1;
    }
    .news-card,
    .news-card * {
        text-decoration: none !important;
    }
    .news-card-title {
        font-size: 1.15rem;
        color: #fff;
        margin: 0;
        font-weight: 700;
    }
    .news-card-excerpt {
        color: #ddd;
        font-size: 0.98rem;
        line-height: 1.6;
        flex: 1;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        min-height: calc(1.6em * 3);
    }
    .news-card-meta {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        align-items: center;
        color: #aaa;
        font-size: 0.95rem;
    }
    .news-card-author {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
    }
    .news-author-avatar {
        width: 16px;
        height: 16px;
        border-radius: 50%;
        object-fit: cover;
        display: inline-block;
    }
    .news-card-edit-button {
        position: absolute;
        top: 16px;
        right: 16px;
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.15);
        color: #ffffff;
        padding: 8px 12px;
        border-radius: 12px;
        font-size: 0.85rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        z-index: 10;
        transition: background 0.2s ease, border-color 0.2s ease;
    }
    .news-card-edit-button:hover {
        background: rgba(255, 255, 255, 0.14);
        border-color: rgba(255, 255, 255, 0.25);
    }
    .news-card-author span {
        display: inline-block;
        vertical-align: middle;
    }
    .news-card-status {
        display: inline-block;
        padding: 6px 10px;
        border-radius: 999px;
        background: rgba(255, 197, 0, 0.16);
        color: #ffcc00;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .news-chip {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 2px 10px;
        border-radius: 999px;
        background: rgba(255, 77, 79, 0.16);
        color: #13667a;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .news-card a {
        color: inherit;
        text-decoration: none;
    }
</style>

<script>
// Auto-refresh recent activity when progress is updated
if (typeof window !== 'undefined') {
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        return originalFetch.apply(this, args).then(response => {
            const clonedResponse = response.clone();
            
            // Check if this is a progress update
            if (args[0] && args[0].includes('admin-ajax.php')) {
                clonedResponse.json().then(data => {
                    if (data.success && args[1] && args[1].body) {
                        const formData = args[1].body;
                        const action = formData.get ? formData.get('action') : null;
                        
                        if (action === 'mangayummy_update_progress') {
                            // Reload the page to show updated recent activity
                            setTimeout(() => {
                                location.reload();
                            }, 500);
                        }
                    }
                }).catch(() => {});
            }
            
            return response;
        });
    };
}

/* Add Friend button on profile page */
(function () {
    var btn = document.querySelector('.js-profile-add-friend');
    if (!btn) return;
    btn.addEventListener('click', function () {
        btn.disabled = true;
        var fd = new FormData();
        fd.append('action', 'mangayummy_add_friend');
        fd.append('nonce', btn.dataset.nonce);
        fd.append('user_id', btn.dataset.userId);
        fetch(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, { method: 'POST', body: fd })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    btn.classList.remove('js-profile-add-friend');
                    btn.classList.add('is-sent');
                    btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>';
                } else {
                    btn.disabled = false;
                }
            })
            .catch(function () { btn.disabled = false; });
    });
}());

(function () {
    document.querySelectorAll('.news-card-author[data-profile-url]').forEach(function(authorLink) {
        authorLink.addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            const url = this.dataset.profileUrl;
            if (url) {
                window.location.href = url;
            }
        });
    });
}());
</script>

<script>
    window.profileHasNews = <?php echo $stiri_count > 0 ? 'true' : 'false'; ?>;
</script>

<?php
get_footer();


