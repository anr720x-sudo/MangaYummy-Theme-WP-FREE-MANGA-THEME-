<?php
/**
 * Recalculate bookmark counts for all manga
 * Run this script once to fix bookmark counts after bug fix
 * 
 * Usage: 
 * - Go to WP Admin → Tools → Recalculate Bookmarks (via Media Manager)
 * - Or run via URL: /wp-admin/admin.php?page=recalculate-bookmarks
 * 
 * NOTE: Menu registration moved to functions.php in the mangayummy_add_admin_menu() function
 */

// Menu registration is handled in functions.php (mangayummy_add_admin_menu)

function mangayummy_recalculate_bookmarks_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }
    
    echo '<div class="wrap">';
    echo '<h1>Recalculate Bookmark Counts</h1>';
    
    // Handle form submit
    if (isset($_POST['recalculate_bookmarks']) && check_admin_referer('recalculate_bookmarks_action')) {
        $result = mangayummy_do_recalculate_bookmarks();
        echo '<div class="notice notice-success"><p>' . esc_html($result) . '</p></div>';
    }
    
    // Get current stats
    global $wpdb;
    $manga_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'manga' AND post_status = 'publish'");
    $users_with_bookmarks = $wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = 'mangayummy_bookmarks' AND meta_value != 'a:0:{}'");
    
    echo '<div style="background:#fff;padding:20px;border:1px solid #ddd;border-radius:8px;margin-top:20px;">';
    echo '<h3>Current Statistics</h3>';
    echo '<p><strong>Total manga:</strong> ' . intval($manga_count) . '</p>';
    echo '<p><strong>Users with bookmarks:</strong> ' . intval($users_with_bookmarks) . '</p>';
    echo '<hr style="margin:20px 0;">';
    echo '<p>This script will recalculate bookmark counts for ALL manga based on how many users have each manga in their list.</p>';
    echo '<p style="color:#d63638;"><strong>⚠️ May take a few minutes for large sites!</strong></p>';
    echo '<form method="post">';
    wp_nonce_field('recalculate_bookmarks_action');
    echo '<button type="submit" name="recalculate_bookmarks" value="1" class="button button-primary" style="padding:10px 20px;font-size:14px;">🔄 Recalculate Bookmarks</button>';
    echo '</form>';
    echo '</div>';
    
    echo '</div>';
}

function mangayummy_do_recalculate_bookmarks() {
    global $wpdb;
    
    // Get all manga IDs
    $manga_ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'manga' AND post_status = 'publish'");
    
    if (empty($manga_ids)) {
        return 'Nu s-au găsit manga-uri.';
    }
    
    // Get all users with bookmarks
    $users_bookmarks = $wpdb->get_results("
        SELECT user_id, meta_value 
        FROM {$wpdb->usermeta} 
        WHERE meta_key IN ('mangayummy_bookmarks', 'bookmarked_manga', 'bookmarked_mangas')
        AND meta_value != '' AND meta_value != 'a:0:{}'
    ");
    
    // Build array: manga_id => count
    $bookmark_counts = array();
    foreach ($manga_ids as $manga_id) {
        $bookmark_counts[$manga_id] = 0;
    }
    
    // Count bookmarks per manga
    $processed_users = array(); // Track which user+manga combos we've counted
    foreach ($users_bookmarks as $row) {
        $bookmarks = maybe_unserialize($row->meta_value);
        if (!is_array($bookmarks)) continue;
        
        foreach ($bookmarks as $manga_id) {
            $manga_id = intval($manga_id);
            $combo_key = $row->user_id . '_' . $manga_id;
            
            // Skip if already counted this user-manga combo (prevents double counting from multiple meta keys)
            if (isset($processed_users[$combo_key])) continue;
            $processed_users[$combo_key] = true;
            
            if (isset($bookmark_counts[$manga_id])) {
                $bookmark_counts[$manga_id]++;
            }
        }
    }
    
    // Update all manga bookmark counts
    $updated = 0;
    foreach ($bookmark_counts as $manga_id => $count) {
        update_post_meta($manga_id, '_mangayummy_bookmark_count', $count);
        $updated++;
    }
    
    return "✅ Recalculare completă! $updated manga-uri actualizate.";
}
