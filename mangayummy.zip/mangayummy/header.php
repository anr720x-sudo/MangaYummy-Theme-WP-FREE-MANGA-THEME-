<!DOCTYPE html>
<?php
/**
 * MangaYummy Theme Header
 */
?>
<html lang="ro" <?php language_attributes(); ?>>
<head>
    <?php $show_main_pattern = (int) get_theme_mod('show_main_background_pattern', 1) === 1; ?>
    <?php $custom_background_image = esc_url(get_theme_mod('custom_background_image', '')); ?>
    <?php $has_custom_background_image = !empty($custom_background_image); ?>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#ffffff">
    <!-- Cache headers removed from HTML: caching should be handled by the server (use WP_DEBUG or server config to force no-cache when needed) -->
    <!-- settings.css removed; styles should be enqueued via wp_enqueue_scripts in functions.php -->

    <!-- Inline critical background: mitigate FOUC for custom background on first paint -->
    <?php if ($show_main_pattern && $has_custom_background_image): ?>
    <link rel="preload" as="image" href="<?php echo $custom_background_image; ?>">
    <?php endif; ?>
    <style>
        .bg-pattern {
            background-repeat: repeat;
            position: fixed;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        #page-rotate-wrapper {
            position: relative;
            z-index: 1;
        }
    </style>

    <!-- SEO: Preconnect & DNS-Prefetch for faster external resource loading -->
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    <link rel="preconnect" href="https://unpkg.com" crossorigin>
    <link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
    
    <!-- DEBUG: Check if page is cached -->
    <link rel="dns-prefetch" href="//cdn.jsdelivr.net">
    <link rel="dns-prefetch" href="//unpkg.com">
    
    <?php if (is_singular('chapter')): ?>
    <!-- Chapter page: Preconnect to allowed image CDNs only -->
    <?php endif; ?>
    
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/img/logo_header_mangayummy.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/assets/img/logo_header_mangayummy.png">
    <!-- Font Awesome - loaded async to prevent render blocking -->
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></noscript>
    <style>
/* Admin bar spacing removed - WordPress handles it */
</style>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-profile-id="<?php echo intval(get_query_var('view_user', get_current_user_id())); ?>">
    <div class="bg-pattern" style="<?php echo ($show_main_pattern && $has_custom_background_image) ? "background-image: url('" . $custom_background_image . "'); background-size: 700px;" : 'background-image: none;'; ?>"></div>
    <div id="page-rotate-wrapper">
    <header class="ya-header">
        <div class="ya-header-inner">
            <div class="ya-left">
                <a href="<?php echo esc_url( home_url('/') ); ?>" class="site-logo">
                    <?php echo esc_html(get_bloginfo('name')); ?>
                </a>
            </div>

            <div class="ya-search-wrapper">
                <button id="searchIconBtn" class="search-icon-btn" type="button" aria-label="Open search">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="var(--text)" viewBox="0 0 20 20">
                      <path d="M7.32 14.7a7.05 7.05 0 01-5.18-2.14A7.1 7.1 0 010 7.36a7.1 7.1 0 012.14-5.21A7.05 7.05 0 017.32 0c2.03 0 3.76.72 5.19 2.15a7.1 7.1 0 012.13 5.2c0 .8-.1 1.57-.33 2.31a6.9 6.9 0 01-.99 2.03l6.31 6.33c.24.25.37.51.37.8s-.12.55-.37.8-.52.38-.81.38c-.3 0-.56-.13-.81-.38l-6.28-6.27c-.59.43-1.28.76-2.07 1-.8.24-1.57.35-2.34.35Zm0-2.3c1.42 0 2.61-.49 3.58-1.46a4.89 4.89 0 001.45-3.59c0-1.42-.49-2.62-1.45-3.59A4.85 4.85 0 007.32 2.31c-1.42 0-2.61.48-3.58 1.45A4.89 4.89 0 002.3 7.36c0 1.42.48 2.61 1.44 3.58a4.85 4.85 0 003.58 1.46Z" transform="translate(0, 0)"></path>
                    </svg>
                </button>
                <a class="search-modal-filter" href="<?php echo home_url('/browse/'); ?>">
                    <i class="fa fa-filter" aria-hidden="true" style="font-size:14px;line-height:1;"></i>
                    Browse
                </a>
            </div>

            <nav class="ya-menu">
                <a href="<?php echo home_url(); ?>" class="<?php echo is_front_page() && strpos($_SERVER['REQUEST_URI'], 'top-100') === false ? 'active' : ''; ?>">HOME</a>
                <a href="<?php echo home_url('/manga'); ?>" class="<?php echo (is_page('manhua') || is_page('manga') || (strpos($_SERVER['REQUEST_URI'], '/manhua') !== false || strpos($_SERVER['REQUEST_URI'], '/manga') !== false) && strpos($_SERVER['REQUEST_URI'], '/random') === false && strpos($_SERVER['REQUEST_URI'], 'top-100') === false) ? 'active' : ''; ?>">MANGA</a>
                <a href="<?php echo home_url('/top-100-manga'); ?>" class="<?php echo strpos($_SERVER['REQUEST_URI'], 'top-100') !== false ? 'active' : ''; ?>">TOP 100</a>
                <a href="<?php echo home_url('/random'); ?>" class="<?php echo strpos($_SERVER['REQUEST_URI'], '/random') !== false ? 'active' : ''; ?>">RANDOM</a>
                                <div class="community-wrapper">
                                    <button class="community-toggle" aria-expanded="false">COMMUNITY</button>
                                    <div class="community-dropdown" aria-hidden="true">
                                        <a href="<?php echo esc_url( home_url('/about/') ); ?>" style="display:block;width:100%">About Site</a>
                                        <a href="<?php echo esc_url( home_url('/news/') ); ?>" class="community-link-stiri" style="display:block;width:100%">News</a>
                                        <a href="<?php echo esc_url( home_url('/users/') ); ?>" style="display:block;width:100%">Users</a>
                                        <a href="https://buymeacoffee.com/mangayummy9" target="_blank" rel="noopener" class="donation-link" style="display:block;width:100%">Donate</a>
                                    </div>
                                </div>
                                <style>
                                @media (max-width: 768px) {
                                    .community-dropdown .community-link-recenzii {
                                        display: none !important;
                                    }
                                }
                                </style>
            </nav>
            <div class="ya-right">
                <?php if ( is_user_logged_in() ) : 
                    // Cache user data to avoid multiple DB calls
                    $current_user = wp_get_current_user();
                    $current_user_id = $current_user->ID;
                    $avatar_url = get_user_meta($current_user_id, 'profile_avatar', true);
                    if (!$avatar_url) {
                        $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
                    }
                ?>
                    <div class="header-user">
                        <button class="user-link" id="userMenuToggle" title="User menu">
                            <span class="user-avatar">
                                <img id="headerAvatar" src="<?php echo esc_url($avatar_url); ?>" class="header-avatar" alt="Avatar" width="40" height="40">
                            </span>
                        </button>
                        <div class="user-menu">
                            <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $current_user_id), home_url('/'))); ?>" class="user-menu-item profile-link">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                Profile
                            </a>
                            <a href="#settings" class="user-menu-item settings-link" data-open-settings="1">
                                <i class="fa fa-cog" aria-hidden="true"></i>
                                Settings
                            </a>
                            <?php $unread_notifications = mangayummy_get_unread_messages_count(); ?>
                            <a href="<?php echo home_url('/messages'); ?>" class="user-menu-item messages-link">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                Messages
                                <?php if ($unread_notifications > 0): ?>
                                    <span class="messages-badge"><?php echo esc_html($unread_notifications); ?></span>
                                <?php endif; ?>
                            </a>
                            <a href="#" class="user-menu-item logout" data-action="logout">
                                <i class="fa fa-sign-out" aria-hidden="true"></i>
                                Logout
                            </a>
                        </div>
                    </div>
                    <script>
                    // Consolidated header scripts for logged-in users
                    (function() {
                        // User menu toggle (IIFE for instant execution)
                        var btn = document.getElementById('userMenuToggle');
                        var menu = document.querySelector('.user-menu');
                        var header = document.querySelector('.header-user');
                        
                        if (btn && menu) {
                            btn.addEventListener('click', function(e) {
                                e.preventDefault();
                                e.stopPropagation();
                                menu.classList.toggle('active');
                            });
                            document.addEventListener('click', function(e) {
                                if (menu.classList.contains('active') && header && !header.contains(e.target)) {
                                    menu.classList.remove('active');
                                }
                            });
                            menu.querySelectorAll('a').forEach(function(link) {
                                link.addEventListener('click', function() { menu.classList.remove('active'); });
                            });
                        }
                        
                        // Wait for DOM and ya_ajax to be ready
                        document.addEventListener('DOMContentLoaded', function() {
                            // Messages badge update (every 30s)
                            function updateBadge() {
                                if (typeof ya_ajax === 'undefined') return;
                                fetch(ya_ajax.ajax_url, {
                                    method: 'POST',
                                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                                    body: 'action=get_unread_messages_count'
                                })
                                .then(function(r) { return r.json(); })
                                .then(function(d) {
                                    if (d.success) {
                                        var b = document.querySelector('.messages-badge');
                                        if (b) b.textContent = d.data.count;
                                    }
                                }).catch(function() {});
                            }
                            updateBadge();
                            setInterval(updateBadge, 30000);
                            
                            // Logout handler
                            var logoutBtn = document.querySelector('.user-menu-item.logout');
                            if (logoutBtn) {
                                logoutBtn.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    if (typeof ya_ajax === 'undefined') { window.location.href = '/'; return; }
                                    fetch(ya_ajax.ajax_url, {
                                        method: 'POST',
                                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                                        body: 'action=mangayummy_logout&nonce=' + ya_ajax.nonce
                                    })
                                    .then(function(r) { return r.json(); })
                                    .then(function(d) { window.location.href = d.success ? d.data.redirect : '/'; })
                                    .catch(function() { window.location.href = '/'; });
                                });
                            }
                        });
                    })();
                    </script>
                <?php else : ?>
                    <div class="auth-buttons">
                        <a href="#" class="auth-btn login" onclick="event.preventDefault(); window.openAuthModal('login');">
                             LOGIN
                        </a>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="search-modal" id="searchModal" aria-hidden="true">
      <div class="search-modal-overlay" data-action="close-modal"></div>
      <div class="search-modal-content">
        <form class="search-modal-form" action="<?php echo home_url('/browse/'); ?>" method="get">
          <div class="search-modal-input-wrap">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
              <path d="M7.32 14.7a7.05 7.05 0 01-5.18-2.14A7.1 7.1 0 010 7.36a7.1 7.1 0 012.14-5.21A7.05 7.05 0 017.32 0c2.03 0 3.76.72 5.19 2.15a7.1 7.1 0 012.13 5.2c0 .8-.1 1.57-.33 2.31a6.9 6.9 0 01-.99 2.03l6.31 6.33c.24.25.37.51.37.8s-.12.55-.37.8-.52.38-.81.38c-.3 0-.56-.13-.81-.38l-6.28-6.27c-.59.43-1.28.76-2.07 1-.8.24-1.57.35-2.34.35Zm0-2.3c1.42 0 2.61-.49 3.58-1.46a4.89 4.89 0 001.45-3.59c0-1.42-.49-2.62-1.45-3.59A4.85 4.85 0 007.32 2.31c-1.42 0-2.61.48-3.58 1.45A4.89 4.89 0 002.3 7.36c0 1.42.48 2.61 1.44 3.58a4.85 4.85 0 003.58 1.46Z" transform="translate(0, 0)"></path>
            </svg>
            <input type="text" name="s" id="searchModalInput" placeholder="Search manga..." autocomplete="off" />
          </div>
        </form>
        <div class="search-results-wrapper">
          <div class="ya-search-results"></div>
        </div>
        <div class="search-recent" id="searchRecent">
          <span>Recent searches</span>
          <ul id="searchRecentList"></ul>
        </div>
      </div>
    </div>

        <style>
        /* Community dropdown styles */
        .ya-menu { display: flex; flex-wrap: nowrap; align-items: center; gap: 6px; }
        .community-wrapper { position: relative; display: flex; align-items: center; margin: 0 12px; }
        .community-toggle { background: none; border: none; color: #fff; font-weight: 600; cursor: pointer; padding: 0; margin: 0; display: inline-flex; align-items: center; gap: 6px; line-height: 1; font-family: inherit; font-size: inherit; text-decoration: none; border-bottom: 2px solid transparent; transition: border-color .18s ease; }
        .community-toggle:hover, .community-toggle[aria-expanded="true"] { border-bottom-color: #13667a; }
        .community-dropdown { position: absolute; top: calc(100% - 1px); left: 0; background: #0f0f0f !important; border: 1px solid #222; border-radius: 6px; overflow: hidden; max-height: 0; transition: max-height 0.28s ease, opacity 0.2s ease; opacity: 0; z-index: 60; width: 220px; pointer-events: none; }
        .community-wrapper::after { content: ''; position: absolute; top: 100%; left: 0; right: 0; height: 8px; background: transparent; pointer-events: auto; }
        .community-dropdown a { display: block !important; padding: 6px 14px !important; color: #ddd !important; text-decoration: none !important; font-weight: normal !important; font-size: 16px !important; line-height: 1.1 !important; border-bottom: 1px solid #333 !important; transition: background 0.2s ease, color 0.2s ease !important; background: #0f0f0f !important; }
        .community-dropdown a:last-child { border-bottom: none !important; }
        .community-dropdown a:hover { background: #111 !important; color: #fff !important; }
        .community-dropdown a:active { background: #222 !important; color: #f00 !important; }
        .community-dropdown.open,
        .community-wrapper:hover .community-dropdown,
        .community-wrapper:focus-within .community-dropdown,
        .community-dropdown:hover {
            max-height: 360px;
            opacity: 1;
            pointer-events: auto;
        }

        .header-user:hover .user-menu {
            display: flex !important;
            flex-direction: column !important;
            opacity: 1 !important;
            visibility: visible !important;
            transform: translateY(0) !important;
        }

        /* Mobile: dropdown positioning */
        @media (max-width: 768px) {
            .ya-bottom-nav .community-toggle {
                background: none !important;
                border: none !important;
                color: #fff !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                justify-content: center !important;
                gap: 4px !important;
                padding: 6px 0 !important;
                line-height: 1 !important;
                width: 100% !important;
                cursor: pointer !important;
                font-family: inherit !important;
            }
            .ya-bottom-nav .community-toggle i {
                font-size: 18px !important;
                margin: 0 !important;
            }
            .ya-bottom-nav .community-toggle span {
                font-size: 10px !important;
                margin: 0 !important;
                padding: 0 !important;
                font-weight: 600 !important;
            }
            .community-dropdown {
                position: fixed !important;
                left: auto !important;
                right: 3px !important;
                transform: none !important;
                bottom: calc(56px + env(safe-area-inset-bottom, 0px) + 8px) !important;
                top: auto !important;
                width: 220px !important;
                max-width: calc(100vw - 16px) !important;
                z-index: 100000 !important;
                padding: 0 !important;
                margin: 0 !important;
                box-sizing: border-box !important;
                overflow: hidden !important;
                border-bottom: 3px solid;
                border-top: 3px solid;
                border-bottom-color: #ff6666;
                border-top-color: #ff6666;
            }
            .community-dropdown.open {
                max-height: 600px !important;
                opacity: 1 !important;
                pointer-events: auto !important;
                visibility: visible !important;
            }
            .community-dropdown a {
                flex-direction: row !important;
                padding: 12px 16px !important;
                font-size: 14px !important;
                width: 100% !important;
            }
            .community-dropdown a:hover,
            .community-dropdown a:active {
                background: #1a1a1a !important;
                color: #fff !important;
            }
            .ya-menu { align-items: center; }
            .community-wrapper { margin: 0 8px; height: 44px; }
            .community-toggle { padding: 0 8px; height: 44px; display: inline-flex; align-items: center; }
        }

        /* Phone: larger dropdown */
        @media (max-width: 480px) {
            .community-dropdown.open { 
                max-height: 600px !important; 
            }
            .community-dropdown a {
                font-size: 18px !important;
            }
        }
        </style>

                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var dropdown = document.querySelector('.community-dropdown');
                    var headerToggle = document.querySelector('.community-wrapper .community-toggle');
                    var mobileToggle = document.querySelector('.ya-bottom-nav .community-toggle');

                    // For mobile, move dropdown to body so that fixed positioning is not affected
                    if (window.innerWidth <= 768 && mobileToggle && dropdown) {
                        document.body.appendChild(dropdown);
                    }

                    function toggleDropdown(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        dropdown.classList.toggle('open');
                        if (headerToggle) {
                            headerToggle.setAttribute('aria-expanded', dropdown.classList.contains('open') ? 'true' : 'false');
                        }
                        dropdown.setAttribute('aria-hidden', dropdown.classList.contains('open') ? 'false' : 'true');
                    }

                    if (headerToggle) {
                        headerToggle.addEventListener('click', toggleDropdown);
                    }

                    if (mobileToggle) {
                        mobileToggle.addEventListener('click', toggleDropdown);
                    }

                    document.addEventListener('click', function(e) {
                        if (!e.target.closest('.community-toggle') && !e.target.closest('.community-dropdown')) {
                            dropdown.classList.remove('open');
                            if (headerToggle) {
                                headerToggle.setAttribute('aria-expanded', 'false');
                            }
                            dropdown.setAttribute('aria-hidden', 'true');
                        }
                    });
                });
                </script>

    <style>
    .messages-badge, .notif-badge {
        display: inline-flex !important;
        align-items: center;
        justify-content: center;
        min-width: 26px;
        height: 22px;
        width: auto;
        padding: 0 6px;
        background: #13667a !important;
        color: #000 !important;
        text-color: #000 !important;
        border-radius: 12px;
        font-size: 11px !important;
        font-weight: bold !important;
        margin-left: 6px;
        text-align: center !important;
        line-height: 22px !important;
        vertical-align: middle;
        overflow: visible !important;
        white-space: nowrap !important;
    }

    @media (max-width: 768px) {
      .messages-badge, .notif-badge {
        min-width: 18px;
        height: 20px;
        padding: 0 10px;
        font-size: 10px !important;
        margin-left: 4px;
      }
    }
    
    .header-avatar {
        border-radius: 8px !important;
        width: 40px !important;
        height: 40px !important;
        
    }
    #headerAvatar {
        width: 40px !important;
        height: 40px !important;
        
    }
    </style>

    <!-- Bottom Navigation for Mobile -->
    <nav class="ya-bottom-nav">
        <ul>
            <li><a href="<?php echo home_url(); ?>" class="<?php echo is_front_page() && strpos($_SERVER['REQUEST_URI'], 'top-100') === false ? 'active' : ''; ?>">
                <i class="fa fa-home" aria-hidden="true"></i>
                <span class="menu-text">HOME</span>
            </a></li>
            <li><a href="<?php echo home_url('/manga'); ?>" class="<?php echo (is_page('manhua') || is_page('manga') || (strpos($_SERVER['REQUEST_URI'], '/manhua') !== false || strpos($_SERVER['REQUEST_URI'], '/manga') !== false) && strpos($_SERVER['REQUEST_URI'], '/random') === false && strpos($_SERVER['REQUEST_URI'], 'top-100') === false) ? 'active' : ''; ?>">
                <i class="fa fa-list" aria-hidden="true"></i>
                <span class="menu-text">MANGA</span>
            </a></li>
            <li><a href="<?php echo home_url('/top-100-manga'); ?>" class="<?php echo strpos($_SERVER['REQUEST_URI'], 'top-100') !== false ? 'active' : ''; ?>">
                <i class="fa fa-star" aria-hidden="true"></i>
                <span class="menu-text">TOP 100</span>
            </a></li>
            <li><a href="<?php echo home_url('/random'); ?>" class="<?php echo strpos($_SERVER['REQUEST_URI'], '/random') !== false ? 'active' : ''; ?>">
                <i class="fa fa-random" aria-hidden="true"></i>
                <span class="menu-text">RANDOM</span>
            </a></li>
                        <li class="community-nav-item">
                            <button type="button" class="community-toggle">
                                <i class="fa fa-users" aria-hidden="true"></i>
                                <span class="menu-text">COMMUNITY</span>
                            </button>
                        </li>
        </ul>
    </nav>


