<?php
get_header();

$term = get_queried_object();
if (!$term || $term->taxonomy !== 'genre') {
    // Fallback
    include get_template_directory() . '/page-manga.php';
    get_footer();
    exit;
}

$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;
$per_page = 30;

// Get manga with this genre that have chapters
global $wpdb;

// Get manga IDs that have chapters and belong to this genre
$manga_query_sql = "
    SELECT DISTINCT pm.meta_value as manga_id, MAX(p.post_date) as latest_chapter_date
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_manga_id'
    INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = pm.meta_value
    INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'genre' AND tt.term_id = %d
    WHERE p.post_type = 'chapter' 
    AND p.post_status = 'publish'
    AND pm.meta_value != ''
    GROUP BY pm.meta_value
    ORDER BY latest_chapter_date DESC
";
$manga_results = $wpdb->get_results($wpdb->prepare($manga_query_sql, $term->term_id));

$manga_ids = [];
foreach ($manga_results as $row) {
    $manga_id = intval($row->manga_id);
    if ($manga_id) {
        $manga = get_post($manga_id);
        if ($manga && $manga->post_status === 'publish' && $manga->post_type === 'manga' && ! get_post_meta($manga_id, '_manga_id', true)) {
            $manga_ids[] = $manga_id;
        }
    }
}

// Now, similar to page-manga.php, get chapter data
$manga_data = [];
if (!empty($manga_ids)) {
    $ids_placeholder = implode(',', array_map('intval', $manga_ids));
    
    // Get latest 2 chapters for each manga in one query
    $chapters_sql = "
        SELECT p.ID, p.post_title, pm1.meta_value as manga_id, pm2.meta_value as chapter_number
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_manga_id'
        LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_chapter_number'
        WHERE p.post_type = 'chapter' 
        AND p.post_status = 'publish'
        AND pm1.meta_value IN ($ids_placeholder)
        ORDER BY CAST(pm2.meta_value AS DECIMAL(10,2)) DESC
    ";
    $all_chapters = $wpdb->get_results($chapters_sql);
    
    // Group chapters by manga
    $chapters_by_manga = [];
    foreach ($all_chapters as $ch) {
        $mid = intval($ch->manga_id);
        if (!isset($chapters_by_manga[$mid])) {
            $chapters_by_manga[$mid] = [];
        }
        if (count($chapters_by_manga[$mid]) < 2) {
            $chapters_by_manga[$mid][] = $ch;
        }
    }

    // Build final data array
    $type_labels = ['manga' => 'Manga', 'manhua' => 'Manhua', 'manhwa' => 'Manhwa'];
    $status_labels = ['ongoing' => 'Ongoing', 'completed' => 'Completed', 'hiatus' => 'On Hiatus', 'dropped' => 'Abandoned'];
    
    foreach ($manga_ids as $manga_id) {
        $manga = get_post($manga_id);
        $manga_type = get_post_meta($manga_id, '_manga_type', true);
        $manga_status = get_post_meta($manga_id, '_status', true);
        
        $manga_data[] = [
            'id' => $manga_id,
            'title' => $manga->post_title,
            'permalink' => get_permalink($manga_id),
            'thumbnail' => get_the_post_thumbnail($manga_id, 'manga-card', ['decoding' => 'async']),
            'type' => $manga_type,
            'type_display' => $type_labels[$manga_type] ?? '',
            'status' => $manga_status,
            'status_display' => $status_labels[$manga_status] ?? '',
            'chapters' => $chapters_by_manga[$manga_id] ?? []
        ];
    }
}

// Pagination
$total_manga = count($manga_data);
$total_pages = ceil($total_manga / $per_page);
$current_page = min($current_page, max(1, $total_pages));
$offset = ($current_page - 1) * $per_page;
$paged_data = array_slice($manga_data, $offset, $per_page);
$manga_count = count($paged_data);

// Build base URL for pagination
$base_url = get_term_link($term);
$url_params = [];
?>

<main class="site-main">
  <div class="ya-section">

    <h1 class="page-title"><?php echo esc_html($term->name); ?> Manga</h1>

    <div class="latest-manga-grid">
      <?php
      $item_index = 0;
      foreach ($paged_data as $manga_item):
          $manga_id = $manga_item['id'];
          $manga_type = $manga_item['type'];
          $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
          
          // First 6 images: eager load with high priority for LCP
          $img_html = $manga_item['thumbnail'];
          if ($item_index < 6) {
              $img_html = str_replace('<img ', '<img loading="eager" fetchpriority="high" ', $img_html);
          } else {
              $img_html = str_replace('<img ', '<img loading="lazy" ', $img_html);
          }
          $item_index++;
          ?>
          
          <div class="latest-manga-item" data-manga-type="<?php echo esc_attr($manga_type ?: ''); ?>">
            <div class="manga-poster-wrap">
              <a href="<?php echo esc_url($manga_item['permalink']); ?>">
                <?php echo $img_html; ?>
              </a>

              <div class="poster-rating-overlay">
                <div class="overlay-left">
                  <?php if ($manga_item['type_display']): ?>
                    <span class="manga-type <?php echo esc_attr($type_class); ?>"><?php echo esc_html($manga_item['type_display']); ?></span>
                  <?php endif; ?>
                  <?php if ($manga_item['status_display']): ?>
                    <span class="manga-status status-<?php echo esc_attr($manga_item['status']); ?>"><?php echo esc_html($manga_item['status_display']); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <?php 
              $is_18_content = get_post_meta($manga_id, '_manga_18', true);
              if ($is_18_content): 
              ?>
                <div class="manga-18-overlay">18+</div>
              <?php endif; ?>
            </div>

            <h3 class="manga-title">
              <a href="<?php echo esc_url($manga_item['permalink']); ?>">
                <?php echo esc_html($manga_item['title']); ?>
              </a>
            </h3>

          <!-- Capitolele nu se afișează pe pagina de gen -->
          </div>
      <?php endforeach; ?>
    </div>

    <?php if ($total_pages > 1): ?>
      <div class="pagination">
        <?php
        $prev_page = $current_page - 1;
        $next_page = $current_page + 1;
        
        if ($prev_page >= 1) {
          $prev_url = add_query_arg('pag', $prev_page, $base_url);
          echo '<a href="' . esc_url($prev_url) . '" class="page-link prev">«</a>';
        }

        for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++) {
          $page_url = $i === 1 ? $base_url : add_query_arg('pag', $i, $base_url);
          $class = $i === $current_page ? ' current' : '';
          echo '<a href="' . esc_url($page_url) . '" class="page-link' . $class . '">' . $i . '</a>';
        }
        
        if ($next_page <= $total_pages) {
          $next_url = add_query_arg('pag', $next_page, $base_url);
          echo '<a href="' . esc_url($next_url) . '" class="page-link next">»</a>';
        }
        ?>
      </div>
    <?php endif; ?>

  </div>
</main>

<?php get_footer(); ?>