<?php
/**
 * Template auto pentru Adăugate Recent
 * WordPress o folosește AUTOMAT pentru slug "adaugate-recent"
 * NU necesită setare manuală în WP
 */

get_header();
$current_page = isset($_GET['pag']) ? max(1, intval($_GET['pag'])) : 1;

// Cache all latest chapters per manga (5 min cache)
$latest_chapters_cache_key = 'latest_chapters_all';
$latest_chapters = get_transient($latest_chapters_cache_key);

if ($latest_chapters === false) {
    global $wpdb;
    // Single query to get latest chapter for each manga
    $results = $wpdb->get_results("
        SELECT pm.meta_value as manga_id, 
               MAX(CAST(pn.meta_value AS UNSIGNED)) as chapter_number
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_manga_id'
        INNER JOIN {$wpdb->postmeta} pn ON p.ID = pn.post_id AND pn.meta_key = '_chapter_number'
        WHERE p.post_type = 'chapter' AND p.post_status = 'publish'
        GROUP BY pm.meta_value
    ", ARRAY_A);
    
    $latest_chapters = [];
    if ($results) {
        foreach ($results as $row) {
            $latest_chapters[$row['manga_id']] = $row['chapter_number'];
        }
    }
    set_transient($latest_chapters_cache_key, $latest_chapters, 5 * MINUTE_IN_SECONDS);
}
?>

<main class="site-main">
  <div class="ya-section">
    <h1 class="page-title page-title--recomandate">MANGA-URI ADĂUGATE RECENT</h1>

    <div class="latest-manga-grid">
      <?php
      // Get latest manga by publish date
      $manga_query = new WP_Query([
        'post_type' => 'manga',
        'post_status' => 'publish',
        'posts_per_page' => 48,
        'paged' => $current_page,
        'orderby' => 'date',
        'order' => 'DESC',
        'suppress_filters' => false,
        'update_post_term_cache' => false // Skip term cache if not using categories
      ]);

      if ($manga_query->have_posts()) {
        while ($manga_query->have_posts()) {
          $manga_query->the_post();
          $manga_id = get_the_ID();
          
          // Get manga data
          $thumbnail_url = get_the_post_thumbnail_url($manga_id, 'full');
          if (!$thumbnail_url) {
            $thumbnail_url = get_post_meta($manga_id, '_cover_image_url', true);
          }
          if (!$thumbnail_url) {
            $thumbnail_url = get_post_meta($manga_id, '_cover_image', true);
          }
          if (!$thumbnail_url) {
            $thumbnail_url = get_template_directory_uri() . '/assets/img/default-manga.jpg';
          }
          
          $title = get_the_title();
          $permalink = get_permalink();
          
          // Get latest chapter info from cached data (no additional query!)
          $chapter_info = '';
          if (isset($latest_chapters[$manga_id]) && $latest_chapters[$manga_id]) {
            $chapter_info = 'Cap. ' . $latest_chapters[$manga_id];
          }
          
          ?>
          <div class="latest-manga-item">
            <div class="manga-poster-wrap">
              <a href="<?php echo esc_url($permalink); ?>">
                <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy">
              </a>
              <?php if ($chapter_info): ?>
                <span class="chapter-badge"><?php echo esc_html($chapter_info); ?></span>
              <?php endif; ?>
            </div>
            <h3 class="manga-title">
              <a href="<?php echo esc_url($permalink); ?>">
                <?php echo esc_html($title); ?>
              </a>
            </h3>
          </div>
          <?php
        }
        wp_reset_postdata();
      } else {
        echo '<p>Nu s-au găsit MANGA-URI ADĂUGATE RECENT.</p>';
      }
      ?>
    </div>

    <?php if ($manga_query->max_num_pages > 1) : ?>
    <div class="pagination-wrapper">
      <?php
      echo paginate_links(array(
        'total' => $manga_query->max_num_pages,
        'current' => $current_page,
        'base' => add_query_arg('pag', '%#%', get_permalink()),
        'format' => '?pag=%#%',
        'prev_text' => '‹',
        'next_text' => '›',
      ));
      ?>
    </div>
    <?php endif; ?>
  </div>
</main>

<?php get_footer(); ?>
