<?php
echo '<style>
.users-container {
  background: var(--head);
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(255,77,79,0.1), inset 0 1px 0 rgba(255,255,255,0.1);
  padding: 10px;
  margin: 30px auto;
  max-width: 1300px;
  position: relative;
}

.users-header {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 50px;
  width: 100%;
  padding: 15px;
  margin-bottom: 12px;
  position: relative;
  z-index: 2;
  background: var(--head);
  color: #fff;
  border-bottom: 3px solid #13667a;
  border-radius: var(--radius) var(--radius) 0 0;
}

.users-header h1 {
  color: #fff;
  font-size: 28px;
  font-weight: 600;
  margin: 0;
}

.users-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 10px;
}

.users-search {
  position: relative;
  flex: 1 1 auto;
}

.users-search__icon {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 18px;
  height: 18px;
  color: #a3a3a3;
  pointer-events: none;
}

.users-search__input {
  width: 100%;
  height: 38px;
  border: 1px solid #3a3a3a;
  border-radius: 8px;
  background: #222;
  color: #eee;
  font-size: 24px;
  line-height: 24px;
  padding: 0 12px 0 40px;
  outline: none;
}

.users-search__input::placeholder {
  color: #8c8c8c;
}

.users-search__input:focus {
  border-color: #13667a;
  box-shadow: 0 0 0 2px rgba(255, 77, 79, 0.18);
}

.users-empty-search {
  display: none;
  margin-top: 16px;
  font-size: 14px;
  color: #aaa;
  text-align: center;
}

.users-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-top: 24px;
}

/* User Card */
.user-card {
  background: #252525;
  border-radius: 12px;
  display: flex;
  align-items: flex-start;
  gap: 12px;
  flex-wrap: wrap;
  position: relative;
  overflow: visible;
  transition: background 0.2s;
  text-decoration: none !important;
  color: inherit !important;
}

.user-card:hover {
  background: #2e2e2e;
}

.user-card__avatar {
  flex-shrink: 0;
  width: 112px;
  height: 112px;
  border-radius: 8px;
  overflow: hidden;
}

.user-card__avatar img {
  width: 100%;
  height: 100%;
  
  display: block;
}

.user-card__info {
  flex: 1;
  min-width: 0;
  padding-bottom: 0;
}

.user-card__name-row {
  display: flex;
  align-items: flex-start;
  gap: 6px;
}

.user-card__name {
  font-size: 18px;
  font-weight: 600;
  margin: 9px 0 0;
  line-height: 18px;
  color: #fff;
  white-space: initial;
  min-width: 0;
  overflow-wrap: anywhere;
  display: -webkit-box;
  text-overflow: ellipsis;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
  overflow: hidden;
  text-decoration: none;
}

.user-card__name:hover {
  color: #eee;
}

.user-card__online-dot {
  flex-shrink: 0;
  position: relative;
  width: 12px;
  height: 12px;
  margin-top: 12px;
  border-radius: 50%;
  background: #aaa;
  cursor: help;
}

.user-card__online-dot.online {
  background: #13667a;
}

.user-card__online-dot.offline {
  background: #13667a;
}

.user-card__online-dot::after {
  content: attr(data-tooltip);
  position: absolute;
  left: calc(100% + 10px);
  top: 50%;
  background: rgba(15, 15, 15, 0.96);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.25;
  white-space: nowrap;
  opacity: 0;
  transform: translate(4px, -50%);
  pointer-events: none;
  transition: opacity 0.16s ease, transform 0.16s ease;
  z-index: 10;
}

.user-card__online-dot:hover::after {
  opacity: 1;
  transform: translate(0, -50%);
}

@media (max-width: 768px) {
  .user-card__online-dot::after {
    left: 50%;
    top: calc(100% + 8px);
    transform: translate(-50%, 0);
    white-space: normal;
    max-width: 220px;
    width: auto;
  }

  .user-card__online-dot:hover::after {
    transform: translate(-50%, 0);
  }
}

.user-card__meta {
  font-size: 12px;
  color: #888;
  margin-top: 10px;
}

.user-card__discord {
  display: inline-flex;
  align-items: center;
  opacity: 0.8;
  transition: opacity 0.2s;
}

.user-card__discord:hover {
  opacity: 1;
}

.user-card__actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  margin-top: 30px;
}

.user-card__action-buttons {
  display: flex;
  gap: 6px;
  margin-left: auto;
  margin-top: -10px;
  transform: translateX(-10px);
}

.user-card__btn {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: opacity 0.2s, transform 0.1s;
  text-decoration: none;
}

.user-card__btn:hover {
  opacity: 0.85;
  transform: scale(1.08);
}

.user-card__btn--msg {
  background: #3a3a3a;
  color: #ccc;
}

.user-card__btn--add {
  background: #13667a;
  color: #fff;
}

.user-card__btn--add.sent {
  background: #555;
  color: #aaa;
  cursor: default;
}

.user-card__btn--add.friends {
  background: #1a6e40;
  color: #13667a;
  cursor: default;
}

.achievement-badge {
  display: inline-flex;
  align-items: center;
  font-size: 13px;
  margin-left: 4px;
}

@media (max-width: 900px) {
  .users-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 540px) {
  .users-toolbar { flex-direction: column; align-items: stretch; }
  .users-search__input { font-size: 18px; line-height: 18px; }
  .users-grid { grid-template-columns: 1fr; }
  .user-card__avatar { width: 112px; height: 112px; }
}
</style>';
/* Template Name: Users Grid */
get_header();

$paged = max(1, intval(get_query_var('paged') ?: get_query_var('page') ?: 1));
$per_page = 40;
$offset = ($paged - 1) * $per_page;

$args = [
    'number' => $per_page,
    'offset' => $offset,
    'orderby' => 'user_registered',
    'order' => 'DESC',
    'fields' => 'all',
    'meta_query' => [
        'relation' => 'AND',
        // Exclude invisible users
        [
            'relation' => 'OR',
            [
                'key' => '_invisible',
                'compare' => 'NOT EXISTS'
            ],
            [
                'key' => '_invisible',
                'value' => '1',
                'compare' => '!='
            ]
        ],
        // Exclude unverified users (email_verified = 0)
        [
            'relation' => 'OR',
            [
                'key' => 'email_verified',
                'compare' => 'NOT EXISTS'  // Older users fără meta key
            ],
            [
                'key' => 'email_verified',
                'value' => '1',
                'compare' => '='
            ]
        ]
    ],
];
$user_query = new WP_User_Query($args);
$total_users = $user_query->get_total();
$total_pages = (int) ceil($total_users / $per_page);
$users_to_display = $user_query->results;
?>
<main class="users-container">
  <header class="users-header">
    <h1>Utilizatori</h1>
  </header>
  <div class="users-toolbar">
    <div class="users-search">
      <svg class="users-search__icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="M20 20L17 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      <input id="users-search-input" class="users-search__input" type="text" placeholder="Caută utilizatorul" autocomplete="off" aria-label="Caută utilizator">
    </div>
  </div>
  <section class="users-grid">
    <?php 
    $current_user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $sent_requests   = $current_user_id ? (array)(get_user_meta($current_user_id, 'friend_requests_sent', true) ?: []) : [];
    $nonce_val       = $current_user_id ? wp_create_nonce('ya_ajax_nonce') : '';

    if (!empty($users_to_display)):
      foreach ($users_to_display as $user):
        $avatar = get_user_meta($user->ID, 'profile_avatar', true);
        if (!$avatar) {
          $avatar = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }
        $display_name = $user->display_name ?: $user->user_login;

        // Online status + hover text
        list($user_status, $user_status_text) = mangayummy_user_status($user->ID);
        if ($user_status === 'offline') {
          $last = get_user_meta($user->ID, 'last_activity', true);
          if (!$last) {
            $last = get_user_meta($user->ID, 'last_active', true);
          }
          if ($last) {
            $user_status_text = 'Ultima dată online: ' . mangayummy_time_ago((int)$last);
          }
        }
        $is_online = ($user_status === 'online');
        if ($current_user_id && $current_user_id === $user->ID) {
            $is_online = true;
            if ($user_status !== 'online') {
                $user_status_text = 'Online acum';
            }
        }

        // Gender
        $gender = mangayummy_get_user_gender($user->ID);
        $gender_label = '';
        if ($gender === 'masculin') {
            $gender_label = 'Masculin';
        } elseif ($gender === 'feminin') {
            $gender_label = 'Feminin';
        } else {
            $gender_label = '???';
        }

        // Discord
        $discord_id = get_user_meta($user->ID, 'discord_id', true);

        // Friend status
        $is_self    = ($current_user_id && $current_user_id === $user->ID);
        $are_friends = $current_user_id && mangayummy_are_friends($current_user_id, $user->ID);
        $req_sent    = $current_user_id && in_array((int)$user->ID, array_map('intval', $sent_requests));
    ?>
      <div class="user-card">
        <!-- Avatar -->
        <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user->ID), home_url('/'))); ?>" class="user-card__avatar">
          <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($display_name); ?>" loading="lazy" decoding="async">
        </a>

        <!-- Info -->
        <div class="user-card__info">
          <div class="user-card__name-row">
            <a href="<?php echo esc_url(add_query_arg(array('pagename' => 'profile', 'view_user' => (int) $user->ID), home_url('/'))); ?>" class="user-card__name" title="<?php echo esc_attr($display_name); ?>">
              <?php echo esc_html($display_name); ?>
              <?php if (mangayummy_user_has_achievement($user->ID, 'bug_hunter')): ?>
                <span class="achievement-badge" title="Bug Hunter">🐛</span>
              <?php endif; ?>
            </a>
            <span class="user-card__online-dot <?php echo $is_online ? 'online' : 'offline'; ?>" data-tooltip="<?php echo esc_attr($user_status_text); ?>" aria-label="<?php echo esc_attr($user_status_text); ?>"></span>
          </div>
          <div class="user-card__meta">Sex: <?php echo esc_html($gender_label); ?></div>

          <div class="user-card__actions">
          <?php if (!$is_self): ?>
          <!-- Discord -->
          <?php if ($discord_id): ?>
          <a href="https://discord.com/users/<?php echo esc_attr($discord_id); ?>" target="_blank" rel="noopener noreferrer" class="user-card__discord" title="Profil Discord">
            <svg width="22" height="17" viewBox="0 0 127.14 96.36" fill="#5865F2"><path d="M107.7 8.07A105.15 105.15 0 0 0 81.47 0a72.06 72.06 0 0 0-3.36 6.83 97.68 97.68 0 0 0-29.11 0A72.37 72.37 0 0 0 45.64 0a105.89 105.89 0 0 0-26.25 8.09C2.79 32.65-1.71 56.6.54 80.21a105.73 105.73 0 0 0 32.17 16.15 77.7 77.7 0 0 0 6.89-11.11 68.42 68.42 0 0 1-10.85-5.18c.91-.66 1.8-1.34 2.66-2a75.57 75.57 0 0 0 64.32 0c.87.71 1.76 1.39 2.66 2a68.68 68.68 0 0 1-10.87 5.19 77 77 0 0 0 6.89 11.1 105.25 105.25 0 0 0 32.19-16.14c2.64-27.38-4.51-51.11-18.9-72.15zM42.45 65.69C36.18 65.69 31 60 31 53s5-12.74 11.43-12.74S54 46 53.89 53s-5.05 12.69-11.44 12.69zm42.24 0C78.41 65.69 73.25 60 73.25 53s5-12.74 11.44-12.74S96.23 46 96.12 53s-5.04 12.69-11.43 12.69z"/></svg>
          </a>
          <?php else: ?>
          <span></span>
          <?php endif; ?>
          <div class="user-card__action-buttons"><!-- Message + Friend -->
          <!-- Message -->
          <a href="<?php echo esc_url(home_url('/messages/?with=' . $user->ID)); ?>"
             class="user-card__btn user-card__btn--msg js-msg-btn"
             data-friends="<?php echo $are_friends ? '1' : '0'; ?>"
             title="Trimite mesaj">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          </a>
          <!-- Add Friend -->
          <?php if ($are_friends): ?>
            <span class="user-card__btn user-card__btn--add friends" title="Deja prieteni">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
            </span>
          <?php elseif ($req_sent): ?>
            <span class="user-card__btn user-card__btn--add sent" title="Cerere trimisă">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
            </span>
          <?php elseif ($current_user_id): ?>
            <button type="button"
                    class="user-card__btn user-card__btn--add js-add-friend"
                    data-uid="<?php echo (int)$user->ID; ?>"
                    data-nonce="<?php echo esc_attr($nonce_val); ?>"
                    title="Adaugă prieten">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
            </button>
          <?php else: ?>
            <a href="<?php echo esc_url(home_url('/login')); ?>" class="user-card__btn user-card__btn--add" title="Autentifică-te pentru a adăuga prieten">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
            </a>
          <?php endif; ?>
          </div>
          <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; else: ?>
      <p>Nu s-au găsit utilizatori.</p>
    <?php endif; ?>
</section>
<p id="users-empty-search" class="users-empty-search">Nu s-au găsit utilizatori pentru căutarea ta.</p>
  <?php if ($total_pages > 1): ?>
    <nav class="users-pagination" role="navigation" aria-label="Users pagination" style="display:flex;justify-content:center;gap:8px;margin:22px 0;flex-wrap:wrap;">
      <?php
        $base = get_pagenum_link(1);
        $format = (strpos($base, '?') === false) ? 'page/%#%/' : '&paged=%#%';
        echo paginate_links([
          'base' => $base . '%_%',
          'format' => $format,
          'current' => $paged,
          'total' => $total_pages,
          'prev_text' => '« Prev',
          'next_text' => 'Next »',
          'type' => 'list',
        ]);
      ?>
    </nav>
  <?php endif; ?>
</main>

<script>
/* ---- Toast notification ---- */
function showUserToast(msg) {
  var t = document.getElementById('uc-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'uc-toast';
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;background:#1e1e1e;color:#fff;padding:12px 18px;border-radius:10px;font-size:14px;box-shadow:0 4px 20px rgba(0,0,0,0.5);border-left:4px solid #13667a;max-width:280px;line-height:1.4;transition:opacity 0.3s;pointer-events:none;';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = '1';
  clearTimeout(t._to);
  t._to = setTimeout(function () { t.style.opacity = '0'; }, 3500);
}

document.addEventListener('DOMContentLoaded', function () {
  var searchInput = document.getElementById('users-search-input');
  var usersGrid = document.querySelector('.users-grid');
  var emptySearch = document.getElementById('users-empty-search');

  if (searchInput && usersGrid) {
    var cards = Array.prototype.slice.call(usersGrid.querySelectorAll('.user-card'));

    function filterUsers() {
      var q = (searchInput.value || '').trim().toLowerCase();
      var visibleCount = 0;

      cards.forEach(function (card) {
        var nameEl = card.querySelector('.user-card__name');
        var name = nameEl ? (nameEl.textContent || '').toLowerCase() : '';
        var match = !q || name.indexOf(q) !== -1;
        card.style.display = match ? '' : 'none';
        if (match) visibleCount++;
      });

      if (emptySearch) {
        emptySearch.style.display = (q && visibleCount === 0) ? 'block' : 'none';
      }
    }

    searchInput.addEventListener('input', filterUsers);
  }

  /* Message button guard */
  document.querySelectorAll('.js-msg-btn').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (btn.dataset.friends !== '1') {
        e.preventDefault();
        showUserToast('Trebuie să fiți prieteni pentru a începe o conversație.');
      }
    });
  });

  document.querySelectorAll('.js-add-friend').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var uid   = btn.dataset.uid;
      var nonce = btn.dataset.nonce;
      btn.disabled = true;

      var fd = new FormData();
      fd.append('action', 'mangayummy_add_friend');
      fd.append('nonce', nonce);
      fd.append('user_id', uid);

      fetch(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, { method: 'POST', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data.success) {
            btn.classList.remove('js-add-friend');
            btn.classList.add('sent');
            btn.title = 'Cerere trimisă';
          } else {
            btn.disabled = false;
          }
        })
        .catch(function () { btn.disabled = false; });
    });
  });
});
</script>
<?php get_footer();

