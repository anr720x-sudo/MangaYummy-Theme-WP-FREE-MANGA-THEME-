<?php
/**
 * Fix Profile Images after PNG to WebP Conversion
 * 
 * This script updates profile avatar and banner URLs from .png to .webp
 * Run once via: wp eval-file fix-profile-images-webp.php
 * or access via: site.com/wp-admin/admin.php?page=mangayummy-fix-images
 */

if (!defined('ABSPATH')) {
    require_once('../../../wp-load.php');
}

// Only allow admins
if (!current_user_can('manage_options')) {
    wp_die('Access denied: Admins only');
}

$upload_dir = wp_upload_dir();
$basedir = $upload_dir['basedir'];
$baseurl = $upload_dir['baseurl'];

$fixed_count = 0;
$errors = [];

// Get all users
$users = get_users(['fields' => 'ID']);

echo '<h2>Fixing Profile Images (PNG → WebP)</h2>';
echo '<p>Processing ' . count($users) . ' users...</p>';
echo '<pre style="background: #f0f0f0; padding: 10px; margin: 10px 0; max-height: 400px; overflow-y: auto;">';

foreach ($users as $user_id) {
    // Check profile_avatar
    $avatar_url = get_user_meta($user_id, 'profile_avatar', true);
    if ($avatar_url && preg_match('/\.png$/i', $avatar_url)) {
        // Check if WebP version exists
        $avatar_webp_url = preg_replace('/\.png$/i', '.webp', $avatar_url);
        $avatar_webp_path = str_replace($baseurl, $basedir, $avatar_webp_url);
        
        if (file_exists($avatar_webp_path)) {
            update_user_meta($user_id, 'profile_avatar', $avatar_webp_url);
            echo "[Avatar] User {$user_id}: {$avatar_url} → {$avatar_webp_url}\n";
            $fixed_count++;
        } else {
            $errors[] = "WebP not found for avatar: {$avatar_webp_path}";
            echo "[Avatar ERROR] User {$user_id}: WebP not found: {$avatar_webp_path}\n";
        }
    }
    
    // Check profile_banner
    $banner_url = get_user_meta($user_id, 'profile_banner', true);
    if ($banner_url && preg_match('/\.png$/i', $banner_url)) {
        // Check if WebP version exists
        $banner_webp_url = preg_replace('/\.png$/i', '.webp', $banner_url);
        $banner_webp_path = str_replace($baseurl, $basedir, $banner_webp_url);
        
        if (file_exists($banner_webp_path)) {
            update_user_meta($user_id, 'profile_banner', $banner_webp_url);
            echo "[Banner] User {$user_id}: {$banner_url} → {$banner_webp_url}\n";
            $fixed_count++;
        } else {
            $errors[] = "WebP not found for banner: {$banner_webp_path}";
            echo "[Banner ERROR] User {$user_id}: WebP not found: {$banner_webp_path}\n";
        }
    }
}

echo '</pre>';
echo "<p style='color: green; font-weight: bold;'>✓ Fixed {$fixed_count} image URLs</p>";

if (!empty($errors)) {
    echo '<p style="color: red; font-weight: bold;">⚠ Errors:</p>';
    echo '<pre style="background: #ffe0e0; padding: 10px; color: red;">';
    foreach ($errors as $error) {
        echo $error . "\n";
    }
    echo '</pre>';
}

echo '<p><a href="' . admin_url() . '">← Back to Dashboard</a></p>';
?>
