<?php
/**
 * Template auto pentru Recente Actualizări
 * WordPress o folosește AUTOMAT pentru slug "recente-actualizari"
 * NU necesită setare manuală în WP
 */

require get_template_directory() . '/page-manga.php';
