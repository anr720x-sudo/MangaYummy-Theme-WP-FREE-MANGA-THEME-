<?php get_header(); ?>

<main class="main-content">
    <section class="banner">
        <!-- Banner rotator - placeholder -->
        <div class="banner-slider">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner1.jpg" alt="Banner">
        </div>
    </section>

    <section class="categories">
        <h2>Categories</h2>
        <div class="category-grid">
            <a href="#" class="category-card">Shonen</a>
            <a href="#" class="category-card">Seinen</a>
            <a href="#" class="category-card">Shojo</a>
            <a href="#" class="category-card">Webtoon</a>
        </div>
    </section>

    <section class="featured-manga">
        <h2>Featured Manga</h2>
        <div class="manga-grid">
            <?php
            $featured_query = new WP_Query(array(
                'post_type' => 'manga',
                'posts_per_page' => 6,
                'meta_key' => '_featured',
                'meta_value' => '1',
            ));
            if ($featured_query->have_posts()) :
                while ($featured_query->have_posts()) : $featured_query->the_post();
            ?>
                <div class="manga-card">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php the_post_thumbnail_url('full'); ?>" alt="<?php the_title(); ?>">
                    <?php endif; ?>
                    <div class="manga-card-content">
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p><?php the_excerpt(); ?></p>
                        <a href="<?php the_permalink(); ?>" class="read-btn">Read</a>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </section>

    <section class="popular-manga">
        <h2>Popular Manga</h2>
        <div class="manga-grid">
            <!-- Similar loop for popular -->
        </div>
    </section>

    <section class="recent-chapters">
        <h2>Recent Chapters</h2>
        <div class="chapter-list">
            <?php
            $recent_chapters = new WP_Query(array(
                'post_type' => 'chapter',
                'posts_per_page' => 10,
            ));
            if ($recent_chapters->have_posts()) :
                while ($recent_chapters->have_posts()) : $recent_chapters->the_post();
            ?>
                <div class="chapter-item">
                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <span><?php echo esc_html(mangayummy_get_date_ro(get_the_ID(), 'j F Y H:i')); ?></span>
                </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>