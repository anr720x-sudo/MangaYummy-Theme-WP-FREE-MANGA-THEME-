<?php
/**
 * Auto template for Mangauri 2026
 * WordPress will use this when the page slug is "mangauri-2026".
 *
 * This simply reuses the generic manga listing logic in page-manga.php
 * but allows us to target the new URL and title separately.
 */

require get_template_directory() . '/page-manga.php';
