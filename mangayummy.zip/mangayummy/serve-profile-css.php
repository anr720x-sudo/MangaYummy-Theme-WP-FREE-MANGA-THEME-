<?php
// Serve profile.css with no-cache headers
header('Content-Type: text/css');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Get the CSS file path
$css_file = dirname(__FILE__) . '/css/profile.css';

// Check if file exists
if (file_exists($css_file)) {
    readfile($css_file);
} else {
    // Fallback if file doesn't exist
    echo '/* CSS file not found */';
}
?>