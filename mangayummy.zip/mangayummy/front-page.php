<?php
/**
 * Template Name: Front Page
 */

get_header();

// Check for invisible user message
if (isset($_GET['invisible_user']) && $_GET['invisible_user'] == '1') {
    echo '<div style="background: #13667a; color: #fff; padding: 10px; text-align: center; margin: 10px 0; border-radius: 5px;">Acest utilizator este blocat.</div>';
}

// Site notice: new site warning
// styling moved to stylesheet

$show_popular_updates = (bool) get_theme_mod('mangayummy_show_popular_updates', 1);
$show_latest_releases = (bool) get_theme_mod('mangayummy_show_latest_releases', 1);
$show_recently_added = (bool) get_theme_mod('mangayummy_show_recently_added', 1);
$show_frontpage_news = (bool) get_theme_mod('mangayummy_show_frontpage_news', 1);
$show_latest_comments = (bool) get_theme_mod('mangayummy_show_latest_comments', 1);

?>



<?php if ($show_popular_updates): ?>
<section class="ya-section cele-mai-recente">
  <div class="section-header">
    <h2>Popular Updates</h2>
    <div class="section-dropdown">
      <button type="button" class="section-dropdown-btn" id="popular-recent-time-btn">
        <span class="dropdown-label"></span>
        <i class="fa fa-ellipsis-v"></i>
      </button>
      <div class="section-dropdown-menu" id="popular-recent-time-menu">
        <div class="dropdown-item active" data-period="1day">1 day</div>
        <div class="dropdown-item" data-period="7days">7 days</div>
        <div class="dropdown-item" data-period="1month">1 month</div>
        <div class="dropdown-item" data-period="3months">3 months</div>
        <div class="dropdown-item" data-period="6months">6 months</div>
        <div class="dropdown-item" data-period="1year">1 year</div>
      </div>
    </div>
  </div>

  <div class="latest-manga-grid" id="popular-recent-grid">
    <?php
    // POPULAR RECENT: default is 1 day (24 hours) views.
    // Reuse centralized cached helper to avoid recomputing buckets on every page load.
    $unique_manga_ids = function_exists('mangayummy_get_popular_recent_ids')
      ? mangayummy_get_popular_recent_ids('1day', 100)
      : [];

    // Pre-fetch latest chapters for the list (avoids 1 WP_Query per manga on cache miss)
    $latest_chapters_map = mangayummy_prefetch_latest_chapters($unique_manga_ids);

    // Pre-fetch ratings for the list (avoids get_post_meta queries per manga)
    $ratings_map = mangayummy_prefetch_ratings($unique_manga_ids);

    // Pre-fetch common meta so we don't call get_post_meta() per card.
    $post_meta_map = mangayummy_prefetch_post_meta_bulk($unique_manga_ids, ['_manga_type', '_status', '_manga_18']);

    $manga_count = 0;
    // on mobile devices show one fewer cover so layout stays even (3×5 rows)
    $max_manga = wp_is_mobile() ? 15 : 16; /* show only top‑16 popular manga (15 mobile) */
    // disable new‑chapter badge in this section
    $show_badge = false;
    // note: badge logic removed from this section entirely


    if (!empty($unique_manga_ids)) {
      foreach ($unique_manga_ids as $manga_id) {
        $manga_id = intval($manga_id);
        
        if ($manga_count >= $max_manga) {
          break;
        }

        // apply reader preferences filter again (restores original behavior)
        // guests and incognito users will no longer see identical results.
        if (!mangayummy_manga_matches_prefs($manga_id)) {
            continue;
        }

        // Get manga post
        $manga = get_post($manga_id);
        if (!$manga || $manga->post_status !== 'publish' || $manga->post_type !== 'manga') {
          continue;
        }

        // Double check: exclude if this post has _manga_id (it's a chapter being shown as manga)
        if (get_post_meta($manga_id, '_manga_id', true)) {
          continue;
        }

        $manga_count++;
        
        // Setup postdata for manga
        setup_postdata($manga);
        $rating_data = $ratings_map[$manga_id] ?? ['average' => 0, 'count' => 0];
        if (floatval($rating_data['average']) <= 0) {
            $rating_data['average'] = floatval(get_post_meta($manga_id, '_rating_avg', true));
            $rating_data['count'] = max(intval($rating_data['count'] ?? 0), intval(get_post_meta($manga_id, '_rating_count', true)));
        }
        
        // Use pre-fetched chapter results (prefetched via mangayummy_prefetch_latest_chapters())
        $chapter_posts = $latest_chapters_map[$manga_id] ?? [];
        ?>
        <div class="latest-manga-item line-b">
          <div class="manga-poster-wrap">
            <a href="<?php echo esc_url(get_permalink($manga_id)); ?>">
                <?php 
                $poster_attrs = ['loading' => 'lazy', 'decoding' => 'async'];
                echo get_the_post_thumbnail($manga_id, 'manga-card', $poster_attrs); 
                ?>
                <!-- grouped label wrapper begins -->
                <?php if ( ! $show_badge ): // Populare Recent items get custom text layout ?>
                  <div class="item-text">
                    <div class="item-text-inner">
                      <a class="item-title" href="<?php echo esc_url(get_permalink($manga_id)); ?>"><?php echo esc_html($manga->post_title); ?></a>
                      <?php if (!empty($chapter_posts)) {
                          $latest = $chapter_posts[0];
                          $latest_num = mangayummy_get_chapter_number($latest->ID);
                          if ($latest_num !== '' && $latest_num !== null) {
                              echo '<a class="item-volch" href="' . esc_url(get_permalink($latest->ID)) . '">Ch.' . esc_html($latest_num) . '</a>';
                          }
                      } ?>
                    </div>
                  </div>
                <?php else: ?>
                  <!-- for latest updates we no longer overlay title on cover; it will appear in the info panel -->
                  <div class="cover-labels">
                  <?php
                  // last chapter badge on popular-recent covers (shouldn’t run when $show_badge true but keep for fallback)
                  if (!empty($chapter_posts)) {
                      $latest = $chapter_posts[0];
                      $latest_num = mangayummy_get_chapter_number($latest->ID);
                      if ($latest_num !== '' && $latest_num !== null) {
                          echo '<div class="last-chapter-overlay">Cap. ' . esc_html($latest_num) . '</div>';
                      }
                  }
                  ?>
                    <!-- title moved out to info block -->
                  </div><!-- .cover-labels -->
                <?php endif; ?>
                <!-- end cover-labels -->
            </a>
          </div>
          <?php if ($show_badge): ?>
          <h3 class="manga-title">
            <a href="<?php echo esc_url(get_permalink($manga_id)); ?>">
              <?php echo esc_html($manga->post_title); ?>
            </a>
          </h3>
          <?php endif; ?>
          <?php if ($show_badge): ?>
          <div class="chapters">
            <?php if (!empty($chapter_posts)): ?>
              <?php foreach ($chapter_posts as $chapter_post): ?>
                <?php
                $chapter_number = mangayummy_get_chapter_number($chapter_post->ID);
                $chapter_title = $chapter_post->post_title;
                $chapter_permalink = get_permalink($chapter_post->ID);
                $post_time = strtotime($chapter_post->post_date);
                $is_new = (current_time('timestamp') - $post_time) <= DAY_IN_SECONDS;
                ?>

                <div class="chapter-link">
                  <a href="<?php echo esc_url($chapter_permalink); ?>">
                    <div class="chapter-row">
                      <?php if ($is_new): ?>
                        <span class="new-badge">NEW</span>
                      <?php endif; ?>
                      <span class="chapter-title" title="<?php echo esc_attr(($chapter_number !== '' && $chapter_number !== null ? 'Cap. ' . $chapter_number . (($chapter_title !== '') ? ' – ' . $chapter_title : '') : $chapter_title)); ?>">
                        <?php
                        if ($chapter_number !== '' && $chapter_number !== null) {
                            echo 'Cap. ' . esc_html($chapter_number) . ($chapter_title !== '' ? ' – ' . esc_html($chapter_title) : '');
                        } else {
                            echo esc_html($chapter_title);
                        }
                        ?>
                      </span>

                    </div>
                  </a>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <?php endif; ?>
        </div>
        <?php
      } // end foreach
    } // end if
    wp_reset_postdata();
    ?>
  </div>
</section>
<?php endif; ?>

<?php if ($show_frontpage_news): ?>
<?php
$news_query = new WP_Query([
    'post_type'      => 'stire',
    'posts_per_page' => 12,
    'post_status'    => 'publish',
    'orderby'        => 'date',
    'order'          => 'DESC',
    'no_found_rows'  => true,
]);
$news_items = [];
if ($news_query->have_posts()) {
    while ($news_query->have_posts()) {
        $news_query->the_post();
        $post_id = get_the_ID();
        $thumb = get_the_post_thumbnail_url($post_id, 'large');
        if (!$thumb) {
            $thumb = get_post_meta($post_id, '_stire_cover_url', true);
        }
        if (!$thumb) {
            $thumb = get_template_directory_uri() . '/assets/img/default-manga.jpg';
        }
        $terms = get_the_terms($post_id, 'stiri_category');
        $term_slug = 'all';
        $term_name = 'Știre';
        if ($terms && !is_wp_error($terms)) {
            $term_slugs = array_map('sanitize_title', wp_list_pluck($terms, 'slug'));
            $term_slugs = array_unique($term_slugs);
            $term_slug = implode(',', $term_slugs);
            $term_name = $terms[0]->name;
        }
        $excerpt = get_the_excerpt();
        if (!$excerpt) {
            $excerpt = wp_trim_words(get_the_content(), 20, '...');
        }
        $author_id = intval(get_post_field('post_author', $post_id));
        if (!$author_id) {
            $author_id = intval(get_post_meta($post_id, '_stire_author_id', true));
        }
        $author_name = $author_id ? get_the_author_meta('display_name', $author_id) : get_the_author();
        $author_avatar_url = $author_id ? get_user_meta($author_id, 'profile_avatar', true) : '';
        if (!$author_avatar_url) {
            $author_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
        }
        $url = function_exists('mangayummy_get_stire_number')
            ? home_url('/stire/' . mangayummy_get_stire_number($post_id) . '/')
            : get_permalink($post_id);
        $news_items[] = [
            'id' => $post_id,
            'thumb' => $thumb,
            'term_slug' => $term_slug,
            'term_name' => $term_name,
            'title' => get_the_title(),
            'excerpt' => $excerpt,
            'url' => $url,
            'date' => get_the_date('j F Y'),
            'author_name' => $author_name,
            'author_avatar' => $author_avatar_url,
        ];
    }
    wp_reset_postdata();
}
$news_featured = $news_items;
$news_list = array_slice($news_items, 2, 3);
?>
<?php endif; ?>

<?php if ($show_latest_releases): ?>
<section class="ya-section latest-updates">
  <div class="section-header">
    <h2>Latest Releases</h2>
  </div>

  <div class="latest-manga-grid" id="latest-new-grid">
    <?php
    // New logic: show manga cards of mangas having the most recent chapters
    $unique_manga_ids = [];
    // enable badge here (Latest releases)
    $show_badge = true;

    // Cache the list of 36 latest-updates manga IDs for a short time to reduce DB load
    $latest_updates_cache_key = 'mangayummy_latest_updates_ids';
    $unique_manga_ids = get_transient($latest_updates_cache_key);

    if ($unique_manga_ids === false || !is_array($unique_manga_ids)) {
        // Ensure we start with an array to avoid PHP 8.3 deprecation warnings
        $unique_manga_ids = [];

        // Efficiently fetch 36 unique manga IDs based on the most recent chapter date
        // without loading all chapters into PHP.
        global $wpdb;
        $sql = "
            SELECT CAST(pm.meta_value AS UNSIGNED) AS manga_id
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_manga_id'
            WHERE p.post_type = 'chapter'
              AND p.post_status = 'publish'
            GROUP BY manga_id
            ORDER BY MAX(p.post_date) DESC
            LIMIT 36
        ";

        $rows = $wpdb->get_results($sql);
        foreach ($rows as $row) {
            $unique_manga_ids[] = intval($row->manga_id);
        }

        // Cache list of IDs briefly
        set_transient($latest_updates_cache_key, $unique_manga_ids, 60);
    }

    // Batch prefetch latest chapters (avoids one WP_Query per manga on cache misses)
    $latest_chapters_map = mangayummy_prefetch_latest_chapters($unique_manga_ids);

    // Prefetch ratings for these manga (avoids get_manga_rating() per card)
    $ratings_map = mangayummy_prefetch_ratings($unique_manga_ids);

    // Prefetch genres for these manga (avoids get_the_terms() per card)
    $genres_map = mangayummy_prefetch_manga_genres($unique_manga_ids);

    // Pre-fetch common meta so we don't call get_post_meta() per card.
    $post_meta_map = mangayummy_prefetch_post_meta_bulk($unique_manga_ids, ['_manga_type', '_status', '_manga_18', '_translator_user']);

    $manga_count = 0;
    foreach ($unique_manga_ids as $manga_id) {
        if ($manga_count >= 36) break;
        $manga_id = intval($manga_id);
        if (!mangayummy_manga_matches_prefs($manga_id)) {
            continue;
        }
        $manga = get_post($manga_id);
        if (!$manga || $manga->post_status !== 'publish' || $manga->post_type !== 'manga') {
            continue;
        }
        if (get_post_meta($manga_id, '_manga_id', true)) {
            continue;
        }
        $manga_count++;

        setup_postdata($manga);
        $rating_data = $ratings_map[$manga_id] ?? ['average' => 0, 'count' => 0];
        if (floatval($rating_data['average']) <= 0) {
            $rating_data['average'] = floatval(get_post_meta($manga_id, '_rating_avg', true));
            $rating_data['count'] = max(intval($rating_data['count'] ?? 0), intval(get_post_meta($manga_id, '_rating_count', true)));
        }

        $post_meta = $post_meta_map[$manga_id] ?? [];
        $translator_avatar_url = '';
        $translator_name = '';
        $translator_meta = $post_meta['_translator_user'] ?? '';
        if (!empty($translator_meta)) {
            $translator_meta = sanitize_text_field($translator_meta);
            if (is_numeric($translator_meta)) {
                $translator_user = get_user_by('ID', intval($translator_meta));
            } else {
                $translator_user = get_user_by('login', $translator_meta);
            }
            if ($translator_user) {
                $translator_name = sanitize_text_field($translator_user->display_name ?: $translator_user->user_login);
                $translator_avatar_url = get_user_meta($translator_user->ID, 'profile_avatar', true);
                if (empty($translator_avatar_url)) {
                    $translator_avatar_url = get_avatar_url($translator_user->ID, ['size' => 80]);
                }
            } else {
                // Fallback for translator text values when user object is not available
                $translator_name = $translator_meta;
                $translator_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
            }
        }

        // Fetch preloaded chapters for this manga
        $chapter_posts = $latest_chapters_map[$manga_id] ?? [];
        // if we're in latest releases section (badge enabled) sort by chapter number (newest first), fallback to date
        if (!empty($show_badge) && is_array($chapter_posts)) {
            usort($chapter_posts, function($a, $b) {
                $a_num = floatval(mangayummy_get_chapter_number($a->ID));
                $b_num = floatval(mangayummy_get_chapter_number($b->ID));
                if ($a_num !== $b_num) {
                    return ($b_num <=> $a_num);
                }
                return strtotime($b->post_date) - strtotime($a->post_date);
            });
            // trim to two in case ordering changed
            $chapter_posts = array_slice($chapter_posts, 0, 2);
        }

        if (empty($translator_avatar_url) && !empty($chapter_posts)) {
            $first_chapter = $chapter_posts[0];
            $translation_group = get_post_meta($first_chapter->ID, '_translation_group', true);
            if (!empty($translation_group)) {
                $translator_name = sanitize_text_field($translation_group);
                $translator_avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
            }
        }
        ?>
        <div class="latest-manga-item">
          <div class="manga-poster-wrap">
            <a href="<?php echo esc_url(get_permalink($manga_id)); ?>">
                <?php 
                $poster_attrs = ['loading' => 'lazy', 'decoding' => 'async'];
                echo get_the_post_thumbnail($manga_id, 'manga-card', $poster_attrs); 
                ?>
                <div class="poster-rating-overlay">
                  <div class="overlay-left">
                    <?php
                    $post_meta = $post_meta_map[$manga_id] ?? [];
                    $manga_type = $post_meta['_manga_type'] ?? '';
                    $manga_status = $post_meta['_status'] ?? '';
                    $manga_18 = $post_meta['_manga_18'] ?? '';

                    $type_labels = ['manga' => 'Manga', 'manhua' => 'Manhua', 'manhwa' => 'Manhwa'];
                    $type_display = $manga_type ? ($type_labels[$manga_type] ?? '') : '';
                    $type_class = $manga_type ? 'type-' . sanitize_html_class($manga_type) : '';
                    $status_labels = ['ongoing' => 'Ongoing', 'completed' => 'Completed', 'hiatus' => 'On hiatus', 'dropped' => 'Dropped'];
                    $status_display = $manga_status ? ($status_labels[$manga_status] ?? '') : '';
                    ?>
                    <?php if ($type_display): ?>
                      <span class="manga-type <?php echo esc_attr($type_class); ?>"><?php echo esc_html($type_display); ?></span>
                    <?php endif; ?>
                    <?php if ($status_display): ?>
                      <span class="manga-status status-<?php echo esc_attr($manga_status); ?>"><?php echo esc_html($status_display); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <?php if ($manga_18): ?>
                  <div class="manga-18-overlay">18+</div>
                <?php endif; ?>
            </a>
          </div>
          <div class="latest-manga-info">
            <h3 class="manga-title">
              <a href="<?php echo esc_url(get_permalink($manga_id)); ?>">
                <?php echo esc_html($manga->post_title); ?>
              </a>
            </h3>
            <div class="manga-genres">
            <?php
            $terms = $genres_map[$manga_id] ?? [];
            if (!empty($terms)) {
                $names = wp_list_pluck($terms, 'name');
                // limit to first eight genres
                $names = array_slice($names, 0, 8);
                // red genres list copied from single-manga.php
                $red_genres = array('sângeros', 'violența sexuală', 'viol', 'matur', 'nuditate', 'tragedie', 'sinucidere', 'masturbare', 'sex în grup', 'adult', 'ecchi', 'hentai', 'canibalism', 'prostituţie', 'tragedie', 'smut', 'yandere', 'sclavie', 'anal', 'droguri');
                $search_url = home_url('/browse/');
                $links = array();
                foreach ($names as $name) {
                    $classes = array();
                    if (in_array(strtolower($name), $red_genres)) {
                        $classes[] = 'genre-red';
                    }
                    $class_attr = $classes ? ' class="' . esc_attr(implode(' ', $classes)) . '"' : '';
                    $links[] = '<span' . $class_attr . '>' . esc_html($name) . '</span>';
                }
                echo implode(', ', $links);
            }
            ?>
          </div>
          <div class="chapters">
            <?php if (!empty($chapter_posts)): ?>
              <?php $chapter_index = 0; ?>
              <?php foreach ($chapter_posts as $chapter_post): ?>
                <?php
                $chapter_number = mangayummy_get_chapter_number($chapter_post->ID);
                $chapter_title = $chapter_post->post_title;
                $chapter_permalink = get_permalink($chapter_post->ID);
                $post_time = strtotime($chapter_post->post_date);
                $is_new = (current_time('timestamp') - $post_time) <= DAY_IN_SECONDS;
                ?>
                <div class="chapter-link">
                  <a href="<?php echo esc_url($chapter_permalink); ?>">
                    <div class="chapter-row">
                      <?php if ($is_new): ?>
                        <span class="new-badge">NEW</span>
                      <?php endif; ?>
                      <span class="chapter-title" title="<?php echo esc_attr(($chapter_number !== '' && $chapter_number !== null ? 'Cap. ' . $chapter_number . (($chapter_title !== '') ? ' - ' . $chapter_title : '') : $chapter_title)); ?>">
                        <?php
                        if ($chapter_number !== '' && $chapter_number !== null) {
                            if ($chapter_title !== '') {
                                echo 'Cap. ' . esc_html($chapter_number) . ' - ' . esc_html($chapter_title);
                            } else {
                                echo 'Cap. ' . esc_html($chapter_number);
                            }
                        } else {
                            echo esc_html($chapter_title);
                        }
                        ?>
                      </span>
                      <?php // show time ago for the first two chapter links
                      if ($chapter_index < 2): ?>
                        <span class="chapter-age">
                          <?php if ($translator_avatar_url): ?>
                            <span class="chapter-translator-icon" title="<?php echo esc_attr($translator_name ?: 'Traducător'); ?>">
                              <img src="<?php echo esc_url($translator_avatar_url); ?>" alt="<?php echo esc_attr($translator_name ?: 'Traducător'); ?>">
                            </span>
                          <?php endif; ?>
                          <?php echo esc_html(mangayummy_time_ago($post_time)); ?>
                        </span>
                      <?php endif; ?>
                    </div>
                    <?php $chapter_index++; ?>
                  </a>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          </div> <!-- .latest-manga-info -->
        </div>
    <?php }
    ?>
  </div>
</section>
<?php endif; ?>

<!-- RECOMANDATE - Slider MangaYummy Style -->
<section class="recommended-section">
  <div class="section-header">
    <h2>Recomandate</h2>
    <div class="section-nav">
      <button class="section-nav-btn swiper-prev-recommended" disabled><i class="fa fa-chevron-left"></i></button>
      <button class="section-nav-btn swiper-next-recommended"><i class="fa fa-chevron-right"></i></button>
    </div>
  </div>

  <div class="swiper recommended-swiper">
    <div class="swiper-wrapper">
      <?php
      // OPTIMIZED: cache recommended manga IDs briefly to reduce repeated meta queries.
      $recommended_cache_key = 'mangayummy_front_recommended_ids';
      $recommended_ids = get_transient($recommended_cache_key);

      if ($recommended_ids === false || !is_array($recommended_ids)) {
        $recommended_ids_query = new WP_Query([
          'post_type'      => 'manga',
          'posts_per_page' => 12,
          'meta_query'     => [
            [
              'key'     => '_recommended',
              'value'   => '1',
              'compare' => '='
            ]
          ],
          'orderby'        => 'date',
          'order'          => 'DESC',
          'no_found_rows'  => true,
          'fields'         => 'ids',
          'update_post_term_cache' => false
        ]);
        $recommended_ids = array_map('intval', $recommended_ids_query->posts);
        set_transient($recommended_cache_key, $recommended_ids, 2 * MINUTE_IN_SECONDS);
      }

      $query = new WP_Query([
        'post_type'      => 'manga',
        'posts_per_page' => 12,
        'post__in'       => !empty($recommended_ids) ? $recommended_ids : [0],
        'orderby'        => 'post__in',
        'no_found_rows'  => true,
        'update_post_term_cache' => false
      ]);

      while ($query->have_posts()) : $query->the_post(); ?>
        <div class="swiper-slide manga-card">
          <a href="<?php the_permalink(); ?>" class="manga-link">
            <?php if (has_post_thumbnail()) : ?>
              <?php 
              $thumb_attrs = [
                'class' => 'manga-cover',
                'loading' => 'lazy',
                'decoding' => 'async',
                'draggable' => 'false',
                'alt' => get_the_title()
              ];
              the_post_thumbnail('manga-card', $thumb_attrs); 
              ?>
            <?php else : ?>
              <img src="<?php echo get_template_directory_uri(); ?>/assets/img/default-avatar.png"
                   class="manga-cover manga-no-cover"
                   alt="No cover"
                   draggable="false">
            <?php endif; ?>
            <span class="manga-title"><?php the_title(); ?></span>
          </a>
        </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <!-- Săgeți -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
  </div>
</section>

<section class="popular-manga">
  <div class="section-header">
    <h2 class="section-title">Cele mai populare manga-<span class="lowercase">uri</span></h2>
    <div class="section-nav">
      <button class="section-nav-btn swiper-prev-popular" disabled><i class="fa fa-chevron-left"></i></button>
      <button class="section-nav-btn swiper-next-popular"><i class="fa fa-chevron-right"></i></button>
    </div>
  </div>

  <?php
  // OPTIMIZED: Added caching and query optimizations for popular manga
  // Sort strictly by total views instead of monthly; "cele mai populare"
  // now means top50 cele mai vizionate manga-uri.
  $popular_manga_cache_key = 'mangayummy_popular_manga_carousel';
  $cached_popular = get_transient($popular_manga_cache_key);

  if ($cached_popular === false) {
    $args = [
      'post_type'      => 'manga',
      'posts_per_page' => 50,
      'meta_key'       => 'manga_views_total',
      'orderby'        => 'meta_value_num',
      'order'          => 'DESC',
      'no_found_rows'  => true,
      'update_post_term_cache' => false,
    ];
    $query = new WP_Query($args);

    // Cache post IDs for 5 minutes
    $post_ids = wp_list_pluck($query->posts, 'ID');
    set_transient($popular_manga_cache_key, $post_ids, 5 * MINUTE_IN_SECONDS);
  } else {
    // Load from cache
    $args = [
      'post_type' => 'manga',
      'post__in' => $cached_popular,
      'orderby' => 'post__in',
      'posts_per_page' => 50,
      'no_found_rows' => true,
      'update_post_term_cache' => false,
    ];
    $query = new WP_Query($args);
  }

  if($query->have_posts()):
  $rank = 0; // Initialize rank counter
  ?>
  <div class="swiper popular-swiper">
    <div class="swiper-wrapper">
      <?php while($query->have_posts()): $query->the_post();
        $rank++;
        // OPTIMIZED: Skip chapter count query - not displayed anyway
        // OPTIMIZED: Use manga-card size instead of full, lazy load after first 3
      ?>
        <div class="swiper-slide manga-card">
          <a href="<?php the_permalink(); ?>" class="manga-link">
            <div class="manga-poster-wrap">
              <?php 
              $img_attrs = ['class' => 'manga-cover'];
              // load lazily after first three to reduce initial payload
              if ($rank > 3) {
                  $img_attrs['loading'] = 'lazy';
                  $img_attrs['decoding'] = 'async';
              } else {
                  $img_attrs['fetchpriority'] = 'high';
              }
              the_post_thumbnail('manga-card', $img_attrs); 
              ?>
            </div>
            <div class="num-container">
              <div class="num"><?php echo $rank; ?></div>
            </div>
            <span class="manga-title"><?php the_title(); ?></span>
          </a>
        </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
  </div>
  <?php endif; ?>
</section>


<?php if ($show_recently_added): ?>
<!-- RECENTLY ADDED - Slider MangaYummy Style -->
<section class="recently-added-section">
  <div class="section-header">
    <h2>Recently Added</h2>
    <div class="section-nav">
      <button class="section-nav-btn swiper-prev-recently" disabled><i class="fa fa-chevron-left"></i></button>
      <button class="section-nav-btn swiper-next-recently"><i class="fa fa-chevron-right"></i></button>
    </div>
  </div>

  <div class="swiper recently-added-swiper">
    <div class="swiper-wrapper">
      <?php
      // OPTIMIZED: cache recently added IDs briefly to reduce repeated full queries.
      $recently_added_cache_key = 'mangayummy_front_recently_added_ids';
      $recently_added_ids = get_transient($recently_added_cache_key);

      if ($recently_added_ids === false || !is_array($recently_added_ids)) {
        $recently_added_ids_query = new WP_Query([
          'post_type'      => 'manga',
          'posts_per_page' => 50,
          'orderby'        => 'date',
          'order'          => 'DESC',
          'no_found_rows'  => true,
          'fields'         => 'ids',
          'update_post_term_cache' => false
        ]);
        $recently_added_ids = array_map('intval', $recently_added_ids_query->posts);
        set_transient($recently_added_cache_key, $recently_added_ids, 2 * MINUTE_IN_SECONDS);
      }

      $query = new WP_Query([
        'post_type'      => 'manga',
        'post__in'       => !empty($recently_added_ids) ? $recently_added_ids : [0],
        'orderby'        => 'post__in',
        'posts_per_page' => 50,
        'no_found_rows'  => true,
        'update_post_term_cache' => false
      ]);

      while ($query->have_posts()) : $query->the_post(); ?>
        <div class="swiper-slide manga-card">
          <a href="<?php the_permalink(); ?>" class="manga-link">
            <?php if (has_post_thumbnail()) : ?>
              <?php 
              $thumb_attrs = [
                'class' => 'manga-cover',
                'loading' => 'lazy',
                'decoding' => 'async',
                'draggable' => 'false',
                'alt' => get_the_title()
              ];
              the_post_thumbnail('manga-card', $thumb_attrs); 
              ?>
            <?php else : ?>
              <img src="<?php echo get_template_directory_uri(); ?>/assets/img/default-avatar.png"
                   class="manga-cover manga-no-cover"
                   alt="No cover"
                   draggable="false">
            <?php endif; ?>
            <span class="manga-title"><?php the_title(); ?></span>
          </a>
        </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <!-- Săgeți -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
  </div>
</section>
<?php endif; ?>

<?php if ($show_frontpage_news): ?>
<section class="ya-section frontpage-news-section">
  <div class="section-header section-header--news">
    <h2><a href="<?php echo esc_url(home_url('/news')); ?>">News</a></h2>
  </div>

  <div class="news-front-grid">
    <div class="news-featured-grid">
      <?php if (!empty($news_featured)): ?>
        <?php foreach ($news_featured as $news): ?>
          <a href="<?php echo esc_url($news['url']); ?>" class="news-featured-card" data-news-cat="<?php echo esc_attr($news['term_slug']); ?>">
            <div class="news-featured-image">
              <img src="<?php echo esc_url($news['thumb']); ?>" alt="<?php echo esc_attr($news['title']); ?>">
            </div>
            <div class="news-featured-body">
              <span class="news-chip"><?php echo esc_html(strtoupper($news['term_name'])); ?></span>
              <h3 class="news-featured-title"><?php echo esc_html($news['title']); ?></h3>
              <p class="news-featured-excerpt"><?php echo esc_html(wp_trim_words($news['excerpt'], 22, '...')); ?></p>
              <div class="news-featured-meta">
                <span class="news-featured-author">
                  <img class="news-featured-author-avatar" src="<?php echo esc_url($news['author_avatar']); ?>" alt="<?php echo esc_attr($news['author_name']); ?>">
                  <?php echo esc_html($news['author_name']); ?>
                </span>
                <span class="news-featured-date"><?php echo esc_html($news['date']); ?></span>
              </div>
            </div>
          </a>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="news-empty">No news available.</div>
      <?php endif; ?>
    </div>

    <div class="news-list-block">
      <div class="news-tabs">
        <button type="button" class="news-tab-button active" data-cat="all">ALL</button>
        <button type="button" class="news-tab-button" data-cat="site">SITE</button>
        <button type="button" class="news-tab-button" data-cat="anime">ANIME</button>
        <button type="button" class="news-tab-button" data-cat="manga">MANGA</button>
      </div>
      <?php if (!empty($news_list)): ?>
        <div class="news-list">
          <?php foreach ($news_list as $news): ?>
            <a href="<?php echo esc_url($news['url']); ?>" class="news-list-item" data-news-cat="<?php echo esc_attr($news['term_slug']); ?>">
              <div>
                <span class="news-chip"><?php echo esc_html(strtoupper($news['term_name'])); ?></span>
                <h4 class="news-list-title"><?php echo esc_html($news['title']); ?></h4>
                <span class="news-list-author">
                  <img class="news-list-author-avatar" src="<?php echo esc_url($news['author_avatar']); ?>" alt="<?php echo esc_attr($news['author_name']); ?>">
                  <?php echo esc_html($news['author_name']); ?>
                </span>
              </div>
              <span class="news-list-date"><?php echo esc_html($news['date']); ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <div class="news-list-empty" style="display:none; color:#aaa; padding: 16px 0;">No news in this category.</div>
    </div>
  </div>

  <style>
    .frontpage-news-section {
      margin: 40px auto;
    }
    .frontpage-news-section .section-header--news {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      flex-wrap: wrap;
    }
    .frontpage-news-section .news-tabs {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    .frontpage-news-section .news-tab-button {
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.12);
      color: #fff;
      padding: 10px 16px;
      border-radius: 999px;
      cursor: pointer;
      transition: all 0.2s ease;
      font-weight: 600;
      font-size: 0.92rem;
    }
    .frontpage-news-section .news-tab-button.active,
    .frontpage-news-section .news-tab-button:hover {
      background: #13667a;
      border-color: #13667a;
      color: #fff;
    }
    .frontpage-news-section .section-header--news h2 a {
      color: inherit;
      text-decoration: none;
      display: inline-block;
    }
    .frontpage-news-section .section-header--news h2 a:hover {
      color: #13667a;
    }
    .news-front-grid {
      display: grid;
      grid-template-columns: minmax(0, 1.0fr) minmax(240px, 1fr);
      gap: 14px;
      margin-top: 18px;
    }
    .news-featured-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px;
    }
    .news-featured-card {
      display: flex;
      flex-direction: column;
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 18px;
      overflow: hidden;
      text-decoration: none;
      color: #fff;
      min-height: 280px;
    }
    .news-featured-card:nth-child(n+3) {
      display: none;
    }
    .news-featured-image img {
      width: 100%;
      height: 160px;
      object-fit: cover;
      display: block;
    }
    .news-featured-body {
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      flex: 1;
    }
    .news-chip {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 6px 12px;
      border-radius: 999px;
      background: #13667a;
      color: #fff;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    .news-featured-title {
      font-size: 1.2rem;
      line-height: 1.3;
      margin: 0;
      font-weight: 800;
    }
    .news-featured-excerpt {
      margin: 0;
      color: #ddd;
      line-height: 1.7;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      max-height: calc(1.7em * 3);
      min-height: calc(1.7em * 3);
      word-break: break-word;
    }
    .news-featured-meta {
      display: flex;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
      color: #bbb;
      font-size: 0.95rem;
    }
    .news-featured-author {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: #ddd;
      font-weight: 600;
    }
    .news-featured-author-avatar,
    .news-list-author-avatar {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      object-fit: cover;
      display: inline-block;
    }
    .news-featured-date {
      color: #bbb;
      font-size: 0.95rem;
    }
    .news-list-author {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: #ccc;
      font-size: 0.88rem;
      margin-top: 6px;
    }
    .news-list-block {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .news-list {
      display: grid;
      gap: 14px;
    }
    .news-list-item {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 14px;
      padding: 18px 18px;
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 16px;
      text-decoration: none;
      color: #fff;
    }
    .news-list-item:hover {
      background: rgba(255,255,255,0.08);
    }
    .news-list-title {
      font-size: 1rem;
      margin: 8px 0 0;
      font-weight: 700;
      line-height: 1.4;
    }
    .news-list-date {
      color: #bbb;
      font-size: 0.9rem;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .news-more-link {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 18px;
      border-radius: 999px;
      border: 1px solid rgba(255,255,255,0.12);
      color: #fff;
      text-decoration: none;
      background: rgba(255,255,255,0.04);
      transition: background 0.2s ease, border-color 0.2s ease;
    }
    .news-more-link:hover {
      background: rgba(255,255,255,0.08);
      border-color: #13667a;
    }
    @media (max-width: 1024px) {
      .news-front-grid {
        grid-template-columns: 1fr;
      }
      .news-featured-grid {
        grid-template-columns: 1fr;
      }
    }
    @media (max-width: 768px) {
      .frontpage-news-section .news-tabs {
        width: 100%;
        justify-content: flex-start;
      }
      .news-list-item {
        flex-direction: column;
        align-items: stretch;
      }
      .news-list-date {
        white-space: normal;
      }
    }
  </style>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const buttons = document.querySelectorAll('.frontpage-news-section .news-tab-button');
      const items = document.querySelectorAll('.frontpage-news-section [data-news-cat]');
      const featuredGrid = document.querySelector('.frontpage-news-section .news-featured-grid');
      const newsListEmpty = document.querySelector('.frontpage-news-section .news-list-empty');

      const updateFeaturedVisibility = () => {
        if (!featuredGrid) return;
        const visibleCards = Array.from(featuredGrid.querySelectorAll('.news-featured-card')).filter(card => card.style.display !== 'none');
        visibleCards.slice(2).forEach(card => {
          card.style.display = 'none';
        });
      };

      const updateListEmpty = () => {
        if (!newsListEmpty) return;
        const visibleList = Array.from(document.querySelectorAll('.frontpage-news-section .news-list-item')).filter(item => item.style.display !== 'none');
        const visibleFeatured = featuredGrid ? Array.from(featuredGrid.querySelectorAll('.news-featured-card')).filter(card => card.style.display !== 'none') : [];
        newsListEmpty.style.display = (visibleList.length === 0 && visibleFeatured.length === 0) ? 'block' : 'none';
      };

      buttons.forEach(function(button) {
        button.addEventListener('click', function() {
          buttons.forEach(function(btn) { btn.classList.remove('active'); });
          button.classList.add('active');
          const category = button.dataset.cat;
          items.forEach(function(item) {
            const categories = (item.dataset.newsCat || '').toLowerCase().split(',').map(function(value) {
              return value.trim();
            }).filter(function(value) {
              return value !== '';
            });
            const show = category === 'all' || categories.includes(category);
            if (show) {
              item.style.display = item.classList.contains('news-featured-card') ? 'flex' : '';
            } else {
              item.style.display = 'none';
            }
          });
          updateFeaturedVisibility();
          updateListEmpty();
        });
      });

      updateFeaturedVisibility();
      updateListEmpty();
    });
  </script>
</section>
<?php endif; ?>

<?php if ($show_latest_comments): ?>
<!-- RECENT COMMENTS -->
<section id="recent-comments-section" class="recent-comments-section">
  <div class="section-header">
    <h2>Latest Comments</h2>
  </div>

  <div class="recent-comments-grid">
    <?php
    // Detect device type for responsive comment count
    function mangayummy_detect_device_type() {
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // Check for tablet
        if (preg_match('/(tablet|ipad|playbook|silk)|(android(?!.*mobile))/i', $user_agent)) {
            return 'tablet';
        }
        
        // Check for mobile
        if (wp_is_mobile() || preg_match('/(mobile|android|iphone|ipod|blackberry|opera mini|opera mobi|skyfire|maemo|windows phone|palm|iemobile|symbian|meego)/i', $user_agent)) {
            return 'phone';
        }
        
        return 'desktop';
    }
    
    $device_type = mangayummy_detect_device_type();
    
    // Set comment count based on device (reduced for smoother scrolling)
    $comment_counts = [
        'desktop' => 6,
        'tablet' => 6,
        'phone' => 6
    ];
    
    $comment_number = $comment_counts[$device_type] ?? 12;
    
    // OPTIMIZED: Cache recent comments for 2 minutes with device-specific key
    $comments_cache_key = 'mangayummy_recent_comments_frontpage_' . $device_type;
    $recent_comments = get_transient($comments_cache_key);
    
    if ($recent_comments === false) {
      $recent_comments = get_comments([
        'number' => $comment_number,
        'status' => 'approve',
        'post_type' => ['manga', 'chapter'],
        'orderby' => 'comment_date_gmt',
        'order' => 'DESC',
      ]);
      // Cache for 2 minutes
      set_transient($comments_cache_key, $recent_comments, 2 * MINUTE_IN_SECONDS);
    }

    if (!empty($recent_comments)) :
      foreach ($recent_comments as $comment) :
        $post_id = $comment->comment_post_ID;
        $post = get_post($post_id);
        $post_type = $post->post_type;
        
        // Get manga info
        if ($post_type === 'chapter') {
          $manga_id = get_post_meta($post_id, '_manga_id', true);
          $manga = get_post($manga_id);
          $manga_title = $manga ? $manga->post_title : 'Unknown';
          $chapter_num = mangayummy_get_chapter_number($post_id);
          $context_label = 'Cap. ' . $chapter_num;
          $link = get_permalink($post_id);
          $cover_id = $manga_id;
        } else {
          $manga_title = $post->post_title;
          $context_label = 'Pagină manga';
          $link = get_permalink($post_id);
          $cover_id = $post_id;
        }
        
        // Get user avatar and name
        $user_id = $comment->user_id;
        $user_level = 0;
        if ($user_id) {
          $avatar_url = get_user_meta($user_id, 'profile_avatar', true);
          if (empty($avatar_url)) {
            $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          }
          // Get display name from user profile
          $user_data = get_userdata($user_id);
          $comment_author_name = $user_data ? $user_data->display_name : $comment->comment_author;
          // Get user level
          $user_level = (int) get_user_meta($user_id, 'reader_level', true);
          if ($user_level < 1) $user_level = 1;
        } else {
          $avatar_url = get_template_directory_uri() . '/assets/img/default-avatar.png';
          $comment_author_name = $comment->comment_author;
        }
        
        // Fallback if name is still empty
        if (empty($comment_author_name)) {
          $comment_author_name = 'Anonim';
        }
        
        // Truncate comment
        $comment_text = wp_strip_all_tags($comment->comment_content);
        $comment_text = mb_strlen($comment_text) > 100 ? mb_substr($comment_text, 0, 100) . '...' : $comment_text;
        
        // Time ago - use comment_date (local time) for correct comparison
        $time_ago = mangayummy_time_ago(strtotime($comment->comment_date));
    ?>
        <div class="recent-comment-card">
          <a href="<?php echo esc_url($link); ?>#comment-<?php echo $comment->comment_ID; ?>" class="comment-link">
            <div class="comment-manga-cover">
              <?php 
              $thumbnail = get_the_post_thumbnail_url($cover_id, 'thumbnail');
              if ($thumbnail) : ?>
                <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr($manga_title); ?>" loading="lazy" decoding="async" width="60" height="80">
              <?php else : ?>
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/default-avatar.png" alt="No cover" loading="lazy" decoding="async" width="60" height="80">
              <?php endif; ?>
            </div>
            <div class="comment-content">
              <div class="comment-header">
                <img src="<?php echo esc_url($avatar_url); ?>" alt="Avatar" class="comment-avatar" loading="lazy" decoding="async" width="24" height="24">
                <span class="comment-author"><?php echo esc_html($comment_author_name); ?></span>
                <?php if ($user_level > 0 && $user_id > 0) : 
                  // Get user's preferred level effect class
                  $level_tier_class = mangayummy_get_user_level_tier_class($user_id);
                  $level_class = 'comment-level' . ($level_tier_class ? ' ' . $level_tier_class : '');
                ?>
                <span class="<?php echo esc_attr($level_class); ?>">Lv.<?php echo $user_level; ?></span>
                <?php endif; ?>
                <span class="comment-time"><?php echo esc_html($time_ago); ?></span>
              </div>
              <div class="comment-manga-info">
                <span class="manga-name"><?php echo esc_html($manga_title); ?></span>
                <span class="chapter-badge"><?php echo esc_html($context_label); ?></span>
              </div>
              <p class="comment-text"><?php echo esc_html($comment_text); ?></p>
            </div>
          </a>
        </div>
    <?php
      endforeach;
    else :
    ?>
      <p class="no-comments">No recent comments.</p>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php get_footer(); ?>



