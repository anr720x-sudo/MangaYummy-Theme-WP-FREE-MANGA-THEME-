<?php
/*
Template Name: Reader Profile
*/
get_header();

// Get username from URL
$username = get_query_var('reader_username');
$user = get_user_by('login', $username);

if (!$user) {
    echo '<div class="main-content"><h1>User not found</h1><p>The requested profile does not exist.</p></div>';
    get_footer();
    exit;
}

$user_id = $user->ID;
$user_data = mangayummy_get_user_xp_level($user_id);
$current_xp = $user_data['xp'];
$current_level = $user_data['level'];
$current_level_xp = mangayummy_get_xp_for_next_level($current_level - 1);
$next_level_xp = mangayummy_get_xp_for_next_level($current_level);
$xp_progress = $next_level_xp - $current_level_xp;
$current_xp_in_level = $current_xp - $current_level_xp;
$progress_percentage = $xp_progress > 0 ? min(100, ($current_xp_in_level / $xp_progress) * 100) : 100;
?>

<main class="main-content">
    <div class="reader-profile">
        <!-- Profile Banner -->
        <?php
        $banner_url = get_user_meta($user_id, 'profile_banner', true);
        $has_custom_banner = !empty($banner_url);
        $banner_class = $has_custom_banner ? '' : ' is-default-banner';
        ?>
        <div class="profile-banner<?php echo esc_attr($banner_class); ?>"<?php if ($has_custom_banner): ?> style="background-image: url('<?php echo esc_url($banner_url); ?>');"<?php endif; ?>>
        </div>

        <!-- Header Section -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?php echo get_avatar($user_id, 120); ?>
            </div>
            <div class="profile-info">
                <h1 class="profile-username"><?php echo esc_html($user->display_name); ?></h1>
                <?php
                $last_active = get_user_meta($user_id, 'last_active', true);
                if (!$last_active) {
                    $last_active = get_user_meta($user_id, 'last_activity', true);
                }
                $now = current_time('timestamp');
                $is_online = ($now - intval($last_active) < 300); // 5 minutes
                ?>
                <div class="profile-status">
                    <?php if ($is_online): ?>
                        <span class="status online">● Online</span>
                    <?php else: ?>
                        <span class="status offline">● Last seen <?php echo yummy_time_ago($last_active); ?></span>
                    <?php endif; ?>
                </div>
                <?php 
                $level_tier_class = mangayummy_get_user_level_tier_class($user_id);
                $profile_level_class = 'profile-level' . ($level_tier_class ? ' ' . $level_tier_class : '');
                ?>
                <div class="<?php echo esc_attr($profile_level_class); ?>">
                    Level <?php echo $current_level; ?>
                </div>
            </div>
        </div>

        <!-- XP Progress Bar -->
        <div class="xp-section">
            <h2>XP Progress</h2>
            <div class="xp-bar-container">
                <div class="xp-bar">
                    <div class="xp-fill" style="width: <?php echo $progress_percentage; ?>%"></div>
                </div>
                <div class="xp-text">
                    XP: <?php echo number_format($current_xp_in_level); ?> / <?php echo number_format($xp_progress); ?>
                </div>
            </div>
            <?php if ($current_level < 99): ?>
                <p class="xp-next">You need <?php echo number_format($next_level_xp - $current_xp); ?> XP to reach LVL <?php echo $current_level + 1; ?></p>
            <?php else: ?>
                <p class="xp-max">Maximum level reached! 🎉</p>
            <?php endif; ?>
        </div>

        <!-- Stats Section -->
        <div class="stats-section">
            <h2>Reader Statistics</h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number"><?php echo number_format($current_xp); ?></div>
                    <div class="stat-label">XP Total</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $current_level; ?></div>
                    <div class="stat-label">Level</div>
                </div>
                <?php
                // Count completed mangas - cached per user (10 min)
                $cache_key = 'user_completed_mangas_' . $user_id;
                $completed_mangas = get_transient($cache_key);
                
                if ($completed_mangas === false) {
                    $completed_mangas = 0;
                    // Get only manga IDs for better performance
                    $all_manga_ids = get_posts(array(
                        'post_type' => 'manga',
                        'posts_per_page' => -1,
                        'fields' => 'ids',
                        'no_found_rows' => true,
                        'update_post_meta_cache' => false,
                        'update_post_term_cache' => false
                    ));
                    
                    foreach ($all_manga_ids as $manga_id) {
                        $total_chapters = mangayummy_get_total_chapters($manga_id);
                        if ($total_chapters > 0) {
                            $user_progress = mangayummy_get_manga_progress($user_id, $manga_id);
                            if ($user_progress >= $total_chapters) {
                                $completed_mangas++;
                            }
                        }
                    }
                    set_transient($cache_key, $completed_mangas, 10 * MINUTE_IN_SECONDS);
                }
                ?>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $completed_mangas; ?></div>
                    <div class="stat-label">Completed Manga</div>
                </div>
                <?php
                // Count total comments
                $comment_count = get_comments(array(
                    'user_id' => $user_id,
                    'count' => true
                ));
                ?>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $comment_count; ?></div>
                    <div class="stat-label">Comments</div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="activity-section">
            <h2>Recent Activity</h2>
            <?php
            $recent_comments = get_comments(array(
                'user_id' => $user_id,
                'number' => 5,
                'orderby' => 'comment_date',
                'order' => 'DESC'
            ));

            if ($recent_comments): ?>
                <div class="recent-activity">
                    <?php foreach ($recent_comments as $comment): ?>
                        <div class="activity-item">
                            <div class="activity-icon">💬</div>
                            <div class="activity-content">
                                <p>Commented on "<?php echo get_the_title($comment->comment_post_ID); ?>"</p>
                                <span class="activity-date"><?php echo mangayummy_time_ago(strtotime($comment->comment_date)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No recent activity.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
.reader-profile {
    max-width: 800px;
    margin: 0 auto;
    padding: 2rem;
}

.profile-header {
    display: flex;
    align-items: center;
    gap: 2rem;
    margin-bottom: 3rem;
    padding: 2rem;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.profile-avatar {
    border-radius: 50%;
    overflow: hidden;
    border: 4px solid #fff;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.profile-info {
    flex: 1;
}

.profile-username {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0 0 0.5rem 0;
    color: #333;
}

.profile-level {
    font-size: 1.5rem;
    font-weight: 600;
    display: inline-block;
    padding: 0.5rem 1rem;
    background: linear-gradient(135deg, #13667a 0%, #0d556a 100%);
    color: #fff;
    border-radius: 25px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.profile-level.level-uncommon {
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
}

.profile-level.level-rare {
    background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);
    animation: level-pulse 2s ease-in-out infinite;
}

.profile-level.level-epic {
    background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
    box-shadow: 0 0 15px rgba(243, 156, 18, 0.5);
    animation: level-glow 2s ease-in-out infinite;
}

.profile-level.level-mythic {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    box-shadow: 0 0 20px rgba(231, 76, 60, 0.6);
    animation: level-shimmer 2s ease-in-out infinite;
}

.profile-level.level-legendary {
    background: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #8b00ff);
    background-size: 400% 100%;
    animation: level-rainbow 3s linear infinite;
    text-shadow: 0 0 5px rgba(255, 255, 255, 0.8);
    box-shadow: 0 0 25px rgba(255, 215, 0, 0.8);
}

@keyframes level-pulse {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.05); opacity: 0.9; }
}

@keyframes level-glow {
    0%, 100% { box-shadow: 0 0 15px rgba(243, 156, 18, 0.5); }
    50% { box-shadow: 0 0 25px rgba(243, 156, 18, 0.8); }
}

@keyframes level-shimmer {
    0%, 100% { 
        box-shadow: 0 0 20px rgba(231, 76, 60, 0.6);
        filter: brightness(1);
    }
    50% { 
        box-shadow: 0 0 30px rgba(231, 76, 60, 0.9);
        filter: brightness(1.1);
    }
}

@keyframes level-rainbow {
    0% { background-position: 0% 50%; }
    100% { background-position: 400% 50%; }
}

.xp-section {
    margin-bottom: 3rem;
}

.xp-section h2 {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #333;
}

.xp-bar-container {
    margin-bottom: 1rem;
}

.xp-bar {
    width: 100%;
    height: 30px;
    background: #e9ecef;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
}

.xp-fill {
    height: 100%;
    background: linear-gradient(90deg, #ff6b35 0%, #ffb400 100%);
    border-radius: 15px;
    transition: width 1s ease-out;
    position: relative;
}

.xp-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 100%);
    border-radius: 15px;
}

.xp-text {
    text-align: center;
    margin-top: 0.5rem;
    font-weight: 600;
    color: #495057;
    font-size: 1.1rem;
}

.xp-next, .xp-max {
    text-align: center;
    color: #6c757d;
    font-style: italic;
}

.xp-max {
    color: #28a745;
    font-weight: 600;
}

.stats-section {
    margin-bottom: 3rem;
}

.stats-section h2 {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #333;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
}

.stat-item {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    border: 1px solid #e9ecef;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #ff6b35;
    margin-bottom: 0.5rem;
}

.stat-label {
    color: #6c757d;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-size: 0.9rem;
}

.activity-section h2 {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #333;
}

.recent-activity {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    border: 1px solid #e9ecef;
}

.activity-item {
    display: flex;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #f8f9fa;
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-icon {
    font-size: 1.5rem;
    margin-right: 1rem;
    width: 40px;
    text-align: center;
}

.activity-content p {
    margin: 0 0 0.25rem 0;
    color: #333;
    font-weight: 500;
}

.activity-date {
    color: #6c757d;
    font-size: 0.85rem;
}

@media (max-width: 768px) {
    .reader-profile {
        padding: 1rem;
    }

    .profile-header {
        flex-direction: column;
        text-align: center;
        gap: 1.5rem;
    }

    .profile-username {
        font-size: 2rem;
    }

    .profile-level {
        font-size: 1.2rem;
    }

    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }

    .stat-item {
        padding: 1.5rem;
    }

    .stat-number {
        font-size: 2rem;
    }
}
</style>

<?php get_footer(); ?>