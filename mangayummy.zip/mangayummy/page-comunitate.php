<?php
/**
 * Template Name: Comunitate
 */
get_header();
?>

<main class="ya-main">
    <div class="ya-container">
        <h1>Comunitate MangaYummy</h1>
        <p>Bine ai venit în comunitatea noastră! Aici poți găsi recenzii, știri, utilizatori și informații despre site.</p>
        <div class="community-links">
            <a href="<?php echo home_url('/recenzii'); ?>">Recenzii</a>
            <a href="<?php echo home_url('/news'); ?>">Știri</a>
            <a href="<?php echo home_url('/users'); ?>">Utilizatori</a>
            <a href="<?php echo home_url('/about'); ?>">Despre site</a>
        </div>
    </div>
</main>

<?php get_footer(); ?>